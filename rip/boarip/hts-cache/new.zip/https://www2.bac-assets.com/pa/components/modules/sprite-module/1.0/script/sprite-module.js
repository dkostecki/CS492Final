/* Retinal detection
*/
$.fn.detectRetinal = function() {
    var retinal = {
        "non-retinal" : 0,
        "retinal-2x" : 1,
        "retinal-4x" : 2
    };
    for( r in retinal ) {
        add = window.devicePixelRatio > retinal[r];
        this.filter(function() { return add; }).addClass(r);
        if(add) break;
    }
    return this;
}

/* Sprite injection plugin
*/
$.fn.injectSprite = function( options ) {
    var defaults = {
            location: "last"
        },
        required = {
            targetClass : "sprite",
            markerClass : "spr",
            completeClass : "sprited",
            ignoreClass: "nosprite"
        };
    options = $.extend( true, {}, defaults, options, required );

    /* If the plugin is called against the page, find any default target sprite containers. 
    */
    var $container = $(this);
    if ( $container.is('html') ) $container = $('.'+options.targetClass);

    switch( true ) {
        case $container.hasClass("mw-sprite-first"):
            options.location = "first";
        break;
    }
    
    var getSpriteClass = function(str) {
        var arr = str.split(' '),
            returnArr = [];
        for (var i = 0; i < arr.length; i++) {
            if (arr[i].match(/sprite-(\S{2,3})$/gi)) {
                returnArr.push(arr[i].toUpperCase().replace("SPRITE-","sprite-"));
            }
        }
        return returnArr;
    };

    $.each( $container.not('.'+options.completeClass+',.'+options.ignoreClass), function(i) {
        var $c = $(this),
            spriteClass = getSpriteClass($c.attr('class'));

        for (var i = 0; i < spriteClass.length; i++) {
            var $sprite = $('<div/>').addClass(options.markerClass);

            $sprite.addClass( options.markerClass +'-'+ spriteClass[i].replace('sprite-','') );
            $c.removeClass( spriteClass[i] ).removeClass( options.targetClass );

            switch( options.location ) {
                case "first" :
                    $sprite.prependTo($c);
                break;
                case "last" :
                    $sprite.appendTo($c);
                break;
            }
        }

        $c.addClass(options.targetClass).addClass(options.completeClass);
    });

    return this;
};

$(document).bind( "ready", function(e) {
    $('html').detectRetinal().injectSprite();
});
