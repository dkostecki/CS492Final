
// Determine which environment we are running in to make the appropriate coremetrics setup call

var testString = window.location.href;

var sitExpression  = /www\d{1}\-sit\d{2}\.bankofamerica\.com/ 
var citExpression  = /www\d{1}\-cit\d{2}\.bankofamerica\.com/ 
var prodExpression = /\.bankofamerica\.com/ 

if( testString.search( sitExpression ) != -1 ) 
{
// alert("SIT - cmSetStaging");
	cmSetStaging();
}
else if( testString.search( citExpression ) != -1 ) 
{
// alert("CIT - DO NOTHING");
}
else if( testString.search( prodExpression ) != -1 ) 
{
//	alert("PRODUCTION - cmSetProduction");
	cmSetProduction();
}
else
{
// alert("OTHER ENVIRONMENT - DO NOTHING")
}



// Function to generate cormetrics tags given passed parameters

function bofaCM( CMCategoryId, CMPageId, CMApp, CMPageView, CMConversionEvent, CMRegistration, CMProductView, CMError )
{
	if( (document.module4CInitialization === undefined) || (document.module4CInitialization == false) )
	{
		// Preset isCMError
		var isCMError = false; 

		// Handle cmCreateErrorTag

		if( CMError != null )
		{
			var firstIndexOf = CMError.indexOf("|");
			var lastIndexOf = CMError.lastIndexOf("|");

			isCMError = true; 
			var err_attr = CMError.substring( lastIndexOf+1 );

			cmCreateErrorTag(CMPageId,CMCategoryId,err_attr);
		}


		// Handle cmCreatePageviewTag  

		if( (CMCategoryId != null) && (CMPageId != null) && (isCMError == false) )
		{
			if(CMPageView != null)
			{
				var firstIndexOf = CMPageView.indexOf("|");
				var lastIndexOf  = CMPageView.lastIndexOf("|");

				var subcmpgnCode = CMPageView.substring( 0, firstIndexOf );              
				var help = CMPageView.substring( firstIndexOf+1, lastIndexOf ).toLowerCase();
				var pageviewAttr = CMPageView.substring( lastIndexOf+1 );

				if (help == "false")
				{
					help = false;
				}
				else
				{
					help = true;           
				}
			}
			else
			{
				var subcmpgnCode = null;
				var help = false;
				var pageviewAttr = null; 
			}                       

			if( CMApp != null )
			{
				var firstIndexOf = CMApp.indexOf("|");
				var lastIndexOf  = CMApp.lastIndexOf("|");

				var appName = CMApp.substring( 0, firstIndexOf );
				var appStepNumber = CMApp.substring( firstIndexOf+1, lastIndexOf );
				var appStepName = CMApp.substring( lastIndexOf+1 );
			}                       

			cmCreatePageviewTag(CMPageId,null,null,CMCategoryId,help,false,null,false,false,null,null,null,null,null,appName,appStepNumber,appStepName,pageviewAttr,subcmpgnCode);
		}


		// Handle cmCreateConversionEvent tag

		if( CMConversionEvent != null )
		{
			var firstIndexOf = CMConversionEvent.indexOf( "|" );
			var nextIndexOf  = CMConversionEvent.indexOf( "|", firstIndexOf+1 );
			var lastIndexOf  = CMConversionEvent.lastIndexOf( "|" );
			var points=null; 

			var eventID          = CMConversionEvent.substring( 0, firstIndexOf );
			var actionType       = CMConversionEvent.substring( firstIndexOf+1, nextIndexOf );
			var points           = CMConversionEvent.substring( nextIndexOf+1, lastIndexOf );
			var conversionAttr   = CMConversionEvent.substring( lastIndexOf+1 );

			cmCreateConversionEventTag(eventID,actionType,CMCategoryId,points,null,null,null,null,conversionAttr);
		}

		// Handle cmCreateRegistrationTag      

		if( CMRegistration != null )
		{
			var isCMRegistration = CMRegistration;

			// Get cust_id value from cookie BOA_0020. If it doesn't exist, get a random number 
			var cust_id = getCookie("BOA_0020");
			if (cust_id == null)
			{
				cust_id = Math.floor((9999999999-999999999)*Math.random()) + 1000000000;
			}       

			// Get olb_customer value by checking BOA_0021
			var olb_customer = false;
			if(getCookie("BA_0021") != null) 
			{
				olb_customer = true;
			}

			// Get state cookie value
			var state = getCookie("state");

			// Get advisor cookie value
			var advisorInfo = getCookie("BOA_ADVISOR"); 

			cmCreateRegistrationTag(CMPageId,null,cust_id,olb_customer,state,advisorInfo,CMCategoryId,null,null,null,null,null,false);
		}

		// Handle cmCreateProductviewTag

		if( CMProductView != null )
		{
			var firstIndexOf = CMProductView.indexOf("|");
			var lastIndexOf = CMProductView.lastIndexOf("|");

			var productName = CMProductView.substring( 0, firstIndexOf );
			var productID = CMProductView.substring( firstIndexOf+1, lastIndexOf );
			var productCategoryID = CMProductView.substring( lastIndexOf+1 );

			var productIDArray = new Array();
			var productNameArray = new Array();         
			var productCategoryIDArray = new Array();

			while(true)
			{
				var commaIndex = productName.indexOf( ',' );
				if( commaIndex == -1 ) break;

				productNameArray[productNameArray.length] = productName.substring( 0, commaIndex );
				productName = productName.substring( commaIndex+1 );
			}
			productNameArray[productNameArray.length] = productName;

			while( true )
			{
				var commaIndex = productID.indexOf( ',' );
				if( commaIndex == -1 ) break;

				productIDArray[productIDArray.length] = productID.substring( 0, commaIndex );
				productID = productID.substring( commaIndex+1 );
			}
			productIDArray[productIDArray.length] = productID;

			while( true )
			{
				var commaIndex = productCategoryID.indexOf( ',' );
				if( commaIndex == -1 ) break;

				productCategoryIDArray[productCategoryIDArray.length] = productCategoryID.substring( 0, commaIndex );
				productCategoryID = productCategoryID.substring( commaIndex+1 );
			}
			productCategoryIDArray[productCategoryIDArray.length] = productCategoryID;

			for( var i = 0; i < productNameArray.length; i++ )
			{
				cmCreateProductviewTag(productIDArray[i],productNameArray[i],productCategoryIDArray[i],null,false,false,null,false,null,null,false,null);
			}
		}
    }
    else
    {
		// Do nothing to avoid calling the function twice on page load
    }
}
