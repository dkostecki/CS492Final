(function ($) {
    $(function () {
		function equalHeight(group) {
			 var tallest = 0;
			 group.each(function() {
				 var thisHeight = $(this).height();
				 if(thisHeight > tallest) {
				 tallest = thisHeight;
				 }
			 });
			 group.height(tallest);
		}
		$(function () {
		 equalHeight($(".equal-height-dialog"));
		});
		$(function () {
		 equalHeight($(".equal-height-upsell"));
		});
		$(function () {
		 equalHeight($(".equal-height-ot-column"));
		});	
		$(function () {
		 equalHeight($(".platinum-align"));
		});	
		$(function () {
		 equalHeight($(".pp-column-content"));
		});	
		$(function () {
		 equalHeight($(".pp-column h2"));
		});
        $(function () {
		 equalHeight($("div.card-detail ul"));
		}); 
		$(function () {
		equalHeight($(".olb-dsp-savings-overview-module .header-content a strong"));
		});
		$(function () {
		equalHeight($(".olb-dsp-cds-overview-module .package-row .header-col"));
		});
		
		
	});
})(jQuery);
;