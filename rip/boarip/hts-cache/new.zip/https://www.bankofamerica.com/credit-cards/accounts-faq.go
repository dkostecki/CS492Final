
 

				<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
				<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
				<head>


<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta http-equiv="content-type" content="text/html;charset=utf-8">

        <link REL="canonical" HREF="https://www.bankofamerica.com/credit-cards/accounts-faq.go"/>                  





	<title>Credit Card Account Information FAQ from Bank of America</title>
			 <meta name="Keywords" CONTENT="credit card information, credit card faq, credit card account information" />
			 <meta name="Description" CONTENT="Review the Bank of America<sup>&reg;</sup> credit card FAQ and find answers to your most frequently asked questions about credit card account information." />


<link rel="shortcut icon" href="/pa/global-assets/1.0/graphic/favicon.ico" type="image/ico" />




			<script src="/pa/components/bundles/gzip-compressed/xengine/Global/1.0/script/tealeafbundle.js" type="text/javascript"></script>


		<link href="/pa/components/bundles/gzip-compressed/xengine/APS-credit-cards/2017.03.0/style/aps-cards-jawr.css" rel="stylesheet" type="text/css" media="all"/>
		<link href="/pa/components/bundles/gzip-compressed/xengine/APS-credit-cards/2017.03.0/style/aps-cards-jawr-print.css" rel="stylesheet" type="text/css" media="print"/>
		<script src="/pa/components/bundles/gzip-compressed/xengine/APS-credit-cards/2017.03.0/script/aps-cards-jawr.js" type="text/javascript"></script>
<script type="text/javascript">
(function() {
	if (typeof mboxUpdate == "function") {
		var windowURL = window.location.href
	    windowURL = windowURL.slice( windowURL.indexOf('.')+1);
		windowURL = windowURL.split( '?' )[0];
		windowURL = windowURL.toLowerCase();
		//alert(windowURL);
		if (
		    //If no mboxes on page, mbox count will be < 1
		    (mboxFactoryDefault.getMboxes().length() < 1) &&  
			
			//Also check for high-volume pages that do not need global logging
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go") &&
			(windowURL != "bankofamerica.com/myaccounts/signin/signin.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/entry/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signonscreen.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatechallengeanswer.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatePassword.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/mobile/banking.go")&&
			(windowURL != "bankofamerica.com/content/preload/olb-myaccount-preload-jawr-module.htm")
			)
		{

			var mboxDiv = document.createElement("div");
			mboxDiv.id = "adobe_touch_clarity_replacement";
			mboxDiv.style.display = "none";
			if (document.body && document.body.firstChild) document.body.insertBefore(mboxDiv,document.body.firstChild);
			mboxDefine(mboxDiv.id,'bac_global_bottom');
			mboxUpdate('bac_global_bottom');
		}
	}	
})();
</script>

			<script>
				var boaPageDataJS = {};
					boaPageDataJS.isLLE = "false";
			</script>
				<style>body{display:none;}</style>
	</head>		

	<body class="fsd-layout-body">	

				<script type="text/javascript">if(self == top){var theBody=document.getElementsByTagName("body")[0];theBody.style.display="block";}else{top.location=self.location;}</script>
				<noscript><style>body{display:block;}</style></noscript>
					<a class='ada-hidden ada-visible-focus' href='#skip-to-h1' id='ada-skip-link'>Skip to main content</a>
		<div class="fsd-layout fsd-2c-700lt-layout">
			<div class="fsd-border">
				<div class="center-content">
					<div class="header">
		  



<script language="javascript" src="/pa/components/modules/tag-manager-module/1.1/script/tag-manager-module-borneo-global-skin.js"></script>
<script>

(function() {
  var fireCallback = function( cb ) {
    if ( typeof cb === "function" ) cb();
  };
  
  function ddoPopulateBase( callback ) {
    try {
		  var DDO = window.digitalData,
		  	bactm_mergeDDO = function( newDDO, priorDDO ) {
		  		if( typeof priorDDO === "undefined" ) {
				  	priorDDO = digitalData || {};
				  }

			    for (var l in newDDO) {
			        if (typeof priorDDO[l] === "undefined") {
			            priorDDO[l] = newDDO[l];
			        }
			        if (newDDO[l] !== null) {
			            if (typeof newDDO[l] === "object") {
			                bactm_mergeDDO(newDDO[l], priorDDO[l]);
			            } else {
			                priorDDO[l] = bactm_validateValue( newDDO[l] ) ? newDDO[l] : priorDDO[l];
			            }
			        }
			    }

			    return priorDDO;
				},
				bactm_olb3rdPartyId = "null";

			if (typeof DDO === "undefined") {
				var simpleDDO = { page: { pageInfo:[{ pageID: null }], attributes: {}, category: { primaryCategory: null }}};

				DDO = (typeof digitalData === "object") ? digitalData : simpleDDO; 
			}

				DDO = bactm_mergeDDO( {pageInstanceID:"notprod",load_coremetrics:false,load_opinionlabs:false,load_touchcommerce:true,load_audiencemanager:true,page:{pageInfo:[{pageID:null,destinationURL:null,referringURL:null,issueDate:null,language:null,segmentValue:null,appName:null,appStepNumber:null,appStepName:null,attr:"-_--_--_--_--_--_--_--_--_--_--_--_--_--_-"}],category:{primaryCategory:null,addlCategory:null,pageType:null},attributes:{searchString:null,searchResults:null,olbSessionID:null,subCampaignCode:null,DARTUrl:null,stateCookie:null,SASIEnabled:false,needOLBcookie:false,standardDART:[],standardDARTes:[],clickDART:[],clickDARTes:[],gaId:[],chat:{account_type:null,boa_associate:null,boa_retiree:null,customer_lob:null,customer_segment:null,data:null,email_campaign:null,entitlement_code:null,error_category:null,error_count:null,first_login:null,inqSalesProductTypes:{},invitation_background:null,invitation_template:null,referral_campaign:null,getStateValue:false,cust_fn:null,cust_ln:null,target:null}}},user:{segment:null,online_id:null,preferred_rewards_tier:null,olb3rdpartyid:null},version:"BAC_0.12"}, DDO );

			DDO.page.pageInfo[0].pageID = "";
			DDO.page.category.primaryCategory  = "";
			DDO.page.pageInfo[0].language = "en-US";
			DDO.page.attributes.olbSessionID = "null";
			DDO.page.attributes.SASIEnabled =  "false";
			if (typeof DDO.user != "undefined" && typeof DDO.user.olb3rdpartyid != "undefined") {
				DDO.user.olb3rdpartyid = bactm_olb3rdPartyId;
			}

			window.utag_data = {};
			window.bactm_envSelector = bactm_setTMLib();
			window.digitalData = DDO;

      return fireCallback( callback );

    } catch(e) { }
  }
	if( window.boa && window.boa.digitalData ) {
    window.boa.digitalData.register( ddoPopulateBase );
	}
	else {
	  // Handle scenario where the header isn't available (and thus the default digitalData object and utag loader are missing).
	  //
		var writeScript = function(a,b,c,d){
			a='//tags.tiqcdn.com/utag/bofa/main/' + bactm_envSelector + '/utag.js';
			b=document;
			c='script';
			d=b.createElement(c);
			d.src=a;
			d.type='text/java'+c;
			d.async=true;
			a=b.getElementsByTagName(c)[0];
			a.parentNode.insertBefore(d,a);
		};

		ddoPopulateBase( writeScript );
	}
})();			
</script>



	
	
		
			<noscript>
				<div class="fauxdal-overlay"></div>
				<div class="fauxdal-module">
					<div class="js-disabled-skin">
						<div class="fauxdal-top"></div>
						<div class="fauxdal-bottom">
							<div class="fsd-fauxdal-content">
									<div class="fsd-fauxdal-title">
										Please Use JavaScript
									</div>
										<p>You need a web browser that supports JavaScript to use our site. Without it, some pages won&rsquo;t work as designed. To make sure JavaScript is turned on, please adjust your browser settings.</p>
<p><a name="Browser_Help_And_Tips" href="/onlinebanking/online-banking-security-faqs.go" target="_blank">Browser Help and Tips</a></p>
							</div>        
							<div class="fsd-fauxdal-close"> 
								<a class="btn-bofa btn-bofa-small" name="close_button_js_disabled_modal" href=?js=y>Close</a>
							</div>
							<div class="clearboth"></div>
						</div>
					</div>
				</div>
			</noscript>



 



<div class="header-module">
	<div class="text-w-logo-skin">
		<div class="header-left">
	  
			<div itemscope itemtype="http://schema.org/Corporation" class="bofa-logo">
				<a itemprop="url" name="anc-credit-cards" title="Bank of America" href="/">
					<img itemprop="logo" height="28" width="221" 
					     alt="Bank of America" src="/content/images/ContextualSiteGraphics/Logos/en_US/boa_logo.gif"/>
				</a>
			</div>
				<div class="product" data-font="cnx-regular">Credit Cards</div>
			
			<div class="clearboth"></div>

		</div>
		
		<div class="header-right">
			<ul class="header-links">
			
				
					
				
							<li class="sign-in">
		<a					href="/sitemap/hub/signin.go" target="_self"
		name="Sign_In">Sign In</a> 
							</li>
					
				
							<li>		<a					href="/" target="_self"
		name="Home_Header">Home</a> 
</li>
					
				
							<li>		<a					href="https://locators.bankofamerica.com" target="_self"
		name="Locations">Locations</a> 
</li>
					
				
							<li>		<a					href="/contactus/contactus.go?topicId=credit_card" target="_self"
		name="Contact_Us">Contact Us</a> 
</li>
					
				
							<li class="last-link">	
		<a					href="/credit-cards/accounts-faq.go" target="_self"
		name="Help">Help</a> 
							</li>
			</ul>
			
			<div class="clearboth"></div>

			<!-- include search-dotcom-util -->



<div class="header-search nlh">
  
  <div class="nav-search">
    <form class="search-form" action="https://secure.bankofamerica.com/myaccounts/public/search-results/unAuthenticatedSearch.go" data-js="/pa/components/utilities/search-util/1.0/script/nav-search.min.js" data-css="/pa/components/utilities/search-util/1.0/style/nav-search.css" data-text-unavailable="Search Currently Unavailable">
      <div class="search-input-container cf" data-icon="search">
        <label for="nav-search-query" class="ada-hidden">Search Term</label>
        <input type="text" placeholder="How can we help you?" name="query" class="search-query" id="nav-search-query" 
          maxlength="99" rel="Search" autocomplete="off"><input type="submit" alt="Search" title="Search" value="Submit Search" name="Search Module - Top Result – Search Button" class="submit track-me">
      </div>
    </form>
  </div>

</div>

		</div>

 		<div class="clearboth"></div>
 	</div>
</div><script language="javascript" src="/pa/global-assets/external/coremetrics/hp/eluminate.js"></script>
<script language="javascript" src="/pa/global-assets/external/coremetrics/hp/cmdatatagutils.js"></script>

<script type="text/javascript">

var passedPageID ="cards:Content:FAQ;accounts-faq";
var passedCatID ="cards:Content:FAQ";

function cmSetDD(){var testString=window.location.href;if(testString.toLowerCase().indexOf(".bankofamerica.com")>-1){testString=testString.toLowerCase();var tempArr=testString.split(".bankofamerica.com");var tempStr=tempArr[0];if(tempStr.indexOf("//")>-1){tempArr=tempStr.split("//");tempStr=tempArr[1];if(tempStr.indexOf(".")>-1){tempArr=tempStr.split(".");tempStr=tempArr[0];var tempStrPt2=tempArr[1]}if(tempStr.indexOf("www")>-1){if(tempStr.indexOf("-")>-1){cmSetStaging()}else{if(tempStrPt2!=null){if(tempStrPt2.indexOf("ecnp")>-1){cmSetStaging()}}else{cmSetProduction()}}}else{if(tempStr.indexOf("-")>-1){if(tempStr.indexOf("sitekey")>-1){if(tempStr=="sitekey"){cmSetProduction()}else{cmSetStaging()}}else{cmSetStaging()}}else{if(tempStrPt2!=null){if(tempStrPt2.indexOf("ecnp")>-1){cmSetStaging()}}else{cmSetProduction()}}}}}}if(typeof cmSetStaging=="function"){cmSetDD()};

	cmCreatePageviewTag('cards:Content:FAQ;accounts-faq', null, null, 'cards:Content:FAQ', false, false, false, false, false, null, null, null, null, null, null, null, null, null, null, null, null);
</script>


	<div class="top-nav-aps-cc-module">
		<div class="fsd-skin sup-ie">
			<ul class="nav-list">
					
					
					<li>
					
							<a href="/credit-cards/overview.go" title="Credit Card Home" class="top-menu-item"
							name="credit_cards_home_accounts_faq_topnav" id="credit_cards_home_accounts_faq_topnav">Credit Card Home<span class="ada-hidden"> link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
														<span>Popular Cards and Offers</span>
															<a href="/credit-cards/products/cash-back-credit-card/"  name="bankamericard_cash_rewards_accounts_faq_topnav" id="bankamericard_cash_rewards_accounts_faq_topnav">BankAmericard Cash Rewards&trade; </a>
															<a href="/credit-cards/products/bankamericard-travel-rewards-credit-card/"  name="bankamericard_travel_rewards_accounts_faq_topnav" id="bankamericard_travel_rewards_accounts_faq_topnav">BankAmericard Travel Rewards<sup>&reg;</sup> </a>
															<a href="/credit-cards/products/bankamericard-credit-card/"  name="bankamericard_visa_accounts_faq_topnav" id="bankamericard_visa_accounts_faq_topnav">BankAmericard<sup>&reg;</sup> </a>
									</div>
								
									<div class="hasSub">
														<span>Related Links</span>
															<a href="/credit-cards/compare-credit-cards.go"  name="compare_credit_card_accounts_faq_topnav" id="compare_credit_card_accounts_faq_topnav">Compare Credit Cards </a>
															<a href="https://mynewcard2.bankofamerica.com/USCCapp/Ctl/entry?pid=padm_prefill&tk=21&to=16&cc=DM"  name="respond_to_mail_offer_accounts_faq_topnav" id="respond_to_mail_offer_accounts_faq_topnav">Respond to Mail Offer </a>
															<a href="https://secure.bankofamerica.com/login/eclo/entry/findCustomizedOffer.go?subchannel=ECVAT2"  name="anc_check_for_customized_offers_accounts_faq_topnav" id="anc_check_for_customized_offers_accounts_faq_topnav">Check for customized offers </a>

									</div>
												<div class="hasSub">
													<a href="/credit-cards/application-status/app-status-form.go"  class="img-btn" name="save_and_submit_app_new_overview_transform_topnav_accounts_faq_topnav" id="save_and_submit_app_new_overview_transform_topnav_accounts_faq_topnav"><img data-src="/content/images/ContextualSiteGraphics/Instructional/en_US/creditcards/save-submit-cc-nav.png" alt="save-and-submit" /></a>
												</div>
									<span class="ada-hidden">End of submenu</span>
								</div>
								
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
					
					
					<li>
					
							<a href="/credit-cards/view-all-credit-cards.go" title="View All Credit Cards" class="top-menu-item"
							name="view_all_cards_accounts_faq_topnav" id="view_all_cards_accounts_faq_topnav">View All Credit Cards<span class="ada-hidden"> link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
														<span>All Credit Cards</span>
															<a href="/credit-cards/cash-back-credit-cards.go"  name="cash_rewards_credit_cards_accounts_faq_topnav" id="cash_rewards_credit_cards_accounts_faq_topnav">Cash Rewards Credit Cards </a>
															<a href="/credit-cards/travel-credit-cards.go"  name="travel__accounts_faq_topnav" id="travel__accounts_faq_topnav">Travel & Airline Rewards Credit Cards </a>
															<a href="/credit-cards/low-interest-credit-cards.go"  name="basic_interest_rate_accounts_faq_topnav" id="basic_interest_rate_accounts_faq_topnav">Lower Interest Rate Credit Cards </a>
															<a href="/credit-cards/point-rewards-credit-cards.go"  name="points_rewards_credit_cards_accounts_faq_topnav" id="points_rewards_credit_cards_accounts_faq_topnav">Points Rewards Credit Cards </a>
															<a href="/credit-cards/credit-cards-to-build-credit.go"  name="build_or_rebuild_credit_accounts_faq_topnav" id="build_or_rebuild_credit_accounts_faq_topnav">Build or Rebuild Credit </a>
									</div>
								
									<div class="hasSub">
														<span>Related Links</span>
															<a href="/credit-cards/view-all-credit-cards.go?request_locale=es_US"  name="tarjetas_de_credito_accounts_faq_topnav" id="tarjetas_de_credito_accounts_faq_topnav"><p lang="sp">Tarjetas de Cr&eacute;dito</p><br>(Credit Cards in Spanish) </a>
															<a href="/smallbusiness/credit-cards/"  name="small_business_credit_cards_accounts_faq_topnav" id="small_business_credit_cards_accounts_faq_topnav">Small Business Credit Cards </a>
									</div>
									<span class="ada-hidden">End of submenu</span>
								</div>
								
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
					
					
					<li>
					
							<a href="https://bettermoneyhabits.bankofamerica.com/en/credit" title="Learn About Credit" class="top-menu-item selected"
							name="learn_about_credit_accounts_faq_topnav" id="learn_about_credit_accounts_faq_topnav">Learn About Credit<span class="ada-hidden"> link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="https://bettermoneyhabits.bankofamerica.com/en/credit?subTopicId=choosing-a-credit-card"  name="anc_top_nav_selecting_a_credit_card_accounts_faq_topnav" id="anc_top_nav_selecting_a_credit_card_accounts_faq_topnav">Selecting a Credit Card </a>
															<a href="https://bettermoneyhabits.bankofamerica.com/en/credit?subTopicId=managing-credit-cards"  name="anc_top_nav_managing_your_credit_card_accounts_faq_topnav" id="anc_top_nav_managing_your_credit_card_accounts_faq_topnav">Managing Your Credit Card </a>
															<a href="https://bettermoneyhabits.bankofamerica.com/en/debt"  name="anc_top_nav_paying_down_debt_accounts_faq_topnav" id="anc_top_nav_paying_down_debt_accounts_faq_topnav">Paying Down Debt </a>
															<a href="https://bettermoneyhabits.bankofamerica.com/en/credit?subTopicId=credit-score"  name="anc_top_nav_improving_your_credit_accounts_faq_topnav" id="anc_top_nav_improving_your_credit_accounts_faq_topnav">Improving Your Credit </a>
															<a href="/credit-cards/education/fico-score-learning.go"  name="anc_get_your_fico_score_accounts_faq_topnav" id="anc_get_your_fico_score_accounts_faq_topnav">Get Your FICO<sup>&reg;</sup> Score </a>
															<a href="/credit-cards/accounts-faq.go"  name="faqs_accounts_faq_topnav" id="faqs_accounts_faq_topnav">FAQs </a>
									</div>
								
									<div class="hasSub">
															<a href="/credit-cards/glossary.go"  name="glossary_accounts_faq_topnav" id="glossary_accounts_faq_topnav">Glossary </a>
														<span>Popular Content</span>
														<a href="/credit-cards/education/which-credit-card-is-right-for-you.go"  name="anc_top_nav_which_credit_card_is_right_accounts_faq_topnav" id="anc_top_nav_which_credit_card_is_right_accounts_faq_topnav"><img class="thumbnail-icon" data-src="/content/images/ContextualSiteGraphics/Instructional/en_US/financial-education/Which_Card_Right_for_You_62X48.png" alt="" />Which credit card is right for you?</a>
														<a href="/credit-cards/education/improving-your-credit-score.go"  name="anc_improving_your_credit_score_accounts_faq_topnav" id="anc_improving_your_credit_score_accounts_faq_topnav"><img class="thumbnail-icon" data-src="/content/images/ContextualSiteGraphics/Instructional/en_US/financial-education/Improving_Credit_score_62X48.png" alt="" />Improving your credit score</a>
									</div>
									<span class="ada-hidden">End of submenu</span>
								</div>
								
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
					
					
					<li>
					
							<a href="/credit-cards/manage-your-credit-card-account.go" title="Manage Your Account" class="top-menu-item"
							name="manage_your_account_accounts_faq_topnav" id="manage_your_account_accounts_faq_topnav">Manage Your Account<span class="ada-hidden"> link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
														<span>Manage your credit card account</span>
															<a href="/onlinebanking/online-banking.go"  name="online_mobile_banking_accounts_faq_topnav" id="online_mobile_banking_accounts_faq_topnav" target="_blank">Online &amp; Mobile Banking </a>
															<a href="/sitemap/hub/signin.go"  name="sign_into_your_account_accounts_faq_topnav" id="sign_into_your_account_accounts_faq_topnav" target="_blank">Sign In To Your Account </a>
															<a href="/privacy/accounts-cards/credit-debit-card-security.go"  name="protect_your_account_accounts_faq_topnav" id="protect_your_account_accounts_faq_topnav" target="_blank">Protect Your Account </a>
															<a href="/banking-information/assistance/credit-cards/credit-cards-assistance-overview.go"  name="get_payment_and_debt_management_tips_accounts_faq_topnav" id="get_payment_and_debt_management_tips_accounts_faq_topnav" target="_blank">Get Payment &amp; Debt Management Tips </a>
									</div>
								
									<div class="hasSub">
														<span>Related FAQs</span>
															<a href="/credit-cards/payments-statements-faq.go"  name="how_do_i_change_my_address_or_phone_number_accounts_faq_topnav" id="how_do_i_change_my_address_or_phone_number_accounts_faq_topnav">How can I update my contact info? </a>
															<a href="/credit-cards/accounts-faq.go"  name="can_i_manage_my_credit_card_using_my_mobile_device_accounts_faq_topnav" id="can_i_manage_my_credit_card_using_my_mobile_device_accounts_faq_topnav">Can I manage my credit card using my mobile device? </a>
															<a href="/credit-cards/benefits-faq.go?request_locale=en-US"  name="where_do_i_find_out_about_my_reward_accounts_faq_topnav" id="where_do_i_find_out_about_my_reward_accounts_faq_topnav">Where do I find out about my rewards? </a>
															<a href="/credit-cards/accounts-faq.go"  name="view_all_faqs_accounts_faq_topnav" id="view_all_faqs_accounts_faq_topnav">View All FAQs </a>
									</div>
									<span class="ada-hidden">End of submenu</span>
								</div>
								
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
			</ul>
				<div class="clearboth"></div>
		</div>
	</div>


<div class="page-title-fsd-module h-100" id="skip-to-h1">
  <div class="red-grad-bar-skin sup-ie">

	  <h1 data-font="cnx-regular">Credit Card Account Information FAQs</h1>

  </div>
</div>




			<!-- true testing -->
<div class="faq-module">
   <div class="nav-skin"><div class="faq-nav-inner">
					<h2 class="ada-hidden">Account</h2>

		<label for="faq-list" class="select-label">View questions about:</label>

		<div class="faq-menu-box" id="faq-selector-div">
				<form name="faq-module-nav-skin">
					<select name="faq-list" id="faq-list" class="select-bofa">
						<option value="javascript:void(0);" selected="selected" >
							Account
						</option>
						<option value="/credit-cards/apply-faq.go">
							Apply for accounts
						</option>
						<option value="/credit-cards/benefits-faq.go">
							Benefits
						</option>
						<option value="/credit-cards/credit-card-ways-to-contact-bac.go">
							Contact us
						</option>
						<option value="/credit-cards/fees-faq.go">
							Fees
						</option>
						<option value="/credit-cards/account-access-faq.go">
							Information & access
						</option>
						<option value="/credit-cards/merchant-checkout-fees-faq.go">
							Merchant checkout fees
						</option>
						<option value="/credit-cards/overdraft-services-faq.go">
							Overdraft services 
						</option>
						<option value="/credit-cards/payments-statements-faq.go">
							Payments & statements
						</option>
						<option value="/credit-cards/security-faq.go">
							Security
						</option>
							<option value="javascript:void(0);" disabled></option>
						<option value="/help/overview.go">
							Need more? Get all FAQs&raquo;
						</option>
					</select>
					<a class="btn-bofa btn-bofa-blue btn-bofa-small" href="javascript:void(0);" id="faq-module-nav-skin-go-button">Go<span class="ada-hidden"> and view FAQ information.</span></a>
				</form>
		</div>
		<div class="clearboth"></div>
	</div></div>
</div>
</div>
					<div class="columns">
						<div class="flex-col lt-col" >








<div class="olb-dsp-faqs-module">
	<div class="viewTools">
			<a href="javascript:void(0);" class="printLink" name="printLink">Print<span class="ada-hidden"> this page</span></a>
		<ul class="showHideFeature">
			<li><a href="javascript:void(0);" class="showAllAnswers" name="showAllAnswers" id="showAllChecking">Show all</a></li>
			<li>&nbsp;|&nbsp;</li>
			<li><a href="javascript:void(0);"  class="hideAllAnswers" name="hideAllAnswers" id="hideAllChecking">Hide all</a></li>
		</ul>
	</div>
	<div id="content-area" class="mid">
		<ul class="accordion">
			<li id="aba-routing-swift-iban-numbersInfo">
				<div class="toggle-section">
															
								
									<div class="title opened"> <a name="dsp-faq-question1" href="javascript:void(0);" class="faq-questions"><span class="ada-hidden">Show</span>Can I manage my Bank of America<sup>&reg;</sup> credit card account using my mobile device?</a> </div>
									<div class="content first-class-open" >
										
												<p>Yes. Bank on your schedule with our Mobile Banking app. Stay on top of your credit card account balances, choose cash back deals with BankAmeriDeals<sup>&reg;</sup>, pay your credit card bill with your Bank of America checking or savings accounts and more. To learn more and download our app visit: <a href="https://www.bankofamerica.com/online-banking/mobile.go" name="bofa_mobile_website">https://www.bankofamerica.com/online-banking/mobile.go</a> today.</p>
										
									</div>
						
															
								
									<div class="title"> <a name="dsp-faq-question2" href="javascript:void(0);" class="faq-questions"><span class="ada-hidden">Show</span>How do I request a credit line increase?</a> </div>
									<div class="content">
											<p>Sign in to <a href="http://www.bankofamerica.com/onlinebanking/?context=en" name="Onlinebanking55" target="_blank">Online Banking</a>, go to your credit card Account details page and choose the <strong>Information &amp; Services</strong> tab. If your account is eligible, you will be able to request a credit line increase.</p>
										
									</div>
						
															
								
									<div class="title"> <a name="dsp-faq-question3" href="javascript:void(0);" class="faq-questions"><span class="ada-hidden">Show</span>Can I access my Bank of America<sup>&reg;</sup> credit card account information online?</a> </div>
									<div class="content">
											<p>Yes, you can do all of these things online:</p>
<ul>
<li>Get a summary of your current account status, including balance, available credit and payment information</li>
<li>Request up to 12 months of detailed transaction information</li>
<li>View and print up to 18 months of credit card statements</li>
<li>Download transactions for use with financial management software</li>
<li>Make your credit card payment online</li>
<li>Manage your credit card PIN</li>
<li>Contact customer service</li>
</ul>
										
									</div>
						
															
								
									<div class="title"> <a name="dsp-faq-question4" href="javascript:void(0);" class="faq-questions"><span class="ada-hidden">Show</span>Can I get information on my credit card account through Text Banking?</a> </div>
									<div class="content">
											<p>Bank as fast as you can text. Get information about checking, savings and credit card accounts within seconds. Simply text a command to MYBofA (<strong>692632</strong>) and we'll text what you need. To enroll, log into Online Banking or call 1.800.604.9961. Learn more at: <a name="TextBanking123" href="https://www.bankofamerica.com/online-banking/sms-text-banking.go" target="_blank">https://www.bankofamerica.com/online-banking/sms-text-banking.go</a>.</p>
										
									</div>
						
															
								
									<div class="title"> <a name="dsp-faq-question5" href="javascript:void(0);" class="faq-questions"><span class="ada-hidden">Show</span>When will I receive my credit card?</a> </div>
									<div class="content">
											<p>You will receive your card within 10 business days after you're approved. You'll need to activate your credit card before you use it. To activate, call the number located on your new credit card or visit our <a name="activate_your_card_1" href="https://www.bankofamerica.com/activate" target="_blank">credit card activation page</a>.</p>
										
									</div>
						
															
								
									<div class="title"> <a name="dsp-faq-question6" href="javascript:void(0);" class="faq-questions"><span class="ada-hidden">Show</span>How do I request a new / replacement card?</a> </div>
									<div class="content">
											<p>You can request an additional card or a replacement card by signing in to Online Banking and going to the <strong>Information &amp; Services</strong> tab for your account.</p>
										
									</div>
						
															
								
									<div class="title"> <a name="dsp-faq-question7" href="javascript:void(0);" class="faq-questions"><span class="ada-hidden">Show</span>What's an annual percentage rate (APR)? </a> </div>
									<div class="content">
											<p>An APR is the interest charged on a credit card expressed as an annualized amount.</p>
										
									</div>
						
															
								
									<div class="title"> <a name="dsp-faq-question8" href="javascript:void(0);" class="faq-questions"><span class="ada-hidden">Show</span>What's an interest charge, and when does it occur? </a> </div>
									<div class="content">
											<p>An interest charge is the sum of interest on your credit card account. It is broken down by transaction type: purchases, cash advances, and balance transfers. If you pay less than the full balance, pay after the payment due date, or if your credit card does not have a grace period, then you will pay interest on those purchases. Please note, cash advances and balance transfers have no grace period, which means they start accruing interest as soon as the transaction is made. This will result in interest due, even if your balance is paid in full.</p>
										
									</div>
						
															
								
									<div class="title"> <a name="dsp-faq-question9" href="javascript:void(0);" class="faq-questions"><span class="ada-hidden">Show</span>What's a periodic rate?</a> </div>
									<div class="content">
											<p>A&nbsp;periodic rate is a rate of interest charge that may be imposed by a creditor on a balance for a day, week, month, or any subdivision of a year.</p>
										
									</div>
						
															
								
									<div class="title"> <a name="dsp-faq-question10" href="javascript:void(0);" class="faq-questions"><span class="ada-hidden">Show</span>What's a prime rate? </a> </div>
									<div class="content">
											<p>A prime rate is the rate of interest a bank offers to its most creditworthy customers. The U.S. Prime Rate, as published daily by the Wall Street Journal, is based on a survey of the prime rates of the 10 largest banks in the United States and is often used as the index for a variable interest rate on a credit card.</p>
										
									</div>
						
															
								
									<div class="title"> <a name="dsp-faq-question11" href="javascript:void(0);" class="faq-questions"><span class="ada-hidden">Show</span>Why do we ask for your country of citizenship? </a> </div>
									<div class="content">
											<p>As a federally regulated bank, we are required to know our customers. We ask for your country of citizenship as part of this requirement.</p>
										
									</div>
						
															
								
									<div class="title"> <a name="dsp-faq-question12" href="javascript:void(0);" class="faq-questions"><span class="ada-hidden">Show</span>How do I transfer a balance? </a> </div>
									<div class="content">
											<p>If you are currently eligible to complete a balance transfer or direct deposit, you can find a balance transfer link in Online Banking on the <strong>Accounts overview</strong> page. Simply sign in to Online Banking and select <strong>Request a balance transfer</strong> in the <strong>Special offers &amp; new accounts</strong> section. This will take you to the balance transfer form. From there you can submit a balance transfer and/or select <strong>Direct deposit</strong>. You can submit up to 3 balance transfers or make 1 direct deposit. You will receive a confirmation page (but no confirmation number) once you have completed the form.</p><p>Please remember that it can take up to 10 business days for an online balance transfer or direct deposit to post to your account. Also remember the total credit available amount may not include recent purchases, advances or transfers. Your transfer amount cannot exceed your total credit available, so be sure to plan for applicable fees and interest charges when determining your transfer amount.</p>
										
									</div>
						
															
								
									<div class="title"> <a name="dsp-faq-question13" href="javascript:void(0);" class="faq-questions"><span class="ada-hidden">Show</span>Can I transfer funds using my Bank of America<sup>&reg;</sup> personal credit card?</a> </div>
									<div class="content">
											<p>Yes, you can make transfers from your personal credit card to your linked checking or savings account in two different ways. First, you can initiate an immediate funds transfer which will be treated as a bank cash advance, will typically be subject to a higher annual percentage rate and incur transaction fees. Please see your Credit Card Agreement for more details.</p><p>Second, you can deposit funds from your credit card into your checking account by selecting <strong>Request a direct deposit from your credit card</strong> on the customer service page. Direct deposits can take up to five days to process and will incur transaction fees. Please see your Credit Card Agreement for more details.</p>
										
									</div>
						
															
								
									<div class="title"> <a name="dsp-faq-question14" href="javascript:void(0);" class="faq-questions"><span class="ada-hidden">Show</span>What should I know about direct deposits from my credit card?</a> </div>
									<div class="content">
											<p>You can request a direct deposit from your credit card to a checking or savings account up to your total credit available.&nbsp; You can do this by logging into Online Banking and going to the Customer Services tab.&nbsp; Under the Credit Card section you will find a link to complete a direct deposit. It may take up to five days to process. Please note that your total credit available may be affected by any outstanding checks you have written, purchases you have made or recent advance requests. Check your Credit Card Agreement for any applicable transaction fees. For your security, all direct deposits from your credit card made online require you to provide two pieces of information you can find on the credit card.</p>
										
									</div>
						
															
								
									<div class="title"> <a name="dsp-faq-question15" href="javascript:void(0);" class="faq-questions"><span class="ada-hidden">Show</span>What's the difference between transferring funds from my credit card and requesting a direct deposit from my credit card?</a> </div>
									<div class="content">
											<p>A same-day online cash advance from your Bank of America<sup>&reg;</sup> credit card account to your Bank of America checking or saving account can be processed through the <strong>Transfers</strong> tab in <a name="OnlineBanking77" href="http://www.bankofamerica.com/onlinebanking/?context=en" target="_blank">Online Banking</a>. These transfers are subject to your cash credit line available and will be processed at the higher annual percentage rate (APR). Consult your Credit Card Agreement under Transaction Fees for any applicable transaction fees.</p><p>Direct deposit transactions from your Bank of America<sup>&reg;</sup> credit card account to a deposit account outside of Bank of America are fulfilled via an automated clearing house and may take up to five days to process. These transactions are subject to your total credit available and processed at the cash advance APR. These transactions may be subject to transaction fees. Consult your Credit Card Agreement under Transaction Fees for any applicable transaction fees.</p>
										
									</div>
						
															
								
									<div class="title"> <a name="dsp-faq-question16" href="javascript:void(0);" class="faq-questions"><span class="ada-hidden">Show</span>What's a cash credit line?</a> </div>
									<div class="content">
											<p>The total credit line is the amount of credit available for the account; however, only a portion of that is available for bank cash advances. The cash credit line is that amount you have available for bank cash advances. Generally, bank cash advances consist of ATM cash advances, over the counter (OTC) cash advances, same-day online cash advances, overdraft protection cash advances, cash equivalents, returned payments and applicable transaction fees.</p>
										
									</div>
						
															
								
									<div class="title"> <a name="dsp-faq-question17" href="javascript:void(0);" class="faq-questions"><span class="ada-hidden">Show</span>What does "cash credit line available" mean?</a> </div>
									<div class="content">
											<p>Your cash credit line available is the amount of money on your credit card that is currently available for you to use for bank cash advance transactions. Keep in mind that any bank cash advance transactions you have made but have not yet been processed should be subtracted from your cash credit line available.</p>
										
									</div>
						
															
								
									<div class="title"> <a name="dsp-faq-question18" href="javascript:void(0);" class="faq-questions"><span class="ada-hidden">Show</span>How do I know the amount of my cash credit line?</a> </div>
									<div class="content">
											<p>You can view your cash credit line on your statement, in <a name="Onlinebanking66" href="http://www.bankofamerica.com/onlinebanking/?context=en" target="_blank">Online Banking</a> on your credit card <strong>Account details</strong>&nbsp;page or by calling customer service.</p>
										
									</div>
						
															
								
									<div class="title"> <a name="dsp-faq-question19" href="javascript:void(0);" class="faq-questions"><span class="ada-hidden">Show</span>What happens if I go over my cash credit line?</a> </div>
									<div class="content">
											<p>If you exceed your cash credit line, you will not be able to make any more bank cash advance transactions until you have paid your balance below the cash credit limit. There is no account penalty if you go over your cash credit line. Exceeding the cash credit line will not result in a fee or a higher APR, but you may have declined transactions.</p>
										
									</div>
						
															
								
									<div class="title"> <a name="dsp-faq-question20" href="javascript:void(0);" class="faq-questions"><span class="ada-hidden">Show</span>Will I receive a confirmation number when completing a balance transfer? </a> </div>
									<div class="content">
											<p>You won't receive a confirmation number, but you'll know your balance transfer request has been successfully submitted by the confirmation page that displays once you complete the form. Remember, if your request is approved, it can take up to 10 business days for an online balance transfer to post to your account. Please do not resubmit your request online. Your available credit amount may not include recent purchases, advances or transfers. Your balance transfer amount cannot exceed your available credit, so be sure to plan for applicable fees and interest charges when determining your transfer amount.</p>
										
									</div>
						
															
								
									<div class="title"> <a name="dsp-faq-question21" href="javascript:void(0);" class="faq-questions"><span class="ada-hidden">Show</span>Can I use my Bank of America<sup>&reg;</sup> credit card to make payments in Bill Pay? </a> </div>
									<div class="content">
											<p>No, this feature is not available.</p>
										
									</div>
						
															
								
									<div class="title"> <a name="dsp-faq-question22" href="javascript:void(0);" class="faq-questions"><span class="ada-hidden">Show</span>How can I avoid problems using my credit card when I'm traveling domestically? </a> </div>
									<div class="content">
											<p>We recommend that you set a travel notice on the credit card(s) you plan to use while traveling in order to prevent any interruption in card access. To set a travel notice, sign in to <a href="https://secure.bankofamerica.com/login/sign-in/signOnScreen.go?reason=travelcard" target="_self">Online Banking</a>. If you do not have access to Online Banking, you can set a travel notice by calling the number on the back of your card and speaking with a Bank of America associate.</p>
<p>If you encounter any issues after the travel notice has been placed, we&rsquo;re here to help. Contact us toll-free at the number on the back of your card.  For business card issues call 1.509.353.6656.</p>
										
									</div>
						
															
								
									<div class="title"> <a name="dsp-faq-question23" href="javascript:void(0);" class="faq-questions"><span class="ada-hidden">Show</span>How do I request my credit card PIN?</a> </div>
									<div class="content">
											<p>You can request your credit card PIN by <a href="https://secure.bankofamerica.com/administer-accounts/public/card/settings.go?type=credit&amp;channel=desktop" target="_self">signing in to Online Banking</a>, through our mobile app or by calling the number on the back of your card.</p>
										
									</div>
						
						<h3><br>Using your Credit Card in international countries<br></h3>
															
								
									<div class="title opened"> <a name="dsp-faq-question24" href="javascript:void(0);" class="faq-questions"><span class="ada-hidden">Show</span>How can I avoid problems using my credit card when I'm traveling internationally?</a> </div>
									<div class="content first-class-open" >
										
												<p>We recommend that you set a travel notice on the credit card(s) you plan to use while traveling in order to prevent any interruption in card access. To set a travel notice, sign in to <a href="https://secure.bankofamerica.com/login/sign-in/signOnScreen.go?reason=travelcard" name="anc-online-banking">Online Banking</a>. If you do not have access to Online Banking, you can set a travel notice by calling the number on the back of your card and speaking with a Bank of America associate.</p>
<p>We recommend that you memorize your credit card PIN as you may be required to enter your PIN to complete a purchase. A PIN will also be needed to withdraw cash at an ATM. You can request your credit card PIN by <a href="https://secure.bankofamerica.com/administer-accounts/public/card/settings.go?type=credit&amp;channel=desktop" name="acct-faq-olb-signin" target="_self">signing in to Online Banking</a>, through our mobile app or by calling the number on the back of your card.</p>
<p>If you encounter any issues after the travel notice has been placed, we're here to help. Contact us toll-free at the number on the back of your card, or internationally by collect-calling 302.738.5719. For business card issues call 509.353.6656.</p>
										
									</div>
						
															
								
									<div class="title"> <a name="dsp-faq-question25" href="javascript:void(0);" class="faq-questions"><span class="ada-hidden">Show</span>Can I use my credit card at an ATM in a foreign country?</a> </div>
									<div class="content">
											<p>Yes. The largest networks are the MasterCard/Cirrus, Visa/Plus and American Express networks which have ATMs worldwide in more than 100 countries.&nbsp;<a href="https://locators.bankofamerica.com/international.html" name="atm-international-partner-bank" target="_self">Find an ATM at an international partner bank</a>&nbsp;and access money without extra bank fees or surcharges. Remember these 3 important considerations when using foreign ATMs:</p>
<ol>
<li>Some foreign ATMs are only available during normal business hours</li>
<li>Many foreign ATMs offer instruction in English, but not all of them</li>
<li>Your PIN must be 4 digits. Some ATMs do not accept PINs longer than 4 digits. You can request your PIN by <a href="https://secure.bankofamerica.com/administer-accounts/public/card/settings.go?type=credit&amp;channel=desktop" name="acct-faqs-international" target="_self">signing in to Online Banking</a>, through our mobile app or by calling the number on the back of your card.</li>
</ol>
<p>*Please note that some business card accounts may not have cash availability. Please check with your Authorized Contact or Program Administrator before you leave the country.</p>
										
									</div>
						
															
								
									<div class="title"> <a name="dsp-faq-question26" href="javascript:void(0);" class="faq-questions"><span class="ada-hidden">Show</span>Is it possible to increase my credit limit on my credit card prior to going on my trip?</a> </div>
									<div class="content">
											<p>You may request an increase to your credit limit by signing in to Online Banking, navigating to the <strong>Information &amp; Services</strong> tab for your account and following the instructions. You may also contact <a title="Contact us" href="http://www.bankofamerica.com/contact/">Customer Service</a> by dialing the toll-free number on the back of your card</p>
<p>**Note to business cardholders, You will need to contact the business owner to have your request submitted by your Authorized Contact or Program Administrator.</p>
										
									</div>
						
															
								
									<div class="title"> <a name="dsp-faq-question27" href="javascript:void(0);" class="faq-questions"><span class="ada-hidden">Show</span>What are the fees for using a credit card in a foreign country?</a> </div>
									<div class="content">
											<p>For detailed information on fees, refer to your most recent Credit Card Agreement and any recent amendment(s) or contact us at the toll free number on the back of your card.</p>
										
									</div>
						
															
								
									<div class="title"> <a name="dsp-faq-question28" href="javascript:void(0);" class="faq-questions"><span class="ada-hidden">Show</span>What are some tips for using an ATM in foreign countries?</a> </div>
									<div class="content">
											<p>ATMs can be used to get foreign currency while traveling and may save you money when compared to buying currency at exchange rate booths. Despite the advantages, you need to be prepared for special circumstances that can arise when using an international ATM. Here are a few tips to help you on your way:</p><p><strong>Check the network</strong>: Check your card's network. Cards in the Cirrus and Maestro networks often feature ATMs with easy-to-read instructions in English. Bank of America belongs to the Global ATM Alliance.</p><p><strong>Research the country</strong>: There are some countries where ATM transactions are blocked. Please research the country to verify whether you will be able to use your credit card.</p><p><strong>Understand the types of fees charged</strong>: Fees may be incurred for using the ATM and there may also be&nbsp; fees for currency conversion and cash advance. It is usually better to make fewer larger transactions instead of multiple smaller ones.</p><p><strong>Make sure your PIN is valid</strong>: Some ATMs only allow 4-digit PINs. If your current PIN is longer than 4 digits, you may need to get a new PIN before you start your trip.</p><p><strong>Have a backup plan</strong>: Some ATMs limit your access to a primary checking account, so have an alternative means of making purchases such as using foreign currency, traveler&rsquo;s cheques or a debit card.</p><p><strong>Additional tips</strong>: Remember that not all foreign ATMs offer instructions in English. <br />If you are unable to use a foreign ATM, you may be able to use your credit card to make a cash advance at a local bank. Finally please note that some business card accounts may not have cash availability; check with your Authorized Contact or Program Administrator before you leave the country.</p>
										
									</div>
						
															
								
									<div class="title"> <a name="dsp-faq-question29" href="javascript:void(0);" class="faq-questions"><span class="ada-hidden">Show</span>What travel benefits do I get with my credit card</a> </div>
									<div class="content">
											<p>For information on travel benefits, contact us at the toll-free number on the back of your card and speak to an associate.&nbsp;For detailed information, ask the associate for a copy of your most recent Credit Card Agreement or benefits guide.</p>
										
									</div>
						
															
								
									<div class="title"> <a name="dsp-faq-question30" href="javascript:void(0);" class="faq-questions"><span class="ada-hidden">Show</span>How do I contact Bank of America from outside the U.S.?</a> </div>
									<div class="content">
											<p>To call from an international location, please dial the AT&amp;T Direct Access Number of the country you're calling from followed by 302.738.5719.</p>
										
									</div>
						
				</div>
			</li>
		</ul>
	</div>
</div></div>
						<div class="flex-col rt-col" ></div>
						<div class="clearboth"></div>
					</div>
					<div class="footer">
						<div class="footer-top">&nbsp;


 
</div>
						<div class="footer-inner">




<div class="power-footer-module">
  <div class="fsd-five-skin sup-ie">

	<div class="breadcrumbs">

						<a class="bold-bc" href="/" name="bank_of_america_accounts_faq_breadcrumbs" target="_self">Bank of America</a>
						<a href="/credit-cards/overview.go" name="credit_cards_accounts_faq_breadcrumbs" target="_self">Credit Cards</a>
				
				
					<a href="https://bettermoneyhabits.bankofamerica.com/en/credit" name="learn_about_credit_accounts_faq_breadcrumbs" target="_self">Learn About Credit</a>
				
				
				
		   	 <span>Credit Card Account Information FAQs</span>
	  <div class="clearboth"></div>
    </div>

    <div class="pf-columns">

						<div class="pf-col pf-one">


						<a href="/credit-cards/overview.go" name="credit_card_home_accounts_faq_power_footer" class="bold" target="_self">Credit Card Home</a>

						<a href="/credit-cards/cash-back-credit-cards.go" name="cash_rewards_credit_cards_accounts_faq_power_footer" target="_self">Cash Rewards Credit Cards</a>
						<a href="/credit-cards/point-rewards-credit-cards.go" name="points_rewards_credit_cards_accounts_faq_power_footer" target="_self">Points Rewards Credit Cards</a>
						<a href="/credit-cards/travel-credit-cards.go" name="travel_airline_rewards_credit_cards_accounts_faq_power_footer" target="_self">Travel & Airline Rewards Credit Cards</a>
						<a href="/credit-cards/low-interest-credit-cards.go" name="basic_interest_rate_accounts_faq_power_footer" target="_self">Lower Interest Rate Credit Cards</a>
						<a href="https://secure.bankofamerica.com/login/eclo/entry/findCustomizedOffer.go?subchannel=ECPOWF" name="customized_credit_card_offers_accounts_faq_power_footer" target="_self">Customized Credit Card Offers</a>
					</div>


						<div class="pf-col pf-two">


						<a href="/credit-cards/view-all-credit-cards.go" name="view_all_credit_cards_accounts_faq_power_footer" class="bold" target="_self">View All Credit Cards</a>

						<a href="/credit-cards/credit-cards-to-build-credit.go" name="build_or_rebuild_credit_accounts_faq_power_footer" target="_self">Build or Rebuild Credit</a>
						<a href="/credit-cards/student-credit-cards.go" name="credit_cards_for_students_accounts_faq_power_footer" target="_self">Credit Cards for Students</a>
						<a href="/credit-cards/credit-card-with-no-annual-fee.go" name="credit_cards_with_no_annual_fee_accounts_faq_power_footer" target="_self">Credit Cards with No Annual Fee</a>
						<a href="/credit-cards/smart-chip-credit-cards.go" name="chip_credit_cards_accounts_faq_power_footer" target="_self">Chip Credit Cards</a>
						<a href="/credit-cards/compare-credit-cards.go" name="compare_credit_cards_accounts_faq_power_footer" target="_self">Compare Credit Cards</a>
					</div>


						<div class="pf-col pf-three">


						<a href="https://bettermoneyhabits.bankofamerica.com/en/credit" name="learn_about_credit_accounts_faq_power_footer" class="bold" target="_self">Learn About Credit</a>

						<a href="https://bettermoneyhabits.bankofamerica.com/en/credit?subTopicId=choosing-a-credit-card" name="pf_selecting_a_credit_card_accounts_faq_power_footer" target="_self">Selecting a Credit Card</a>
						<a href="https://bettermoneyhabits.bankofamerica.com/en/credit?subTopicId=managing-credit-cards" name="pf_managing_your_credit_card_accounts_faq_power_footer" target="_self">Managing Your Credit Card</a>
						<a href="https://bettermoneyhabits.bankofamerica.com/en/debt" name="pf_paying_down_debt_accounts_faq_power_footer" target="_self">Paying Down Debt</a>
						<a href="https://bettermoneyhabits.bankofamerica.com/en/credit?subTopicId=credit-score" name="pf_improving_your_credit_accounts_faq_power_footer" target="_self">Improving Your Credit Score</a>
						<a href="/credit-cards/education/fico-score-learning.go" name="pf_get_your_fico_score_accounts_faq_power_footer" target="_self">Get Your FICO<sup>&reg;</sup> Score</a>
						<a href="/credit-cards/accounts-faq.go" name="faqs_accounts_faq_power_footer" target="_self">FAQs</a>
						<a href="/credit-cards/glossary.go" name="glossary_accounts_faq_power_footer" target="_self">Glossary</a>
					</div>


						<div class="pf-col pf-four">


						<a href="/credit-cards/manage-your-credit-card-account.go" name="manage_your_credit_card_accounts_faq_power_footer" class="bold" target="_self">Manage Your Credit Card</a>

						<a href="/onlinebanking/online-banking.go" name="online_mobile_banking_accounts_faq_power_footer" target="_self">Online &amp; Mobile Banking</a>
						<a href="/sitemap/hub/signin.go" name="sign_into_your_account_accounts_faq_power_footer" target="_self">Sign Into Your Account</a>
						<a href="/privacy/accounts-cards/credit-debit-card-security.go" name="protect_your_account_accounts_faq_power_footer" target="_self">Protect Your Account</a>
						<a href="/banking-information/assistance/credit-cards/credit-cards-assistance-overview.go" name="get_payment_and_debt_management_tips_accounts_faq_power_footer" target="_self">Get Payment &amp; Debt Management Tips</a>
					</div>


		  <div class="clearboth"></div>
    </div>
  </div>
</div>



 



		<div class="global-footer-module">
			<div class="fsd-skin">

				<div class="footer-bottom-left" style="float:left;max-width:66%;">
	    			<div class="gf-links">	          	
						
					
									
									<a  target="_self" href="/" 
									    name="global_footer_home">Home
									</a>
									
						
					
									
									<a  target="layer" href="/privacy/overview.go" 
									    name="global_footer_privacy_security">Privacy & Security
									</a>
									
						
					
									
									<a  target="layer" href="http://www.bankofamerica.com/careers/" 
									    name="global_footer_careers">Careers
									</a>
									
						
					
									<a	target="layer" href="https://www.bankofamerica.com/sitemap/personal.go" 
										name="global_footer_site_map" class="gf-last-link ">Site Map
									</a> 
						<div class="clearboth"></div>
	    			</div>
	      			<p>Bank of America, N.A. Member FDIC. <a onclick="window.open('/help/equalhousing_popup.cfm','newwin','width=640,height=371,scrollbars=yes,resizable=yes,left=35,top=161');return false;" name="Equal_Housing_Lender" href="/help/equalhousing_popup.go" target="_blank">Equal Housing Lender<img style="vertical-align: baseline;" src="/content/images/ContextualSiteGraphics/Logos/en_US/icon_equal_housing_lender.gif" alt="" width="14" height="9" /></a><br />&copy; 2017 Bank of America Corporation.</p>
         		</div>
         		<div class="footer-social-container" style="float:right;max-width:30%;padding-left:50px;padding-top:19px;">




<div class="boa-social-loader" data-loaded="false" data-platform="borneo"  data-options=''></div>

         		</div>
         		<div class="clearboth"></div>
  			</div>
		</div>

</div>
					</div>
				</div>
			</div>
		</div>
	</body>	
</html>

