
 

				<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
				<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
				<head>


<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta http-equiv="content-type" content="text/html;charset=utf-8">


			<link rel="canonical" href="https://www.bankofamerica.com/privacy/privacy-policy-glossary.go"/>







<title>Privacy & Security Glossary from Bank of America</title>

<meta name="Description" CONTENT="Use the Bank of America privacy & security glossary to find definitions of important privacy and security terms you need to know.">
<meta name="Keywords" CONTENT="privacy and security glossary, privacy policy glossary, online security glossary">

<link rel="shortcut icon" href="https://www2.bac-assets.com/pa/global-assets/1.0/graphic/favicon.ico" type="image/ico" />


	


			<script src="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/Global/1.0/script/tealeafbundle.js" type="text/javascript"></script>
	
	   
			<link rel="stylesheet" type="text/css" href="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/PBI-WEB/2017.03.0/style/pbi-web-ps-jawr.css" media="all" />
			<link rel="stylesheet" type="text/css" href="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/PBI-WEB/2017.03.0/style/pbi-web-ps-jawr-print.css" media="print" />
			<script src="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/PBI-WEB/2017.03.0/script/pbi-web-ps-jawr.js" type="text/javascript"></script>

<script type="text/javascript">
(function() {
	if (typeof mboxUpdate == "function") {
		var windowURL = window.location.href
	    windowURL = windowURL.slice( windowURL.indexOf('.')+1);
		windowURL = windowURL.split( '?' )[0];
		windowURL = windowURL.toLowerCase();
		//alert(windowURL);
		if (
		    //If no mboxes on page, mbox count will be < 1
		    (mboxFactoryDefault.getMboxes().length() < 1) &&  
			
			//Also check for high-volume pages that do not need global logging
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go") &&
			(windowURL != "bankofamerica.com/myaccounts/signin/signin.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/entry/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signonscreen.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatechallengeanswer.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatePassword.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/mobile/banking.go")&&
			(windowURL != "bankofamerica.com/content/preload/olb-myaccount-preload-jawr-module.htm")
			)
		{

			var mboxDiv = document.createElement("div");
			mboxDiv.id = "adobe_touch_clarity_replacement";
			mboxDiv.style.display = "none";
			if (document.body && document.body.firstChild) document.body.insertBefore(mboxDiv,document.body.firstChild);
			mboxDefine(mboxDiv.id,'bac_global_bottom');
			mboxUpdate('bac_global_bottom');
		}
	}	
})();
</script>

	
			<script>
				var boaPageDataJS = {};
					boaPageDataJS.isLLE = "false";
			</script>
				<style>body{display:none;}</style>
	</head>		

	<body class="fsd-layout-body">	

				<script type="text/javascript">if(self == top){var theBody=document.getElementsByTagName("body")[0];theBody.style.display="block";}else{top.location=self.location;}</script>
				<noscript><style>body{display:block;}</style></noscript>
					<a class='ada-hidden ada-visible-focus' href='#skip-to-h1' id='ada-skip-link'>Skip to main content</a>
		<div class="fsd-layout fsd-2c-700lt-layout fsd-full-width">
			<div class="fsd-border">
				<div class="center-content">
					<div class="header">
		  



<script language="javascript" src="/pa/components/modules/tag-manager-module/1.1/script/tag-manager-module-borneo-global-skin.js"></script>
<script>

(function() {
  var fireCallback = function( cb ) {
    if ( typeof cb === "function" ) cb();
  };
  
  function ddoPopulateBase( callback ) {
    try {
		  var DDO = window.digitalData,
		  	bactm_mergeDDO = function( newDDO, priorDDO ) {
		  		if( typeof priorDDO === "undefined" ) {
				  	priorDDO = digitalData || {};
				  }

			    for (var l in newDDO) {
			        if (typeof priorDDO[l] === "undefined") {
			            priorDDO[l] = newDDO[l];
			        }
			        if (newDDO[l] !== null) {
			            if (typeof newDDO[l] === "object") {
			                bactm_mergeDDO(newDDO[l], priorDDO[l]);
			            } else {
			                priorDDO[l] = bactm_validateValue( newDDO[l] ) ? newDDO[l] : priorDDO[l];
			            }
			        }
			    }

			    return priorDDO;
				},
				bactm_olb3rdPartyId = "null";

			if (typeof DDO === "undefined") {
				var simpleDDO = { page: { pageInfo:[{ pageID: null }], attributes: {}, category: { primaryCategory: null }}};

				DDO = (typeof digitalData === "object") ? digitalData : simpleDDO; 
			}

				DDO = bactm_mergeDDO( {pageInstanceID:"notprod",load_coremetrics:true,load_opinionlabs:false,load_touchcommerce:true,load_audiencemanager:true,page:{pageInfo:[{pageID:null,destinationURL:null,referringURL:null,issueDate:null,language:null,segmentValue:null,appName:null,appStepNumber:null,appStepName:null,attr:"-_--_--_--_--_--_--_--_--_--_--_--_--_--_-"}],category:{primaryCategory:null,addlCategory:null,pageType:null},attributes:{searchString:null,searchResults:null,olbSessionID:null,subCampaignCode:null,DARTUrl:null,stateCookie:null,SASIEnabled:false,needOLBcookie:false,standardDART:[],standardDARTes:[],clickDART:[],clickDARTes:[],gaId:[],chat:{account_type:null,boa_associate:null,boa_retiree:null,customer_lob:null,customer_segment:null,data:null,email_campaign:null,entitlement_code:null,error_category:null,error_count:null,first_login:null,inqSalesProductTypes:{},invitation_background:null,invitation_template:null,referral_campaign:null,getStateValue:false,cust_fn:null,cust_ln:null,target:null}}},user:{segment:null,online_id:null,preferred_rewards_tier:null,olb3rdpartyid:null},version:"BAC_0.12"}, DDO );

			DDO.page.pageInfo[0].pageID = "Privacy:Content:Problem_Resources;privacy-policy-glossary";
			DDO.page.category.primaryCategory  = "Privacy:Content:Problem_Resources";
			DDO.page.pageInfo[0].language = "en-US";
			DDO.page.attributes.olbSessionID = "null";
			DDO.page.attributes.SASIEnabled =  "false";
			if (typeof DDO.user != "undefined" && typeof DDO.user.olb3rdpartyid != "undefined") {
				DDO.user.olb3rdpartyid = bactm_olb3rdPartyId;
			}

			window.utag_data = {};
			window.bactm_envSelector = bactm_setTMLib();
			window.digitalData = DDO;

      return fireCallback( callback );

    } catch(e) { }
  }
	if( window.boa && window.boa.digitalData ) {
    window.boa.digitalData.register( ddoPopulateBase );
	}
	else {
	  // Handle scenario where the header isn't available (and thus the default digitalData object and utag loader are missing).
	  //
		var writeScript = function(a,b,c,d){
			a='//tags.tiqcdn.com/utag/bofa/main/' + bactm_envSelector + '/utag.js';
			b=document;
			c='script';
			d=b.createElement(c);
			d.src=a;
			d.type='text/java'+c;
			d.async=true;
			a=b.getElementsByTagName(c)[0];
			a.parentNode.insertBefore(d,a);
		};

		ddoPopulateBase( writeScript );
	}
})();			
</script>




 


<div class="header-module">
	<div class="text-w-logo-skin">
		<div class="header-left">
	  
			<div itemscope itemtype="http://schema.org/Corporation" class="bofa-logo">
				<a itemprop="url" name="anc-privacy-&-security" title="Bank of America" href="/">
					<img itemprop="logo" height="28" width="221" 
					     alt="Bank of America" src="https://www2.bac-assets.com/content/images/ContextualSiteGraphics/Logos/en_US/boa_logo.gif"/>
				</a>
			</div>
				<div class="product" data-font="cnx-regular">Privacy & Security</div>
			
			<div class="clearboth"></div>

		</div>
		
		<div class="header-right">
			<ul class="header-links">
			
				
					
				
							<li class="sign-in">
		<a					href="/sitemap/hub/signin.go" target="_self"
		name="Sign_In">Sign In</a> 
							</li>
					
				
							<li>		<a					href="/" target="_self"
		name="Home_Header">Home</a> 
</li>
					
				
							<li>		<a					href="https://locators.bankofamerica.com" target="_self"
		name="Locations">Locations</a> 
</li>
					
				
							<li>		<a					href="/contactus/contactus.go?topicId=privacy_security" target="_self"
		name="Contact_Us">Contact Us</a> 
</li>
					
				
							<li class="last-link">	
		<a					href="/privacy/faq/data-compromise-faq.go" target="_self"
		name="Help">Help</a> 
							</li>
			</ul>
			
			<div class="clearboth"></div>

			<!-- include search-dotcom-util -->



<div class="header-search nlh">
  
  <div class="nav-search">
    <form class="search-form" action="https://secure.bankofamerica.com/myaccounts/public/search-results/unAuthenticatedSearch.go" data-js="/pa/components/utilities/search-util/1.0/script/nav-search.min.js" data-css="/pa/components/utilities/search-util/1.0/style/nav-search.css" data-text-unavailable="Search Currently Unavailable">
      <div class="search-input-container cf" data-icon="search">
        <label for="nav-search-query" class="ada-hidden">Search Term</label>
        <input type="text" placeholder="How can we help you?" name="query" class="search-query" id="nav-search-query" 
          maxlength="99" rel="Search" autocomplete="off"><input type="submit" alt="Search" title="Search" value="Submit Search" name="Search Module - Top Result – Search Button" class="submit track-me">
      </div>
    </form>
  </div>

</div>

		</div>

 		<div class="clearboth"></div>
 	</div>
</div>

	<div class="top-nav-module">
		<div class="fsd-skin sup-ie">
			<ul class="nav-list">
					
					
					<li>
						
									<a href="/privacy/overview.go" class="top-menu-item"
									name="overview_topnav" id="overview_topnav">Overview</a>
					</li>
					
					
					<li>
						
								<a href="/privacy/privacy-overview.go" class="top-menu-item"
								name="privacy_topnav" id="privacy_topnav">Privacy<span class="ada-hidden">  link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/privacy/privacy-overview.go"  name="privacy_overview_topnav" id="privacy_overview_topnav">Privacy Overview </a>
															<a href="/privacy/online-privacy-notice.go"  name="online_privacy_notice_topnav" id="online_privacy_notice_topnav">Online Privacy Notice </a>
															<a href="/privacy/consumer-privacy-notice.go"  name="consumer_privacy_notice_topnav" id="consumer_privacy_notice_topnav">Consumer Privacy Notice </a>
															<a href="/privacy/Preferences.do"  name="your_privacy_choices_topnav" id="your_privacy_choices_topnav">Your Privacy Choices </a>
									</div>
								
									<span class="ada-hidden"> End of submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
					
					
					<li>
						
								<a href="/privacy/accounts-cards/checking-savings-security.go" class="top-menu-item"
								name="account__card_security_topnav" id="account__card_security_topnav">Account & Card Security<span class="ada-hidden">  link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/privacy/accounts-cards/checking-savings-security.go"  name="checking_savings_security_topnav" id="checking_savings_security_topnav">Checking & Savings Security </a>
															<a href="/privacy/accounts-cards/credit-debit-card-security.go"  name="credit_debit_card_security_topnav" id="credit_debit_card_security_topnav">Credit & Debit Card Security </a>
															<a href="/privacy/accounts-cards/ATM-security.go"  name="atm_security_topnav" id="atm_security_topnav">ATM Security </a>
									</div>
								
									<div class="hasSub">
														<a class="with-info" href="/privacy/accounts-cards/shopsafe.go"  name="shopsafe_topnav" id="shopsafe_topnav">ShopSafe<sup>&reg;</sup> 
															
															<span class="sub-nav-item-info">Generate temporary credit card numbers for safe online shopping</span>
														</a>
									</div>
									<span class="ada-hidden"> End of submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
					
					
					<li>
						
								<a href="/privacy/online-mobile-banking-privacy/online-banking-security.go" class="top-menu-item"
								name="online__mobile_security_topnav" id="online__mobile_security_topnav">Online & Mobile Security<span class="ada-hidden">  link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/privacy/online-mobile-banking-privacy/online-banking-security.go"  name="online_banking_security_topnav" id="online_banking_security_topnav">Online Banking Security </a>
															<a href="/privacy/online-mobile-banking-privacy/mobile-banking-security.go"  name="mobile_banking_security_topnav" id="mobile_banking_security_topnav">Mobile Banking Security </a>
															<a href="/privacy/online-mobile-banking-privacy/email-fraud.go"  name="email_fraud_topnav" id="email_fraud_topnav">Email Fraud </a>
									</div>
								
									<div class="hasSub">
														<a class="with-info" href="/privacy/online-mobile-banking-privacy/trusteer-rapport.go"  name="trusteer_rapport_topnav" id="trusteer_rapport_topnav">Trusteer Rapport<sup>&reg;</sup> 
															
															<span class="sub-nav-item-info">Free fraud protection while signed in to Online Banking</span>
														</a>
														<a class="with-info" href="/privacy/online-mobile-banking-privacy/safepass.go"  name="safepass_topnav" id="safepass_topnav">SafePass<sup>&reg;</sup> 
															
															<span class="sub-nav-item-info">Authorize transactions using secure one-time Passcodes</span>
														</a>
									</div>
									<span class="ada-hidden"> End of submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
					
					
					<li>
						
								<a href="/privacy/report-suspicious-email.go" class="top-menu-item selected"
								name="report_a_problem_topnav" id="report_a_problem_topnav">Report a Problem<span class="ada-hidden">  link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/privacy/report-suspicious-email.go"  name="report_a_suspicious_email_topnav" id="report_a_suspicious_email_topnav">Report a Suspicious Email </a>
															<a href="/privacy/report-lost-stolen-credit-card.go"  name="report_a_lost_or_stolen_card_topnav" id="report_a_lost_or_stolen_card_topnav">Report a Lost or Stolen Card </a>
															<a href="/privacy/resolve-identity-theft.go"  name="resolve_identity_theft_topnav" id="resolve_identity_theft_topnav">Resolve Identity Theft </a>
															<a href="/privacy/report-data-compromise.go"  name="understand__data_compromise_topnav" id="understand__data_compromise_topnav">Understand Data Compromise </a>
									</div>
								
									<div class="hasSub">
														<span>Resources</span>
														<a href="/privacy/faq/collecting-information-faq.go  "  name="faqs_topnav" id="faqs_topnav">FAQs </a>
														<a href="/privacy/privacy-policy-glossary.go"  name="glossary_topnav" id="glossary_topnav">Glossary </a>
														<a href="/privacy/external-resources.go"  name="external_links_topnav" id="external_links_topnav">External Links </a>
									</div>
									<span class="ada-hidden"> End of submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
			</ul>
				<div class="clearboth"></div>
		</div>
	</div>



<div class="page-title-fsd-module h-100" id="skip-to-h1">
	<div class="standard-red-skin sup-ie">
			<h1 data-font="cnx-regular">Privacy & Security Glossary</h1>
	</div>
</div>
<div class="print-module-browser-dialog-skin" style=""> 
	<a href="javascript:window.print();" name="print">PRINT<span class="ada-hidden"> this page</span></a>
</div></div>
					<div class="columns">
						<div class="flex-col lt-col" >
<div class="main-well-content-module">
  <div class="glossary-skin com-main-well-content">
				<div id = 'glossary_Antivirus software' class="bold">Antivirus software</div>
				<p>Software that detects and removes or quarantines code identified as malicious or harmful. Many providers of antivirus software provide frequent updates to help prevent the spread of new threats that can infect computers and other devices that access the internet.</p>
				<div id = 'glossary_Back door' class="bold">Back door</div>
				<p>A hidden method for bypassing normal computer authentication. Back door access can be used by a hacker to gain unauthorized access to information that is otherwise intended to be secure and private.</p>
				<div id = 'glossary_Botnet' class="bold">Botnet</div>
				<p>A network of computers that is used to forward spam and viruses on the internet. The term is a combination of shortened versions of two words, robot and network. The use of a proper firewall on your home computer is one of the best methods to help prevent becoming part of a botnet.</p>
				<div id = 'glossary_Browser hijack' class="bold">Browser hijack</div>
				<p>A form of malware that alters the settings of your browser so that you are redirected to websites you have no intention of visiting. Browser hijackers may be installed as the result of a variety of actions such as installing certain types of software, clicking on a link in an infected email or as the result of a drive-by download.</p>
				<div id = 'glossary_Check scam' class="bold">Check scam</div>
				<p>A crime in which an unsuspecting victim deposits a check into a bank account then wires a portion of the money to a criminal. By the time the check is confirmed as counterfeit, the money has already been wired and picked up by the criminal, leaving the victim without recourse for retrieving the funds they wired. Popular variations of the check scam involve online auctions, sweepstakes, work-at-home schemes and foreign currency transfers.</p>
				<div id = 'glossary_Data compromise' class="bold">Data compromise</div>
				<p>An organized theft of ATM, debit or credit card information primarily through merchant data breaches, merchant third-party processors, computer theft, stolen storage tapes or company insiders working for a merchant or merchant&rsquo;s contractor.</p>
				<div id = 'glossary_Drive-by download' class="bold">Drive-by download</div>
				<p>A method by which malware such as a browser hijacker is added to your computer without your knowledge. A drive-by download can happen when you visit a malicious web page or view a malicious html email, and may go undetected if your computer's security settings are not strict enough.</p>
				<div id = 'glossary_Encryption' class="bold">Encryption</div>
				<p>A method of making information unreadable to everyone except the recipient of that information who holds the key that unlocks the encryption method. A popular example of encryption in use is the secure transmission of credit card numbers while shopping on the internet.</p>
				<div id = 'glossary_Firewall' class="bold">Firewall</div>
				<p>Hardware or software that is designed to allow or deny access to an individual computer or a computer system. Most security experts agree that a firewall is necessary when using a computer that is connected to the internet.</p>
				<div id = 'glossary_Fraud' class="bold">Fraud</div>
				<p>An act that occurs when someone uses your account to make unauthorized purchases. This happens after your card, card number, online credentials or other account details have been stolen.</p>
				<div id = 'glossary_Hacker' class="bold">Hacker</div>
				<p>A computer criminal who tries to get access to a computer system without authorization.</p>
				<div id = 'glossary_Identity theft' class="bold">Identity theft</div>
				<p>A criminal activity in which someone obtains key pieces of personal information such as a Social Security number or driver's license number in order to be able to impersonate that individual. Identity theft activity can generally be divided into 2 categories: using someone else's identity to access their existing accounts and using someone else's identity to open new accounts. (Additional information about identity theft can be found on the sites listed on our <a title="External Resources" name="external_resources_A" href="/privacy/external-resources.go" target="_self">External Resources</a> page.)</p>
				<div id = 'glossary_ITRC' class="bold">ITRC</div>
				<p><a class="com-interstitial-modal-link" rel="http://www.idtheftcenter.org/" name="identity_theft_resource_center" href="javascript:void(0);">The Identity Theft Resource Center</a>, a nonprofit organization that provides step-by-step resolution instructions, form letters and other resources to assist identity theft victims.</p>
				<div id = 'glossary_Keystroke logger' class="bold">Keystroke logger</div>
				<p>A hardware device or software program that monitors and records each keystroke made on a specific computer user's keyboard. Malicious keystroke loggers that are downloaded unwittingly by computer users operate in a covert manner so that the person using the keyboard is unaware their actions are being monitored. The keystroke logger then records the keystrokes, which can include user names and passwords, and periodically uploads the information over the internet to the person doing the monitoring. Also known as keyloggers or system monitors, keystroke loggers have been marketed as a way for parents to monitor their children's computer activities.</p>
				<div id = 'glossary_Malware' class="bold">Malware</div>
				<p>Malicious software designed to covertly infiltrate or damage a computer or computer system. Types of malware include viruses, worms, trojan horses and spyware. Malware can be distributed in a variety of ways including email attachments, links in email or on social networking sites and downloads from file sharing sites.</p>
				<div id = 'glossary_Opt in' class="bold">Opt in</div>
				<p>Giving permission for an organization to use information in a specific way.</p>
				<div id = 'glossary_Opt out' class="bold">Opt out</div>
				<p>Withdrawing permission for an organization to use information in a specific way.</p>
				<div id = 'glossary_Patch' class="bold">Patch</div>
				<p>A software update designed to correct problems with and/or improve performance of a computer program. A software patch is typically made available in order to eliminate vulnerabilities in a program that can allow a hacker to compromise the software user's computer.</p>
				<div id = 'glossary_Phishing' class="bold">Phishing</div>
				<p>A type of online fraud in which a criminal sends email that appears to be from a legitimate source, but in fact is designed to entice the recipient into clicking a link to a website where the unsuspecting victim is asked to provide sensitive personal information. That information can subsequently be used for identity theft purposes. A typical phishing scam involves an email from a bank or a popular online company telling the recipient that there is an account problem that needs to be addressed. (Additional information on phishing can be found on the sites listed on our <a title="External Resources" name="external_resources_B" href="/privacy/external-resources.go" target="_self">External Resources</a> page.)</p>
				<div id = 'glossary_Privacy breach' class="bold">Privacy breach</div>
				<p>A privacy breach is a situation in which sensitive information that is controlled by Bank of America (or a third party acting on our behalf) is lost, misused (including inappropriately accessed) or disclosed to an unauthorized third party. The information may be in any form, including paper, electronic and encrypted data. A privacy breach may occur within Bank of America or at a supplier working on behalf of Bank of America.</p>
				<div id = 'glossary_Privacy notice' class="bold">Privacy notice</div>
				<p>The policy under which a company operating a website handles personal information collected about visitors to the site. <a title="View the Bank of America online privacy notice" name="online_privacy_notice" href="/privacy/online-privacy-notice.go" target="_self">View the Bank of America online privacy notice</a></p>
				<div id = 'glossary_Secure Sockets Layer (SSL)' class="bold">Secure Sockets Layer (SSL)</div>
				<p>A protocol for securely encoding and sending sensitive information over the internet. Bank of America utilizes SSL technology as part of our commitment to maintaining the security and confidentiality of your information.</p>
				<div id = 'glossary_Service pack' class="bold">Service pack</div>
				<p>A software program, sometimes referred to as a patch, that corrects known problems or adds new features to a software program already installed on your computer.</p>
				<div id = 'glossary_Skimming' class="bold">Skimming</div>
				<p>Stealing credit card information during an otherwise legitimate transaction. Skimming occurs when the information thief photocopies credit card receipts or uses a small electronic device added to a credit card scanner to capture card numbers and security codes.</p>
				<div id = 'glossary_SMShing' class="bold">SMShing</div>
				<p>The mobile phone version of phishing. An example of SMShing fraud would be a text message that appears to be sent from a legitimate source, such as a bank or credit card company, that urgently requests the recipient to call a phone number or follow a link in the message. The phone number or website will then ask for sensitive account or personal information.</p>
				<div id = 'glossary_Spam' class="bold">Spam</div>
				<p>Unsolicited email or text messages sent to large numbers of people to promote products or services. Federal legislation known as CAN-SPAM Act sets the rules for commercial email, establishes requirements for commercial messages, gives customers the right to stop receiving email and spells out tough penalties for violations. <a class="com-interstitial-modal-link" rel="http://business.ftc.gov/documents/bus61-can-spam-act-compliance-guide-business" name="can-span" href="javascript:void(0);">Learn more about CAN-SPAM</a></p>
				<div id = 'glossary_Spoofing' class="bold">Spoofing</div>
				<p>An online identity theft scam in which criminals send emails that appear to be sent from legitimate sources. Also known as phishing, spoofing most often refers to the specific component of the scam in which elements of the email are made to appear legitimate. For example, the &ldquo;From&rdquo; address in the email may appear legitimate when in fact it is not.</p>
				<div id = 'glossary_Spyware' class="bold">Spyware</div>
				<p>A type of malware that gathers information from your computer activities and sends it to an unknown source without your knowledge. Spyware programs can be particularly damaging when they are designed to capture personal and financial information that can be used to commit fraud.</p>
				<div id = 'glossary_Trojan horse' class="bold">Trojan horse</div>
				<p>A seemingly legitimate piece of software that carries an unwanted bit of programming code that can be used by hackers to gain unauthorized access to your computer.</p>
				<div id = 'glossary_Virus' class="bold">Virus</div>
				<p>A malicious program or piece of programming code. A virus can be transmitted in a variety of ways, including being copied from one device to another through an infected thumb drive or being transmitted through an infected email attachment. Viruses can be as harmless as delivering a birthday message or as destructive as causing your hard drive to be reformatted.</p>
				<div id = 'glossary_Vishing' class="bold">Vishing</div>
				<p>A form of phishing that occurs over VOIP (Voice Over Internet Protocol) connections. In a vishing scam, a person receives a phone call that appears to be coming from a legitimate source such as a bank or credit card company. The caller identification on the victim&rsquo;s phone will show a legitimate business name and number, when in fact a criminal is really making the call. The criminal will pose as a representative of the company and ask the victim to confirm account details and other sensitive information, thereby illegally obtaining sensitive financial and personal information that can be fraudulently used.</p>
				<div id = 'glossary_Worm' class="bold">Worm</div>
				<p>A worm is a form of malware that reproduces itself in order to spread to other computers on a network. A malicious worm will typically use up computer resources with the intention of shutting down the entire system.</p>
				<div id = 'glossary_Zombie' class="bold">Zombie</div>
				<p>A computer that has been maliciously accessed and set up as part of a botnet.</p>
	</div>
</div></div>
						<div class="flex-col rt-col" >

<div class="side-well-module">
   <div class="content-list-skin sup-ie" style="">
      <div class="sw-outer">
         <div class="sw-inner">
            <div class="sw-corner sw-tleft"></div>
            <div class="sw-corner sw-tright"></div>
            <div class="sw-main sw-std-pad">
            
            	<h2>Report suspicious activity
            	</h2>
			            	<ul>
			            		<li>
									<strong>In your email:</strong><br />To report a suspicious email that uses Bank of America's name, forward it to us immediately at <a href="mailto:abuse@bankofamerica.com" name="report-sus-email"><span class="ada-hidden">mailto: </span>abuse@bankofamerica.com</a>.
			               		</li>
			            		<li>
									<strong>On your statement:</strong><br />To report fraudulent activity on your Bank of America account, call 800.432.1000.
			               		</li>
			            		<li>
									<strong>In texts:</strong><br />&ldquo;<a href="/privacy/privacy-policy-glossary.go#glossary_SMShing" name="smishing" target="_self">SMShing</a>&rdquo; and Smishing are like phishing but sent via SMS text messages to access information. Report attempts at <a href="mailto:abuse@bankofamerica.com" name="report-sms-email"><span class="ada-hidden">mailto: </span>abuse@bankofamerica.com</a>.
			               		</li>
			            		<li>
									<strong>By phone:</strong><br />&ldquo;<a href="/privacy/privacy-policy-glossary.go#glossary_Vishing" name="vishing" target="_self">Vishing</a>&rdquo; uses the features of Voice over IP (VoIP) phones to steal personal and financial information. Report it at <a href="mailto:abuse@bankofamerica.com" name="report-vish-email"><span class="ada-hidden">mailto: </span>abuse@bankofamerica.com</a>.
			               		</li>
			               	</ul>
             
            </div>
            <div class="sw-bottom"></div>
         </div>
         <div class="sw-corner sw-bleft"></div>
         <div class="sw-corner sw-bright"></div>
      </div>
   </div>
</div>

</div>
						<div class="clearboth"></div>
					</div>
					<div class="footer">
						<div class="footer-top">&nbsp;</div>
						<div class="footer-inner">


 



		<div class="global-footer-module">
			<div class="fsd-skin">

				<div class="footer-bottom-left" style="float:left;max-width:66%;">
	    			<div class="gf-links">	          	
						
					
									
									<a  target="_self" href="/" 
									    name="global_footer_home">Home
									</a>
									
						
					
									
									<a  target="_self" href="/accessiblebanking/overview.go" 
									    name="global_footer_accessible_banking">Accessible Banking
									</a>
									
						
					
									
									<a  target="_self" href="/privacy/overview.go" 
									    name="global_footer_privacy_security">Privacy & Security
									</a>
									
						
					
									
									<a  target="_self" href="http://careers.bankofamerica.com/careershome.aspx" 
									    name="global_footer_careers">Careers
									</a>
									
						
					
									
									<a  target="_self" href="/sitemap/personal.go" 
									    name="global_footer_site_map">Site Map
									</a>
									
						
					
									<a href="javascript:void(0);" class="gf-last-link boa-dialog boa-com-info-layer-link" name="global_footer_ad_practices_lnk" rel="global_footer_ad_practices">Advertising Practices</a>
								<div id="global_footer_ad_practices" class="hide">
									<h3>Advertising Practices</h3>
										<p>We strive to provide you with information about products and services you might find interesting and useful. Relationship-based ads and online behavioral advertising help us do that.</p>
<p>Here's how it works: We gather information about your online activities, such as the searches you conduct on our Sites and the pages you visit. This information may be used to deliver advertising on our Sites and offline (for example, by phone, email and direct mail) that's customized to meet specific interests you may have.</p>
<p>If you prefer that we do not use this information, you may <a onclick="$('.ui-dialog').remove();" name="WebsiteAdPractices_OptOut" href="/privacy/online-privacy-notice.go#advertising-on-our-sites" target="_blank">opt out of online behavioral advertising</a>. If you opt out, though, you may still receive generic advertising. In addition, financial advisors/Client Managers may continue to use information collected online to provide product and service information in accordance with account agreements.</p>
<p>Also, if you opt out of online behavioral advertising, you may still see ads when you sign in to your account, for example through Online Banking or MyMerrill. These ads are based on your specific account relationships with us.</p>
<p>To learn more about relationship-based ads, online behavioral advertising and our privacy practices, please review the <a onclick="$('.ui-dialog').remove();" name="WebsiteAdPractices_PrivacyNotice" href="/privacy/online-privacy-notice.go" target="_blank">Bank of America Online Privacy Notice</a> and our <a onclick="$('.ui-dialog').remove();" name="Online-privacy-faqs" href="/privacy/faq/online-privacy-faq.go" target="_blank">Online Privacy FAQs</a>.</p>
								</div>
						<div class="clearboth"></div>
	    			</div>
	      			<p>Bank of America, N.A. Member FDIC. <a onclick="function onclick() { function onclick() { window.open('/help/equalhousing_popup.go','newwin','width=640,height=371,scrollbars=yes,resizable=yes,left=35,top=161'); return false; } }" name="Equal_Housing_Lender" href="/help/equalhousing_popup.go">Equal Housing Lender <img src="https://www2.bac-assets.com/content/images/ContextualSiteGraphics/Logos/en_US/icon_equal_housing_lender.gif" alt="" width="14" height="9" /> </a><br />&copy; 2017 Bank of America Corporation.</p>
         		</div>
         		<div class="footer-social-container" style="float:right;max-width:30%;padding-left:50px;padding-top:19px;">




<div class="boa-social-loader" data-loaded="false" data-platform="borneo"  data-options=''></div>

         		</div>
         		<div class="clearboth"></div>
  			</div>
		</div>





	<div class="hide com-interstitial-modal">
     	<h3>Important Notice</h3>
   		<div class="flex-modal-main-content">
   		
      		<p><strong>You're going to another website</strong></p>
      		<p>Before you go, we want you to know the site owner is responsible for what's on their site. Also, their privacy practices and level of security may be different from ours, so please review their policies.</p>
   	
   	<div class="flex-modal-buttons">
	      	<a href="javascript:void(0);" class="button-common button-blue" name="leaving_bank_modal_continue"><span>Continue</span></a>
	         
	      	<a href="javascript:void(0);" class="button-common button-gray close-com-interstitial" name="leaving_bank_modal_cancel"><span>Go back to Bank of America</span></a>
	         
          <div class="clearboth"></div>
      </div>
   </div>
</div>

</div>
					</div>
				</div>
			</div>
		</div>
	</body>	
</html>

