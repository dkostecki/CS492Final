
 

				<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
				<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
				<head>


<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta http-equiv="content-type" content="text/html;charset=utf-8">


			<link rel="canonical" href="https://www.bankofamerica.com/privacy/accounts-cards/credit-debit-card-security.go"/>







<title>Credit and Debit Card Security from Bank of America</title>

<meta name="Description" CONTENT="Learn how Bank of America helps protect your credit and debit card accounts and find out what you can do to help keep your accounts secure.">
<meta name="Keywords" CONTENT="Credit and Debit Card Security from Bank of America">

<link rel="shortcut icon" href="https://www2.bac-assets.com/pa/global-assets/1.0/graphic/favicon.ico" type="image/ico" />


	


			<script src="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/Global/1.0/script/tealeafbundle.js" type="text/javascript"></script>
	
	   
			<link rel="stylesheet" type="text/css" href="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/PBI-WEB/2017.03.0/style/pbi-web-ps-jawr.css" media="all" />
			<link rel="stylesheet" type="text/css" href="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/PBI-WEB/2017.03.0/style/pbi-web-ps-jawr-print.css" media="print" />
			<script src="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/PBI-WEB/2017.03.0/script/pbi-web-ps-jawr.js" type="text/javascript"></script>

<script type="text/javascript">
(function() {
	if (typeof mboxUpdate == "function") {
		var windowURL = window.location.href
	    windowURL = windowURL.slice( windowURL.indexOf('.')+1);
		windowURL = windowURL.split( '?' )[0];
		windowURL = windowURL.toLowerCase();
		//alert(windowURL);
		if (
		    //If no mboxes on page, mbox count will be < 1
		    (mboxFactoryDefault.getMboxes().length() < 1) &&  
			
			//Also check for high-volume pages that do not need global logging
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go") &&
			(windowURL != "bankofamerica.com/myaccounts/signin/signin.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/entry/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signonscreen.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatechallengeanswer.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatePassword.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/mobile/banking.go")&&
			(windowURL != "bankofamerica.com/content/preload/olb-myaccount-preload-jawr-module.htm")
			)
		{

			var mboxDiv = document.createElement("div");
			mboxDiv.id = "adobe_touch_clarity_replacement";
			mboxDiv.style.display = "none";
			if (document.body && document.body.firstChild) document.body.insertBefore(mboxDiv,document.body.firstChild);
			mboxDefine(mboxDiv.id,'bac_global_bottom');
			mboxUpdate('bac_global_bottom');
		}
	}	
})();
</script>

	
			<script>
				var boaPageDataJS = {};
					boaPageDataJS.isLLE = "false";
			</script>
				<style>body{display:none;}</style>
	</head>		

	<body class="fsd-layout-body">	

				<script type="text/javascript">if(self == top){var theBody=document.getElementsByTagName("body")[0];theBody.style.display="block";}else{top.location=self.location;}</script>
				<noscript><style>body{display:block;}</style></noscript>
					<a class='ada-hidden ada-visible-focus' href='#skip-to-h1' id='ada-skip-link'>Skip to main content</a>
		<div class="fsd-layout fsd-2c-700lt-layout fsd-full-width">
			<div class="fsd-border">
				<div class="center-content">
					<div class="header">
		  



<script language="javascript" src="/pa/components/modules/tag-manager-module/1.1/script/tag-manager-module-borneo-global-skin.js"></script>
<script>

(function() {
  var fireCallback = function( cb ) {
    if ( typeof cb === "function" ) cb();
  };
  
  function ddoPopulateBase( callback ) {
    try {
		  var DDO = window.digitalData,
		  	bactm_mergeDDO = function( newDDO, priorDDO ) {
		  		if( typeof priorDDO === "undefined" ) {
				  	priorDDO = digitalData || {};
				  }

			    for (var l in newDDO) {
			        if (typeof priorDDO[l] === "undefined") {
			            priorDDO[l] = newDDO[l];
			        }
			        if (newDDO[l] !== null) {
			            if (typeof newDDO[l] === "object") {
			                bactm_mergeDDO(newDDO[l], priorDDO[l]);
			            } else {
			                priorDDO[l] = bactm_validateValue( newDDO[l] ) ? newDDO[l] : priorDDO[l];
			            }
			        }
			    }

			    return priorDDO;
				},
				bactm_olb3rdPartyId = "null";

			if (typeof DDO === "undefined") {
				var simpleDDO = { page: { pageInfo:[{ pageID: null }], attributes: {}, category: { primaryCategory: null }}};

				DDO = (typeof digitalData === "object") ? digitalData : simpleDDO; 
			}

				DDO = bactm_mergeDDO( {pageInstanceID:"notprod",load_coremetrics:true,load_opinionlabs:false,load_touchcommerce:true,load_audiencemanager:true,page:{pageInfo:[{pageID:null,destinationURL:null,referringURL:null,issueDate:null,language:null,segmentValue:null,appName:null,appStepNumber:null,appStepName:null,attr:"-_--_--_--_--_--_--_--_--_--_--_--_--_--_-"}],category:{primaryCategory:null,addlCategory:null,pageType:null},attributes:{searchString:null,searchResults:null,olbSessionID:null,subCampaignCode:null,DARTUrl:null,stateCookie:null,SASIEnabled:false,needOLBcookie:false,standardDART:[],standardDARTes:[],clickDART:[],clickDARTes:[],gaId:[],chat:{account_type:null,boa_associate:null,boa_retiree:null,customer_lob:null,customer_segment:null,data:null,email_campaign:null,entitlement_code:null,error_category:null,error_count:null,first_login:null,inqSalesProductTypes:{},invitation_background:null,invitation_template:null,referral_campaign:null,getStateValue:false,cust_fn:null,cust_ln:null,target:null}}},user:{segment:null,online_id:null,preferred_rewards_tier:null,olb3rdpartyid:null},version:"BAC_0.12"}, DDO );

			DDO.page.pageInfo[0].pageID = "Privacy:Content:Accounts_Cards;credit-debit-card-security";
			DDO.page.category.primaryCategory  = "Privacy:Content:Accounts_Cards";
			DDO.page.pageInfo[0].language = "en-US";
			DDO.page.attributes.olbSessionID = "null";
			DDO.page.attributes.SASIEnabled =  "false";
			if (typeof DDO.user != "undefined" && typeof DDO.user.olb3rdpartyid != "undefined") {
				DDO.user.olb3rdpartyid = bactm_olb3rdPartyId;
			}

			window.utag_data = {};
			window.bactm_envSelector = bactm_setTMLib();
			window.digitalData = DDO;

      return fireCallback( callback );

    } catch(e) { }
  }
	if( window.boa && window.boa.digitalData ) {
    window.boa.digitalData.register( ddoPopulateBase );
	}
	else {
	  // Handle scenario where the header isn't available (and thus the default digitalData object and utag loader are missing).
	  //
		var writeScript = function(a,b,c,d){
			a='//tags.tiqcdn.com/utag/bofa/main/' + bactm_envSelector + '/utag.js';
			b=document;
			c='script';
			d=b.createElement(c);
			d.src=a;
			d.type='text/java'+c;
			d.async=true;
			a=b.getElementsByTagName(c)[0];
			a.parentNode.insertBefore(d,a);
		};

		ddoPopulateBase( writeScript );
	}
})();			
</script>




 


<div class="header-module">
	<div class="text-w-logo-skin">
		<div class="header-left">
	  
			<div itemscope itemtype="http://schema.org/Corporation" class="bofa-logo">
				<a itemprop="url" name="anc-privacy-&-security" title="Bank of America" href="/">
					<img itemprop="logo" height="28" width="221" 
					     alt="Bank of America" src="https://www2.bac-assets.com/content/images/ContextualSiteGraphics/Logos/en_US/boa_logo.gif"/>
				</a>
			</div>
				<div class="product" data-font="cnx-regular">Privacy & Security</div>
			
			<div class="clearboth"></div>

		</div>
		
		<div class="header-right">
			<ul class="header-links">
			
				
					
				
							<li class="sign-in">
		<a					href="/sitemap/hub/signin.go" target="_self"
		name="Sign_In">Sign In</a> 
							</li>
					
				
							<li>		<a					href="/" target="_self"
		name="Home_Header">Home</a> 
</li>
					
				
							<li>		<a					href="https://locators.bankofamerica.com" target="_self"
		name="Locations">Locations</a> 
</li>
					
				
							<li>		<a					href="/contactus/contactus.go?topicId=privacy_security" target="_self"
		name="Contact_Us">Contact Us</a> 
</li>
					
				
							<li class="last-link">	
		<a					href="/privacy/faq/data-compromise-faq.go" target="_self"
		name="Help">Help</a> 
							</li>
			</ul>
			
			<div class="clearboth"></div>

			<!-- include search-dotcom-util -->



<div class="header-search nlh">
  
  <div class="nav-search">
    <form class="search-form" action="https://secure.bankofamerica.com/myaccounts/public/search-results/unAuthenticatedSearch.go" data-js="/pa/components/utilities/search-util/1.0/script/nav-search.min.js" data-css="/pa/components/utilities/search-util/1.0/style/nav-search.css" data-text-unavailable="Search Currently Unavailable">
      <div class="search-input-container cf" data-icon="search">
        <label for="nav-search-query" class="ada-hidden">Search Term</label>
        <input type="text" placeholder="How can we help you?" name="query" class="search-query" id="nav-search-query" 
          maxlength="99" rel="Search" autocomplete="off"><input type="submit" alt="Search" title="Search" value="Submit Search" name="Search Module - Top Result – Search Button" class="submit track-me">
      </div>
    </form>
  </div>

</div>

		</div>

 		<div class="clearboth"></div>
 	</div>
</div>

	<div class="top-nav-module">
		<div class="fsd-skin sup-ie">
			<ul class="nav-list">
					
					
					<li>
						
									<a href="/privacy/overview.go" class="top-menu-item"
									name="overview_topnav" id="overview_topnav">Overview</a>
					</li>
					
					
					<li>
						
								<a href="/privacy/privacy-overview.go" class="top-menu-item"
								name="privacy_topnav" id="privacy_topnav">Privacy<span class="ada-hidden">  link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/privacy/privacy-overview.go"  name="privacy_overview_topnav" id="privacy_overview_topnav">Privacy Overview </a>
															<a href="/privacy/online-privacy-notice.go"  name="online_privacy_notice_topnav" id="online_privacy_notice_topnav">Online Privacy Notice </a>
															<a href="/privacy/consumer-privacy-notice.go"  name="consumer_privacy_notice_topnav" id="consumer_privacy_notice_topnav">Consumer Privacy Notice </a>
															<a href="/privacy/Preferences.do"  name="your_privacy_choices_topnav" id="your_privacy_choices_topnav">Your Privacy Choices </a>
									</div>
								
									<span class="ada-hidden"> End of submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
					
					
					<li>
						
								<a href="/privacy/accounts-cards/checking-savings-security.go" class="top-menu-item selected"
								name="account__card_security_topnav" id="account__card_security_topnav">Account & Card Security<span class="ada-hidden">  link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/privacy/accounts-cards/checking-savings-security.go"  name="checking_savings_security_topnav" id="checking_savings_security_topnav">Checking & Savings Security </a>
															<a href="/privacy/accounts-cards/credit-debit-card-security.go"  name="credit_debit_card_security_topnav" id="credit_debit_card_security_topnav">Credit & Debit Card Security </a>
															<a href="/privacy/accounts-cards/ATM-security.go"  name="atm_security_topnav" id="atm_security_topnav">ATM Security </a>
									</div>
								
									<div class="hasSub">
														<a class="with-info" href="/privacy/accounts-cards/shopsafe.go"  name="shopsafe_topnav" id="shopsafe_topnav">ShopSafe<sup>&reg;</sup> 
															
															<span class="sub-nav-item-info">Generate temporary credit card numbers for safe online shopping</span>
														</a>
									</div>
									<span class="ada-hidden"> End of submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
					
					
					<li>
						
								<a href="/privacy/online-mobile-banking-privacy/online-banking-security.go" class="top-menu-item"
								name="online__mobile_security_topnav" id="online__mobile_security_topnav">Online & Mobile Security<span class="ada-hidden">  link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/privacy/online-mobile-banking-privacy/online-banking-security.go"  name="online_banking_security_topnav" id="online_banking_security_topnav">Online Banking Security </a>
															<a href="/privacy/online-mobile-banking-privacy/mobile-banking-security.go"  name="mobile_banking_security_topnav" id="mobile_banking_security_topnav">Mobile Banking Security </a>
															<a href="/privacy/online-mobile-banking-privacy/email-fraud.go"  name="email_fraud_topnav" id="email_fraud_topnav">Email Fraud </a>
									</div>
								
									<div class="hasSub">
														<a class="with-info" href="/privacy/online-mobile-banking-privacy/trusteer-rapport.go"  name="trusteer_rapport_topnav" id="trusteer_rapport_topnav">Trusteer Rapport<sup>&reg;</sup> 
															
															<span class="sub-nav-item-info">Free fraud protection while signed in to Online Banking</span>
														</a>
														<a class="with-info" href="/privacy/online-mobile-banking-privacy/safepass.go"  name="safepass_topnav" id="safepass_topnav">SafePass<sup>&reg;</sup> 
															
															<span class="sub-nav-item-info">Authorize transactions using secure one-time Passcodes</span>
														</a>
									</div>
									<span class="ada-hidden"> End of submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
					
					
					<li>
						
								<a href="/privacy/report-suspicious-email.go" class="top-menu-item"
								name="report_a_problem_topnav" id="report_a_problem_topnav">Report a Problem<span class="ada-hidden">  link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/privacy/report-suspicious-email.go"  name="report_a_suspicious_email_topnav" id="report_a_suspicious_email_topnav">Report a Suspicious Email </a>
															<a href="/privacy/report-lost-stolen-credit-card.go"  name="report_a_lost_or_stolen_card_topnav" id="report_a_lost_or_stolen_card_topnav">Report a Lost or Stolen Card </a>
															<a href="/privacy/resolve-identity-theft.go"  name="resolve_identity_theft_topnav" id="resolve_identity_theft_topnav">Resolve Identity Theft </a>
															<a href="/privacy/report-data-compromise.go"  name="understand__data_compromise_topnav" id="understand__data_compromise_topnav">Understand Data Compromise </a>
									</div>
								
									<div class="hasSub">
														<span>Resources</span>
														<a href="/privacy/faq/collecting-information-faq.go  "  name="faqs_topnav" id="faqs_topnav">FAQs </a>
														<a href="/privacy/privacy-policy-glossary.go"  name="glossary_topnav" id="glossary_topnav">Glossary </a>
														<a href="/privacy/external-resources.go"  name="external_links_topnav" id="external_links_topnav">External Links </a>
									</div>
									<span class="ada-hidden"> End of submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
			</ul>
				<div class="clearboth"></div>
		</div>
	</div>



<div class="page-title-fsd-module h-100" id="skip-to-h1">
	<div class="standard-red-skin sup-ie">
			<h1 data-font="cnx-regular">Credit & Debit Card Security from Bank of America</h1>
	</div>
</div>		<div class="global-banner-module g-banner image-right text-left bkg-gray h2-black" >
			<div class="content">
								<img alt=" " src="/content/images/ContextualSiteGraphics/Instructional/en_US/mobile-web-branded/cc-chip.jpg"/>
						<h2 data-font="cnx-medium" class="small ptop-40">We're helping you keep your credit and debit cards more secure</h2>
						<div class="text medium"></div>				
			</div>
			<div class="clearboth"></div>			
		</div>
</div>
					<div class="columns">
						<div class="flex-col lt-col" >



<div class="tabs-module">
   <div class="engagement-com-content-skin" id="engagement-com-content-tabs">
    
     <ul class="tabs-com-vzd3-common">
	         <li class="tab-com">
	            <div class="tab-cap-com"></div>
	            <h2>
	               <a href="#how-we-protect-you" name="how_we_protect_you"><span>How we protect you</span></a>
	            </h2>
	            <div class="tab-cap-com tab-rt-cap-com"></div>
	            <div class="clearboth"></div>
	         </li>
	         <li class="tab-com">
	            <div class="tab-cap-com"></div>
	            <h2>
	               <a href="#what-you-can-do" name="what_you_can_do"><span>What you can do</span></a>
	            </h2>
	            <div class="tab-cap-com tab-rt-cap-com"></div>
	            <div class="clearboth"></div>
	         </li>
         <div class="clearboth"></div>
      </ul>
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
      
    <div class="com-tabs-content com-main-well-content" style="				padding-top:46px;
">
         <div id="how-we-protect-you" style=""> 
						<p>At Bank of America, we take your security seriously. That's why our credit and debit cards come with security features that help protect your information.</p>
							<h3 class="h4-styling">Chip card technology</h3>
						<p>Get stronger security for your credit and debit card with chip technology that protects your information when used at a chip-enabled terminal.<br /><a href="/privacy/accounts-cards/emv-chip-card-technology.go" name="privacy_chip_card" target="_self">Find out more about chip cards</a></p>
							<h3 class="h4-styling">Fraud Protection</h3>
						<ul><li><strong>$0 Liability Guarantee.</strong> Should your card be lost or stolen, Bank of America will credit fraudulent charges made with your card back to your account as soon as the next business day.<a href="#footnote1" name="zero-liability"><span class="ada-hidden">Footnote</span><sup>1</sup></a></li>
						<li><strong>Fraud monitoring.</strong> Reviews how and where your card is being used and is designed to help block potential fraud if abnormal patterns are detected.</li></ul>
							<h3 class="h4-styling">Privacy policy</h3>
						<p>Keeping your financial information secure is one of our most important responsibilities. For an explanation of how we manage customer information, visit <a href="/privacy/overview.go" name="privacy_overview" target="_self">www.bankofamerica.com/privacy</a>.</p>
							<h3 class="h4-styling">Verified by Visa<sup>&reg;</sup> and MasterCard SecureCode<sup>&reg;</sup> Secure Transactions</h3>
						<p>Bank of America utilizes various tools designed to help protect your debit cards against fraudulent transactions. We are active participants in Verified by Visa<sup>&reg;</sup> and MasterCard SecureCode<sup>&reg;</sup>. As a result we may request that you authenticate yourself when you use your Bank of America debit card online. You can shop with confidence knowing that when you make a purchase with your Bank of America debit card at a Verified by Visa<sup>&reg;</sup> or MasterCard SecureCode<sup>&reg;</sup> merchant you are still covered by our $0 Liability Guarantee.<a href="#footnote1" name="zero-liability"><span class="ada-hidden">footnote</span><sup>1</sup></a></p>
							<h3 class="h4-styling">Photo Security<sup>&reg;</sup></h3>
						<p>Placing your photo on the front of your Bank of America personal or small business debit card can help prevent fraud if your card is lost or stolen. <a href="javascript:void(0);" id="Photo Security<sup>&reg;</sup>" class="boa-dialog boa-com-info-layer-link dotted" rel="glossary-popup-1" name="glossary_ PhotoSecurity"><span class="ada-hidden">Glossary Term: </span>Learn how to add Photo Security<sup>&reg;</sup> to your card</a></p>
         	</div>
         <div id="what-you-can-do" style=""> 
							<h3 class="h4-styling">Sign your cards immediately</h3>
						<p>Sign the signature panel on your credit and debit cards as soon as you receive them.</p>
							<h3 class="h4-styling">Check your statements</h3>
						<p>Save the receipts from your charges and keep them in a safe location. Check your statements to verify that they properly reflect the amounts you have authorized. Report any fraudulent transactions immediately.&nbsp;Once you have reconciled your statements, shred up all receipts and discard them at home.</p>
							<h3 class="h4-styling">Go paperless with Online Banking</h3>
						<p>Access your Bank of America card statements through Online Banking and ask us to stop sending paper.&nbsp;Checking your balances and viewing your account statements online is safer than having information sent&nbsp;through the mail.</p>
							<h3 class="h4-styling">Keep a list of all your card account numbers</h3>
						<p>Keep the list in a safe and secure place and include the telephone numbers to call if your cards are ever&nbsp;lost or stolen.</p>
							<h3 class="h4-styling">Use a digital wallet</h3>
						<p>A digital wallet stores information about your physical debit and credit cards so you can make purchases at participating merchants. Certain digital wallets use virtual cards<a href="#footnote2" name="virtual-cards"><span class="ada-hidden">Footnote</span><sup>2</sup></a>. A virtual card is the digital form of your physical debit or credit card and it has a unique card number stored within a digital wallet that's different from the physical card number. So, it cannot be accessed from your digital wallet if your mobile device is lost or stolen. You can use your virtual card with your digital wallet to conveniently make purchases, just like your physical debit and credit cards. You still get all the rewards, benefits and protections your physical card provides.<br /><a href="/onlinebanking/mobile-wallet.go" target="_self">Learn more about Apple Pay<sup>&reg;</sup> &raquo;</a><br /><a href="http://promo.bankofamerica.com/androidpay" target="_self">Learn more about Android Pay&trade; &raquo;</a><br /><a href="http://promo.bankofamerica.com/samsungpay" target="_self">Learn more about Samsung Pay &raquo;</a><br /><a href="http://promo.bankofamerica.com/microsoftwallet" target="_self">Learn more about Microsoft&trade; Wallet &raquo;</a><br /><a href="http://promo.bankofamerica.com/visa-checkout" target="_self">Learn more about Visa Checkout &raquo;</a><br /><a href="http://promo.bankofamerica.com/masterpass" target="_self">Learn more about Masterpass&trade; &raquo;</a></p>
							<h3 class="h4-styling">Use ATMs safely</h3>
						<p>Use ATMs with surveillance cameras and be aware of people and your surroundings. When you enter or&nbsp;exit an ATM in an enclosed area, be sure you close the entry door completely. Do not open locked ATM vestibule doors for others or allow any unknown persons to enter the ATM area while you are making your&nbsp;transaction. Shield the ATM keypad with your hand or body while entering your PIN. Secure your card and cash after completing your transaction and before exiting the ATM area. Count your cash later in the safety of your locked car or home. Your ATM card is like cash, so keep it in a safe place.</p>
							<h3 class="h4-styling">Always be cautious</h3>
						<p>Never provide credit or debit account information to anyone who calls you. Bank of America will never reach&nbsp;out to you in this way to request sensitive account information.</p>
         	</div>
      </div>
   </div>
</div>

					<div id="glossary-popup-1" class="hide tabs-main-content">
						<h3>Photo Security<sup>&reg;</sup></h3>
						<p>Your picture on your debit card helps protect you from fraudulent use if your card is lost or stolen. Plus, you may be able to use your Photo Security<sup>&reg;</sup> card as an additional form of ID.</p> <p>The Photo Security feature is available on most Bank of America debit cards. The Photo Security feature is not available on ATM cards, small business employee debit cards or small business deposit only cards.</p> <p><strong>Adding a photo to a new or existing Bank of America card is easy:</strong></p> <p>Stop by a banking center. We can take your photo in just a few minutes and you&rsquo;ll receive your new card in 5-7 business days (a debit card replacement fee may apply). Continue to use your existing card until your new Photo Security card arrives. We'll keep your photo on file so it automatically appears on your card when it&rsquo;s reissued. <a href="http://locators.bankofamerica.com/locator/locator/LocatorAction.do" target="Pop-up medium">Find a banking center</a></p>
					</div>
		
</div>
						<div class="flex-col rt-col" >

<div class="side-well-module">
   <div class="content-list-skin sup-ie" style="">
      <div class="sw-outer">
         <div class="sw-inner">
            <div class="sw-corner sw-tleft"></div>
            <div class="sw-corner sw-tright"></div>
            <div class="sw-main sw-std-pad">
            
            	<h2>Report suspicious activity
            	</h2>
			            	<ul>
			            		<li>
									<strong>In your email:</strong><br />To report a suspicious email that uses Bank of America's name, forward it to us immediately at <a href="mailto:abuse@bankofamerica.com" name="report-sus-email"><span class="ada-hidden">mailto: </span>abuse@bankofamerica.com</a>.
			               		</li>
			            		<li>
									<strong>On your statement:</strong><br />To report fraudulent activity on your Bank of America account, call 800.432.1000.
			               		</li>
			            		<li>
									<strong>In texts:</strong><br />&ldquo;<a href="/privacy/privacy-policy-glossary.go#glossary_SMShing" name="smishing" target="_self">SMShing</a>&rdquo; and Smishing are like phishing but sent via SMS text messages to access information. Report attempts at <a href="mailto:abuse@bankofamerica.com" name="report-sms-email"><span class="ada-hidden">mailto: </span>abuse@bankofamerica.com</a>.
			               		</li>
			            		<li>
									<strong>By phone:</strong><br />&ldquo;<a href="/privacy/privacy-policy-glossary.go#glossary_Vishing" name="vishing" target="_self">Vishing</a>&rdquo; uses the features of Voice over IP (VoIP) phones to steal personal and financial information. Report it at <a href="mailto:abuse@bankofamerica.com" name="report-vish-email"><span class="ada-hidden">mailto: </span>abuse@bankofamerica.com</a>.
			               		</li>
			               	</ul>
             
            </div>
            <div class="sw-bottom"></div>
         </div>
         <div class="sw-corner sw-bleft"></div>
         <div class="sw-corner sw-bright"></div>
      </div>
   </div>
</div>


<div class="side-well-module">
   <div class="content-list-skin sup-ie" style="">
      <div class="sw-outer">
         <div class="sw-inner">
            <div class="sw-corner sw-tleft"></div>
            <div class="sw-corner sw-tright"></div>
            <div class="sw-main sw-std-pad">
            
            	<h2>Additional resources
            	</h2>
			            	<ul>
			            		<li>
									<a class="com-interstitial-modal-link" rel="http://www.ftc.gov/idtheft" name="ftc-identity-theft" href="javascript:void(0);">Federal Trade Commission (FTC) Identity Theft</a><br />A national resource to help you deter, detect and defend against identity theft.
			               		</li>
			            		<li>
									<a class="com-interstitial-modal-link" rel="http://www.identitytheftassistance.org/" name="identity-theft-assistance" href="javascript:void(0);">Identity Theft Assistance Center (ITAC)</a><br />Helpful resources for preventing and detecting fraud and identity theft.
			               		</li>
			               	</ul>
             
               	<div class="boa-brd-top">
               			<a name="more-ext-resources" href="/privacy/external-resources.go">More external resources</a>
               	</div>
            </div>
            <div class="sw-bottom"></div>
         </div>
         <div class="sw-corner sw-bleft"></div>
         <div class="sw-corner sw-bright"></div>
      </div>
   </div>
</div>

</div>
						<div class="clearboth"></div>
					</div>
					<div class="footer">
						<div class="footer-top">&nbsp;
<div class="disclaimers-module">
	<div class="fsd-skin sup-ie">
			<p>Apple and Apple Pay are trademarks of Apple Inc., registered in the U.S. and other countries. Android Pay is a trademark of Google Inc. Microsoft and Microsoft Wallet are trademarks of Microsoft Corporation.</p>
<p>Mastercard is a registered trademark, and Masterpass and the circles design are trademarks of Mastercard International Incorporated and are used by the issuer pursuant to license.</p>
	</div>
</div>

</div>
						<div class="footer-inner">
<div class="footnote-com-module">
   <div class="fsd-layout-skin sup-ie">
					<div class="h-100">
						<div class="footnote" id="footnote1">
							<div class="fn-num">1.</div>
							<div class="fn-text">The $0 Liability Guarantee covers fraudulent transactions made by others using your Bank of America consumer credit cards and consumer and small business debit and ATM cards. To be covered, report transactions made by others promptly, and don't share personal or account information with anyone. Access to funds next business day in most cases, pending resolution of claim. Consult customer and account agreements for full details. </div>
							<div class="clearboth"></div>
						</div>
					</div>
					<div class="h-100">
						<div class="footnote" id="footnote2">
							<div class="fn-num">2.</div>
							<div class="fn-text">Apple Pay, Android Pay, and Samsung Pay and Microsoft Wallet use virtual cards. </div>
							<div class="clearboth"></div>
						</div>
					</div>
   </div>
</div>





 



		<div class="global-footer-module">
			<div class="fsd-skin">

				<div class="footer-bottom-left" style="float:left;max-width:66%;">
	    			<div class="gf-links">	          	
						
					
									
									<a  target="_self" href="/" 
									    name="global_footer_home">Home
									</a>
									
						
					
									
									<a  target="_self" href="/accessiblebanking/overview.go" 
									    name="global_footer_accessible_banking">Accessible Banking
									</a>
									
						
					
									
									<a  target="_self" href="/privacy/overview.go" 
									    name="global_footer_privacy_security">Privacy & Security
									</a>
									
						
					
									
									<a  target="_self" href="http://careers.bankofamerica.com/careershome.aspx" 
									    name="global_footer_careers">Careers
									</a>
									
						
					
									
									<a  target="_self" href="/sitemap/personal.go" 
									    name="global_footer_site_map">Site Map
									</a>
									
						
					
									<a href="javascript:void(0);" class="gf-last-link boa-dialog boa-com-info-layer-link" name="global_footer_ad_practices_lnk" rel="global_footer_ad_practices">Advertising Practices</a>
								<div id="global_footer_ad_practices" class="hide">
									<h3>Advertising Practices</h3>
										<p>We strive to provide you with information about products and services you might find interesting and useful. Relationship-based ads and online behavioral advertising help us do that.</p>
<p>Here's how it works: We gather information about your online activities, such as the searches you conduct on our Sites and the pages you visit. This information may be used to deliver advertising on our Sites and offline (for example, by phone, email and direct mail) that's customized to meet specific interests you may have.</p>
<p>If you prefer that we do not use this information, you may <a onclick="$('.ui-dialog').remove();" name="WebsiteAdPractices_OptOut" href="/privacy/online-privacy-notice.go#advertising-on-our-sites" target="_blank">opt out of online behavioral advertising</a>. If you opt out, though, you may still receive generic advertising. In addition, financial advisors/Client Managers may continue to use information collected online to provide product and service information in accordance with account agreements.</p>
<p>Also, if you opt out of online behavioral advertising, you may still see ads when you sign in to your account, for example through Online Banking or MyMerrill. These ads are based on your specific account relationships with us.</p>
<p>To learn more about relationship-based ads, online behavioral advertising and our privacy practices, please review the <a onclick="$('.ui-dialog').remove();" name="WebsiteAdPractices_PrivacyNotice" href="/privacy/online-privacy-notice.go" target="_blank">Bank of America Online Privacy Notice</a> and our <a onclick="$('.ui-dialog').remove();" name="Online-privacy-faqs" href="/privacy/faq/online-privacy-faq.go" target="_blank">Online Privacy FAQs</a>.</p>
								</div>
						<div class="clearboth"></div>
	    			</div>
	      			<p>Bank of America, N.A. Member FDIC. <a onclick="function onclick() { function onclick() { window.open('/help/equalhousing_popup.go','newwin','width=640,height=371,scrollbars=yes,resizable=yes,left=35,top=161'); return false; } }" name="Equal_Housing_Lender" href="/help/equalhousing_popup.go">Equal Housing Lender <img src="https://www2.bac-assets.com/content/images/ContextualSiteGraphics/Logos/en_US/icon_equal_housing_lender.gif" alt="" width="14" height="9" /> </a><br />&copy; 2017 Bank of America Corporation.</p>
         		</div>
         		<div class="footer-social-container" style="float:right;max-width:30%;padding-left:50px;padding-top:19px;">




<div class="boa-social-loader" data-loaded="false" data-platform="borneo"  data-options=''></div>

         		</div>
         		<div class="clearboth"></div>
  			</div>
		</div>





	<div class="hide com-interstitial-modal">
     	<h3>Important Notice</h3>
   		<div class="flex-modal-main-content">
   		
      		<p><strong>You're going to another website</strong></p>
      		<p>Before you go, we want you to know the site owner is responsible for what's on their site. Also, their privacy practices and level of security may be different from ours, so please review their policies.</p>
   	
   	<div class="flex-modal-buttons">
	      	<a href="javascript:void(0);" class="button-common button-blue" name="leaving_bank_modal_continue"><span>Continue</span></a>
	         
	      	<a href="javascript:void(0);" class="button-common button-gray close-com-interstitial" name="leaving_bank_modal_cancel"><span>Go back to Bank of America</span></a>
	         
          <div class="clearboth"></div>
      </div>
   </div>
</div>

</div>
					</div>
				</div>
			</div>
		</div>
	</body>	
</html>

