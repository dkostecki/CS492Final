
 

				<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
				<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
				<head>



<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<title>Bank of America Glossary of Banking Terms for Students</title>


					<meta name="Keywords" CONTENT="banking glossary, financial glossary, student finance glossary" />
					<meta name="Description" CONTENT="This glossary of financial terms is designed to help students understand the most common financial terms and concepts." />


<link rel="shortcut icon" href="https://www2.bac-assets.com/pa/global-assets/1.0/graphic/favicon.ico" type="image/ico" />


		<link rel="stylesheet" type="text/css" media="all" href="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/APS-deposits/2017.03.0/style/global-aps-dp-jawr.css"/>
		<link rel="stylesheet" type="text/css" media="all" href="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/APS-deposits/2017.03.0/style/sb-aps-dp-jawr.css"/>
		
		<script type="text/javascript" src="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/APS-deposits/2017.03.0/script/global-aps-dp-jawr.js"></script>
		<script type="text/javascript" src="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/APS-deposits/2017.03.0/script/sb-aps-dp-jawr.js"></script>
		
			<script type="text/javascript">
				$(window).load(function(){asyncPrintCssInclude('https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/APS-deposits/2017.03.0/style/global-aps-dp-jawr-print.css');});
				$(window).load(function(){asyncPrintCssInclude('https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/APS-deposits/2017.03.0/style/sb-aps-dp-jawr-print.css');});
			</script>
<script type="text/javascript">
(function() {
	if (typeof mboxUpdate == "function") {
		var windowURL = window.location.href
	    windowURL = windowURL.slice( windowURL.indexOf('.')+1);
		windowURL = windowURL.split( '?' )[0];
		windowURL = windowURL.toLowerCase();
		//alert(windowURL);
		if (
		    //If no mboxes on page, mbox count will be < 1
		    (mboxFactoryDefault.getMboxes().length() < 1) &&  
			
			//Also check for high-volume pages that do not need global logging
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go") &&
			(windowURL != "bankofamerica.com/myaccounts/signin/signin.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/entry/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signonscreen.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatechallengeanswer.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatePassword.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/mobile/banking.go")&&
			(windowURL != "bankofamerica.com/content/preload/olb-myaccount-preload-jawr-module.htm")
			)
		{

			var mboxDiv = document.createElement("div");
			mboxDiv.id = "adobe_touch_clarity_replacement";
			mboxDiv.style.display = "none";
			if (document.body && document.body.firstChild) document.body.insertBefore(mboxDiv,document.body.firstChild);
			mboxDefine(mboxDiv.id,'bac_global_bottom');
			mboxUpdate('bac_global_bottom');
		}
	}	
})();
</script>

		<script src="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/Global/1.0/script/tealeafbundle.js" type="text/javascript"></script>
			<script>
				var boaPageDataJS = {};
					boaPageDataJS.isLLE = "false";
			</script>
				<style>body{display:none;}</style>
	</head>		

	<body class="fsd-layout-body">	

				<script type="text/javascript">if(self == top){var theBody=document.getElementsByTagName("body")[0];theBody.style.display="block";}else{top.location=self.location;}</script>
				<noscript><style>body{display:block;}</style></noscript>
					<a class='ada-hidden ada-visible-focus' href='#skip-to-h1' id='ada-skip-link'>Skip to main content</a>
		<div class="fsd-layout fsd-2c-700lt-layout">
			<div class="fsd-border">
				<div class="center-content">
					<div class="header">
		  



<script language="javascript" src="/pa/components/modules/tag-manager-module/1.1/script/tag-manager-module-borneo-global-skin.js"></script>
<script>

(function() {
  var fireCallback = function( cb ) {
    if ( typeof cb === "function" ) cb();
  };
  
  function ddoPopulateBase( callback ) {
    try {
		  var DDO = window.digitalData,
		  	bactm_mergeDDO = function( newDDO, priorDDO ) {
		  		if( typeof priorDDO === "undefined" ) {
				  	priorDDO = digitalData || {};
				  }

			    for (var l in newDDO) {
			        if (typeof priorDDO[l] === "undefined") {
			            priorDDO[l] = newDDO[l];
			        }
			        if (newDDO[l] !== null) {
			            if (typeof newDDO[l] === "object") {
			                bactm_mergeDDO(newDDO[l], priorDDO[l]);
			            } else {
			                priorDDO[l] = bactm_validateValue( newDDO[l] ) ? newDDO[l] : priorDDO[l];
			            }
			        }
			    }

			    return priorDDO;
				},
				bactm_olb3rdPartyId = "null";

			if (typeof DDO === "undefined") {
				var simpleDDO = { page: { pageInfo:[{ pageID: null }], attributes: {}, category: { primaryCategory: null }}};

				DDO = (typeof digitalData === "object") ? digitalData : simpleDDO; 
			}

				DDO = bactm_mergeDDO( {pageInstanceID:"notprod",load_coremetrics:false,load_opinionlabs:false,load_touchcommerce:true,load_audiencemanager:true,page:{pageInfo:[{pageID:null,destinationURL:null,referringURL:null,issueDate:null,language:null,segmentValue:null,appName:null,appStepNumber:null,appStepName:null,attr:"-_--_--_--_--_--_--_--_--_--_--_--_--_--_-"}],category:{primaryCategory:null,addlCategory:null,pageType:null},attributes:{searchString:null,searchResults:null,olbSessionID:null,subCampaignCode:null,DARTUrl:null,stateCookie:null,SASIEnabled:false,needOLBcookie:false,standardDART:[],standardDARTes:[],clickDART:[],clickDARTes:[],gaId:[],chat:{account_type:null,boa_associate:null,boa_retiree:null,customer_lob:null,customer_segment:null,data:null,email_campaign:null,entitlement_code:null,error_category:null,error_count:null,first_login:null,inqSalesProductTypes:{},invitation_background:null,invitation_template:null,referral_campaign:null,getStateValue:false,cust_fn:null,cust_ln:null,target:null}}},user:{segment:null,online_id:null,preferred_rewards_tier:null,olb3rdpartyid:null},version:"BAC_0.12"}, DDO );

			DDO.page.pageInfo[0].pageID = "studentbanking:Content:resources;glossary";
			DDO.page.category.primaryCategory  = "studentbanking:Content:resources";
			DDO.page.pageInfo[0].language = "en-US";
			DDO.page.attributes.olbSessionID = "null";
			DDO.page.attributes.SASIEnabled =  "false";
			if (typeof DDO.user != "undefined" && typeof DDO.user.olb3rdpartyid != "undefined") {
				DDO.user.olb3rdpartyid = bactm_olb3rdPartyId;
			}

			window.utag_data = {};
			window.bactm_envSelector = bactm_setTMLib();
			window.digitalData = DDO;

      return fireCallback( callback );

    } catch(e) { }
  }
	if( window.boa && window.boa.digitalData ) {
    window.boa.digitalData.register( ddoPopulateBase );
	}
	else {
	  // Handle scenario where the header isn't available (and thus the default digitalData object and utag loader are missing).
	  //
		var writeScript = function(a,b,c,d){
			a='//tags.tiqcdn.com/utag/bofa/main/' + bactm_envSelector + '/utag.js';
			b=document;
			c='script';
			d=b.createElement(c);
			d.src=a;
			d.type='text/java'+c;
			d.async=true;
			a=b.getElementsByTagName(c)[0];
			a.parentNode.insertBefore(d,a);
		};

		ddoPopulateBase( writeScript );
	}
})();			
</script>





	
	
				<noscript>
				
					<div class="fauxdal-overlay"></div>
					<div class="fauxdal-module">
						<div class="js-disabled-skin">
							<div class="fauxdal-top"></div>
							<div class="fauxdal-bottom">
								<div class="fauxdal-content">
										<div class="fauxdal-title">
											Please Use JavaScript
										</div>
											<p>You need a web browser that supports JavaScript to use our site. Without it, some pages won&rsquo;t work as designed. To make sure JavaScript is turned on, please adjust your browser settings and refresh.</p><p><a title="Browser Help and Tips" name="Browser_Help_and_Tips" href="/onlinebanking/online-banking-security-faqs.go">Browser Help and Tips</a></p>
										
								</div>        
								<div class="fauxdal-close"> 
									<a class="btn-bofa btn-bofa-small" href=?js=y>Close</a>
								</div>
								
							</div>
						</div>
					</div>
				</noscript>



 


<div class="header-module">
	<div class="text-w-logo-skin">
		<div class="header-left">
	  
			<div itemscope itemtype="http://schema.org/Corporation" class="bofa-logo">
				<a itemprop="url" name="anc-student-banking" title="Bank of America Logo" href="/">
					<img itemprop="logo" height="28" width="221" 
					     alt="Bank of America Logo" src="https://www2.bac-assets.com/content/images/ContextualSiteGraphics/Logos/en_US/boa_logo.gif"/>
				</a>
			</div>
				<div class="product" data-font="cnx-regular">Student Banking</div>
			
			<div class="clearboth"></div>

		</div>
		
		<div class="header-right">
			<ul class="header-links">
			
				
					
				
							<li class="sign-in">
		<a					href="/sitemap/hub/signin.go" target="_self"
		name="sign_in">Sign In</a> 
							</li>
					
				
							<li>		<a					href="/" target="_self"
		name="home">Home</a> 
</li>
					
				
							<li>		<a					href="https://locators.bankofamerica.com" target="_self"
		name="locations">Locations</a> 
</li>
					
				
							<li>		<a					href="/contactus/contactus.go" target="_self"
		name="contact_us">Contact Us</a> 
</li>
					
				
							<li class="last-link">	
		<a					href="/student-banking/resources/student-banking-faqs.go" target="_self"
		name="help">Help</a> 
							</li>
			</ul>
			
			<div class="clearboth"></div>

			<!-- include search-dotcom-util -->



<div class="header-search nlh">
  
  <div class="nav-search">
    <form class="search-form" action="https://secure.bankofamerica.com/myaccounts/public/search-results/unAuthenticatedSearch.go" data-js="/pa/components/utilities/search-util/1.0/script/nav-search.min.js" data-css="/pa/components/utilities/search-util/1.0/style/nav-search.css" data-text-unavailable="Search Currently Unavailable">
      <div class="search-input-container cf" data-icon="search">
        <label for="nav-search-query" class="ada-hidden">Search Term</label>
        <input type="text" placeholder="How can we help you?" name="query" class="search-query" id="nav-search-query" 
          maxlength="99" rel="Search" autocomplete="off"><input type="submit" alt="Search" title="Search" value="Submit Search" name="Search Module - Top Result – Search Button" class="submit track-me">
      </div>
    </form>
  </div>

</div>

		</div>

 		<div class="clearboth"></div>
 	</div>
</div>







	<div class="top-nav-module">
		<div class="fsd-skin sup-ie">
			<ul class="nav-list">
					
					
					<li>
						
									<a href="/student-banking/overview.go" class="top-menu-item"
									name="overview_topnav" id="overview_topnav">Overview</a>
					</li>
					
					
					<li>
						
								<a href="/student-banking/solutions-for-students.go" class="top-menu-item"
								name="accounts_for_students_topnav" id="accounts_for_students_topnav">Accounts for Students<span class="ada-hidden"> link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/student-banking/solutions-for-students.go"  name="solutions_for_students_topnav" id="solutions_for_students_topnav">Solutions for Students </a>
															<a href="/student-banking/student-checking-savings-account.go"  name="checking_and_savings_topnav" id="checking_and_savings_topnav">Checking & Savings </a>
															<a href="/student-banking/student-credit-cards.go"  name="credit_cards_topnav" id="credit_cards_topnav">Credit Cards </a>
									</div>
								
									<div class="hasSub">
														<a class="with-info" href="/student-banking/online-mobile-banking.go"  name="mobile_and_online_banking_topnav" id="mobile_and_online_banking_topnav"><strong>Mobile &amp; Online Banking</strong> 
															
															<span class="sub-nav-item-info">Services designed for a student's on-the-go lifestyle</span>
														</a>
														<a class="with-info" href="/student-banking/resources/types-of-student-loans.go"  name="college_planning_topnav" id="college_planning_topnav"><strong>Student Loan Options</strong> 
															
															<span class="sub-nav-item-info">Find out about different types of student loans
</span>
														</a>
									</div>
									<span class="ada-hidden"> End of Submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
					
					
					<li>
						
								<a href="/planning/college.go" class="top-menu-item"
								name="college_planning_topnav" id="college_planning_topnav">College Planning<span class="ada-hidden"> link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/planning/college.go"  name="preparing_for_college_topnav" id="preparing_for_college_topnav">Preparing for College </a>
															<a href="/student-banking/saving-for-college.go"  name="saving_for_college_topnav" id="saving_for_college_topnav">Saving for College </a>
															<a href="/student-banking/financial-aid.go"  name="financial_aid_topnav" id="financial_aid_topnav">Financial Aid </a>
															<a href="/student-banking/managing-student-finances.go"  name="managing_student_finances_topnav" id="managing_student_finances_topnav">Managing Student Finances </a>
															<a href="/student-banking/resources/fafsa-form.go"  name="understanding_the_fafsa_form_topnav" id="understanding_the_fafsa_form_topnav">Understanding the FAFSA form </a>
									</div>
								
									<div class="hasSub">
									</div>
									<span class="ada-hidden"> End of Submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
					
					
					<li>
						
								<a href="/student-banking/resources/overview.go" class="top-menu-item selected"
								name="resources_topnav" id="resources_topnav">Resources<span class="ada-hidden"> link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/student-banking/resources/overview.go"  name="resources_overview_topnav" id="resources_overview_topnav"><span class="ada-hidden">Resources </span>Overview </a>
															<a href="/student-banking/resources/glossary.go"  name="glossary_topnav" id="glossary_topnav">Glossary </a>
															<a href="/student-banking/resources/student-banking-faqs.go"  name="faqs_topnav" id="faqs_topnav">FAQs </a>
									</div>
								
									<div class="hasSub">
														<a class="with-info" href="/student-banking/resources/shared-credit-cards.go"  name="banking_basics_topnav" id="banking_basics_topnav"><strong>Banking basics</strong> 
															
															<span class="sub-nav-item-info">Shared credit card accounts</span>
														</a>
														<a class="with-info" href="/student-banking/resources/building-your-credit-history.go"  name="after_college_topnav" id="after_college_topnav"><strong>After college</strong> 
															
															<span class="sub-nav-item-info">Building your credit history</span>
														</a>
									</div>
									<span class="ada-hidden"> End of Submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
			</ul>
				<div class="clearboth"></div>
		</div>
	</div>



<div class="page-title-fsd-module h-100" id="skip-to-h1">
	<div class="standard-red-skin sup-ie">
			<h1 data-font="cnx-regular">Student Banking Glossary</h1>
	</div>
</div>
<div class="olb-dsp-glossary-nav-module">
	<div class="nav-box" id="top-page">
			<a href="#alp-A" name="click-A">A</a>
			<a href="#alp-B" name="click-B">B</a>
			<a href="#alp-C" name="click-C">C</a>
			<a href="#alp-D" name="click-D">D</a>
			<a href="#alp-E" name="click-E">E</a>
			<a href="#alp-F" name="click-F">F</a>
			<a href="#alp-G" name="click-G">G</a>
			<span>H</span>
			<a href="#alp-I" name="click-I">I</a>
			<span>J</span>
			<span>K</span>
			<a href="#alp-L" name="click-L">L</a>
			<a href="#alp-M" name="click-M">M</a>
			<a href="#alp-N" name="click-N">N</a>
			<a href="#alp-O" name="click-O">O</a>
			<a href="#alp-P" name="click-P">P</a>
			<span>Q</span>
			<span>R</span>
			<a href="#alp-S" name="click-S">S</a>
			<a href="#alp-T" name="click-T">T</a>
			<a href="#alp-U" name="click-U">U</a>
			<a href="#alp-V" name="click-V">V</a>
			<span>W</span>
			<span>X</span>
			<span>Y</span>
			<span>Z</span>
	<div class="clearboth"></div>
	</div>
</div></div>
					<div class="columns">
						<div class="flex-col lt-col" >


<div class="olb-dsp-glossary-module">
   <div class="glossary-content">
			<div class="alp-A">
				<a name="alp-A" class="glossary-sub-section-title">A</a>
						<div class="bold" id="A_id_0">Academic scholarship</div>
						<p>A grant of financial aid awarded to a student to help pay for his or her education on the merits of academic performance.</p>
						<div class="bold" id="A_id_1">Accrued interest</div>
						<p>Interest that has accumulated on a loan but that has not yet been paid.</p>
						<div class="bold" id="A_id_2">Annuity</div>
						<p>A contract or agreement by which one receives fixed payments on an investment for a lifetime or for a specified number of years.</p>
						<div class="bold" id="A_id_3">APR (annual percentage rate)</div>
						<p>The APR (annual percentage rate) is the cost of credit expressed as a yearly rate. The APR is a measure of the total cost of credit, including interest, loan discount, origination fees, transaction charges, and premiums for credit-guarantee insurance; it is not an interest rate. The APR relates the amount and timing of value received by the borrower to the amount and timing of payments made by the borrower. The APR is designed to take into account all relevant factors and to provide a uniform measure for comparing the costs of similar credit transactions.</p>
						<div class="bold" id="A_id_4">Athletic scholarship</div>
						<p>A grant of financial aid awarded to a student to help pay for his or her education on the merits of athletic performance.</p>
						<div class="bold" id="A_id_5">ATM (automated teller machine)</div>
						<p>An ATM (automated teller machine) is a device activated by a debit or credit card. Generally, the cardholder must enter a code to perform transactions. An ATM can dispense cash, accept deposits, transfer funds between accounts and allow account inquiries, depending on the ATM application used.</p>
						<div class="bold" id="A_id_6">ATM card</div>
						<p>A card used in an ATM (automated teller machine) to access a credit or debit account to complete banking inquiries and fund transfers between accounts.</p>
					<div class="back-top"> <a class="back-to-top" href="#top-page">Back to top</a> </div>
					<div class="clearboth"></div>
			</div>
			<div class="alp-B">
				<a name="alp-B" class="glossary-sub-section-title">B</a>
						<div class="bold" id="B_id_0">Bankrupt</div>
						<p>The status of being legally declared unable to pay your debts as they become due. Federal bankruptcy laws allow a person or organization to liquidate assets in order to pay a reduced amount to their creditors. They also allow the rehabilitation of the debtor by requiring creditors to accept reduced payments from future earnings of the debtor. Student loans are generally non-dischargeable in bankruptcy. A declaration of bankruptcy will remain on a person's credit report from 7 to 10 years. Declaring bankruptcy is typically considered a last resort for addressing debt issues.</p>
						<div class="bold" id="B_id_1">Billing cycle</div>
						<p>The length of time between billing statements.</p>
					<div class="back-top"> <a class="back-to-top" href="#top-page">Back to top</a> </div>
					<div class="clearboth"></div>
			</div>
			<div class="alp-C">
				<a name="alp-C" class="glossary-sub-section-title">C</a>
						<div class="bold" id="C_id_0">Capitalization</div>
						<p>The addition of unpaid interest to the principal balance of a loan. When the interest is not paid as it accrues during periods of in-school status, the grace period, deferment, or forbearance, your lender may capitalize the interest. This increases the outstanding principal amount due on the loan and may cause your monthly payment amount to increase. Interest is then charged on that higher principal balance, increasing the overall cost of the loan.</p>
						<div class="bold" id="C_id_1">Cash advance</div>
						<p>A service provided to credit card holders to have the ability to access cash against their available credit on his or her card.</p>
						<div class="bold" id="C_id_2">CCCS (Consumer Credit Counseling Service)</div>
						<p>The CCCS is a nonprofit organization that has helped thousands of people get out of debt. CCCS counselors can advise you on how to develop a budget you can live with and can be invaluable in helping you negotiate repayment plans with your creditors. This service is confidential. To reach the CCCS, call 1.800.355.2227.</p>
						<div class="bold" id="C_id_3">Chip card</div>
						<p>Sometimes called a smart card, a chip card contains an electronic chip that allows the card to function in multiple ways: as a credit card, debit card, frequent buyer or rewards program card, ID card or any combination of these card types. Many college ID cards are chip cards.</p>
						<div class="bold" id="C_id_4">COA (cost of attendance)</div>
						<p>The total amount it will cost you to go to school determined by the school using rules established by law. COA includes tuition, fees, meals, housing costs, books, supplies, transportation and personal expenses.</p>
						<div class="bold" id="C_id_5">Co-branded card</div>
						<p>A credit card sponsored by both the issuing bank and a retail organization such as a department store or an airline. Cardholders may benefit through account enhancements that provide benefits such as discounts or free merchandise from the sponsoring merchant.</p>
						<div class="bold" id="C_id_6">Co-signer</div>
						<p>The person who agrees to take responsibility for making sure the loan is repaid. Co-signers must be able to demonstrate the ability to repay the loan if the borrower fails to pay it. Sometimes called a co-applicant, joint applicant or co-borrower.</p>
						<div class="bold" id="C_id_7">Credit card</div>
						<p>Unlike a charge card, a credit card allows you to carry over, or revolve, portions of your balance from month to month. However, even if you have a grace period on certain types of transactions, you will be assessed interest charges if you do not pay your balance in full. To protect your credit rating, always pay at least the minimum amount due by the payment due date.</p>
						<div class="bold" id="C_id_8">Credit line</div>
						<p>The most you can charge on your credit card account, including or taking into account fees and interest charges. When you receive a new credit card, you're usually issued a set credit line. Under some circumstances, your card issuer may increase or decrease your credit line.</p>
						<div class="bold" id="C_id_9">Credit rating</div>
						<p>A numeric expression of creditworthiness based upon an individual's present financial condition and past credit history.</p>
						<div class="bold" id="C_id_10">Credit report</div>
						<p>The record of your credit history, which includes information such as whether you pay your bills on time and how much debt you have. Your report is compiled by credit reporting agencies and released to lenders and others.</p>
						<div class="bold" id="C_id_11">Credit reporting agencies</div>
						<p>Credit reporting agencies collect and report vital facts about your financial habits, for example whether or not you pay your bills on time. These facts are then compiled into a credit report that can be accessed by potential creditors, employers, and others. The 3 major credit reporting agencies are:</p><p><span style="padding-left:40px">Equifax: </span><a class="new-window-hover com-interstitial-modal-link" rel="http://www.equifax.com" name="equifax_website_interstitial" href="javascript:void(0);" target="_self">www.equifax.com</a>, 1.800.685.1111</p><p><span style="padding-left:40px">TransUnion: </span><a class="new-window-hover com-interstitial-modal-link" rel="http://www.transunion.com" name="transunion_website_interstitial" href="javascript:void(0);" target="_self">www.transunion.com</a>, 1.800.888.4213</p><p><span style="padding-left:40px">Experian: </span><a class="new-window-hover com-interstitial-modal-link" rel="http://www.experian.com" name="experian_website_interstitial" href="javascript:void(0);" target="_self">www.experian.com</a>, 1.888.397.3742</p>
						<div class="bold" id="C_id_12">Credit score</div>
						<p>A number that rates the quality of an individual's credit. Credit reporting agencies calculate this number, often with the assistance of computer systems. The number helps predict the relative likelihood that a person will repay a credit obligation, such as a mortgage loan. In general, the higher your credit score, the more likely you are to be approved for and to pay a lower interest rate on a loan.</p>
						<div class="bold" id="C_id_13">CSS/Financial Aid PROFILE<sup>&reg;</sup></div>
						<p>A supplemental financial aid form, processed by The College Board, which is used by some colleges, universities and scholarship programs to determine eligibility for non-federal financial aid.</p>
					<div class="back-top"> <a class="back-to-top" href="#top-page">Back to top</a> </div>
					<div class="clearboth"></div>
			</div>
			<div class="alp-D">
				<a name="alp-D" class="glossary-sub-section-title">D</a>
						<div class="bold" id="D_id_0">Debit card</div>
						<p>With your checking account, you can request a Bank of America debit card. Use it to make purchases at merchants worldwide, make deposits to your account at deposit ATMs, and withdraw cash at ATMs wherever you are. This enhanced ATM card deducts money from your designated deposit account when you use it to make a purchase or get cash.</p>
						<div class="bold" id="D_id_1">Default</div>
						<p>Failure to repay a loan according to the agreed terms and conditions.</p>
						<div class="bold" id="D_id_2">Defer payment</div>
						<p>A contract option where the initial payment from the customer (usually due within 45 days of the contract date) is financed on the contract, thus allowing up to 180 days before the customer is obligated to send the first payment to the bank.</p>
						<div class="bold" id="D_id_3">Delinquency</div>
						<p>Failure to make payments on time; late fees may be charged.</p>
						<div class="bold" id="D_id_4">Demonstrated need</div>
						<p>The difference between the calculated EFC (expected family contribution) and the cost of college attendance is called demonstrated need. This is calculated each year and is based on an assessment of all financial data required by a given college as a student or family applies for financial aid for an academic year. Schools will be able to tell students what portion of demonstrated need they are able to meet in any given year.</p>
						<div class="bold" id="D_id_5">Dependent student</div>
						<p>A student who does not meet the criteria for an independent student or is claimed on the parents' income tax return.</p>
						<div class="bold" id="D_id_6">Digital wallet</div>
						<p>You can use the credit and debit cards stored in your digital wallet to make purchases at participating merchants.<br /><a href="/onlinebanking/mobile-wallet.go" name="student-banking-glossary-apple-pay" target="_self">Learn more about Apple Pay<sup>&reg;</sup> &raquo;</a><br /><a href="http://promo.bankofamerica.com/androidpay" name="student-banking-glossary-android-pay" target="_self">Learn more about Android Pay&trade; &raquo;</a><br /><a href="http://promo.bankofamerica.com/samsungpay" name="student-banking-glossary-samsung-pay" target="_self">Learn more about Samsung Pay &raquo;</a><br /><a href="http://promo.bankofamerica.com/microsoftwallet" name="anc-learn-more-about-microsoft-wallet" target="_self">Learn more about Microsoft&trade; Wallet &raquo;</a> <br /><a href="http://promo.bankofamerica.com/visa-checkout" name="student-banking-glossary-visa-checkout" target="_self">Learn more about Visa Checkout &raquo;</a><br /><a href="http://promo.bankofamerica.com/masterpass" name="student-banking-glossary-visa-checkout" target="_self">Learn more about Masterpass&trade; &raquo;</a></p>
						<div class="bold" id="D_id_7">Direct deposit</div>
						<p>The process by which a customer's regularly received payment is deposited automatically into his or her checking or savings account, for example Social Security payments.</p>
						<div class="bold" id="D_id_8">Disbursement</div>
						<p>Payment of loan proceeds by the lender.</p>
					<div class="back-top"> <a class="back-to-top" href="#top-page">Back to top</a> </div>
					<div class="clearboth"></div>
			</div>
			<div class="alp-E">
				<a name="alp-E" class="glossary-sub-section-title">E</a>
						<div class="bold" id="E_id_0">Educational IRA</div>
						<p>A custodial account or trust, usually maintained by a bank or financial organization, exclusively for the purpose of paying the qualified higher-education expenses of the designated beneficiary.</p>
						<div class="bold" id="E_id_1">Education tax credit</div>
						<p>A tax credit that can reduce the total tax burden of an individual or a business on a dollar-for-dollar basis.</p>
						<div class="bold" id="E_id_2">EFC (expected family contribution)</div>
						<p>The amount a student's family is expected to be able to contribute toward college costs, based on a federal formula. To calculate EFC, the government assesses the detailed financial information indicated on the FAFSA.</p>
						<div class="bold" id="E_id_3">Endorsed card</div>
						<p>A credit card endorsed by a group such as a college, sports team, professional organization or special interest group and offered to their alumni, fans or members. Typically, use of the credit card gives financial benefit to the endorsing organization.</p>
						<div class="bold" id="E_id_4">Equal Credit Opportunity Act</div>
						<p>Implemented by Federal Reserve Regulation B, this federal law protects your rights against being denied credit because of sex, race, color, age, national origin or religion. It also guarantees your right to have credit in your given name or your married name, the right to know why your credit application is rejected and the right to have someone other than your husband or wife co-sign for you.</p>
					<div class="back-top"> <a class="back-to-top" href="#top-page">Back to top</a> </div>
					<div class="clearboth"></div>
			</div>
			<div class="alp-F">
				<a name="alp-F" class="glossary-sub-section-title">F</a>
						<div class="bold" id="F_id_0">FAFSA (Free Application for Federal Student Aid)</div>
						<p>Application that students must complete to qualify for federal aid. This application must be resubmitted each year the student wishes to obtain financial aid.</p>
						<div class="bold" id="F_id_1">FAFSA4caster</div>
						<p>A tool provided by the federal government that helps students and their families to learn about the financial aid process and get an early estimate of their eligibility for federal student aid. <a class="new-window-hover com-interstitial-modal-link" rel="https://fafsa.ed.gov/" name="access_fafsa4caster_interstitial" href="javascript:void(0);" target="_self">Access the FAFSA4caster</a></p>
						<div class="bold" id="F_id_2">Fair Credit Billing Act</div>
						<p>A federal law that protects many important credit rights including your right to dispute billing errors, unauthorized use of your account and charges for unsatisfactory goods and services.</p>
						<div class="bold" id="F_id_3">Federal default fee</div>
						<p>Fee deducted from the loan proceeds and paid to the guaranty agency to cover the loan if the borrower defaults.</p>
						<div class="bold" id="F_id_4">The FFEL (Federal Family Education Loan) program</div>
						<p>This is the largest source of federal aid. Stafford, PLUS and Graduate PLUS loans are part of the FFEL program. The advantage of federal aid is that the government pays the interest on certain types of loans while the student is in school. Students don't have to make payments until they graduate, leave school or drop below half-time status.</p>
						<div class="bold" id="F_id_5">Federal student aid</div>
						<p>Need-based financial aid provided by the federal government, such as grants, loans and work-study programs.</p>
						<div class="bold" id="F_id_6">Financial aid</div>
						<p>Financial assistance intended to aid students in paying for education. This assistance may come in a variety of forms such as grants, scholarships, work-study and loan programs and may be provided by the federal government or by the student's college or university. Financial aid is available for qualifying students for a variety of qualifying schools, including community college programs and online programs.</p>
						<div class="bold" id="F_id_7">Forbearance</div>
						<p>A period during which your monthly loan payments are temporarily suspended or reduced. You may qualify for forbearance if you are willing but unable to make loan payments due to certain types of financial hardships. During forbearance, principal payments are postponed but interest continues to accrue. Accrued unpaid interest will be added to the principal balance (capitalized) of your loan(s) at the end of the forbearance period, increasing the total amount you owe.</p>
					<div class="back-top"> <a class="back-to-top" href="#top-page">Back to top</a> </div>
					<div class="clearboth"></div>
			</div>
			<div class="alp-G">
				<a name="alp-G" class="glossary-sub-section-title">G</a>
						<div class="bold" id="G_id_0">Gapping</div>
						<p>Also called unmet need. When a college or university does not, or cannot, make up the difference between the EFC (expected family contribution) and the cost of attendance, the college has gapped the student. In other words, the college has offered the student less than the demonstrated need in his or her award package.</p>
						<div class="bold" id="G_id_1">Grace period</div>
						<p>For student loans, the grace period is the set time period after borrowers graduate, leave school or drop below half-time enrollment during which the borrower doesn't need to make payments of principal or interest on certain loans. For a credit card, the grace period is the period of time that the issuer does not charge interest on certain types of transactions. Many credit cards have a grace period on purchases but not on balance transfers or cash advances.</p>
						<div class="bold" id="G_id_2">Grant</div>
						<p>A type of need-based financial aid that a student does not have to repay.</p>
						<div class="bold" id="G_id_3">Guarantor</div>
						<p>A guarantor is someone who pledges that a loan or other type of debt will be paid. Usually, a guarantor agrees to pay another person's debt should that person fail to do so. For example, if a parent co-signs a loan for a child, the parent could be considered a guarantor: If the child defaults on his or her debt, the parent would be held liable for the remainder of the loan.</p>
						<div class="bold" id="G_id_4">Guaranty agencies</div>
						<p>State agencies or private nonprofit institutions that insure student loans for lenders and help administer the FFEL program for the U.S. Department of Education.</p>
					<div class="back-top"> <a class="back-to-top" href="#top-page">Back to top</a> </div>
					<div class="clearboth"></div>
			</div>
			<div class="alp-I">
				<a name="alp-I" class="glossary-sub-section-title">I</a>
						<div class="bold" id="I_id_0">Inheritance</div>
						<p>Property passing at the owner's death to the heir or those entitled to receive the property.</p>
						<div class="bold" id="I_id_1">Interest</div>
						<p>A fee charged for borrowing money. Also refers to money that a financial institution may pay individuals for keeping their money in an account there (such as an interest-bearing savings account).</p>
						<div class="bold" id="I_id_2">Introductory APR</div>
						<p>A temporary low interest rate, expressed as an annual percentage rate, offered by credit providers to introduce you to their services. It will usually expire after a certain amount of time and may often be terminated based on your behavior, such as if you make a late payment. Be sure to check the details of the offer closely for any limitations on an introductory APR.</p>
						<div class="bold" id="I_id_3">Institutional financial aid</div>
						<p>Financial aid awarded to students by a college or university rather than the federal government. Most schools will require the student fill out the FAFSA, CSS/Financial Aid PROFILE<sup>&reg;</sup> and/or the school's own institutional aid application in order to be eligible for institutional aid.</p>
						<div class="bold" id="I_id_4">Investments</div>
						<p>Property or possessions acquired for future financial return or benefit.</p>
					<div class="back-top"> <a class="back-to-top" href="#top-page">Back to top</a> </div>
					<div class="clearboth"></div>
			</div>
			<div class="alp-L">
				<a name="alp-L" class="glossary-sub-section-title">L</a>
						<div class="bold" id="L_id_0">Liability</div>
						<p>Items which create, or could create, a monetary cost to their bearer, for example: debt service on mortgage debt, auto loans, consumer finance company debt, bank debt, or credit card debt.</p>
						<div class="bold" id="L_id_1">LIBOR (London interbank offered rates)</div>
						<p>Fixed interest rates set daily by 5 major London banks. LIBOR may be used by some banks instead of the prime rate to set APRs.</p>
					<div class="back-top"> <a class="back-to-top" href="#top-page">Back to top</a> </div>
					<div class="clearboth"></div>
			</div>
			<div class="alp-M">
				<a name="alp-M" class="glossary-sub-section-title">M</a>
						<div class="bold" id="M_id_0">Maintenance fees</div>
						<p>A charge made by a financial institution for keeping an account, a charge made to a deposit account if the minimum balance is not met or a recurring charge applied to deposit products to pay for their maintenance.</p>
						<div class="bold" id="M_id_1">Major scholarships</div>
						<p>A grant of financial aid offered to students who are pursuing a particular degree, major, credential or certificate.</p>
						<div class="bold" id="M_id_2">MPN (master promissory note)</div>
						<p>Legally binding contract between the borrower and lender that is valid for 10 years. Use of the MPN may eliminate the need to complete a new promissory note every year a loan is needed.</p>
						<div class="bold" id="M_id_3">Minimum payment</div>
						<p>The minimum amount a credit card holder is required to pay each billing period, based on that month's balance at the time of billing.</p>
						<div class="bold" id="M_id_4">Mobile wallet</div>
						<p>A mobile wallet, which is a type of digital wallet, stores your physical credit and debit cards in your mobile device as virtual cards, allowing you to make purchases at participating merchants.<br /><a href="/onlinebanking/mobile-wallet.go" name="student-banking-glossary-apple-pay" target="_self">Learn more about Apple Pay<sup>&reg;</sup> &raquo;</a><br /><a href="http://promo.bankofamerica.com/androidpay" name="student-banking-glossary-android-pay" target="_self">Learn more about Android Pay&trade; &raquo;</a><br /><a href="http://promo.bankofamerica.com/samsungpay" name="student-banking-glossary-samsung-pay" target="_self">Learn more about Samsung Pay &raquo;</a><br /><a href="http://promo.bankofamerica.com/microsoftwallet" name="anc-learn-more-about-microsoft-wallet" target="_self">Learn more about Microsoft&trade; Wallet &raquo;</a></p>
					<div class="back-top"> <a class="back-to-top" href="#top-page">Back to top</a> </div>
					<div class="clearboth"></div>
			</div>
			<div class="alp-N">
				<a name="alp-N" class="glossary-sub-section-title">N</a>
						<div class="bold" id="N_id_0">Need-based scholarship</div>
						<p>A grant of financial aid awarded to a student based on demonstrated financial need. These scholarships typically fall into 3 categories: private, service and institutional.</p>
						<div class="bold" id="N_id_1">Non-variable APR</div>
						<p>Unlike a variable APR (annual percentage rate), this type of APR does not automatically fluctuate based on changes in an index such as the prime rate or LIBOR. A non-variable or fixed APR does not mean that the rate is guaranteed not to change, though. Refer to your account terms for information on your issuer's ability to change the APR on your account.</p>
					<div class="back-top"> <a class="back-to-top" href="#top-page">Back to top</a> </div>
					<div class="clearboth"></div>
			</div>
			<div class="alp-O">
				<a name="alp-O" class="glossary-sub-section-title">O</a>
						<div class="bold" id="O_id_0">Origination fee</div>
						<p>Charge deducted from the loan proceeds and paid to the federal government or lender to partially offset the cost of the loan.</p>
						<div class="bold" id="O_id_1">Overdraft fees</div>
						<p>The dollar amount charged for overdrafts during the previous month or statement period.</p>
						<div class="bold" id="O_id_2">Overdraft protection</div>
						<p>A product feature that provides protection against overdrafts by linking a credit card, line of credit or a savings account to one or more eligible checking or Money Market Savings accounts. If the eligible checking or Money Market account is overdrawn, the linked account covers the fund deficit; transfers are usually made in certain dollar increments and charged to the credited account when the funds are transferred. Refer to the terms of your account for details.</p>
					<div class="back-top"> <a class="back-to-top" href="#top-page">Back to top</a> </div>
					<div class="clearboth"></div>
			</div>
			<div class="alp-P">
				<a name="alp-P" class="glossary-sub-section-title">P</a>
						<div class="bold" id="P_id_0">PLUS Loan (Parent Loan for Undergraduate Students)</div>
						<p>A low-interest student loan for parents of dependent undergraduate students. A version of the PLUS loan is also available for graduate students.</p>
						<div class="bold" id="P_id_1">Prepaid tuition</div>
						<p>College savings plans that are guaranteed to increase in value at the same rate as college tuition.</p>
						<div class="bold" id="P_id_2">Previous balance</div>
						<p>How much you owed your card issuer at the end of your last billing period.</p>
						<div class="bold" id="P_id_3">Prime rate</div>
						<p>The interest rate that banks charge their best customers when lending them money. The U.S. Prime Rate, as published daily by The Wall Street Journal, is based on a survey of the prime rates of the 10 largest banks in the United States. The U.S. Prime Rate is used by some financial institutions to calculate variable interest rates for credit cards. Changes in the U.S. Prime Rate influence changes in other rates, including mortgage interest rates.</p>
						<div class="bold" id="P_id_4">Principal</div>
						<p>The amount of money borrowed or remaining unpaid on a loan.</p>
						<div class="bold" id="P_id_5">Private loan</div>
						<p>Private loans are typically offered by private lenders like banks and are used by families when there is still a gap between the cost of attendance and what the government allows you to borrow.</p>
					<div class="back-top"> <a class="back-to-top" href="#top-page">Back to top</a> </div>
					<div class="clearboth"></div>
			</div>
			<div class="alp-S">
				<a name="alp-S" class="glossary-sub-section-title">S</a>
						<div class="bold" id="S_id_0">SAR (student aid report)</div>
						<p>A report that summarizes the information included in the FAFSA. The SAR is the notification of the student's expected family contribution (EFC) and eligibility for other types of federal financial aid.</p>
						<div class="bold" id="S_id_1">Secured card</div>
						<p>Often viewed as a good first credit card or a way to reestablish your credit rating, this kind of card is secured by money you deposit in a designated savings account. For instance, if you deposit $500, your credit card limit will generally be for that amount. If for some reason you cannot pay your credit card bills, your credit card issuer will be paid from the savings account.</p>
						<div class="bold" id="S_id_2">Servicing agency</div>
						<p>An organization that administers loans for lenders and secondary markets. A servicing agency issues monthly statements, handles billing and collects payments. If your lender transfers administrative tasks to a servicing agency, you'll receive your payment schedule from, and make your payments to, that agency.</p>
						<div class="bold" id="S_id_3">Smart card</div>
						<p>See: <a name="glossary_c_link" href="#alp-C" target="_self">Chip card</a>.</p>
						<div class="bold" id="S_id_4">State 529 plan</div>
						<p>A tax-advantaged investment vehicle designed to encourage saving for the future higher education expenses of a designated beneficiary.</p>
						<div class="bold" id="S_id_5">Subsidized interest</div>
						<p>Interest paid on certain types of federal student loans by the federal government while the student is in college or during grace and deferment periods.</p>
					<div class="back-top"> <a class="back-to-top" href="#top-page">Back to top</a> </div>
					<div class="clearboth"></div>
			</div>
			<div class="alp-T">
				<a name="alp-T" class="glossary-sub-section-title">T</a>
						<div class="bold" id="T_id_0">Transaction fees</div>
						<p>Fees charged when you make certain types of transactions. Transaction fees are typically assessed on balance transfers, cash advances and cash-like transactions such as money orders, wire transfers and casino gaming chips.</p>
						<div class="bold" id="T_id_1">Trusts</div>
						<p>A legal title to property held by one party for the benefit of another.</p>
						<div class="bold" id="T_id_2">Truth in Lending Act</div>
						<p>Implemented by Federal Reserve Regulation Z, this federal law protects you by making sure lenders tell you about the costs, terms and conditions at the time they offer you a loan or credit card.</p>
					<div class="back-top"> <a class="back-to-top" href="#top-page">Back to top</a> </div>
					<div class="clearboth"></div>
			</div>
			<div class="alp-U">
				<a name="alp-U" class="glossary-sub-section-title">U</a>
						<div class="bold" id="U_id_0">Unsubsidized interest</div>
						<p>Interest paid by the borrower on certain types of loans beginning on the date the loan is disbursed.</p>
					<div class="back-top"> <a class="back-to-top" href="#top-page">Back to top</a> </div>
					<div class="clearboth"></div>
			</div>
			<div class="alp-V">
				<a name="alp-V" class="glossary-sub-section-title">V</a>
						<div class="bold" id="V_id_0">Variable APR</div>
						<p>An APR (annual percentage rate) that changes periodically and is usually tied to a published rate such as LIBOR or the U.S. Prime Rate.</p>
						<div class="bold" id="V_id_1">Virtual card</div>
						<p>A virtual card is the digital form of your physical credit card and has a unique card number that's stored within a digital wallet.<br /><a href="/onlinebanking/mobile-wallet.go" name="student-banking-glossary-apple-pay" target="_self">Learn more about Apple Pay<sup>&reg;</sup> &raquo;</a><br /><a href="http://promo.bankofamerica.com/androidpay" name="student-banking-glossary-android-pay" target="_self">Learn more about Android Pay&trade; &raquo;</a><br /><a href="http://promo.bankofamerica.com/samsungpay" name="student-banking-glossary-samsung-pay" target="_self">Learn more about Samsung Pay &raquo;</a><br /><a href="http://promo.bankofamerica.com/microsoftwallet" name="anc-learn-more-about-microsoft-wallet" target="_self">Learn more about Microsoft&trade; Wallet &raquo;</a></p>
					<div class="back-top"> <a class="back-to-top" href="#top-page">Back to top</a> </div>
					<div class="clearboth"></div>
			</div>
	</div>
</div>



	<div class="hide com-interstitial-modal">
     	<h3>Important Notice</h3>
   		<div class="flex-modal-main-content">
   		
      		<p><strong>You're continuing to another website</strong></p>
      		<p>You're continuing to another website that Bank of America doesn't own or operate. Its owner is solely responsible for the website's content, offerings and level of security, so please refer to the website's posted privacy policy and terms of use.</p>
   	
   	<div class="flex-modal-buttons">
	      	<a href="javascript:void(0);" class="button-common button-blue" name="leaving_bank_modal_continue"><span>Continue</span></a>
	         
	      	<a href="javascript:void(0);" class="button-common button-gray close-com-interstitial" name="leaving_bank_modal_cancel"><span>Return to Bank of America</span></a>
	         
          <div class="clearboth"></div>
      </div>
   </div>
</div>

</div>
						<div class="flex-col rt-col" > <!-- code for preferred rewards pages -->

<div class="olb-dsp-state-selector-module">
    <div class="no-href-skin">
        <div class="sw-outer bg-none">
            <div class="sw-inner">
                <div class="sw-corner sw-tleft"></div>
                <div class="sw-corner sw-tright"></div>
                <div class="sw-corner sw-bleft"></div>
                <div class="sw-corner sw-bright"></div>
				<p class="pbtm-5">Information for 
					Virginia
				</p>
			  	<a name="anc-change-state" class="show-state-select-modal" rel="state-select-modal" href="javascript:void(0)">Change State <span class="ada-hidden">layer</span></a>
			</div>
            <div class="sw-bottom"></div>
        </div>      
    </div>
</div>


<!-- XSS attack Prevention -->
<script type="text/javascript">
</script>	


<div class="modal-content-module">
   <div class="state-select-skin">
      
	  
	<div class="state-select-modal hide" id="state-select-modal" >
	  
		<div class="modal-content">
            <h2>
				Select Your State
				<span class="ada-hidden"></span>
			</h2>
			<p>Please tell us where you bank so we can give you accurate rate and fee information for your location.</p>
			<form method="post" action="" name="submitState" id="submitState">
				<fieldset>
					<legend><span class="ada-hidden">State Selection Form</span></legend>
					<input type="hidden" name="requestedUrl" value="" />
					<label for="stateListId">Current State</label> 
					
<select name="stateListName" id="stateListId" class="select-box" title="Select a state" required="true">
    <option value=" "
    >Select state</option>
    <option value="AL">Alabama</option>
    <option value="AK">Alaska</option>
    <option value="AZ">Arizona</option>
    <option value="AR">Arkansas</option>
    <option value="CA">California</option>
    <option value="CO">Colorado</option>
    <option value="CT">Connecticut</option>
    <option value="DE">Delaware</option>
    <option value="DC">District of Columbia</option>
    <option value="FL">Florida</option>
    <option value="GA">Georgia</option>
    <option value="HI">Hawaii</option>
    <option value="ID">Idaho</option>
    <option value="IL">Illinois</option>
    <option value="IN">Indiana</option>
    <option value="IA">Iowa</option>
    <option value="KS">Kansas</option>
    <option value="KY">Kentucky</option>
    <option value="LA">Louisiana</option>
    <option value="ME">Maine</option>
    <option value="MD">Maryland</option>
    <option value="MA">Massachusetts</option>
    <option value="MI">Michigan</option>
    <option value="MN">Minnesota</option>
    <option value="MS">Mississippi</option>
    <option value="MO">Missouri</option>
    <option value="MT">Montana</option>
    <option value="NE">Nebraska</option>
    <option value="NV">Nevada</option>
    <option value="NH">New Hampshire</option>
    <option value="NJ">New Jersey</option>
    <option value="NM">New Mexico</option>
    <option value="NY">New York</option>
    <option value="NC">North Carolina</option>
    <option value="ND">North Dakota</option>
    <option value="OH">Ohio</option>
    <option value="OK">Oklahoma</option>
    <option value="OR">Oregon</option>
    <option value="PA">Pennsylvania</option>
    <option value="RI">Rhode Island</option>
    <option value="SC">South Carolina</option>
    <option value="SD">South Dakota</option>
    <option value="TN">Tennessee</option>
    <option value="TX">Texas</option>
    <option value="UT">Utah</option>
    <option value="VT">Vermont</option>
    <option value="VA">Virginia</option>
    <option value="WA">Washington</option>
    <option value="WV">West Virginia</option>
    <option value="WI">Wisconsin</option>
    <option value="WY">Wyoming</option>


</select>

						<a name="state_select_submit" class="btn-bofa btn-bofa-small state-select-modal-go-button" href="javascript:void(0);" >
							Go<span class="ada-hidden"> Button to be used after you select your state.</span>
						</a>
				</fieldset>
			</form>
			<div class="clearboth"></div>
         </div>
      </div>
   </div>
</div>


</div>
						<div class="clearboth"></div>
					</div>
					<div class="footer">
						<div class="footer-top">&nbsp;
<div class="disclaimers-module">
	<div class="fsd-skin sup-ie">
			<p>Apple and Apple Pay are trademarks of Apple Inc., registered in the U.S. and other countries. Android Pay is a trademark of Google Inc. Microsoft and Microsoft Wallet are trademarks of Microsoft Corporation.</p>
<p>Mastercard is a registered trademark, and Masterpass and the circles design are trademarks of Mastercard International Incorporated and are used by the issuer pursuant to license.</p>
	</div>
</div>

</div>
						<div class="footer-inner">





<div class="power-footer-module">
	<div class="flex-microdata-skin sup-ie">
			<div class="breadcrumbs">
			<div itemscope itemtype="http://schema.org/BreadcrumbList">
				<!-- breadcrumbs div -->
					<!-- Inside 1st breadcrumb -->
					<div itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="bold-arrow">
								<a itemprop="item" href="/" name="bank_of_america_breadcrumb" target="_self"><span itemprop="name">Bank of America</span><meta itemprop="position" content="1"/></a>
					</div>
					
						<!-- Inside 2nd breadcrumb -->
						<div itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="arrow">
									<a itemprop="item" href="/student-banking/overview.go" name="student_banking_breadcrumb" target="_self"><span itemprop="name">Student Banking</span><meta itemprop="position" content="2"/></a>
						</div>
				
					<!-- Inside 3rd breadcrumb -->
					<div itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="arrow">
								<a itemprop="item" name="resources_breadcrumb" href="/student-banking/resources/overview.go" target="_self">Resources</a>
					</div>
				
				<!-- Inside 4th breadcrumb -->
				<div itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
					<span itemprop="name">
						Student Banking Glossary
					</span>
					<meta itemprop="position" content="4" />
				</div>
				<div class="clearboth"></div>
			</div>
			</div>
		
			<!-- Inside power footer columns -->
			<div class="pf-columns">		   
						<div class="pf-col">
							<ul>
								<li>Solutions for Students</li>
										<li><a href="/student-banking/student-checking-savings-account.go" name="power_footer_checking_and_savings">Checking & Savings</a></li>
										<li><a href="/student-banking/student-credit-cards.go" name="power_footer_credit_cards">Credit Cards</a></li>
										<li><a href="/student-banking/online-mobile-banking.go" name="power_footer_mobile_and_online_banking">Mobile & Online Banking</a></li>
										<li><a href="/student-banking/solutions-for-students.go" name="power_footer_banking_options_students">Banking options for students</a></li>
							</ul>
						</div>
						<div class="pf-col">
							<ul>
								<li>Solutions for Parents</li>
										<li><a href="/student-banking/saving-for-college.go" name="saving_for_college">Saving for College</a></li>
										<li><a href="/student-banking/financial-aid.go" name="financial_aid">Financial Aid</a></li>
										<li><a href="/student-banking/managing-student-finances.go" name="managing_student_finances">Managing Student Finances</a></li>
							</ul>
						</div>
						<div class="pf-col">
							<ul>
								<li>Resources</li>
										<li><a href="/student-banking/resources/overview.go" name="sb-resource-loans-banking">Student loans & banking</a></li>
							</ul>
						</div>
					<div class="clearboth"></div>
			</div>
	</div>
</div>




 



		<div class="global-footer-module">
			<div class="fsd-skin">

				<div class="footer-bottom-left" style="float:left;max-width:66%;">
	    			<div class="gf-links">	          	
						
					
									
									<a  target="_self" href="/" 
									    name="global_footer_home">Home
									</a>
									
						
					
									
									<a  target="_self" href="/accessiblebanking/overview.go" 
									    name="global_footer_accessible_banking">Accessible Banking
									</a>
									
						
					
									
									<a  target="_self" href="/privacy/overview.go" 
									    name="global_footer_privacy_security">Privacy & Security
									</a>
									
						
					
									
									<a  target="_self" href="http://careers.bankofamerica.com/careershome.aspx" 
									    name="global_footer_careers">Careers
									</a>
									
						
					
									
									<a  target="_self" href="/sitemap/personal.go" 
									    name="global_footer_site_map">Site Map
									</a>
									
						
					
									<a href="javascript:void(0);" class="gf-last-link boa-dialog boa-com-info-layer-link" name="global_footer_advertising_practices_lnk" rel="global_footer_advertising_practices">Advertising Practices</a>
								<div id="global_footer_advertising_practices" class="hide">
									<h3>Advertising Practices</h3>
										<p>We strive to provide you with information about products and services you might find interesting and useful. Relationship-based ads and online behavioral advertising help us do that.</p>
<p>Here's how it works: We gather information about your online activities, such as the searches you conduct on our Sites and the pages you visit. This information may be used to deliver advertising on our Sites and offline (for example, by phone, email and direct mail) that's customized to meet specific interests you may have.</p>
<p>If you prefer that we do not use this information, you may <a onclick="$('.ui-dialog').remove();" name="WebsiteAdPractices_OptOut" href="/privacy/online-privacy-notice.go#advertising-on-our-sites" target="_blank">opt out of online behavioral advertising</a>. If you opt out, though, you may still receive generic advertising. In addition, financial advisors/Client Managers may continue to use information collected online to provide product and service information in accordance with account agreements.</p>
<p>Also, if you opt out of online behavioral advertising, you may still see ads when you sign in to your account, for example through Online Banking or MyMerrill. These ads are based on your specific account relationships with us.</p>
<p>To learn more about relationship-based ads, online behavioral advertising and our privacy practices, please review the <a onclick="$('.ui-dialog').remove();" name="WebsiteAdPractices_PrivacyNotice" href="/privacy/online-privacy-notice.go" target="_blank">Bank of America Online Privacy Notice</a> and our <a onclick="$('.ui-dialog').remove();" name="Online-privacy-faqs" href="/privacy/faq/online-privacy-faq.go" target="_blank">Online Privacy FAQs</a>.</p>
								</div>
						<div class="clearboth"></div>
	    			</div>
	      			<p>Bank of America, N.A. Member <acronym title="Federal Deposit Insurance Corporation">FDIC</acronym>. <a onclick="window.open('/help/equalhousing_popup.go','newwin','width=640,height=371,scrollbars=yes,resizable=yes,left=35,top=161'); return false;" name="equal_housing_lender" href="/help/equalhousing_popup.go" target="_blank">Equal Housing Lender<img src="https://www2.bac-assets.com/content/images/ContextualSiteGraphics/Logos/en_US/icon_equal_housing_lender.gif" alt="" width="14" height="9" /></a><br />&copy; 2017 Bank of America Corporation.</p>
         		</div>
         		<div class="footer-social-container" style="float:right;max-width:30%;padding-left:50px;padding-top:19px;">




<div class="boa-social-loader" data-loaded="false" data-platform="borneo"  data-options=''></div>

         		</div>
         		<div class="clearboth"></div>
  			</div>
		</div>




 
<script language="javascript" src="https://www2.bac-assets.com/pa/global-assets/external/coremetrics/hp/eluminate.js"></script>
<script language="javascript" src="https://www2.bac-assets.com/pa/global-assets/external/coremetrics/hp/cmdatatagutils.js"></script>


<script language="javascript">
	function cmSetDD(){var testString=window.location.href;if(testString.toLowerCase().indexOf('.bankofamerica.com')>-1){testString=testString.toLowerCase();var tempArr=testString.split('.bankofamerica.com');var tempStr=tempArr[0];if(tempStr.indexOf('\/\/')>-1){tempArr=tempStr.split('\/\/');tempStr=tempArr[1];if(tempStr.indexOf('.')>-1){tempArr=tempStr.split('.');tempStr=tempArr[0];var tempStrPt2=tempArr[1]}if(tempStr.indexOf('www')>-1){if(tempStr.indexOf('-')>-1){cmSetStaging()}else if(tempStrPt2!=null){if(tempStrPt2.indexOf('ecnp')>-1){cmSetStaging()}}else{cmSetProduction()}}else if(tempStr.indexOf('-')>-1){if(tempStr.indexOf('sitekey')>-1){if(tempStr=='sitekey'){cmSetProduction()}else{cmSetStaging()}}else{cmSetStaging()}}else if(tempStrPt2!=null){if(tempStrPt2.indexOf('ecnp')>-1){cmSetStaging()}}else{cmSetProduction()}}}}if(typeof cmSetStaging=='function'){cmSetDD()}
</script> 

		<script type="text/javascript">
			cmCreatePageviewTag('studentbanking:Content:resources;glossary', null, null, 'studentbanking:Content:resources', false, false, null, false, false, null, null, null, null, null, null, null, null, null, null, null, null);
		</script>

</div>
					</div>
				</div>
			</div>
		</div>
	</body>	
</html>

