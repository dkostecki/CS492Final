
 

				<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
				<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
				<head prefix="og:http://ogp.me/ns#">



<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<title>Bank of America Article - After College: Understanding Investments</title>


					<meta name="Keywords" CONTENT="student investing, getting statted with investments, new investors, basic investing, basic investing information, basic stocks info, basic bonds info, basic mutual funds info" />
					<meta name="Description" CONTENT="Stocks. Bonds. Mutual funds. CDs and more. We've assembled some basic information about different types of investments to help you understand basic investing options." />
					<meta property="og:type" CONTENT="website" />
					<meta property="og:site_name" CONTENT="Bank of America" />
					<meta property="og:url" CONTENT="https://www.bankofamerica.com/student-banking/resources/understanding-investments.go" />
					<meta property="og:title" CONTENT="After College&#58; Getting Started With Investments" />
					<meta property="og:description" CONTENT="Stocks. Bonds. Mutual funds. CDs and more. We've assembled some basic information about different types of investments to help you understand basic investing options." />
					<meta property="og:image" CONTENT="https://www.bankofamerica.com/content/images/ContextualSiteGraphics/Logos/en_US/80x150_flagscape_trans.gif" />


<link rel="shortcut icon" href="https://www2.bac-assets.com/pa/global-assets/1.0/graphic/favicon.ico" type="image/ico" />


		<link rel="stylesheet" type="text/css" media="all" href="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/APS-deposits/2017.03.0/style/global-aps-dp-jawr.css"/>
		<link rel="stylesheet" type="text/css" media="all" href="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/APS-deposits/2017.03.0/style/sb-aps-dp-jawr.css"/>
		
		<script type="text/javascript" src="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/APS-deposits/2017.03.0/script/global-aps-dp-jawr.js"></script>
		<script type="text/javascript" src="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/APS-deposits/2017.03.0/script/sb-aps-dp-jawr.js"></script>
		
			<script type="text/javascript">
				$(window).load(function(){asyncPrintCssInclude('https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/APS-deposits/2017.03.0/style/global-aps-dp-jawr-print.css');});
				$(window).load(function(){asyncPrintCssInclude('https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/APS-deposits/2017.03.0/style/sb-aps-dp-jawr-print.css');});
			</script>
<script type="text/javascript">
(function() {
	if (typeof mboxUpdate == "function") {
		var windowURL = window.location.href
	    windowURL = windowURL.slice( windowURL.indexOf('.')+1);
		windowURL = windowURL.split( '?' )[0];
		windowURL = windowURL.toLowerCase();
		//alert(windowURL);
		if (
		    //If no mboxes on page, mbox count will be < 1
		    (mboxFactoryDefault.getMboxes().length() < 1) &&  
			
			//Also check for high-volume pages that do not need global logging
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go") &&
			(windowURL != "bankofamerica.com/myaccounts/signin/signin.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/entry/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signonscreen.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatechallengeanswer.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatePassword.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/mobile/banking.go")&&
			(windowURL != "bankofamerica.com/content/preload/olb-myaccount-preload-jawr-module.htm")
			)
		{

			var mboxDiv = document.createElement("div");
			mboxDiv.id = "adobe_touch_clarity_replacement";
			mboxDiv.style.display = "none";
			if (document.body && document.body.firstChild) document.body.insertBefore(mboxDiv,document.body.firstChild);
			mboxDefine(mboxDiv.id,'bac_global_bottom');
			mboxUpdate('bac_global_bottom');
		}
	}	
})();
</script>

		<script src="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/Global/1.0/script/tealeafbundle.js" type="text/javascript"></script>
			<script>
				var boaPageDataJS = {};
					boaPageDataJS.isLLE = "false";
			</script>
				<style>body{display:none;}</style>
	</head>		

	<body class="fsd-layout-body">	

				<script type="text/javascript">if(self == top){var theBody=document.getElementsByTagName("body")[0];theBody.style.display="block";}else{top.location=self.location;}</script>
				<noscript><style>body{display:block;}</style></noscript>
					<a class='ada-hidden ada-visible-focus' href='#skip-to-h1' id='ada-skip-link'>Skip to main content</a>
		<div class="fsd-layout fsd-2c-600lt-layout">
			<div class="fsd-border">
				<div class="center-content">
					<div class="header">
		  



<script language="javascript" src="/pa/components/modules/tag-manager-module/1.1/script/tag-manager-module-borneo-global-skin.js"></script>
<script>

(function() {
  var fireCallback = function( cb ) {
    if ( typeof cb === "function" ) cb();
  };
  
  function ddoPopulateBase( callback ) {
    try {
		  var DDO = window.digitalData,
		  	bactm_mergeDDO = function( newDDO, priorDDO ) {
		  		if( typeof priorDDO === "undefined" ) {
				  	priorDDO = digitalData || {};
				  }

			    for (var l in newDDO) {
			        if (typeof priorDDO[l] === "undefined") {
			            priorDDO[l] = newDDO[l];
			        }
			        if (newDDO[l] !== null) {
			            if (typeof newDDO[l] === "object") {
			                bactm_mergeDDO(newDDO[l], priorDDO[l]);
			            } else {
			                priorDDO[l] = bactm_validateValue( newDDO[l] ) ? newDDO[l] : priorDDO[l];
			            }
			        }
			    }

			    return priorDDO;
				},
				bactm_olb3rdPartyId = "null";

			if (typeof DDO === "undefined") {
				var simpleDDO = { page: { pageInfo:[{ pageID: null }], attributes: {}, category: { primaryCategory: null }}};

				DDO = (typeof digitalData === "object") ? digitalData : simpleDDO; 
			}

				DDO = bactm_mergeDDO( {pageInstanceID:"notprod",load_coremetrics:false,load_opinionlabs:false,load_touchcommerce:true,load_audiencemanager:true,page:{pageInfo:[{pageID:null,destinationURL:null,referringURL:null,issueDate:null,language:null,segmentValue:null,appName:null,appStepNumber:null,appStepName:null,attr:"-_--_--_--_--_--_--_--_--_--_--_--_--_--_-"}],category:{primaryCategory:null,addlCategory:null,pageType:null},attributes:{searchString:null,searchResults:null,olbSessionID:null,subCampaignCode:null,DARTUrl:null,stateCookie:null,SASIEnabled:false,needOLBcookie:false,standardDART:[],standardDARTes:[],clickDART:[],clickDARTes:[],gaId:[],chat:{account_type:null,boa_associate:null,boa_retiree:null,customer_lob:null,customer_segment:null,data:null,email_campaign:null,entitlement_code:null,error_category:null,error_count:null,first_login:null,inqSalesProductTypes:{},invitation_background:null,invitation_template:null,referral_campaign:null,getStateValue:false,cust_fn:null,cust_ln:null,target:null}}},user:{segment:null,online_id:null,preferred_rewards_tier:null,olb3rdpartyid:null},version:"BAC_0.12"}, DDO );

			DDO.page.pageInfo[0].pageID = "studentbanking:Content:resources:after_college;understanding-investments";
			DDO.page.category.primaryCategory  = "studentbanking:Content:resources:after_college";
			DDO.page.pageInfo[0].language = "en-US";
			DDO.page.attributes.olbSessionID = "null";
			DDO.page.attributes.SASIEnabled =  "false";
			if (typeof DDO.user != "undefined" && typeof DDO.user.olb3rdpartyid != "undefined") {
				DDO.user.olb3rdpartyid = bactm_olb3rdPartyId;
			}

			window.utag_data = {};
			window.bactm_envSelector = bactm_setTMLib();
			window.digitalData = DDO;

      return fireCallback( callback );

    } catch(e) { }
  }
	if( window.boa && window.boa.digitalData ) {
    window.boa.digitalData.register( ddoPopulateBase );
	}
	else {
	  // Handle scenario where the header isn't available (and thus the default digitalData object and utag loader are missing).
	  //
		var writeScript = function(a,b,c,d){
			a='//tags.tiqcdn.com/utag/bofa/main/' + bactm_envSelector + '/utag.js';
			b=document;
			c='script';
			d=b.createElement(c);
			d.src=a;
			d.type='text/java'+c;
			d.async=true;
			a=b.getElementsByTagName(c)[0];
			a.parentNode.insertBefore(d,a);
		};

		ddoPopulateBase( writeScript );
	}
})();			
</script>





	
	
				<noscript>
				
					<div class="fauxdal-overlay"></div>
					<div class="fauxdal-module">
						<div class="js-disabled-skin">
							<div class="fauxdal-top"></div>
							<div class="fauxdal-bottom">
								<div class="fauxdal-content">
										<div class="fauxdal-title">
											Please Use JavaScript
										</div>
											<p>You need a web browser that supports JavaScript to use our site. Without it, some pages won&rsquo;t work as designed. To make sure JavaScript is turned on, please adjust your browser settings and refresh.</p><p><a title="Browser Help and Tips" name="Browser_Help_and_Tips" href="/onlinebanking/online-banking-security-faqs.go">Browser Help and Tips</a></p>
										
								</div>        
								<div class="fauxdal-close"> 
									<a class="btn-bofa btn-bofa-small" href=?js=y>Close</a>
								</div>
								
							</div>
						</div>
					</div>
				</noscript>



 


<div class="header-module">
	<div class="text-w-logo-skin">
		<div class="header-left">
	  
			<div itemscope itemtype="http://schema.org/Corporation" class="bofa-logo">
				<a itemprop="url" name="anc-student-banking" title="Bank of America Logo" href="/">
					<img itemprop="logo" height="28" width="221" 
					     alt="Bank of America Logo" src="https://www2.bac-assets.com/content/images/ContextualSiteGraphics/Logos/en_US/boa_logo.gif"/>
				</a>
			</div>
				<div class="product" data-font="cnx-regular">Student Banking</div>
			
			<div class="clearboth"></div>

		</div>
		
		<div class="header-right">
			<ul class="header-links">
			
				
					
				
							<li class="sign-in">
		<a					href="/sitemap/hub/signin.go" target="_self"
		name="sign_in">Sign In</a> 
							</li>
					
				
							<li>		<a					href="/" target="_self"
		name="home">Home</a> 
</li>
					
				
							<li>		<a					href="https://locators.bankofamerica.com" target="_self"
		name="locations">Locations</a> 
</li>
					
				
							<li>		<a					href="/contactus/contactus.go" target="_self"
		name="contact_us">Contact Us</a> 
</li>
					
				
							<li class="last-link">	
		<a					href="/student-banking/resources/student-banking-faqs.go" target="_self"
		name="help">Help</a> 
							</li>
			</ul>
			
			<div class="clearboth"></div>

			<!-- include search-dotcom-util -->



<div class="header-search nlh">
  
  <div class="nav-search">
    <form class="search-form" action="https://secure.bankofamerica.com/myaccounts/public/search-results/unAuthenticatedSearch.go" data-js="/pa/components/utilities/search-util/1.0/script/nav-search.min.js" data-css="/pa/components/utilities/search-util/1.0/style/nav-search.css" data-text-unavailable="Search Currently Unavailable">
      <div class="search-input-container cf" data-icon="search">
        <label for="nav-search-query" class="ada-hidden">Search Term</label>
        <input type="text" placeholder="How can we help you?" name="query" class="search-query" id="nav-search-query" 
          maxlength="99" rel="Search" autocomplete="off"><input type="submit" alt="Search" title="Search" value="Submit Search" name="Search Module - Top Result – Search Button" class="submit track-me">
      </div>
    </form>
  </div>

</div>

		</div>

 		<div class="clearboth"></div>
 	</div>
</div>







	<div class="top-nav-module">
		<div class="fsd-skin sup-ie">
			<ul class="nav-list">
					
					
					<li>
						
									<a href="/student-banking/overview.go" class="top-menu-item"
									name="overview_topnav" id="overview_topnav">Overview</a>
					</li>
					
					
					<li>
						
								<a href="/student-banking/solutions-for-students.go" class="top-menu-item"
								name="accounts_for_students_topnav" id="accounts_for_students_topnav">Accounts for Students<span class="ada-hidden"> link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/student-banking/solutions-for-students.go"  name="solutions_for_students_topnav" id="solutions_for_students_topnav">Solutions for Students </a>
															<a href="/student-banking/student-checking-savings-account.go"  name="checking_and_savings_topnav" id="checking_and_savings_topnav">Checking & Savings </a>
															<a href="/student-banking/student-credit-cards.go"  name="credit_cards_topnav" id="credit_cards_topnav">Credit Cards </a>
									</div>
								
									<div class="hasSub">
														<a class="with-info" href="/student-banking/online-mobile-banking.go"  name="mobile_and_online_banking_topnav" id="mobile_and_online_banking_topnav"><strong>Mobile &amp; Online Banking</strong> 
															
															<span class="sub-nav-item-info">Services designed for a student's on-the-go lifestyle</span>
														</a>
														<a class="with-info" href="/student-banking/resources/types-of-student-loans.go"  name="college_planning_topnav" id="college_planning_topnav"><strong>Student Loan Options</strong> 
															
															<span class="sub-nav-item-info">Find out about different types of student loans
</span>
														</a>
									</div>
									<span class="ada-hidden"> End of Submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
					
					
					<li>
						
								<a href="/planning/college.go" class="top-menu-item"
								name="college_planning_topnav" id="college_planning_topnav">College Planning<span class="ada-hidden"> link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/planning/college.go"  name="preparing_for_college_topnav" id="preparing_for_college_topnav">Preparing for College </a>
															<a href="/student-banking/saving-for-college.go"  name="saving_for_college_topnav" id="saving_for_college_topnav">Saving for College </a>
															<a href="/student-banking/financial-aid.go"  name="financial_aid_topnav" id="financial_aid_topnav">Financial Aid </a>
															<a href="/student-banking/managing-student-finances.go"  name="managing_student_finances_topnav" id="managing_student_finances_topnav">Managing Student Finances </a>
															<a href="/student-banking/resources/fafsa-form.go"  name="understanding_the_fafsa_form_topnav" id="understanding_the_fafsa_form_topnav">Understanding the FAFSA form </a>
									</div>
								
									<div class="hasSub">
									</div>
									<span class="ada-hidden"> End of Submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
					
					
					<li>
						
								<a href="/student-banking/resources/overview.go" class="top-menu-item selected"
								name="resources_topnav" id="resources_topnav">Resources<span class="ada-hidden"> link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/student-banking/resources/overview.go"  name="resources_overview_topnav" id="resources_overview_topnav"><span class="ada-hidden">Resources </span>Overview </a>
															<a href="/student-banking/resources/glossary.go"  name="glossary_topnav" id="glossary_topnav">Glossary </a>
															<a href="/student-banking/resources/student-banking-faqs.go"  name="faqs_topnav" id="faqs_topnav">FAQs </a>
									</div>
								
									<div class="hasSub">
														<a class="with-info" href="/student-banking/resources/shared-credit-cards.go"  name="banking_basics_topnav" id="banking_basics_topnav"><strong>Banking basics</strong> 
															
															<span class="sub-nav-item-info">Shared credit card accounts</span>
														</a>
														<a class="with-info" href="/student-banking/resources/building-your-credit-history.go"  name="after_college_topnav" id="after_college_topnav"><strong>After college</strong> 
															
															<span class="sub-nav-item-info">Building your credit history</span>
														</a>
									</div>
									<span class="ada-hidden"> End of Submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
			</ul>
				<div class="clearboth"></div>
		</div>
	</div>



<div class="page-title-fsd-module h-100" id="skip-to-h1">
	<div class="standard-red-skin sup-ie">
			<h1 data-font="cnx-regular">After College: Understanding Investments</h1>
	</div>
</div>
<div class="print-module-browser-dialog-skin" style=""> 
	<a href="javascript:window.print();" name="print">PRINT<span class="ada-hidden"> this page</span></a>
</div></div>
					<div class="columns">
						<div class="flex-col lt-col" ><div class="text-img-module">	<div class="text-info-skin">			<h2>You have some money you want to invest&mdash;now what?</h2>			<p class="summary">It's never too soon, even for students, to start investing money with the idea of someday buying a home or starting a business&mdash;or building a nest egg toward retirement.</p>									<p class="image">Before you invest anything, you have a lot of homework to do: You need to understand not just the types of investments that are available, but the risks involved with each investment. Here are some themes to keep in mind:</p>							<p><strong>Risk:</strong> Different types of investments have different degrees of risk for loss. Generally, the more risk you are willing to take, the greater your opportunity for potential returns. Unlike a deposit account at a bank, though,&nbsp;investments are not FDIC-insured, are not a deposit or other obligation of (or guaranteed by) a bank and are subject to investment risks, including possible loss of the principal amount invested. You could lose money with an investment.</p>
<p><strong>Time:</strong> How long do you plan on investing? 10 years? 20 years? 30 years? Do you anticipate needing to get to your money before your investment matures? The longer you leave the money in your investments alone, the more opportunity you will give it to grow in the long run. Remember, too: Some investment types penalize you if you touch your money before the investment matures.</p>
<p><strong>Diversification:</strong> Diversification means you spread your money among different investments to reduce risk. By doing this, you might be able to mitigate the effects of a meltdown within a particular investment type or industry. The more diversified your investments, the less any one investment can hurt you if it blows up. Please keep in mind that diversification and&nbsp;asset allocation don't ensure a profit or protect against loss in declining markets.</p>
<p><strong>Liquidity:</strong> You may have heard people talk about having &ldquo;liquid assets&rdquo; or &ldquo;being liquid.&rdquo; Liquidity simply means being able to buy or sell an asset or security at its current value, which may be more or less than its original cost. Assets that can be easily bought or sold are known as liquid assets&mdash;which are good if you have concerns about ever needing to quickly access the money you're investing.</p>
<p>We've assembled some basic information about the most common forms of investments, but this is only the very beginning of the information you need to know before you invest. Before making any investment decision, you should speak with a financial advisor and weigh all the pros and cons. Remember: When it comes to investing, there's no such thing as a sure thing.</p>													<div class="twenty-height"></div>	</div></div>



	<div class="main-well-content-module">
	   <div class="show-hide-alt-skin com-main-well-content table-vzd3-common table-vzd3-com table-vzd-alt-row sup-ie">	   	
	      		<div class="show-hide-all">
	      			<a href="javascript:void(0);" class="sh-show-all" name="show-all">Show all<span class="ada-hidden"> hidden sections</span></a>
	      			&nbsp;|&nbsp;
		 		<a href="javascript:void(0);" class="sh-hide-all" name="hide-all">Hide all<span class="ada-hidden"> expanded sections</span></a>
	      		</div>
		
			<ul class="sh-main">
				<li>
				<span class="sh-link closed"><a href="javascript:void(0);" name="Stocks"><span class="ada-hidden ada-action">Show</span> <span class="sh-link-text">Stocks</span></a></span>
				<div class="sh-content-area hide">
					<p>When you purchase an individual stock, you become part owner in a company. If the company does well, you might be able to sell your stock for a profit. With some stocks you may also get paid a dividend, which is simply a payment the company makes to its shareholders. However, if the company does poorly and its stock price falls, you may lose some or all of your investment.</p><p>Most stocks fall into these 2 main types:</p><p><strong>Common:</strong> If you own a common stock, you're usually entitled to attend the company's annual meetings and you'll get one vote per share you own to elect board members, who oversee the major decisions made by the company's management. Your dividends, if any, are variable and not guaranteed and, if the company goes bankrupt, you will be paid last, after the creditors, bondholders and preferred shareholders.</p><p><strong>Preferred:</strong> With preferred stocks, if the company does not do well, you will receive your dividends before common shareholders. However, you will not have the same voting rights as common stock holders, though this might vary depending on the company.</p><p>The most common way to purchase stocks is through an investment firm or brokerage. Fullservice brokerages offer advice on your investments and will manage your account for you. However, they can be pretty expensive. Discount brokerages won't give very much personal attention or advice, but they cost quite a bit less than a full-service brokerage</p><p>Another way to buy stocks is through your employer's direct stock purchase plan, if they offer one. These plans allow investors to buy shares of the company's stock directly from the company itself. Most have a minimum initial deposit but may be able to waive it if you agree to automatic monthly withdrawals from your checking or savings account. In some cases, you can even choose to have an amount taken directly from your paycheck.</p>                         
					</div>
				</li>
		
		
				<li>
				<span class="sh-link closed"><a href="javascript:void(0);" name="Bonds"><span class="ada-hidden ada-action">Show</span> <span class="sh-link-text">Bonds</span></a></span>
				<div class="sh-content-area hide">
					<p>When you purchase a bond, you're basically loaning money to a company or to the federal or local government. You're paid <a class="boa-dialog boa-com-info-layer-link" rel="glossary-popup-1" name="interest" href="javascript:void(0);">interest</a> for the use of that money during a specified period of time, generally a few months to 30 years.</p>
<p>If you hang on to a bond until it matures, the issuer guarantees that you'll receive the original amount you paid, plus interest. Bonds may pay better interest than savings accounts or CDs, but you need to make sure you're loaning your money to a strong, secure company. If repayment is guaranteed only by the issuer, you could lose part or all of your bond investment if the issuer fails.</p>
<p>The most common types of bonds include:</p>
<p><strong>Government bonds:</strong> These are issued by the federal or state government and include savings bonds and treasury bonds. These are relatively safe investments, but they yield lower interest rates than most other bond types.</p>
<p><strong>Municipal bonds:</strong> Also known as munis, this type of bond is sold by local governments, such as cities and towns. They are often exempt from tax, which means you may pay no taxes on any interest you earn. Certain investors&rsquo; income may be subject to the federal alternative minimum tax (AMT), and state and local taxes may also apply.</p>
<p><strong>Corporate bonds:</strong> Corporate bonds are issued by private and public corporations and are usually issued in multiples of $1,000 or $5,000. The interest payments you receive from corporate bonds are taxable and, unlike stocks, they don't give you an ownership interest in the company.</p>
<p><strong>Convertible bonds:</strong> A convertible bond can be converted into shares of stock in the company that issues the bond, usually at a pre-determined ratio.</p>
<p><strong>High-yield bonds:</strong> Also known as junk bonds, high-yield bonds are issued by organizations that don't qualify for investment-grade ratings by one of the leading credit rating agencies, meaning the issuer is considered to have a greater risk of not paying interest in a timely manner. These bonds pay higher interest rates, but are considered very risky.</p>
<p>You can purchase government bonds through a brokerage firm or, in some cases, directly from a government agency such as the Federal Reserve. If you're interested in purchasing other types of bonds, such as corporate bonds, you can do so through an investment firm or through a bond dealer.</p>
<p>It's important to note that investing in fixed-income securities may involve certain risks, including the credit quality of individual issuers, possible prepayments, market or economic developments and yields and share price fluctuations due to changes in interest rates. When interest rates go up, bond prices typically drop, and vice versa.</p>
				</div>
				</li>

		
				<li>
				<span class="sh-link closed"><a href="javascript:void(0);" name="Mutual_funds"><span class="ada-hidden ada-action">Show</span> <span class="sh-link-text">Mutual funds</span></a></span>
				<div class="sh-content-area hide">
					<p>Mutual funds are pools of money from different investors that are professionally managed. Mutual funds are typically invested in stocks or bonds, and you can usually buy mutual funds from an investment firm or directly from the fund. Mutual funds may offer less risk than individual stocks because they diversify your money by spreading it among multiple, professionally selected investments.</p>
<p>You can purchase mutual funds a few different ways. The least expensive way is directly through the fund company itself. Contact the fund company to request information and a prospectus for the fund or funds that you're interested in and ask what you need to do in order to make an investment in the fund. You can also purchase mutual funds from investment firms and brokerages. Keep in mind, though, that there will likely be some fees involved if you go through a third party to purchase mutual funds.</p>
				</div>
				</li>

		
				<li>
				<span class="sh-link closed"><a href="javascript:void(0);" name="401k_plans"><span class="ada-hidden ada-action">Show</span> <span class="sh-link-text">401(k) plans</span></a></span>
				<div class="sh-content-area hide">
					<p>A 401(k) plan is a retirement plan that is funded with your before-tax salary contributions and often with a matching contribution from your employer.</p>
<p>Here's how the tax benefit portion of this savings plan works. Let's say you have a job making $50,000 a year and you elect to put $5,000 into your 401(k) plan. Only $45,000 would be recognized as income on that year's income tax return. You would not have to pay taxes on the $5,000 you invested into your retirement account until it is withdrawn. If your employer has a matching program in which they contribute money into your 401(k) as part of your benefits package, you are not taxed on that money until it is withdrawn.</p>
<p>Tax savings and contributions from your employer. Sounds like a no-brainer, right? You might be surprised by how many people choose not to participate in their company's 401(k) plan despite the obvious advantages. For those who do chose to contribute to a 401(k) plan, the IRS determines a maximum amount that can be contributed from your pre-tax salary. Those limits may change on an annual basis. For more information and to learn what the current amounts are, visit <a href="javascript:void(0);" class="new-window-hover com-interstitial-modal-link" rel="http://www.irs.gov" name="irs_interstitial" target="_self">www.irs.gov<span class="ada-hidden"> layer</span></a>.</p>
<p>Once there is money in your 401(k) account, you usually can't make any withdrawals before age 59 1/2, unless you have a special circumstance. If you do make an early withdrawal from your account, you will have to pay a penalty, generally 10%, for doing so. You will also lose the additional value that money would have gained over time.</p>
<p>As part of managing your 401(k) plan, you will typically be given several different investment options, including mutual funds and employer stock. You have the opportunity to decide how to divide your money among the available options. The choices you make could have a huge impact on the value of your 401(k), so you should do some research before you make those investment choices.</p>
<p>Even if you don't plan to be in a particular job for long, it makes sense to take advantage of any 401(k) option you have. When you leave a job, you can generally move your 401(k) into your new employer's plan or into a different IRA.<a href="#footnote1" name="ira_footnote"><span class="ada-hidden">footnote</span><sup>1</sup></a></p>
				</div>
				</li>
			</ul>
	   </div>
	</div>

					<div id="glossary-popup-1" class="hide tabs-main-content">
						<h3>Interest</h3>
						<p>A fee charged for borrowing money. Also refers to money that a financial institution may pay individuals for keeping their money in an account there (such as an interest-bearing savings account).</p>
					</div>
		




	<div class="hide com-interstitial-modal">
     	<h3>Important Notice</h3>
   		<div class="flex-modal-main-content">
   		
      		<p><strong>You're continuing to another website</strong></p>
      		<p>You're continuing to another website that Bank of America doesn't own or operate. Its owner is solely responsible for the website's content, offerings and level of security, so please refer to the website's posted privacy policy and terms of use.</p>
   	
   	<div class="flex-modal-buttons">
	      	<a href="javascript:void(0);" class="button-common button-blue" name="leaving_bank_modal_continue"><span>Continue</span></a>
	         
	      	<a href="javascript:void(0);" class="button-common button-gray close-com-interstitial" name="leaving_bank_modal_cancel"><span>Return to Bank of America</span></a>
	         
          <div class="clearboth"></div>
      </div>
   </div>
</div>


	<div class="main-well-content-module">
		<div class="article-skin com-main-well-content">		
<br />This article is provided by <a href="https://www.merrilledge.com/m/pages/home.aspx?src_cd=bac_student_banking" target="_self">Merrill Edge</a>, providers of streamlined and simplified online investment services and products.	
							
		</div>
		
	</div>


<div class="page-navigation-module">	<div class="link-w-gray-dotted-skin">			<div class="thirty-height"></div>		<div class="boa-brd-top"></div>			<div>				<a href="/student-banking/resources/overview.go" name="return_resources_menu_link" class="left-link"><span class="guillemet guillement-set">&#8249;&#8249;</span> Return to resources menu</a>			</div>		<div class="clear-both"></div>	</div></div>	<script type="text/javascript" src="https://www.bankofamerica.com/pa/components/modules/social-widget-module/1.2.5/script/socialplugin.js"></script>
	





<div class="social-widget-module">
	<div class="social-widget-inner" style="margin:22px 0px 3px 0px;">
		
			<div id="sharebar">
				 <script type="text/javascript">
				new com.bofa.socialplugin.core.ShareBarPlugin().display({
						"socialplugin_apppath" : "https://www.bankofamerica.com/pa/components/modules/social-widget-module/1.2.5",
						"socialconfig_apppath" : "https://www.bankofamerica.com/content/social",
						"gigyaApiKey" : "3_tIhxOOqZ3o4KC8r_VvalOR-b72A08kp4a1vdf6uyaSH4VTdeKCqMmAwh7n7AX4gz",
						"elementId" : "sharebar",
						"type" : "bottom600",
						"showCounters" : true,
						"enablePrint" : false,
						"contentOverride"	: {
							"facebook" : { "showCounter": false , "tinyUrlCode": '2zt8k' },
							"twitter"  : { "showCounter": false , "tinyUrlCode": '78uvc' },
							"linkedin"  : { "showCounter": false , "tinyUrlCode": 'nzgf9' },
							"digg"  : { "showCounter": false },
							"delicious"  : { "showCounter": false },
							"reddit"  : { "showCounter": false },
							"stumbleupon"  : { "showCounter": false },
							"pinterest"  : { "showCounter": false }
						}
					});
				 </script>
			</div>

	</div>
</div></div>
						<div class="flex-col rt-col" >

<div class="side-well-module">
    <div class="img-header-skin" style="">
        <div class="sw-outer bg-none">
            <div class="sw-inner">
                <h2><span class="ada-hidden">Merrill Edge - Bank of America Corporation</span>
                    <img src="/content/images/ContextualSiteGraphics/Marketing/Highlights/en_US/merrill-logo-w-bac.png" alt="Merrill Edge Logo" style="width:150px;" />
                </h2>
					<p>Looking for more ways to invest? Select from thousands of mutual funds, plus ETFs, stocks, bonds, and other investments</p>
<p><a class="style-link guillemet-right" name="merrill-edge-sw-link2" href="http://www.merrilledge.com/why-merrill-edge?src_cd=bac_deposits_savings" target="_blank">Learn more<span class="ada-hidden"> about Merrill Edge investments</span></a></p>
                
            </div>
        </div>
    </div>
</div>

 <!-- code for preferred rewards pages -->

<div class="olb-dsp-state-selector-module">
    <div class="no-href-skin">
        <div class="sw-outer bg-none">
            <div class="sw-inner">
                <div class="sw-corner sw-tleft"></div>
                <div class="sw-corner sw-tright"></div>
                <div class="sw-corner sw-bleft"></div>
                <div class="sw-corner sw-bright"></div>
				<p class="pbtm-5">Information for 
					Virginia
				</p>
			  	<a name="anc-change-state" class="show-state-select-modal" rel="state-select-modal" href="javascript:void(0)">Change State <span class="ada-hidden">layer</span></a>
			</div>
            <div class="sw-bottom"></div>
        </div>      
    </div>
</div>


<!-- XSS attack Prevention -->
<script type="text/javascript">
</script>	


<div class="modal-content-module">
   <div class="state-select-skin">
      
	  
	<div class="state-select-modal hide" id="state-select-modal" >
	  
		<div class="modal-content">
            <h2>
				Select Your State
				<span class="ada-hidden"></span>
			</h2>
			<p>Please tell us where you bank so we can give you accurate rate and fee information for your location.</p>
			<form method="post" action="" name="submitState" id="submitState">
				<fieldset>
					<legend><span class="ada-hidden">State Selection Form</span></legend>
					<input type="hidden" name="requestedUrl" value="" />
					<label for="stateListId">Current State</label> 
					
<select name="stateListName" id="stateListId" class="select-box" title="Select a state" required="true">
    <option value=" "
    >Select state</option>
    <option value="AL">Alabama</option>
    <option value="AK">Alaska</option>
    <option value="AZ">Arizona</option>
    <option value="AR">Arkansas</option>
    <option value="CA">California</option>
    <option value="CO">Colorado</option>
    <option value="CT">Connecticut</option>
    <option value="DE">Delaware</option>
    <option value="DC">District of Columbia</option>
    <option value="FL">Florida</option>
    <option value="GA">Georgia</option>
    <option value="HI">Hawaii</option>
    <option value="ID">Idaho</option>
    <option value="IL">Illinois</option>
    <option value="IN">Indiana</option>
    <option value="IA">Iowa</option>
    <option value="KS">Kansas</option>
    <option value="KY">Kentucky</option>
    <option value="LA">Louisiana</option>
    <option value="ME">Maine</option>
    <option value="MD">Maryland</option>
    <option value="MA">Massachusetts</option>
    <option value="MI">Michigan</option>
    <option value="MN">Minnesota</option>
    <option value="MS">Mississippi</option>
    <option value="MO">Missouri</option>
    <option value="MT">Montana</option>
    <option value="NE">Nebraska</option>
    <option value="NV">Nevada</option>
    <option value="NH">New Hampshire</option>
    <option value="NJ">New Jersey</option>
    <option value="NM">New Mexico</option>
    <option value="NY">New York</option>
    <option value="NC">North Carolina</option>
    <option value="ND">North Dakota</option>
    <option value="OH">Ohio</option>
    <option value="OK">Oklahoma</option>
    <option value="OR">Oregon</option>
    <option value="PA">Pennsylvania</option>
    <option value="RI">Rhode Island</option>
    <option value="SC">South Carolina</option>
    <option value="SD">South Dakota</option>
    <option value="TN">Tennessee</option>
    <option value="TX">Texas</option>
    <option value="UT">Utah</option>
    <option value="VT">Vermont</option>
    <option value="VA">Virginia</option>
    <option value="WA">Washington</option>
    <option value="WV">West Virginia</option>
    <option value="WI">Wisconsin</option>
    <option value="WY">Wyoming</option>


</select>

						<a name="state_select_submit" class="btn-bofa btn-bofa-small state-select-modal-go-button" href="javascript:void(0);" >
							Go<span class="ada-hidden"> Button to be used after you select your state.</span>
						</a>
				</fieldset>
			</form>
			<div class="clearboth"></div>
         </div>
      </div>
   </div>
</div>


</div>
						<div class="clearboth"></div>
					</div>
					<div class="footer">
						<div class="footer-top">&nbsp;</div>
						<div class="footer-inner">

<div class="footnote-com-module">
   <div class="fsd-layout-skin sup-ie">
   
   <script>
		$(function() {
			if ($('.footnote-com-module .fsd-layout-skin').text().length > 10) {
				$('.footnote-com-module .fsd-layout-skin').addClass('wfootnote');
			}
		});
	</script>
   
					<div class="h-100">
						<div class="footnote" id="footnote1">
							<div class="fn-num">1.</div>
							<div class="fn-text">If you have a professional advisor, we also recommend that you review any planned financial transactions or arrangements that may have tax, accounting or legal implications. </div>
							<div class="clearboth"></div>
						</div>
					</div>
   </div>
</div>

<div class="disclaimers-module">
	<div class="fsd-skin sup-ie">
			<p>Merrill Lynch is the marketing name for Merrill Lynch Wealth Management and Merrill Edge which are made available through Merrill Lynch, Pierce, Fenner &amp; Smith Incorporated (MLPF&amp;S).</p><p>Merrill Lynch Wealth Management makes available products and services offered by MLPF&amp;S and other subsidiaries of Bank of America Corporation. Merrill Edge is the marketing name for two businesses: Merrill Edge Advisory Center, which offers team-based advice and guidance brokerage services; and a self-directed online investing platform.</p><p>Investment products:</p><table border="0"><tbody><tr><td>Are Not FDIC Insured</td><td>Are Not Bank Guaranteed</td><td>May Lose Value</td></tr></tbody></table><p>MLPF&amp;S is a registered broker-dealer, Member SIPC and a wholly-owned subsidiary of Bank of America Corporation.<br />Banking products are provided by Bank of America, N.A. and affiliated banks. Members FDIC and wholly-owned subsidiaries of Bank of America Corporation.</p>
	</div>
</div>






<div class="power-footer-module">
	<div class="flex-microdata-skin sup-ie">
			<div class="breadcrumbs">
			<div itemscope itemtype="http://schema.org/BreadcrumbList">
				<!-- breadcrumbs div -->
					<!-- Inside 1st breadcrumb -->
					<div itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="bold-arrow">
								<a itemprop="item" href="/" name="bank_of_america_breadcrumb" target="_self"><span itemprop="name">Bank of America</span><meta itemprop="position" content="1"/></a>
					</div>
					
						<!-- Inside 2nd breadcrumb -->
						<div itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="arrow">
									<a itemprop="item" href="/student-banking/overview.go" name="student_banking_breadcrumb" target="_self"><span itemprop="name">Student Banking</span><meta itemprop="position" content="2"/></a>
						</div>
				
					<!-- Inside 3rd breadcrumb -->
					<div itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="arrow">
								<a itemprop="item" name="resources_breadcrumb" href="/student-banking/resources/overview.go" target="_self">Resources</a>
					</div>
				
				<!-- Inside 4th breadcrumb -->
				<div itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
					<span itemprop="name">
						After College: Understanding Investments
					</span>
					<meta itemprop="position" content="4" />
				</div>
				<div class="clearboth"></div>
			</div>
			</div>
		
			<!-- Inside power footer columns -->
			<div class="pf-columns">		   
						<div class="pf-col">
							<ul>
								<li>Solutions for Students</li>
										<li><a href="/student-banking/student-checking-savings-account.go" name="power_footer_checking_and_savings">Checking & Savings</a></li>
										<li><a href="/student-banking/student-credit-cards.go" name="power_footer_credit_cards">Credit Cards</a></li>
										<li><a href="/student-banking/online-mobile-banking.go" name="power_footer_mobile_and_online_banking">Mobile & Online Banking</a></li>
										<li><a href="/student-banking/solutions-for-students.go" name="power_footer_banking_options_students">Banking options for students</a></li>
							</ul>
						</div>
						<div class="pf-col">
							<ul>
								<li>Solutions for Parents</li>
										<li><a href="/student-banking/saving-for-college.go" name="saving_for_college">Saving for College</a></li>
										<li><a href="/student-banking/financial-aid.go" name="financial_aid">Financial Aid</a></li>
										<li><a href="/student-banking/managing-student-finances.go" name="managing_student_finances">Managing Student Finances</a></li>
							</ul>
						</div>
						<div class="pf-col">
							<ul>
								<li>Resources</li>
										<li><a href="/student-banking/resources/overview.go" name="sb-resource-loans-banking">Student loans & banking</a></li>
							</ul>
						</div>
					<div class="clearboth"></div>
			</div>
	</div>
</div>




 



		<div class="global-footer-module">
			<div class="fsd-skin">

				<div class="footer-bottom-left" style="float:left;max-width:66%;">
	    			<div class="gf-links">	          	
						
					
									
									<a  target="_self" href="/" 
									    name="global_footer_home">Home
									</a>
									
						
					
									
									<a  target="_self" href="/accessiblebanking/overview.go" 
									    name="global_footer_accessible_banking">Accessible Banking
									</a>
									
						
					
									
									<a  target="_self" href="/privacy/overview.go" 
									    name="global_footer_privacy_security">Privacy & Security
									</a>
									
						
					
									
									<a  target="_self" href="http://careers.bankofamerica.com/careershome.aspx" 
									    name="global_footer_careers">Careers
									</a>
									
						
					
									
									<a  target="_self" href="/sitemap/personal.go" 
									    name="global_footer_site_map">Site Map
									</a>
									
						
					
									<a href="javascript:void(0);" class="gf-last-link boa-dialog boa-com-info-layer-link" name="global_footer_advertising_practices_lnk" rel="global_footer_advertising_practices">Advertising Practices</a>
								<div id="global_footer_advertising_practices" class="hide">
									<h3>Advertising Practices</h3>
										<p>We strive to provide you with information about products and services you might find interesting and useful. Relationship-based ads and online behavioral advertising help us do that.</p>
<p>Here's how it works: We gather information about your online activities, such as the searches you conduct on our Sites and the pages you visit. This information may be used to deliver advertising on our Sites and offline (for example, by phone, email and direct mail) that's customized to meet specific interests you may have.</p>
<p>If you prefer that we do not use this information, you may <a onclick="$('.ui-dialog').remove();" name="WebsiteAdPractices_OptOut" href="/privacy/online-privacy-notice.go#advertising-on-our-sites" target="_blank">opt out of online behavioral advertising</a>. If you opt out, though, you may still receive generic advertising. In addition, financial advisors/Client Managers may continue to use information collected online to provide product and service information in accordance with account agreements.</p>
<p>Also, if you opt out of online behavioral advertising, you may still see ads when you sign in to your account, for example through Online Banking or MyMerrill. These ads are based on your specific account relationships with us.</p>
<p>To learn more about relationship-based ads, online behavioral advertising and our privacy practices, please review the <a onclick="$('.ui-dialog').remove();" name="WebsiteAdPractices_PrivacyNotice" href="/privacy/online-privacy-notice.go" target="_blank">Bank of America Online Privacy Notice</a> and our <a onclick="$('.ui-dialog').remove();" name="Online-privacy-faqs" href="/privacy/faq/online-privacy-faq.go" target="_blank">Online Privacy FAQs</a>.</p>
								</div>
						<div class="clearboth"></div>
	    			</div>
	      			<p>Bank of America, N.A. Member <acronym title="Federal Deposit Insurance Corporation">FDIC</acronym>. <a onclick="window.open('/help/equalhousing_popup.go','newwin','width=640,height=371,scrollbars=yes,resizable=yes,left=35,top=161'); return false;" name="equal_housing_lender" href="/help/equalhousing_popup.go" target="_blank">Equal Housing Lender<img src="https://www2.bac-assets.com/content/images/ContextualSiteGraphics/Logos/en_US/icon_equal_housing_lender.gif" alt="" width="14" height="9" /></a><br />&copy; 2017 Bank of America Corporation.</p>
         		</div>
         		<div class="footer-social-container" style="float:right;max-width:30%;padding-left:50px;padding-top:19px;">




<div class="boa-social-loader" data-loaded="false" data-platform="borneo"  data-options=''></div>

         		</div>
         		<div class="clearboth"></div>
  			</div>
		</div>




 
<script language="javascript" src="https://www2.bac-assets.com/pa/global-assets/external/coremetrics/hp/eluminate.js"></script>
<script language="javascript" src="https://www2.bac-assets.com/pa/global-assets/external/coremetrics/hp/cmdatatagutils.js"></script>


<script language="javascript">
	function cmSetDD(){var testString=window.location.href;if(testString.toLowerCase().indexOf('.bankofamerica.com')>-1){testString=testString.toLowerCase();var tempArr=testString.split('.bankofamerica.com');var tempStr=tempArr[0];if(tempStr.indexOf('\/\/')>-1){tempArr=tempStr.split('\/\/');tempStr=tempArr[1];if(tempStr.indexOf('.')>-1){tempArr=tempStr.split('.');tempStr=tempArr[0];var tempStrPt2=tempArr[1]}if(tempStr.indexOf('www')>-1){if(tempStr.indexOf('-')>-1){cmSetStaging()}else if(tempStrPt2!=null){if(tempStrPt2.indexOf('ecnp')>-1){cmSetStaging()}}else{cmSetProduction()}}else if(tempStr.indexOf('-')>-1){if(tempStr.indexOf('sitekey')>-1){if(tempStr=='sitekey'){cmSetProduction()}else{cmSetStaging()}}else{cmSetStaging()}}else if(tempStrPt2!=null){if(tempStrPt2.indexOf('ecnp')>-1){cmSetStaging()}}else{cmSetProduction()}}}}if(typeof cmSetStaging=='function'){cmSetDD()}
</script> 

		<script type="text/javascript">
			cmCreatePageviewTag('studentbanking:Content:resources:after_college;understanding-investments', null, null, 'studentbanking:Content:resources:after_college', false, false, null, false, false, null, null, null, null, null, null, null, null, null, null, null, null);
		</script>

</div>
					</div>
				</div>
			</div>
		</div>
	</body>	
</html>

