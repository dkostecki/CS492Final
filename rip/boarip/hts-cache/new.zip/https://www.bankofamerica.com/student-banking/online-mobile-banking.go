
 

				<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
				<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
				<head>



<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<title>Student Banking: Mobile & Online Banking for Students at Bank of America</title>


					<meta name="Keywords" CONTENT="mobile banking, online banking, mobile banking app, money transfers, mobile transfers, mobile bill payments" />
					<meta name="Description" CONTENT="With Mobile and Online Banking from Bank of America, you can manage your money on your schedule." />


<link rel="shortcut icon" href="https://www2.bac-assets.com/pa/global-assets/1.0/graphic/favicon.ico" type="image/ico" />


		<link rel="stylesheet" type="text/css" media="all" href="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/APS-deposits/2017.03.0/style/global-aps-dp-jawr.css"/>
		<link rel="stylesheet" type="text/css" media="all" href="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/APS-deposits/2017.03.0/style/sb-aps-dp-jawr.css"/>
		
		<script type="text/javascript" src="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/APS-deposits/2017.03.0/script/global-aps-dp-jawr.js"></script>
		<script type="text/javascript" src="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/APS-deposits/2017.03.0/script/sb-aps-dp-jawr.js"></script>
		
			<script type="text/javascript">
				$(window).load(function(){asyncPrintCssInclude('https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/APS-deposits/2017.03.0/style/global-aps-dp-jawr-print.css');});
				$(window).load(function(){asyncPrintCssInclude('https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/APS-deposits/2017.03.0/style/sb-aps-dp-jawr-print.css');});
			</script>
<script type="text/javascript">
(function() {
	if (typeof mboxUpdate == "function") {
		var windowURL = window.location.href
	    windowURL = windowURL.slice( windowURL.indexOf('.')+1);
		windowURL = windowURL.split( '?' )[0];
		windowURL = windowURL.toLowerCase();
		//alert(windowURL);
		if (
		    //If no mboxes on page, mbox count will be < 1
		    (mboxFactoryDefault.getMboxes().length() < 1) &&  
			
			//Also check for high-volume pages that do not need global logging
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go") &&
			(windowURL != "bankofamerica.com/myaccounts/signin/signin.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/entry/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signonscreen.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatechallengeanswer.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatePassword.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/mobile/banking.go")&&
			(windowURL != "bankofamerica.com/content/preload/olb-myaccount-preload-jawr-module.htm")
			)
		{

			var mboxDiv = document.createElement("div");
			mboxDiv.id = "adobe_touch_clarity_replacement";
			mboxDiv.style.display = "none";
			if (document.body && document.body.firstChild) document.body.insertBefore(mboxDiv,document.body.firstChild);
			mboxDefine(mboxDiv.id,'bac_global_bottom');
			mboxUpdate('bac_global_bottom');
		}
	}	
})();
</script>

		<script src="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/Global/1.0/script/tealeafbundle.js" type="text/javascript"></script>
			<script>
				var boaPageDataJS = {};
					boaPageDataJS.isLLE = "false";
			</script>
				<style>body{display:none;}</style>
	</head>	

	<body class="fsd-layout-body">	

				<script type="text/javascript">if(self == top){var theBody=document.getElementsByTagName("body")[0];theBody.style.display="block";}else{top.location=self.location;}</script>
				<noscript><style>body{display:block;}</style></noscript>
					<a class='ada-hidden ada-visible-focus' href='#skip-to-h1' id='ada-skip-link'>Skip to main content</a>
		<div class="fsd-layout fsd-1c-layout">
			<div class="center-content">
				<div class="header">
		  



<script language="javascript" src="/pa/components/modules/tag-manager-module/1.1/script/tag-manager-module-borneo-global-skin.js"></script>
<script>

(function() {
  var fireCallback = function( cb ) {
    if ( typeof cb === "function" ) cb();
  };
  
  function ddoPopulateBase( callback ) {
    try {
		  var DDO = window.digitalData,
		  	bactm_mergeDDO = function( newDDO, priorDDO ) {
		  		if( typeof priorDDO === "undefined" ) {
				  	priorDDO = digitalData || {};
				  }

			    for (var l in newDDO) {
			        if (typeof priorDDO[l] === "undefined") {
			            priorDDO[l] = newDDO[l];
			        }
			        if (newDDO[l] !== null) {
			            if (typeof newDDO[l] === "object") {
			                bactm_mergeDDO(newDDO[l], priorDDO[l]);
			            } else {
			                priorDDO[l] = bactm_validateValue( newDDO[l] ) ? newDDO[l] : priorDDO[l];
			            }
			        }
			    }

			    return priorDDO;
				},
				bactm_olb3rdPartyId = "null";

			if (typeof DDO === "undefined") {
				var simpleDDO = { page: { pageInfo:[{ pageID: null }], attributes: {}, category: { primaryCategory: null }}};

				DDO = (typeof digitalData === "object") ? digitalData : simpleDDO; 
			}

				DDO = bactm_mergeDDO( {pageInstanceID:"notprod",load_coremetrics:false,load_opinionlabs:false,load_touchcommerce:true,load_audiencemanager:true,page:{pageInfo:[{pageID:null,destinationURL:null,referringURL:null,issueDate:null,language:null,segmentValue:null,appName:null,appStepNumber:null,appStepName:null,attr:"-_--_--_--_--_--_--_--_--_--_--_--_--_--_-"}],category:{primaryCategory:null,addlCategory:null,pageType:null},attributes:{searchString:null,searchResults:null,olbSessionID:null,subCampaignCode:null,DARTUrl:null,stateCookie:null,SASIEnabled:false,needOLBcookie:false,standardDART:[],standardDARTes:[],clickDART:[],clickDARTes:[],gaId:[],chat:{account_type:null,boa_associate:null,boa_retiree:null,customer_lob:null,customer_segment:null,data:null,email_campaign:null,entitlement_code:null,error_category:null,error_count:null,first_login:null,inqSalesProductTypes:{},invitation_background:null,invitation_template:null,referral_campaign:null,getStateValue:false,cust_fn:null,cust_ln:null,target:null}}},user:{segment:null,online_id:null,preferred_rewards_tier:null,olb3rdpartyid:null},version:"BAC_0.12"}, DDO );

			DDO.page.pageInfo[0].pageID = "studentbanking:Content:students:online_mobile;overview";
			DDO.page.category.primaryCategory  = "studentbanking:Content:students:online_mobile";
			DDO.page.pageInfo[0].language = "en-US";
			DDO.page.attributes.olbSessionID = "null";
			DDO.page.attributes.SASIEnabled =  "false";
			if (typeof DDO.user != "undefined" && typeof DDO.user.olb3rdpartyid != "undefined") {
				DDO.user.olb3rdpartyid = bactm_olb3rdPartyId;
			}

			window.utag_data = {};
			window.bactm_envSelector = bactm_setTMLib();
			window.digitalData = DDO;

      return fireCallback( callback );

    } catch(e) { }
  }
	if( window.boa && window.boa.digitalData ) {
    window.boa.digitalData.register( ddoPopulateBase );
	}
	else {
	  // Handle scenario where the header isn't available (and thus the default digitalData object and utag loader are missing).
	  //
		var writeScript = function(a,b,c,d){
			a='//tags.tiqcdn.com/utag/bofa/main/' + bactm_envSelector + '/utag.js';
			b=document;
			c='script';
			d=b.createElement(c);
			d.src=a;
			d.type='text/java'+c;
			d.async=true;
			a=b.getElementsByTagName(c)[0];
			a.parentNode.insertBefore(d,a);
		};

		ddoPopulateBase( writeScript );
	}
})();			
</script>





	
	
				<noscript>
				
					<div class="fauxdal-overlay"></div>
					<div class="fauxdal-module">
						<div class="js-disabled-skin">
							<div class="fauxdal-top"></div>
							<div class="fauxdal-bottom">
								<div class="fauxdal-content">
										<div class="fauxdal-title">
											Please Use JavaScript
										</div>
											<p>You need a web browser that supports JavaScript to use our site. Without it, some pages won&rsquo;t work as designed. To make sure JavaScript is turned on, please adjust your browser settings and refresh.</p><p><a title="Browser Help and Tips" name="Browser_Help_and_Tips" href="/onlinebanking/online-banking-security-faqs.go">Browser Help and Tips</a></p>
										
								</div>        
								<div class="fauxdal-close"> 
									<a class="btn-bofa btn-bofa-small" href=?js=y>Close</a>
								</div>
								
							</div>
						</div>
					</div>
				</noscript>



 


<div class="header-module">
	<div class="text-w-logo-skin">
		<div class="header-left">
	  
			<div itemscope itemtype="http://schema.org/Corporation" class="bofa-logo">
				<a itemprop="url" name="anc-student-banking" title="Bank of America Logo" href="/">
					<img itemprop="logo" height="28" width="221" 
					     alt="Bank of America Logo" src="https://www2.bac-assets.com/content/images/ContextualSiteGraphics/Logos/en_US/boa_logo.gif"/>
				</a>
			</div>
				<div class="product" data-font="cnx-regular">Student Banking</div>
			
			<div class="clearboth"></div>

		</div>
		
		<div class="header-right">
			<ul class="header-links">
			
				
					
				
							<li class="sign-in">
		<a					href="/sitemap/hub/signin.go" target="_self"
		name="sign_in">Sign In</a> 
							</li>
					
				
							<li>		<a					href="/" target="_self"
		name="home">Home</a> 
</li>
					
				
							<li>		<a					href="https://locators.bankofamerica.com" target="_self"
		name="locations">Locations</a> 
</li>
					
				
							<li>		<a					href="/contactus/contactus.go" target="_self"
		name="contact_us">Contact Us</a> 
</li>
					
				
							<li class="last-link">	
		<a					href="/student-banking/resources/student-banking-faqs.go" target="_self"
		name="help">Help</a> 
							</li>
			</ul>
			
			<div class="clearboth"></div>

			<!-- include search-dotcom-util -->



<div class="header-search nlh">
  
  <div class="nav-search">
    <form class="search-form" action="https://secure.bankofamerica.com/myaccounts/public/search-results/unAuthenticatedSearch.go" data-js="/pa/components/utilities/search-util/1.0/script/nav-search.min.js" data-css="/pa/components/utilities/search-util/1.0/style/nav-search.css" data-text-unavailable="Search Currently Unavailable">
      <div class="search-input-container cf" data-icon="search">
        <label for="nav-search-query" class="ada-hidden">Search Term</label>
        <input type="text" placeholder="How can we help you?" name="query" class="search-query" id="nav-search-query" 
          maxlength="99" rel="Search" autocomplete="off"><input type="submit" alt="Search" title="Search" value="Submit Search" name="Search Module - Top Result – Search Button" class="submit track-me">
      </div>
    </form>
  </div>

</div>

		</div>

 		<div class="clearboth"></div>
 	</div>
</div>







	<div class="top-nav-module">
		<div class="fsd-skin sup-ie">
			<ul class="nav-list">
					
					
					<li>
						
									<a href="/student-banking/overview.go" class="top-menu-item"
									name="overview_topnav" id="overview_topnav">Overview</a>
					</li>
					
					
					<li>
						
								<a href="/student-banking/solutions-for-students.go" class="top-menu-item selected"
								name="accounts_for_students_topnav" id="accounts_for_students_topnav">Accounts for Students<span class="ada-hidden"> link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/student-banking/solutions-for-students.go"  name="solutions_for_students_topnav" id="solutions_for_students_topnav">Solutions for Students </a>
															<a href="/student-banking/student-checking-savings-account.go"  name="checking_and_savings_topnav" id="checking_and_savings_topnav">Checking & Savings </a>
															<a href="/student-banking/student-credit-cards.go"  name="credit_cards_topnav" id="credit_cards_topnav">Credit Cards </a>
									</div>
								
									<div class="hasSub">
														<a class="with-info" href="/student-banking/online-mobile-banking.go"  name="mobile_and_online_banking_topnav" id="mobile_and_online_banking_topnav"><strong>Mobile &amp; Online Banking</strong> 
															
															<span class="sub-nav-item-info">Services designed for a student's on-the-go lifestyle</span>
														</a>
														<a class="with-info" href="/student-banking/resources/types-of-student-loans.go"  name="college_planning_topnav" id="college_planning_topnav"><strong>Student Loan Options</strong> 
															
															<span class="sub-nav-item-info">Find out about different types of student loans
</span>
														</a>
									</div>
									<span class="ada-hidden"> End of Submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
					
					
					<li>
						
								<a href="/planning/college.go" class="top-menu-item"
								name="college_planning_topnav" id="college_planning_topnav">College Planning<span class="ada-hidden"> link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/planning/college.go"  name="preparing_for_college_topnav" id="preparing_for_college_topnav">Preparing for College </a>
															<a href="/student-banking/saving-for-college.go"  name="saving_for_college_topnav" id="saving_for_college_topnav">Saving for College </a>
															<a href="/student-banking/financial-aid.go"  name="financial_aid_topnav" id="financial_aid_topnav">Financial Aid </a>
															<a href="/student-banking/managing-student-finances.go"  name="managing_student_finances_topnav" id="managing_student_finances_topnav">Managing Student Finances </a>
															<a href="/student-banking/resources/fafsa-form.go"  name="understanding_the_fafsa_form_topnav" id="understanding_the_fafsa_form_topnav">Understanding the FAFSA form </a>
									</div>
								
									<div class="hasSub">
									</div>
									<span class="ada-hidden"> End of Submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
					
					
					<li>
						
								<a href="/student-banking/resources/overview.go" class="top-menu-item"
								name="resources_topnav" id="resources_topnav">Resources<span class="ada-hidden"> link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/student-banking/resources/overview.go"  name="resources_overview_topnav" id="resources_overview_topnav"><span class="ada-hidden">Resources </span>Overview </a>
															<a href="/student-banking/resources/glossary.go"  name="glossary_topnav" id="glossary_topnav">Glossary </a>
															<a href="/student-banking/resources/student-banking-faqs.go"  name="faqs_topnav" id="faqs_topnav">FAQs </a>
									</div>
								
									<div class="hasSub">
														<a class="with-info" href="/student-banking/resources/shared-credit-cards.go"  name="banking_basics_topnav" id="banking_basics_topnav"><strong>Banking basics</strong> 
															
															<span class="sub-nav-item-info">Shared credit card accounts</span>
														</a>
														<a class="with-info" href="/student-banking/resources/building-your-credit-history.go"  name="after_college_topnav" id="after_college_topnav"><strong>After college</strong> 
															
															<span class="sub-nav-item-info">Building your credit history</span>
														</a>
									</div>
									<span class="ada-hidden"> End of Submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
			</ul>
				<div class="clearboth"></div>
		</div>
	</div>



<div class="page-title-fsd-module h-100" id="skip-to-h1">
	<div class="standard-red-skin sup-ie">
			<h1 data-font="cnx-regular">Mobile & Online Banking</h1>
	</div>
</div>


	<div class="engagement-module">
		<div class="img-btn-text-skin sup-ie">
				<div>		
					<h2><span class="bannerquote"></span>I love being able to bank wherever I go.<span class="endquote"></span></h2>
					<p>With Mobile and Online Banking, you can manage your money on your schedule.</p>
					
						<div class="big-bubbly-button">
						
							<a name="mobile_app" href="/online-banking/mobile-banking-applications.go">Get the mobile app</a>
						</div>
						<div class="big-bubbly-button last">
						
							<a name="online_banking" href="https://secure.bankofamerica.com/login/enroll/entry/olbEnroll.go?reason=model_enroll">Enroll in Online Banking</a>
						</div>
					
					<div class="btm-rt-img"><img alt="" src="/content/images/ContextualSiteGraphics/Marketing/Banners/en_US/banner-hero-mobile-online-devices.png" /></div>
				</div>

		</div>
	</div>

</div>
				<div class="columns">
					<div class="one-col">


	<div class="main-text-img-module">
		<div class="wide-text-image-skin">
					<div class="ipc-section ipc-alt-section">
						<div class="ipc-col ipc-left-col">
							<div class="ipc-main-content">
								 <div class="ipc-header h-100">
									<h2 id=""><span>Account management</span></h2>
									<div class="clearboth"></div>
								 </div>
								 <p>Open a <a href="/deposits/checking/personal-checking-account.go?STUDENT_IND=Y">Bank of America Core Checking<sup>&reg;</sup></a> account (we waive the monthly maintenance fee for eligible students under 23) and enjoy banking convenience on your laptop, tablet or smartphone.<a name="students_under23_footnote" href="#footnote1"><span class="ada-hidden">footnote</span><sup>1</sup></a> With <a name="mobile_online_banking" href="/online-banking/mobile.go" target="_self">Mobile and Online Banking<span class="ada-hidden"> for Account management</span></a><a name="online_mobile_banking_footnote" href="#footnote2"><span class="ada-hidden">footnote</span><sup>2</sup></a> it's easy and secure.</p>
<p>You can check your balance before buying that new outfit, make a transfer so you can order next semester's books, track your spending and easily access your accounts online 24/7. You can even set up <a name="alerts" href="/onlinebanking/online-bank-account.go">Alerts</a> to keep track of changes and updates to your account.<a name="alerts_received_footnote" href="#footnote3"><span class="ada-hidden">footnote</span><sup>3</sup></a></p>
							</div>
						</div>
						<div class="ipc-col">
							<img src="/content/images/ContextualSiteGraphics/Marketing/Highlights/en_US/content-image-account-mgmt.png" alt="" />
						</div>
						<div class="clearboth"></div>
					</div>

					<div class="hr-img">&nbsp;</div>

					<div class="ipc-section ipc-alt-section">
						<div class="ipc-col ipc-left-col">
							<img src="/content/images/ContextualSiteGraphics/Marketing/Highlights/en_US/content-image-mobile-banking.png" alt="" />
						</div>
						<div class="ipc-col">
							<div class="ipc-main-content">
								 <div class="ipc-header h-100">
									<h2 id="mobile-banking"><span>Mobile Banking</span></h2>
									<div class="clearboth"></div>
								 </div>
								 <p>Access your Bank of America<sup>&reg;</sup> accounts directly on your mobile device and bank on your schedule with our <a name="mobile_banking_app" href="/online-banking/mobile-internet-banking.go" target="_self">Mobile Banking app<span class="ada-hidden"> for using Mobile Banking</span></a>.</p>
<p>You can check <a name="bankamerideals" href="http://promotions.bankofamerica.com/deals/" target="_self">BankAmeriDeals<sup>&reg;</sup></a><a name="bankamerideals_footnote" href="#footnote4"><span class="ada-hidden">footnote</span><sup>4</sup></a> and get cash back deals without the hassle of coupons. You can securely deposit a check with just your mobile device's camera.<a name="mobile_camera_footnote" href="#footnote5"><span class="ada-hidden">footnote</span><sup>5</sup></a> You can even find the nearest financial center or ATM without having to enter your address or ZIP code.</p>
							</div>
						</div>
						<div class="clearboth"></div>
					</div>
					
					<div class="hr-img">&nbsp;</div>
					<div class="ipc-section ipc-alt-section">
						<div class="ipc-col ipc-left-col">
							<div class="ipc-main-content">
								 <div class="ipc-header h-100">
									<h2 id=""><span>Easy money transfers</span></h2>
									<div class="clearboth"></div>
								 </div>
								 <p>Transfer money from home, your dorm or almost anywhere else you happen to be.<a name="transfer_safely_footnote" href="#footnote6"><span class="ada-hidden">footnote</span><sup>6</sup></a></p>
<p>Say you're splitting the check 5 ways or you need to pay your best friend for concert tickets. You can transfer money from your Bank of America account to your friend's account at any U.S.-based bank without a fee, using your friend's email address or mobile phone number.<a name="mobile_phone_number_footnote" href="#footnote7"><span class="ada-hidden">footnote</span><sup>7</sup></a> Every transfer is covered by our <a name="security_guarantee" href="/onlinebanking/online-banking-security-guarantee.go" target="_self">Online Banking Security Guarantee</a>, which protects you from fraudulent transfers from your account.<a name="fraudulent_transactions_footnote" href="#footnote8"><span class="ada-hidden">footnote</span><sup>8</sup></a></p>
							</div>
						</div>
						<div class="ipc-col">
							<img src="/content/images/ContextualSiteGraphics/Marketing/Highlights/en_US/content-image-easy-money-transfers.png" alt="" />
						</div>
						<div class="clearboth"></div>
					</div>

					<div class="hr-img">&nbsp;</div>

					<div class="ipc-section ipc-alt-section">
						<div class="ipc-col ipc-left-col">
							<img src="/content/images/ContextualSiteGraphics/Marketing/Highlights/en_US/content-image-simple-bill-payments.png" alt="" />
						</div>
						<div class="ipc-col">
							<div class="ipc-main-content">
								 <div class="ipc-header h-100">
									<h2 id="mobile-banking"><span>Simple bill payments</span></h2>
									<div class="clearboth"></div>
								 </div>
								 <p>Once you set up Pay To accounts in Online Banking, bills can be paid as one-time or recurring payments. Make payments wherever you are, whatever you're doing.</p>
<p>Choose the amount and when to pay. Get your bills online from any company participating in eBills (there are thousands). You can even pay your bills using Mobile Banking.<a name="online_mobile_banking_footnote" href="#footnote2"><span class="ada-hidden">footnote</span><sup>2</sup></a> Mobile Bill Pay is available on our <a name="mobile_website" href="/online-banking/mobile-banking-applications.go" target="_self">mobile website</a> and in our <a name="mobile_banking_app" href="/online-banking/mobile-banking-applications.go" target="_self">Mobile Banking App<span class="ada-hidden"> for bill payments</span></a>.</p>
							</div>
						</div>
						<div class="clearboth"></div>
					</div>
					
		</div>
	</div>
		

</div>
				</div>
				<div class="footer">
					<div class="footer-top">&nbsp;</div>
					<div class="footer-inner">

<div class="footnote-com-module">
   <div class="fsd-layout-skin sup-ie">
   
   <script>
		$(function() {
			if ($('.footnote-com-module .fsd-layout-skin').text().length > 10) {
				$('.footnote-com-module .fsd-layout-skin').addClass('wfootnote');
			}
		});
	</script>
   
					<div class="h-100">
						<div class="footnote" id="footnote1">
							<div class="fn-num">1.</div>
							<div class="fn-text">Students under age 23 are eligible for a waiver of the monthly maintenance fee while enrolled in a high school or in a college, university or vocational program. Please refer to your Personal Schedule of Fees for details. </div>
							<div class="clearboth"></div>
						</div>
					</div>
					<div class="h-100">
						<div class="footnote" id="footnote2">
							<div class="fn-num">2.</div>
							<div class="fn-text">Mobile Banking requires enrollment through the Mobile Banking app, mobile website or Online Banking. View the <a name="online_banking_service_agreement_mob_footnote" href="/online-banking/service-agreement.go" target="_self">Online Banking Service Agreement</a> for more information. Data connection required. Wireless carrier fees may apply. Enrollment not available through the Mobile Banking app on all devices. </div>
							<div class="clearboth"></div>
						</div>
					</div>
					<div class="h-100">
						<div class="footnote" id="footnote3">
							<div class="fn-num">3.</div>
							<div class="fn-text">Alerts received as text messages on your mobile device may incur a charge from your mobile access service eprovider. Mobile alerts are not available on select mobile devices. </div>
							<div class="clearboth"></div>
						</div>
					</div>
					<div class="h-100">
						<div class="footnote" id="footnote4">
							<div class="fn-num">4.</div>
							<div class="fn-text">You must be enrolled in Online Banking or Mobile Banking to participate in the BankAmeriDeals<sup>&reg;</sup> program and have either an eligible Bank of America<sup>&reg;</sup> debit or credit card or Merrill Lynch<sup>&reg;</sup> credit card. Select co-brand credit cards are not eligible. Earned cash back will be credited into an eligible checking, savings, money market or credit account in the next month following redemption. For more information, please read the <a name="online_banking_service_agreement" href="/online-banking/service-agreement.go" target="_self">program terms of use</a>. </div>
							<div class="clearboth"></div>
						</div>
					</div>
					<div class="h-100">
						<div class="footnote" id="footnote5">
							<div class="fn-num">5.</div>
							<div class="fn-text">Mobile check deposits are subject to verification and not available for immediate withdrawal. In the Mobile Banking app, select <strong>Help &amp; Support</strong>, then <strong>Mobile Check Deposit</strong> for details, including funds availability, deposit limits, proper disposal of checks, restrictions and terms and conditions. Wireless carrier fees may apply. Requires at least a 2-megapixel camera. This feature is not available on the mobile website and select mobile devices. </div>
							<div class="clearboth"></div>
						</div>
					</div>
					<div class="h-100">
						<div class="footnote" id="footnote6">
							<div class="fn-num">6.</div>
							<div class="fn-text">Fees apply to wires and certain transfers. See the <a name="online_banking_service_agreement_easy_money_txfr" href="/online-banking/service-agreement.go" target="_self">Online Banking Service Agreement</a> for details. </div>
							<div class="clearboth"></div>
						</div>
					</div>
					<div class="h-100">
						<div class="footnote" id="footnote7">
							<div class="fn-num">7.</div>
							<div class="fn-text">Email and mobile transfers requires enrollment in service and must be made from a Bank of America consumer checking or savings account to a U.S.-based bank account. Recipients have 14 days to register to receive money or transfer will be cancelled. Dollar and frequency limits apply. See the <a name="online_banking_service_agreement_mob_footnote" href="/online-banking/service-agreement.go" target="_self">Online Banking Service Agreement</a> for details, including cut-off and delivery times. Wireless carrier charges may apply. </div>
							<div class="clearboth"></div>
						</div>
					</div>
					<div class="h-100">
						<div class="footnote" id="footnote8">
							<div class="fn-num">8.</div>
							<div class="fn-text">You are not liable for fraudulent Online Banking transactions when you notify the bank within 60 days of the transaction first appearing on your statement and comply with security responsibilities. See our <a name="online_banking_service_agreement" href="/online-banking/service-agreement.go" target="_self">Online Banking Service Agreement</a> for full terms and conditions. </div>
							<div class="clearboth"></div>
						</div>
					</div>
   </div>
</div>

<div class="disclaimers-module">
	<div class="fsd-skin sup-ie">
			<div class="apple-disclaimer">				
				<img alt="Available on the Apple App Store" src="/content/images/ContextualSiteGraphics/Logos/en_US/Apple_logo.jpg">
				<p>Apple, the Apple logo, iPhone, iPad, Mac and MacBookAir are trademarks of Apple Inc., registered in the U.S. and other countries. App Store is a service mark of Apple Inc.</p>
<p>BankAmeriDeals, Bank of America Core Checking, Bank of America and the Bank of America logo are registered trademarks of the Bank of America Corporation.</p>
				<div class="clearboth"></div>
			</div>
	</div>
</div>






<div class="power-footer-module">
	<div class="flex-microdata-skin sup-ie">
			<div class="breadcrumbs">
			<div itemscope itemtype="http://schema.org/BreadcrumbList">
				<!-- breadcrumbs div -->
					<!-- Inside 1st breadcrumb -->
					<div itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="bold-arrow">
								<a itemprop="item" href="/" name="bank_of_america_breadcrumb" target="_self"><span itemprop="name">Bank of America</span><meta itemprop="position" content="1"/></a>
					</div>
					
						<!-- Inside 2nd breadcrumb -->
						<div itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="arrow">
									<a itemprop="item" href="/student-banking/overview.go" name="student_banking_breadcrumb" target="_self"><span itemprop="name">Student Banking</span><meta itemprop="position" content="2"/></a>
						</div>
				
					<!-- Inside 3rd breadcrumb -->
					<div itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="arrow">
								<a itemprop="item" href="/student-banking/solutions-for-students.go" name="solutions_for_students_breadcrumb" target="_self">Solutions for Students</a>
					</div>
				
				<!-- Inside 4th breadcrumb -->
				<div itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
					<span itemprop="name">
						Mobile & Online Banking
					</span>
					<meta itemprop="position" content="4" />
				</div>
				<div class="clearboth"></div>
			</div>
			</div>
		
			<!-- Inside power footer columns -->
			<div class="pf-columns">		   
						<div class="pf-col">
							<ul>
								<li>Solutions for Students</li>
										<li><a href="/student-banking/student-checking-savings-account.go" name="power_footer_checking_and_savings">Checking & Savings</a></li>
										<li><a href="/student-banking/student-credit-cards.go" name="power_footer_credit_cards">Credit Cards</a></li>
										<li><a href="/student-banking/online-mobile-banking.go" name="power_footer_mobile_and_online_banking">Mobile & Online Banking</a></li>
										<li><a href="/student-banking/solutions-for-students.go" name="power_footer_banking_options_students">Banking options for students</a></li>
							</ul>
						</div>
						<div class="pf-col">
							<ul>
								<li>Solutions for Parents</li>
										<li><a href="/student-banking/saving-for-college.go" name="saving_for_college">Saving for College</a></li>
										<li><a href="/student-banking/financial-aid.go" name="financial_aid">Financial Aid</a></li>
										<li><a href="/student-banking/managing-student-finances.go" name="managing_student_finances">Managing Student Finances</a></li>
							</ul>
						</div>
						<div class="pf-col">
							<ul>
								<li>Resources</li>
										<li><a href="/student-banking/resources/overview.go" name="sb-resource-loans-banking">Student loans & banking</a></li>
							</ul>
						</div>
					<div class="clearboth"></div>
			</div>
	</div>
</div>




 



		<div class="global-footer-module">
			<div class="fsd-skin">

				<div class="footer-bottom-left" style="float:left;max-width:66%;">
	    			<div class="gf-links">	          	
						
					
									
									<a  target="_self" href="/" 
									    name="global_footer_home">Home
									</a>
									
						
					
									
									<a  target="_self" href="/accessiblebanking/overview.go" 
									    name="global_footer_accessible_banking">Accessible Banking
									</a>
									
						
					
									
									<a  target="_self" href="/privacy/overview.go" 
									    name="global_footer_privacy_security">Privacy & Security
									</a>
									
						
					
									
									<a  target="_self" href="http://careers.bankofamerica.com/careershome.aspx" 
									    name="global_footer_careers">Careers
									</a>
									
						
					
									
									<a  target="_self" href="/sitemap/personal.go" 
									    name="global_footer_site_map">Site Map
									</a>
									
						
					
									<a href="javascript:void(0);" class="gf-last-link boa-dialog boa-com-info-layer-link" name="global_footer_advertising_practices_lnk" rel="global_footer_advertising_practices">Advertising Practices</a>
								<div id="global_footer_advertising_practices" class="hide">
									<h3>Advertising Practices</h3>
										<p>We strive to provide you with information about products and services you might find interesting and useful. Relationship-based ads and online behavioral advertising help us do that.</p>
<p>Here's how it works: We gather information about your online activities, such as the searches you conduct on our Sites and the pages you visit. This information may be used to deliver advertising on our Sites and offline (for example, by phone, email and direct mail) that's customized to meet specific interests you may have.</p>
<p>If you prefer that we do not use this information, you may <a onclick="$('.ui-dialog').remove();" name="WebsiteAdPractices_OptOut" href="/privacy/online-privacy-notice.go#advertising-on-our-sites" target="_blank">opt out of online behavioral advertising</a>. If you opt out, though, you may still receive generic advertising. In addition, financial advisors/Client Managers may continue to use information collected online to provide product and service information in accordance with account agreements.</p>
<p>Also, if you opt out of online behavioral advertising, you may still see ads when you sign in to your account, for example through Online Banking or MyMerrill. These ads are based on your specific account relationships with us.</p>
<p>To learn more about relationship-based ads, online behavioral advertising and our privacy practices, please review the <a onclick="$('.ui-dialog').remove();" name="WebsiteAdPractices_PrivacyNotice" href="/privacy/online-privacy-notice.go" target="_blank">Bank of America Online Privacy Notice</a> and our <a onclick="$('.ui-dialog').remove();" name="Online-privacy-faqs" href="/privacy/faq/online-privacy-faq.go" target="_blank">Online Privacy FAQs</a>.</p>
								</div>
						<div class="clearboth"></div>
	    			</div>
	      			<p>Bank of America, N.A. Member <acronym title="Federal Deposit Insurance Corporation">FDIC</acronym>. <a onclick="window.open('/help/equalhousing_popup.go','newwin','width=640,height=371,scrollbars=yes,resizable=yes,left=35,top=161'); return false;" name="equal_housing_lender" href="/help/equalhousing_popup.go" target="_blank">Equal Housing Lender<img src="https://www2.bac-assets.com/content/images/ContextualSiteGraphics/Logos/en_US/icon_equal_housing_lender.gif" alt="" width="14" height="9" /></a><br />&copy; 2017 Bank of America Corporation.</p>
         		</div>
         		<div class="footer-social-container" style="float:right;max-width:30%;padding-left:50px;padding-top:19px;">




<div class="boa-social-loader" data-loaded="false" data-platform="borneo"  data-options=''></div>

         		</div>
         		<div class="clearboth"></div>
  			</div>
		</div>




 
<script language="javascript" src="https://www2.bac-assets.com/pa/global-assets/external/coremetrics/hp/eluminate.js"></script>
<script language="javascript" src="https://www2.bac-assets.com/pa/global-assets/external/coremetrics/hp/cmdatatagutils.js"></script>


<script language="javascript">
	function cmSetDD(){var testString=window.location.href;if(testString.toLowerCase().indexOf('.bankofamerica.com')>-1){testString=testString.toLowerCase();var tempArr=testString.split('.bankofamerica.com');var tempStr=tempArr[0];if(tempStr.indexOf('\/\/')>-1){tempArr=tempStr.split('\/\/');tempStr=tempArr[1];if(tempStr.indexOf('.')>-1){tempArr=tempStr.split('.');tempStr=tempArr[0];var tempStrPt2=tempArr[1]}if(tempStr.indexOf('www')>-1){if(tempStr.indexOf('-')>-1){cmSetStaging()}else if(tempStrPt2!=null){if(tempStrPt2.indexOf('ecnp')>-1){cmSetStaging()}}else{cmSetProduction()}}else if(tempStr.indexOf('-')>-1){if(tempStr.indexOf('sitekey')>-1){if(tempStr=='sitekey'){cmSetProduction()}else{cmSetStaging()}}else{cmSetStaging()}}else if(tempStrPt2!=null){if(tempStrPt2.indexOf('ecnp')>-1){cmSetStaging()}}else{cmSetProduction()}}}}if(typeof cmSetStaging=='function'){cmSetDD()}
</script> 

		<script type="text/javascript">
			cmCreatePageviewTag('studentbanking:Content:students:online_mobile;overview', null, null, 'studentbanking:Content:students:online_mobile', false, false, null, false, false, null, null, null, null, null, null, null, null, null, null, null, null);
		</script>

</div>
				</div>
			</div>
		</div>	
	</body>	
</html>

