
 

				<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
				<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
				<head>



<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<title>Bank of America Article - Banking Basics: Choosing a Credit Card</title>


					<meta name="Keywords" CONTENT="banking basics, credit card basics, student credit card basics, understanding credit cards, how to apply for a credit card" />
					<meta name="Description" CONTENT="It's important to know how to apply for a credit card: There's more to it than just filling out an application. Here's a 3-step guide to finding the right credit card." />
					<meta property="og:type" CONTENT="website" />
					<meta property="og:site_name" CONTENT="Bank of America" />
					<meta property="og:url" CONTENT="https://www.bankofamerica.com/student-banking/resources/choosing-a-credit-card.go" />
					<meta property="og:title" CONTENT="Banking Basics&#58; Applying for a Credit Card" />
					<meta property="og:description" CONTENT="It's important to know how to apply for a credit card: There's more to it than just filling out an application. Here's a 3-step guide to finding the right credit card." />
					<meta property="og:image" CONTENT="https://www.bankofamerica.com/content/images/ContextualSiteGraphics/Logos/en_US/80x150_flagscape_trans.gif" />


<link rel="shortcut icon" href="https://www2.bac-assets.com/pa/global-assets/1.0/graphic/favicon.ico" type="image/ico" />


		<link rel="stylesheet" type="text/css" media="all" href="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/APS-deposits/2017.03.0/style/global-aps-dp-jawr.css"/>
		<link rel="stylesheet" type="text/css" media="all" href="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/APS-deposits/2017.03.0/style/sb-aps-dp-jawr.css"/>
		
		<script type="text/javascript" src="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/APS-deposits/2017.03.0/script/global-aps-dp-jawr.js"></script>
		<script type="text/javascript" src="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/APS-deposits/2017.03.0/script/sb-aps-dp-jawr.js"></script>
		
			<script type="text/javascript">
				$(window).load(function(){asyncPrintCssInclude('https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/APS-deposits/2017.03.0/style/global-aps-dp-jawr-print.css');});
				$(window).load(function(){asyncPrintCssInclude('https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/APS-deposits/2017.03.0/style/sb-aps-dp-jawr-print.css');});
			</script>
<script type="text/javascript">
(function() {
	if (typeof mboxUpdate == "function") {
		var windowURL = window.location.href
	    windowURL = windowURL.slice( windowURL.indexOf('.')+1);
		windowURL = windowURL.split( '?' )[0];
		windowURL = windowURL.toLowerCase();
		//alert(windowURL);
		if (
		    //If no mboxes on page, mbox count will be < 1
		    (mboxFactoryDefault.getMboxes().length() < 1) &&  
			
			//Also check for high-volume pages that do not need global logging
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go") &&
			(windowURL != "bankofamerica.com/myaccounts/signin/signin.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/entry/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signonscreen.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatechallengeanswer.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatePassword.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/mobile/banking.go")&&
			(windowURL != "bankofamerica.com/content/preload/olb-myaccount-preload-jawr-module.htm")
			)
		{

			var mboxDiv = document.createElement("div");
			mboxDiv.id = "adobe_touch_clarity_replacement";
			mboxDiv.style.display = "none";
			if (document.body && document.body.firstChild) document.body.insertBefore(mboxDiv,document.body.firstChild);
			mboxDefine(mboxDiv.id,'bac_global_bottom');
			mboxUpdate('bac_global_bottom');
		}
	}	
})();
</script>

		<script src="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/Global/1.0/script/tealeafbundle.js" type="text/javascript"></script>
			<script>
				var boaPageDataJS = {};
					boaPageDataJS.isLLE = "false";
			</script>
				<style>body{display:none;}</style>
	</head>		

	<body class="fsd-layout-body">	

				<script type="text/javascript">if(self == top){var theBody=document.getElementsByTagName("body")[0];theBody.style.display="block";}else{top.location=self.location;}</script>
				<noscript><style>body{display:block;}</style></noscript>
					<a class='ada-hidden ada-visible-focus' href='#skip-to-h1' id='ada-skip-link'>Skip to main content</a>
		<div class="fsd-layout fsd-2c-600lt-layout">
			<div class="fsd-border">
				<div class="center-content">
					<div class="header">
		  



<script language="javascript" src="/pa/components/modules/tag-manager-module/1.1/script/tag-manager-module-borneo-global-skin.js"></script>
<script>

(function() {
  var fireCallback = function( cb ) {
    if ( typeof cb === "function" ) cb();
  };
  
  function ddoPopulateBase( callback ) {
    try {
		  var DDO = window.digitalData,
		  	bactm_mergeDDO = function( newDDO, priorDDO ) {
		  		if( typeof priorDDO === "undefined" ) {
				  	priorDDO = digitalData || {};
				  }

			    for (var l in newDDO) {
			        if (typeof priorDDO[l] === "undefined") {
			            priorDDO[l] = newDDO[l];
			        }
			        if (newDDO[l] !== null) {
			            if (typeof newDDO[l] === "object") {
			                bactm_mergeDDO(newDDO[l], priorDDO[l]);
			            } else {
			                priorDDO[l] = bactm_validateValue( newDDO[l] ) ? newDDO[l] : priorDDO[l];
			            }
			        }
			    }

			    return priorDDO;
				},
				bactm_olb3rdPartyId = "null";

			if (typeof DDO === "undefined") {
				var simpleDDO = { page: { pageInfo:[{ pageID: null }], attributes: {}, category: { primaryCategory: null }}};

				DDO = (typeof digitalData === "object") ? digitalData : simpleDDO; 
			}

				DDO = bactm_mergeDDO( {pageInstanceID:"notprod",load_coremetrics:false,load_opinionlabs:false,load_touchcommerce:true,load_audiencemanager:true,page:{pageInfo:[{pageID:null,destinationURL:null,referringURL:null,issueDate:null,language:null,segmentValue:null,appName:null,appStepNumber:null,appStepName:null,attr:"-_--_--_--_--_--_--_--_--_--_--_--_--_--_-"}],category:{primaryCategory:null,addlCategory:null,pageType:null},attributes:{searchString:null,searchResults:null,olbSessionID:null,subCampaignCode:null,DARTUrl:null,stateCookie:null,SASIEnabled:false,needOLBcookie:false,standardDART:[],standardDARTes:[],clickDART:[],clickDARTes:[],gaId:[],chat:{account_type:null,boa_associate:null,boa_retiree:null,customer_lob:null,customer_segment:null,data:null,email_campaign:null,entitlement_code:null,error_category:null,error_count:null,first_login:null,inqSalesProductTypes:{},invitation_background:null,invitation_template:null,referral_campaign:null,getStateValue:false,cust_fn:null,cust_ln:null,target:null}}},user:{segment:null,online_id:null,preferred_rewards_tier:null,olb3rdpartyid:null},version:"BAC_0.12"}, DDO );

			DDO.page.pageInfo[0].pageID = "studentbanking:Content:resources:bank_basics;choosing-a-credit-card";
			DDO.page.category.primaryCategory  = "studentbanking:Content:resources:bank_basics";
			DDO.page.pageInfo[0].language = "en-US";
			DDO.page.attributes.olbSessionID = "null";
			DDO.page.attributes.SASIEnabled =  "false";
			if (typeof DDO.user != "undefined" && typeof DDO.user.olb3rdpartyid != "undefined") {
				DDO.user.olb3rdpartyid = bactm_olb3rdPartyId;
			}

			window.utag_data = {};
			window.bactm_envSelector = bactm_setTMLib();
			window.digitalData = DDO;

      return fireCallback( callback );

    } catch(e) { }
  }
	if( window.boa && window.boa.digitalData ) {
    window.boa.digitalData.register( ddoPopulateBase );
	}
	else {
	  // Handle scenario where the header isn't available (and thus the default digitalData object and utag loader are missing).
	  //
		var writeScript = function(a,b,c,d){
			a='//tags.tiqcdn.com/utag/bofa/main/' + bactm_envSelector + '/utag.js';
			b=document;
			c='script';
			d=b.createElement(c);
			d.src=a;
			d.type='text/java'+c;
			d.async=true;
			a=b.getElementsByTagName(c)[0];
			a.parentNode.insertBefore(d,a);
		};

		ddoPopulateBase( writeScript );
	}
})();			
</script>





	
	
				<noscript>
				
					<div class="fauxdal-overlay"></div>
					<div class="fauxdal-module">
						<div class="js-disabled-skin">
							<div class="fauxdal-top"></div>
							<div class="fauxdal-bottom">
								<div class="fauxdal-content">
										<div class="fauxdal-title">
											Please Use JavaScript
										</div>
											<p>You need a web browser that supports JavaScript to use our site. Without it, some pages won&rsquo;t work as designed. To make sure JavaScript is turned on, please adjust your browser settings and refresh.</p><p><a title="Browser Help and Tips" name="Browser_Help_and_Tips" href="/onlinebanking/online-banking-security-faqs.go">Browser Help and Tips</a></p>
										
								</div>        
								<div class="fauxdal-close"> 
									<a class="btn-bofa btn-bofa-small" href=?js=y>Close</a>
								</div>
								
							</div>
						</div>
					</div>
				</noscript>



 


<div class="header-module">
	<div class="text-w-logo-skin">
		<div class="header-left">
	  
			<div itemscope itemtype="http://schema.org/Corporation" class="bofa-logo">
				<a itemprop="url" name="anc-student-banking" title="Bank of America Logo" href="/">
					<img itemprop="logo" height="28" width="221" 
					     alt="Bank of America Logo" src="https://www2.bac-assets.com/content/images/ContextualSiteGraphics/Logos/en_US/boa_logo.gif"/>
				</a>
			</div>
				<div class="product" data-font="cnx-regular">Student Banking</div>
			
			<div class="clearboth"></div>

		</div>
		
		<div class="header-right">
			<ul class="header-links">
			
				
					
				
							<li class="sign-in">
		<a					href="/sitemap/hub/signin.go" target="_self"
		name="sign_in">Sign In</a> 
							</li>
					
				
							<li>		<a					href="/" target="_self"
		name="home">Home</a> 
</li>
					
				
							<li>		<a					href="https://locators.bankofamerica.com" target="_self"
		name="locations">Locations</a> 
</li>
					
				
							<li>		<a					href="/contactus/contactus.go" target="_self"
		name="contact_us">Contact Us</a> 
</li>
					
				
							<li class="last-link">	
		<a					href="/student-banking/resources/student-banking-faqs.go" target="_self"
		name="help">Help</a> 
							</li>
			</ul>
			
			<div class="clearboth"></div>

			<!-- include search-dotcom-util -->



<div class="header-search nlh">
  
  <div class="nav-search">
    <form class="search-form" action="https://secure.bankofamerica.com/myaccounts/public/search-results/unAuthenticatedSearch.go" data-js="/pa/components/utilities/search-util/1.0/script/nav-search.min.js" data-css="/pa/components/utilities/search-util/1.0/style/nav-search.css" data-text-unavailable="Search Currently Unavailable">
      <div class="search-input-container cf" data-icon="search">
        <label for="nav-search-query" class="ada-hidden">Search Term</label>
        <input type="text" placeholder="How can we help you?" name="query" class="search-query" id="nav-search-query" 
          maxlength="99" rel="Search" autocomplete="off"><input type="submit" alt="Search" title="Search" value="Submit Search" name="Search Module - Top Result – Search Button" class="submit track-me">
      </div>
    </form>
  </div>

</div>

		</div>

 		<div class="clearboth"></div>
 	</div>
</div>







	<div class="top-nav-module">
		<div class="fsd-skin sup-ie">
			<ul class="nav-list">
					
					
					<li>
						
									<a href="/student-banking/overview.go" class="top-menu-item"
									name="overview_topnav" id="overview_topnav">Overview</a>
					</li>
					
					
					<li>
						
								<a href="/student-banking/solutions-for-students.go" class="top-menu-item"
								name="accounts_for_students_topnav" id="accounts_for_students_topnav">Accounts for Students<span class="ada-hidden"> link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/student-banking/solutions-for-students.go"  name="solutions_for_students_topnav" id="solutions_for_students_topnav">Solutions for Students </a>
															<a href="/student-banking/student-checking-savings-account.go"  name="checking_and_savings_topnav" id="checking_and_savings_topnav">Checking & Savings </a>
															<a href="/student-banking/student-credit-cards.go"  name="credit_cards_topnav" id="credit_cards_topnav">Credit Cards </a>
									</div>
								
									<div class="hasSub">
														<a class="with-info" href="/student-banking/online-mobile-banking.go"  name="mobile_and_online_banking_topnav" id="mobile_and_online_banking_topnav"><strong>Mobile &amp; Online Banking</strong> 
															
															<span class="sub-nav-item-info">Services designed for a student's on-the-go lifestyle</span>
														</a>
														<a class="with-info" href="/student-banking/resources/types-of-student-loans.go"  name="college_planning_topnav" id="college_planning_topnav"><strong>Student Loan Options</strong> 
															
															<span class="sub-nav-item-info">Find out about different types of student loans
</span>
														</a>
									</div>
									<span class="ada-hidden"> End of Submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
					
					
					<li>
						
								<a href="/planning/college.go" class="top-menu-item"
								name="college_planning_topnav" id="college_planning_topnav">College Planning<span class="ada-hidden"> link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/planning/college.go"  name="preparing_for_college_topnav" id="preparing_for_college_topnav">Preparing for College </a>
															<a href="/student-banking/saving-for-college.go"  name="saving_for_college_topnav" id="saving_for_college_topnav">Saving for College </a>
															<a href="/student-banking/financial-aid.go"  name="financial_aid_topnav" id="financial_aid_topnav">Financial Aid </a>
															<a href="/student-banking/managing-student-finances.go"  name="managing_student_finances_topnav" id="managing_student_finances_topnav">Managing Student Finances </a>
															<a href="/student-banking/resources/fafsa-form.go"  name="understanding_the_fafsa_form_topnav" id="understanding_the_fafsa_form_topnav">Understanding the FAFSA form </a>
									</div>
								
									<div class="hasSub">
									</div>
									<span class="ada-hidden"> End of Submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
					
					
					<li>
						
								<a href="/student-banking/resources/overview.go" class="top-menu-item selected"
								name="resources_topnav" id="resources_topnav">Resources<span class="ada-hidden"> link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/student-banking/resources/overview.go"  name="resources_overview_topnav" id="resources_overview_topnav"><span class="ada-hidden">Resources </span>Overview </a>
															<a href="/student-banking/resources/glossary.go"  name="glossary_topnav" id="glossary_topnav">Glossary </a>
															<a href="/student-banking/resources/student-banking-faqs.go"  name="faqs_topnav" id="faqs_topnav">FAQs </a>
									</div>
								
									<div class="hasSub">
														<a class="with-info" href="/student-banking/resources/shared-credit-cards.go"  name="banking_basics_topnav" id="banking_basics_topnav"><strong>Banking basics</strong> 
															
															<span class="sub-nav-item-info">Shared credit card accounts</span>
														</a>
														<a class="with-info" href="/student-banking/resources/building-your-credit-history.go"  name="after_college_topnav" id="after_college_topnav"><strong>After college</strong> 
															
															<span class="sub-nav-item-info">Building your credit history</span>
														</a>
									</div>
									<span class="ada-hidden"> End of Submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
			</ul>
				<div class="clearboth"></div>
		</div>
	</div>



<div class="page-title-fsd-module h-100" id="skip-to-h1">
	<div class="standard-red-skin sup-ie">
			<h1 data-font="cnx-regular">Banking Basics: Choosing a Credit Card</h1>
	</div>
</div>
<div class="print-module-browser-dialog-skin" style=""> 
	<a href="javascript:window.print();" name="print">PRINT<span class="ada-hidden"> this page</span></a>
</div></div>
					<div class="columns">
						<div class="flex-col lt-col" ><div class="text-img-module">	<div class="text-info-skin">			<h2>Review this 3-step guide to finding the right card for you</h2>			<p class="summary">Always shop for the right card&mdash;the company that sends you a great student credit card offer isn&rsquo;t necessarily your best option.</p>								<p class="image"><img src="/content/images/ContextualSiteGraphics/Marketing/Highlights/en_US/bac_cards_branded/content-image-creditcard.png" alt=""></p>					<div class="shopping-for-credit">					<p class="image">When you decide the time is right to get a credit card, there are some things you should consider before you apply. Here's a 3-step guide to help you find the right card:</p>							<ol>
<li><span>Define your needs&mdash;and recognize your limits</span>
<p>Ask yourself some key questions: How, when and where will I use my card? Will I be able to pay off the balance every month? What are the most important credit card features I need?</p>
<p>If you are using this as an opportunity to build your <a class="boa-dialog boa-com-info-layer-link" rel="glossary-popup-4" name="credit_rating" href="javascript:void(0);">credit rating</a> and plan to pay off the balance every month, you might focus on rewards and discounts because interest rates won't be as much of a factor. If you know that you will likely carry a balance on the card, then searching for the best <a class="boa-dialog boa-com-info-layer-link" rel="glossary-popup-3" name="apr" href="javascript:void(0);">APR</a> could save you money in the long run.</p>
<p>Be sure to consider what your appropriate credit limit, including any fees or interest charges, might be. If you've already defined how much credit you want or need, you may be less tempted to apply for more credit than you need just because the lender offers it to you. Your limit should be high enough to meet your needs, but low enough to keep you out of trouble.</p>
</li>
<li><span>Compare features</span>
<p>Here's a list of features you should consider when comparing credit card offers:</p>
<ul>
<li><strong>Student credit cards.</strong> Does the company offer a card designed with students in mind? Many student cards have special APRs and fairly low credit limits that will help you build a strong credit history.</li>
<li><strong>Maintenance fees.</strong> Some credit cards require you to pay monthly or annual <a class="boa-dialog boa-com-info-layer-link" rel="glossary-popup-2" name="maintenance_fees" href="javascript:void(0);">maintenance fees</a>. Many banks offer credit cards without maintenance fees, but you may have to give up other features.</li>
<li><strong>Annual percentage rate.</strong> The APR tells you how much credit will cost you on a yearly basis. Many cards offer an introductory or promotional rate that increases after several months, so be aware: That low rate may increase significantly after a while. Some cards will increase your APR if you miss or are late with a payment. Some cards have variable APRs that fluctuate based on an index such as the <a class="boa-dialog boa-com-info-layer-link" rel="glossary-popup-1" name="prime_rate" href="javascript:void(0);">U.S. Prime Rate</a>.</li>
<li><strong>Grace period.</strong> If you charge something today, does the card issuer start charging you interest on that purchase today or after a grace period of a certain number of days? Some credit card issuers give you a grace period only when the account is paid in full and consists entirely of purchases.</li>
<li><strong>Fees and penalties.</strong> How much will you pay in late fees or fees for balance transfers and cash advances?</li>
<li><strong>Rewards and discounts.</strong> Does the card offer special incentives like the opportunity to build up frequent flyer miles or earn rewards that can be redeemed for merchandise or cash back? Do cardholders get discounts that would pay off for you?</li>
<li><strong>Special offers.</strong> Is the lender offering any special rates or bonus rewards for opening the account? Can you take advantage of any special offers just for students?</li>
<li><strong>Acceptance.</strong> Can you use the card anywhere? You can find the best credit card deal in the world, but if you can&rsquo;t use it when and where you want, all the other features won&rsquo;t matter.</li>
</ul>
</li>
<li><span>Read the fine print</span>
<p>Before you submit your credit card application, make sure that you've read all the terms and conditions closely. If you don't take the time to read them now, you may get hit with unexpected fees or APR increases later.</p>
</li>
</ol>															</div>			<div class="empty"></div>	</div></div>
					<div id="glossary-popup-1" class="hide tabs-main-content">
						<h3>Prime rate</h3>
						<p>The interest rate that banks charge their best customers when lending them money. The U.S. Prime Rate, as published daily by The Wall Street Journal, is based on a survey of the prime rates of the 10 largest banks in the United States. The U.S. Prime Rate is used by some financial institutions to calculate variable interest rates for credit cards. Changes in the U.S. Prime Rate influence changes in other rates, including mortgage interest rates.</p>
					</div>
					<div id="glossary-popup-2" class="hide tabs-main-content">
						<h3>Maintenance fees</h3>
						<p>A charge made by a financial institution for keeping an account, a charge made to a deposit account if the minimum balance is not met or a recurring charge applied to deposit products to pay for their maintenance.</p>
					</div>
					<div id="glossary-popup-3" class="hide tabs-main-content">
						<h3>Annual percentage rate (APR)</h3>
						<p>The annual percentage rate (APR) is the cost of credit expressed as a yearly rate. The APR is a measure of the total cost of credit, including interest, loan discount, origination fees, transaction charges, and premiums for credit-guarantee insurance; it is not an interest rate. The APR relates the amount and timing of value received by the borrower to the amount and timing of payments made by the borrower. The APR is designed to take into account all relevant factors and to provide a uniform measure for comparing the costs of similar credit transactions.</p>
					</div>
					<div id="glossary-popup-4" class="hide tabs-main-content">
						<h3>Credit rating</h3>
						<p>A numeric expression of creditworthiness based upon an individual's present financial condition and past credit history.</p>
					</div>
		
<div class="page-navigation-module">	<div class="link-w-gray-dotted-skin">			<div class="empty"></div>		<div class="boa-brd-top"></div>			<div>				<a href="/student-banking/resources/overview.go" name="return_resources_menu_link" class="left-link"><span class="guillemet guillement-set">&#8249;&#8249;</span> Return to resources menu</a>					<a href="/student-banking/resources/using-online-mobile-banking.go" name="next_article_mobile_online_banking_link" class="right-link">Next article: Using Mobile and Online Banking <span class="raquo-link">&#8250;&#8250;</span></a>			</div>		<div class="clear-both"></div>	</div></div>	<script type="text/javascript" src="https://www.bankofamerica.com/pa/components/modules/social-widget-module/1.2.5/script/socialplugin.js"></script>
	





<div class="social-widget-module">
	<div class="social-widget-inner" style="margin:22px 0px 3px 0px;">
		
			<div id="sharebar">
				 <script type="text/javascript">
				new com.bofa.socialplugin.core.ShareBarPlugin().display({
						"socialplugin_apppath" : "https://www.bankofamerica.com/pa/components/modules/social-widget-module/1.2.5",
						"socialconfig_apppath" : "https://www.bankofamerica.com/content/social",
						"gigyaApiKey" : "3_tIhxOOqZ3o4KC8r_VvalOR-b72A08kp4a1vdf6uyaSH4VTdeKCqMmAwh7n7AX4gz",
						"elementId" : "sharebar",
						"type" : "bottom600",
						"showCounters" : true,
						"enablePrint" : false,
						"contentOverride"	: {
							"facebook" : { "showCounter": false , "tinyUrlCode": 'gvllq' },
							"twitter"  : { "showCounter": false , "tinyUrlCode": '6tv6v' },
							"linkedin"  : { "showCounter": false , "tinyUrlCode": '9u23z' },
							"digg"  : { "showCounter": false },
							"delicious"  : { "showCounter": false },
							"reddit"  : { "showCounter": false },
							"stumbleupon"  : { "showCounter": false },
							"pinterest"  : { "showCounter": false }
						}
					});
				 </script>
			</div>

	</div>
</div></div>
						<div class="flex-col rt-col" >

<div class="side-well-module">
   <div class="content-list-skin sup-ie" style="">
      <div class="sw-outer">
         <div class="sw-inner">
            <div class="sw-corner sw-tleft"></div>
            <div class="sw-corner sw-tright"></div>
            <div class="sw-main sw-std-pad">
            
            	<h2>Credit cards for students
            	</h2>
			            	<ul>
			            		<li>
									Travel rewards. Cash rewards. Lower APR. We have 3 credit card options available to students. Choose the one that's right for you.
			               		</li>
			            		<li>
									<a name="explore_credit_card_options" href="/student-banking/student-credit-cards.go" target="_self">Explore credit card options <span class="raquo-link">&rsaquo;&rsaquo;</span></a>
			               		</li>
			               	</ul>
             
            </div>
            <div class="sw-bottom"></div>
         </div>
         <div class="sw-corner sw-bleft"></div>
         <div class="sw-corner sw-bright"></div>
      </div>
   </div>
</div>

<!-- module-specific stylesheet -->







	<div class="icon-w-text-link-module" style="padding-top:8px;">
		<div class="icon-w-text-skin"> 
			<div class="sw-outer bg-none">
				<div class="sw-inner">
					<div class="sw-corner sw-tleft"><!--  --></div>
					<div class="sw-corner sw-tright"><!--  --></div>
					<div class="sw-corner sw-bleft"><!--  --></div>
					<div class="sw-corner sw-bright"><!--  --></div>
					<h2 class="h2-fsd-sw-red">Additional resources</h2>
					<p></p>
					<ul class="features">
						<li>
							<img alt="credit-icon" src="/content/images/ContextualSiteGraphics/Marketing/Highlights/en_US/credit-icon-77x77.png"  />							
							<a href="/credit-cards/credit-education.go " target="_self">Learn About Credit</a><br />Explore a wide range of articles and FAQs about credit cards.
							<div class="clearboth"></div>
						</li>
						<li>
							<img alt="better-money-habits-icon" src="/content/images/ContextualSiteGraphics/Marketing/Highlights/en_US/khan-77x77.png"  />							
							<a href="https://www.bettermoneyhabits.com/credit.html?bcen=8a6b" target="_blank">Better Money Habits&trade;</a><br />Informative credit videos&mdash;powered by Bank of America in partnership with Khan Academy.
							<div class="clearboth"></div>
						</li>
						<li>
							<img alt="college-planning-icon" src="/content/images/ContextualSiteGraphics/Marketing/Highlights/en_US/college-planning-78x78.png "  />							
							<a href="/planning/college.go" name="college-planning" target="_self">College Planning</a><br />Find out how to plan for and manage college expenses.
							<div class="clearboth"></div>
						</li>
					</ul>
				</div>
				<div class="sw-bottom"><!--  --></div>
			</div> 
		</div>
	</div>

	<style type="text/css">
		.icon-w-text-link-module .icon-w-text-skin h2.h2-fsd-sw-red {border-bottom:1px solid #E0D3D9;font-weight:normal!important;padding-top:13px;}
	</style>




	<div class="hide com-interstitial-modal">
     	<h3>Important Notice</h3>
   		<div class="flex-modal-main-content">
   		
      		<p><strong>You're continuing to another website</strong></p>
      		<p>You're continuing to another website that Bank of America doesn't own or operate. Its owner is solely responsible for the website's content, offerings and level of security, so please refer to the website's posted privacy policy and terms of use.</p>
   	
   	<div class="flex-modal-buttons">
	      	<a href="javascript:void(0);" class="button-common button-blue" name="leaving_bank_modal_continue"><span>Continue</span></a>
	         
	      	<a href="javascript:void(0);" class="button-common button-gray close-com-interstitial" name="leaving_bank_modal_cancel"><span>Return to Bank of America</span></a>
	         
          <div class="clearboth"></div>
      </div>
   </div>
</div>

 <!-- code for preferred rewards pages -->

<div class="olb-dsp-state-selector-module">
    <div class="no-href-skin">
        <div class="sw-outer bg-none">
            <div class="sw-inner">
                <div class="sw-corner sw-tleft"></div>
                <div class="sw-corner sw-tright"></div>
                <div class="sw-corner sw-bleft"></div>
                <div class="sw-corner sw-bright"></div>
				<p class="pbtm-5">Information for 
					Virginia
				</p>
			  	<a name="anc-change-state" class="show-state-select-modal" rel="state-select-modal" href="javascript:void(0)">Change State <span class="ada-hidden">layer</span></a>
			</div>
            <div class="sw-bottom"></div>
        </div>      
    </div>
</div>


<!-- XSS attack Prevention -->
<script type="text/javascript">
</script>	


<div class="modal-content-module">
   <div class="state-select-skin">
      
	  
	<div class="state-select-modal hide" id="state-select-modal" >
	  
		<div class="modal-content">
            <h2>
				Select Your State
				<span class="ada-hidden"></span>
			</h2>
			<p>Please tell us where you bank so we can give you accurate rate and fee information for your location.</p>
			<form method="post" action="" name="submitState" id="submitState">
				<fieldset>
					<legend><span class="ada-hidden">State Selection Form</span></legend>
					<input type="hidden" name="requestedUrl" value="" />
					<label for="stateListId">Current State</label> 
					
<select name="stateListName" id="stateListId" class="select-box" title="Select a state" required="true">
    <option value=" "
    >Select state</option>
    <option value="AL">Alabama</option>
    <option value="AK">Alaska</option>
    <option value="AZ">Arizona</option>
    <option value="AR">Arkansas</option>
    <option value="CA">California</option>
    <option value="CO">Colorado</option>
    <option value="CT">Connecticut</option>
    <option value="DE">Delaware</option>
    <option value="DC">District of Columbia</option>
    <option value="FL">Florida</option>
    <option value="GA">Georgia</option>
    <option value="HI">Hawaii</option>
    <option value="ID">Idaho</option>
    <option value="IL">Illinois</option>
    <option value="IN">Indiana</option>
    <option value="IA">Iowa</option>
    <option value="KS">Kansas</option>
    <option value="KY">Kentucky</option>
    <option value="LA">Louisiana</option>
    <option value="ME">Maine</option>
    <option value="MD">Maryland</option>
    <option value="MA">Massachusetts</option>
    <option value="MI">Michigan</option>
    <option value="MN">Minnesota</option>
    <option value="MS">Mississippi</option>
    <option value="MO">Missouri</option>
    <option value="MT">Montana</option>
    <option value="NE">Nebraska</option>
    <option value="NV">Nevada</option>
    <option value="NH">New Hampshire</option>
    <option value="NJ">New Jersey</option>
    <option value="NM">New Mexico</option>
    <option value="NY">New York</option>
    <option value="NC">North Carolina</option>
    <option value="ND">North Dakota</option>
    <option value="OH">Ohio</option>
    <option value="OK">Oklahoma</option>
    <option value="OR">Oregon</option>
    <option value="PA">Pennsylvania</option>
    <option value="RI">Rhode Island</option>
    <option value="SC">South Carolina</option>
    <option value="SD">South Dakota</option>
    <option value="TN">Tennessee</option>
    <option value="TX">Texas</option>
    <option value="UT">Utah</option>
    <option value="VT">Vermont</option>
    <option value="VA">Virginia</option>
    <option value="WA">Washington</option>
    <option value="WV">West Virginia</option>
    <option value="WI">Wisconsin</option>
    <option value="WY">Wyoming</option>


</select>

						<a name="state_select_submit" class="btn-bofa btn-bofa-small state-select-modal-go-button" href="javascript:void(0);" >
							Go<span class="ada-hidden"> Button to be used after you select your state.</span>
						</a>
				</fieldset>
			</form>
			<div class="clearboth"></div>
         </div>
      </div>
   </div>
</div>


</div>
						<div class="clearboth"></div>
					</div>
					<div class="footer">
						<div class="footer-top">&nbsp;</div>
						<div class="footer-inner">





<div class="power-footer-module">
	<div class="flex-microdata-skin sup-ie">
			<div class="breadcrumbs">
			<div itemscope itemtype="http://schema.org/BreadcrumbList">
				<!-- breadcrumbs div -->
					<!-- Inside 1st breadcrumb -->
					<div itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="bold-arrow">
								<a itemprop="item" href="/" name="bank_of_america_breadcrumb" target="_self"><span itemprop="name">Bank of America</span><meta itemprop="position" content="1"/></a>
					</div>
					
						<!-- Inside 2nd breadcrumb -->
						<div itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="arrow">
									<a itemprop="item" href="/student-banking/overview.go" name="student_banking_breadcrumb" target="_self"><span itemprop="name">Student Banking</span><meta itemprop="position" content="2"/></a>
						</div>
				
					<!-- Inside 3rd breadcrumb -->
					<div itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="arrow">
								<a itemprop="item" name="resources_breadcrumb" href="/student-banking/resources/overview.go" target="_self">Resources</a>
					</div>
				
				<!-- Inside 4th breadcrumb -->
				<div itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
					<span itemprop="name">
						Banking Basics: Choosing a Credit Card
					</span>
					<meta itemprop="position" content="4" />
				</div>
				<div class="clearboth"></div>
			</div>
			</div>
		
			<!-- Inside power footer columns -->
			<div class="pf-columns">		   
						<div class="pf-col">
							<ul>
								<li>Solutions for Students</li>
										<li><a href="/student-banking/student-checking-savings-account.go" name="power_footer_checking_and_savings">Checking & Savings</a></li>
										<li><a href="/student-banking/student-credit-cards.go" name="power_footer_credit_cards">Credit Cards</a></li>
										<li><a href="/student-banking/online-mobile-banking.go" name="power_footer_mobile_and_online_banking">Mobile & Online Banking</a></li>
										<li><a href="/student-banking/solutions-for-students.go" name="power_footer_banking_options_students">Banking options for students</a></li>
							</ul>
						</div>
						<div class="pf-col">
							<ul>
								<li>Solutions for Parents</li>
										<li><a href="/student-banking/saving-for-college.go" name="saving_for_college">Saving for College</a></li>
										<li><a href="/student-banking/financial-aid.go" name="financial_aid">Financial Aid</a></li>
										<li><a href="/student-banking/managing-student-finances.go" name="managing_student_finances">Managing Student Finances</a></li>
							</ul>
						</div>
						<div class="pf-col">
							<ul>
								<li>Resources</li>
										<li><a href="/student-banking/resources/overview.go" name="sb-resource-loans-banking">Student loans & banking</a></li>
							</ul>
						</div>
					<div class="clearboth"></div>
			</div>
	</div>
</div>




 



		<div class="global-footer-module">
			<div class="fsd-skin">

				<div class="footer-bottom-left" style="float:left;max-width:66%;">
	    			<div class="gf-links">	          	
						
					
									
									<a  target="_self" href="/" 
									    name="global_footer_home">Home
									</a>
									
						
					
									
									<a  target="_self" href="/accessiblebanking/overview.go" 
									    name="global_footer_accessible_banking">Accessible Banking
									</a>
									
						
					
									
									<a  target="_self" href="/privacy/overview.go" 
									    name="global_footer_privacy_security">Privacy & Security
									</a>
									
						
					
									
									<a  target="_self" href="http://careers.bankofamerica.com/careershome.aspx" 
									    name="global_footer_careers">Careers
									</a>
									
						
					
									
									<a  target="_self" href="/sitemap/personal.go" 
									    name="global_footer_site_map">Site Map
									</a>
									
						
					
									<a href="javascript:void(0);" class="gf-last-link boa-dialog boa-com-info-layer-link" name="global_footer_advertising_practices_lnk" rel="global_footer_advertising_practices">Advertising Practices</a>
								<div id="global_footer_advertising_practices" class="hide">
									<h3>Advertising Practices</h3>
										<p>We strive to provide you with information about products and services you might find interesting and useful. Relationship-based ads and online behavioral advertising help us do that.</p>
<p>Here's how it works: We gather information about your online activities, such as the searches you conduct on our Sites and the pages you visit. This information may be used to deliver advertising on our Sites and offline (for example, by phone, email and direct mail) that's customized to meet specific interests you may have.</p>
<p>If you prefer that we do not use this information, you may <a onclick="$('.ui-dialog').remove();" name="WebsiteAdPractices_OptOut" href="/privacy/online-privacy-notice.go#advertising-on-our-sites" target="_blank">opt out of online behavioral advertising</a>. If you opt out, though, you may still receive generic advertising. In addition, financial advisors/Client Managers may continue to use information collected online to provide product and service information in accordance with account agreements.</p>
<p>Also, if you opt out of online behavioral advertising, you may still see ads when you sign in to your account, for example through Online Banking or MyMerrill. These ads are based on your specific account relationships with us.</p>
<p>To learn more about relationship-based ads, online behavioral advertising and our privacy practices, please review the <a onclick="$('.ui-dialog').remove();" name="WebsiteAdPractices_PrivacyNotice" href="/privacy/online-privacy-notice.go" target="_blank">Bank of America Online Privacy Notice</a> and our <a onclick="$('.ui-dialog').remove();" name="Online-privacy-faqs" href="/privacy/faq/online-privacy-faq.go" target="_blank">Online Privacy FAQs</a>.</p>
								</div>
						<div class="clearboth"></div>
	    			</div>
	      			<p>Bank of America, N.A. Member <acronym title="Federal Deposit Insurance Corporation">FDIC</acronym>. <a onclick="window.open('/help/equalhousing_popup.go','newwin','width=640,height=371,scrollbars=yes,resizable=yes,left=35,top=161'); return false;" name="equal_housing_lender" href="/help/equalhousing_popup.go" target="_blank">Equal Housing Lender<img src="https://www2.bac-assets.com/content/images/ContextualSiteGraphics/Logos/en_US/icon_equal_housing_lender.gif" alt="" width="14" height="9" /></a><br />&copy; 2017 Bank of America Corporation.</p>
         		</div>
         		<div class="footer-social-container" style="float:right;max-width:30%;padding-left:50px;padding-top:19px;">




<div class="boa-social-loader" data-loaded="false" data-platform="borneo"  data-options=''></div>

         		</div>
         		<div class="clearboth"></div>
  			</div>
		</div>




 
<script language="javascript" src="https://www2.bac-assets.com/pa/global-assets/external/coremetrics/hp/eluminate.js"></script>
<script language="javascript" src="https://www2.bac-assets.com/pa/global-assets/external/coremetrics/hp/cmdatatagutils.js"></script>


<script language="javascript">
	function cmSetDD(){var testString=window.location.href;if(testString.toLowerCase().indexOf('.bankofamerica.com')>-1){testString=testString.toLowerCase();var tempArr=testString.split('.bankofamerica.com');var tempStr=tempArr[0];if(tempStr.indexOf('\/\/')>-1){tempArr=tempStr.split('\/\/');tempStr=tempArr[1];if(tempStr.indexOf('.')>-1){tempArr=tempStr.split('.');tempStr=tempArr[0];var tempStrPt2=tempArr[1]}if(tempStr.indexOf('www')>-1){if(tempStr.indexOf('-')>-1){cmSetStaging()}else if(tempStrPt2!=null){if(tempStrPt2.indexOf('ecnp')>-1){cmSetStaging()}}else{cmSetProduction()}}else if(tempStr.indexOf('-')>-1){if(tempStr.indexOf('sitekey')>-1){if(tempStr=='sitekey'){cmSetProduction()}else{cmSetStaging()}}else{cmSetStaging()}}else if(tempStrPt2!=null){if(tempStrPt2.indexOf('ecnp')>-1){cmSetStaging()}}else{cmSetProduction()}}}}if(typeof cmSetStaging=='function'){cmSetDD()}
</script> 

		<script type="text/javascript">
			cmCreatePageviewTag('studentbanking:Content:resources:bank_basics;choosing-a-credit-card', null, null, 'studentbanking:Content:resources:bank_basics', false, false, null, false, false, null, null, null, null, null, null, null, null, null, null, null, null);
		</script>

</div>
					</div>
				</div>
			</div>
		</div>
	</body>	
</html>

