
 

				<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
				<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
				<head>



<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<title>Student Bank Accounts & Solutions from Bank of America</title>


					<meta name="Keywords" CONTENT="student bank accounts, student bank account, bank accounts for students, bank account for students" />
					<meta name="Description" CONTENT="Browse a variety of student bank accounts and student banking solutions provided by Bank of America. Open a student bank account today." />


<link rel="shortcut icon" href="https://www2.bac-assets.com/pa/global-assets/1.0/graphic/favicon.ico" type="image/ico" />


		<link rel="stylesheet" type="text/css" media="all" href="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/APS-deposits/2017.03.0/style/global-aps-dp-jawr.css"/>
		<link rel="stylesheet" type="text/css" media="all" href="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/APS-deposits/2017.03.0/style/sb-aps-dp-jawr.css"/>
		
		<script type="text/javascript" src="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/APS-deposits/2017.03.0/script/global-aps-dp-jawr.js"></script>
		<script type="text/javascript" src="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/APS-deposits/2017.03.0/script/sb-aps-dp-jawr.js"></script>
		
			<script type="text/javascript">
				$(window).load(function(){asyncPrintCssInclude('https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/APS-deposits/2017.03.0/style/global-aps-dp-jawr-print.css');});
				$(window).load(function(){asyncPrintCssInclude('https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/APS-deposits/2017.03.0/style/sb-aps-dp-jawr-print.css');});
			</script>
<script type="text/javascript">
(function() {
	if (typeof mboxUpdate == "function") {
		var windowURL = window.location.href
	    windowURL = windowURL.slice( windowURL.indexOf('.')+1);
		windowURL = windowURL.split( '?' )[0];
		windowURL = windowURL.toLowerCase();
		//alert(windowURL);
		if (
		    //If no mboxes on page, mbox count will be < 1
		    (mboxFactoryDefault.getMboxes().length() < 1) &&  
			
			//Also check for high-volume pages that do not need global logging
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go") &&
			(windowURL != "bankofamerica.com/myaccounts/signin/signin.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/entry/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signonscreen.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatechallengeanswer.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatePassword.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/mobile/banking.go")&&
			(windowURL != "bankofamerica.com/content/preload/olb-myaccount-preload-jawr-module.htm")
			)
		{

			var mboxDiv = document.createElement("div");
			mboxDiv.id = "adobe_touch_clarity_replacement";
			mboxDiv.style.display = "none";
			if (document.body && document.body.firstChild) document.body.insertBefore(mboxDiv,document.body.firstChild);
			mboxDefine(mboxDiv.id,'bac_global_bottom');
			mboxUpdate('bac_global_bottom');
		}
	}	
})();
</script>

		<script src="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/Global/1.0/script/tealeafbundle.js" type="text/javascript"></script>
			<script>
				var boaPageDataJS = {};
					boaPageDataJS.isLLE = "false";
			</script>
				<style>body{display:none;}</style>
	</head>		

	<body class="fsd-layout-body">	

				<script type="text/javascript">if(self == top){var theBody=document.getElementsByTagName("body")[0];theBody.style.display="block";}else{top.location=self.location;}</script>
				<noscript><style>body{display:block;}</style></noscript>
					<a class='ada-hidden ada-visible-focus' href='#skip-to-h1' id='ada-skip-link'>Skip to main content</a>
		<div class="fsd-layout fsd-2c-600lt-layout">
			<div class="fsd-border">
				<div class="center-content">
					<div class="header">
		  



<script language="javascript" src="/pa/components/modules/tag-manager-module/1.1/script/tag-manager-module-borneo-global-skin.js"></script>
<script>

(function() {
  var fireCallback = function( cb ) {
    if ( typeof cb === "function" ) cb();
  };
  
  function ddoPopulateBase( callback ) {
    try {
		  var DDO = window.digitalData,
		  	bactm_mergeDDO = function( newDDO, priorDDO ) {
		  		if( typeof priorDDO === "undefined" ) {
				  	priorDDO = digitalData || {};
				  }

			    for (var l in newDDO) {
			        if (typeof priorDDO[l] === "undefined") {
			            priorDDO[l] = newDDO[l];
			        }
			        if (newDDO[l] !== null) {
			            if (typeof newDDO[l] === "object") {
			                bactm_mergeDDO(newDDO[l], priorDDO[l]);
			            } else {
			                priorDDO[l] = bactm_validateValue( newDDO[l] ) ? newDDO[l] : priorDDO[l];
			            }
			        }
			    }

			    return priorDDO;
				},
				bactm_olb3rdPartyId = "null";

			if (typeof DDO === "undefined") {
				var simpleDDO = { page: { pageInfo:[{ pageID: null }], attributes: {}, category: { primaryCategory: null }}};

				DDO = (typeof digitalData === "object") ? digitalData : simpleDDO; 
			}

				DDO = bactm_mergeDDO( {pageInstanceID:"notprod",load_coremetrics:false,load_opinionlabs:false,load_touchcommerce:true,load_audiencemanager:true,page:{pageInfo:[{pageID:null,destinationURL:null,referringURL:null,issueDate:null,language:null,segmentValue:null,appName:null,appStepNumber:null,appStepName:null,attr:"-_--_--_--_--_--_--_--_--_--_--_--_--_--_-"}],category:{primaryCategory:null,addlCategory:null,pageType:null},attributes:{searchString:null,searchResults:null,olbSessionID:null,subCampaignCode:null,DARTUrl:null,stateCookie:null,SASIEnabled:false,needOLBcookie:false,standardDART:[],standardDARTes:[],clickDART:[],clickDARTes:[],gaId:[],chat:{account_type:null,boa_associate:null,boa_retiree:null,customer_lob:null,customer_segment:null,data:null,email_campaign:null,entitlement_code:null,error_category:null,error_count:null,first_login:null,inqSalesProductTypes:{},invitation_background:null,invitation_template:null,referral_campaign:null,getStateValue:false,cust_fn:null,cust_ln:null,target:null}}},user:{segment:null,online_id:null,preferred_rewards_tier:null,olb3rdpartyid:null},version:"BAC_0.12"}, DDO );

			DDO.page.pageInfo[0].pageID = "studentbanking:Content:students;solutions-for-students";
			DDO.page.category.primaryCategory  = "studentbanking:Content:students";
			DDO.page.pageInfo[0].language = "en-US";
			DDO.page.attributes.olbSessionID = "null";
			DDO.page.attributes.SASIEnabled =  "false";
			if (typeof DDO.user != "undefined" && typeof DDO.user.olb3rdpartyid != "undefined") {
				DDO.user.olb3rdpartyid = bactm_olb3rdPartyId;
			}

			window.utag_data = {};
			window.bactm_envSelector = bactm_setTMLib();
			window.digitalData = DDO;

      return fireCallback( callback );

    } catch(e) { }
  }
	if( window.boa && window.boa.digitalData ) {
    window.boa.digitalData.register( ddoPopulateBase );
	}
	else {
	  // Handle scenario where the header isn't available (and thus the default digitalData object and utag loader are missing).
	  //
		var writeScript = function(a,b,c,d){
			a='//tags.tiqcdn.com/utag/bofa/main/' + bactm_envSelector + '/utag.js';
			b=document;
			c='script';
			d=b.createElement(c);
			d.src=a;
			d.type='text/java'+c;
			d.async=true;
			a=b.getElementsByTagName(c)[0];
			a.parentNode.insertBefore(d,a);
		};

		ddoPopulateBase( writeScript );
	}
})();			
</script>





	
	
				<noscript>
				
					<div class="fauxdal-overlay"></div>
					<div class="fauxdal-module">
						<div class="js-disabled-skin">
							<div class="fauxdal-top"></div>
							<div class="fauxdal-bottom">
								<div class="fauxdal-content">
										<div class="fauxdal-title">
											Please Use JavaScript
										</div>
											<p>You need a web browser that supports JavaScript to use our site. Without it, some pages won&rsquo;t work as designed. To make sure JavaScript is turned on, please adjust your browser settings and refresh.</p><p><a title="Browser Help and Tips" name="Browser_Help_and_Tips" href="/onlinebanking/online-banking-security-faqs.go">Browser Help and Tips</a></p>
										
								</div>        
								<div class="fauxdal-close"> 
									<a class="btn-bofa btn-bofa-small" href=?js=y>Close</a>
								</div>
								
							</div>
						</div>
					</div>
				</noscript>



 


<div class="header-module">
	<div class="text-w-logo-skin">
		<div class="header-left">
	  
			<div itemscope itemtype="http://schema.org/Corporation" class="bofa-logo">
				<a itemprop="url" name="anc-student-banking" title="Bank of America Logo" href="/">
					<img itemprop="logo" height="28" width="221" 
					     alt="Bank of America Logo" src="https://www2.bac-assets.com/content/images/ContextualSiteGraphics/Logos/en_US/boa_logo.gif"/>
				</a>
			</div>
				<div class="product" data-font="cnx-regular">Student Banking</div>
			
			<div class="clearboth"></div>

		</div>
		
		<div class="header-right">
			<ul class="header-links">
			
				
					
				
							<li class="sign-in">
		<a					href="/sitemap/hub/signin.go" target="_self"
		name="sign_in">Sign In</a> 
							</li>
					
				
							<li>		<a					href="/" target="_self"
		name="home">Home</a> 
</li>
					
				
							<li>		<a					href="https://locators.bankofamerica.com" target="_self"
		name="locations">Locations</a> 
</li>
					
				
							<li>		<a					href="/contactus/contactus.go" target="_self"
		name="contact_us">Contact Us</a> 
</li>
					
				
							<li class="last-link">	
		<a					href="/student-banking/resources/student-banking-faqs.go" target="_self"
		name="help">Help</a> 
							</li>
			</ul>
			
			<div class="clearboth"></div>

			<!-- include search-dotcom-util -->



<div class="header-search nlh">
  
  <div class="nav-search">
    <form class="search-form" action="https://secure.bankofamerica.com/myaccounts/public/search-results/unAuthenticatedSearch.go" data-js="/pa/components/utilities/search-util/1.0/script/nav-search.min.js" data-css="/pa/components/utilities/search-util/1.0/style/nav-search.css" data-text-unavailable="Search Currently Unavailable">
      <div class="search-input-container cf" data-icon="search">
        <label for="nav-search-query" class="ada-hidden">Search Term</label>
        <input type="text" placeholder="How can we help you?" name="query" class="search-query" id="nav-search-query" 
          maxlength="99" rel="Search" autocomplete="off"><input type="submit" alt="Search" title="Search" value="Submit Search" name="Search Module - Top Result – Search Button" class="submit track-me">
      </div>
    </form>
  </div>

</div>

		</div>

 		<div class="clearboth"></div>
 	</div>
</div>







	<div class="top-nav-module">
		<div class="fsd-skin sup-ie">
			<ul class="nav-list">
					
					
					<li>
						
									<a href="/student-banking/overview.go" class="top-menu-item"
									name="overview_topnav" id="overview_topnav">Overview</a>
					</li>
					
					
					<li>
						
								<a href="/student-banking/solutions-for-students.go" class="top-menu-item selected"
								name="accounts_for_students_topnav" id="accounts_for_students_topnav">Accounts for Students<span class="ada-hidden"> link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/student-banking/solutions-for-students.go"  name="solutions_for_students_topnav" id="solutions_for_students_topnav">Solutions for Students </a>
															<a href="/student-banking/student-checking-savings-account.go"  name="checking_and_savings_topnav" id="checking_and_savings_topnav">Checking & Savings </a>
															<a href="/student-banking/student-credit-cards.go"  name="credit_cards_topnav" id="credit_cards_topnav">Credit Cards </a>
									</div>
								
									<div class="hasSub">
														<a class="with-info" href="/student-banking/online-mobile-banking.go"  name="mobile_and_online_banking_topnav" id="mobile_and_online_banking_topnav"><strong>Mobile &amp; Online Banking</strong> 
															
															<span class="sub-nav-item-info">Services designed for a student's on-the-go lifestyle</span>
														</a>
														<a class="with-info" href="/student-banking/resources/types-of-student-loans.go"  name="college_planning_topnav" id="college_planning_topnav"><strong>Student Loan Options</strong> 
															
															<span class="sub-nav-item-info">Find out about different types of student loans
</span>
														</a>
									</div>
									<span class="ada-hidden"> End of Submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
					
					
					<li>
						
								<a href="/planning/college.go" class="top-menu-item"
								name="college_planning_topnav" id="college_planning_topnav">College Planning<span class="ada-hidden"> link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/planning/college.go"  name="preparing_for_college_topnav" id="preparing_for_college_topnav">Preparing for College </a>
															<a href="/student-banking/saving-for-college.go"  name="saving_for_college_topnav" id="saving_for_college_topnav">Saving for College </a>
															<a href="/student-banking/financial-aid.go"  name="financial_aid_topnav" id="financial_aid_topnav">Financial Aid </a>
															<a href="/student-banking/managing-student-finances.go"  name="managing_student_finances_topnav" id="managing_student_finances_topnav">Managing Student Finances </a>
															<a href="/student-banking/resources/fafsa-form.go"  name="understanding_the_fafsa_form_topnav" id="understanding_the_fafsa_form_topnav">Understanding the FAFSA form </a>
									</div>
								
									<div class="hasSub">
									</div>
									<span class="ada-hidden"> End of Submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
					
					
					<li>
						
								<a href="/student-banking/resources/overview.go" class="top-menu-item"
								name="resources_topnav" id="resources_topnav">Resources<span class="ada-hidden"> link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/student-banking/resources/overview.go"  name="resources_overview_topnav" id="resources_overview_topnav"><span class="ada-hidden">Resources </span>Overview </a>
															<a href="/student-banking/resources/glossary.go"  name="glossary_topnav" id="glossary_topnav">Glossary </a>
															<a href="/student-banking/resources/student-banking-faqs.go"  name="faqs_topnav" id="faqs_topnav">FAQs </a>
									</div>
								
									<div class="hasSub">
														<a class="with-info" href="/student-banking/resources/shared-credit-cards.go"  name="banking_basics_topnav" id="banking_basics_topnav"><strong>Banking basics</strong> 
															
															<span class="sub-nav-item-info">Shared credit card accounts</span>
														</a>
														<a class="with-info" href="/student-banking/resources/building-your-credit-history.go"  name="after_college_topnav" id="after_college_topnav"><strong>After college</strong> 
															
															<span class="sub-nav-item-info">Building your credit history</span>
														</a>
									</div>
									<span class="ada-hidden"> End of Submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
			</ul>
				<div class="clearboth"></div>
		</div>
	</div>



<div class="page-title-fsd-module h-100" id="skip-to-h1">
	<div class="standard-red-skin sup-ie">
			<h1 data-font="cnx-regular">Solutions and Bank Accounts for Students</h1>
	</div>
</div>




<div class="engagement-module">
	<div class="carousel-banner-skin">
		<div id="banner-slides">
			<a href="javascript:void(0);" name ="previous_content" class="prev"><span class="ada-hidden">Previous featured content item</span></a>
				<div class="banner-slides-container">
							<div class="carousel-slide carousel-first" style="width:980px;height:350px;">
								<div class="carousel-content">
									<h2>I want a checking account that&rsquo;s simple and easy</h2>
									<p></p>
									<div class="tile-links">
											<a name="core_checking_student_tile" href="/deposits/checking/personal-checking-account.go?STUDENT_IND=Y"><strong>Bank of America Core Checking<sup>&reg;</sup> <span class="raquo-link">&#8250;&#8250;</span></strong></a>
											<a name="online_banking_student_tile" href="/student-banking/online-mobile-banking.go"><strong>Explore benefits of Online Banking <span class="raquo-link">&#8250;&#8250;</span></strong></a>
											<a name="credit_cards_tile" href="/student-banking/student-credit-cards.go"><strong>Apply for credit cards for students <span class="raquo-link">&#8250;&#8250;</span></strong></a>
									</div>
									<div class="clearboth"></div>
								</div>						

								<div class="carousel-image">
									<img src="/content/images/ContextualSiteGraphics/Marketing/Banners/en_US/banner-hero-carousel-two-students.png" alt=""/>
								</div>
									<div class="slide-count first-count"><span class="ada-hidden">Featured content</span>1 of 3</div>
							</div> 		
							<div class="carousel-slide carousel-second" style="width:980px;height:350px;">
								<div class="carousel-content">
									<h2>Help me set up Mobile Banking</h2>
									<p>That's what we are here for</p>
									<div class="tile-links">
											<a name="mobile_banking_tile" href="/student-banking/online-mobile-banking.go"><strong>Learn about <br/>Mobile Banking <span class="raquo-link">&#8250;&#8250;</span></strong></a>
											<a name="using_mob_banking_tile" href="/student-banking/resources/using-online-mobile-banking.go"><strong>Using Mobile &amp; Online Banking <span class="raquo-link">&#8250;&#8250;</span></strong></a>
											<a name="mob_app_tile" href="/online-banking/mobile-banking-applications.go"><strong>Get the<br/>Mobile App <span class="raquo-link">&#8250;&#8250;</span></strong></a>
									</div>
									<div class="clearboth"></div>
								</div>						

								<div class="carousel-image">
									<img src="/content/images/ContextualSiteGraphics/Marketing/Banners/en_US/banner-hero-student-banking-solutions.png" alt=""/>
								</div>
									<div class="slide-count"><span class="ada-hidden">Featured content</span>2 of 3</div>
							</div> 		
							<div class="carousel-slide carousel-third" style="width:980px;height:350px;">
								<div class="carousel-content">
									<h2>Help me learn about banking</h2>
									<p>Done&mdash;and in easy-to-understand language</p>
									<div class="tile-links">
											<a name="shared_credit_card_accts_tile" href="/student-banking/resources/shared-credit-cards.go"><strong>Shared credit card accounts <span class="raquo-link">&#8250;&#8250;</span></strong></a>
											<a name="auto_loan_tile" href="/student-banking/resources/getting-an-auto-loan.go"><strong>Getting an <br />auto loan <span class="raquo-link">&#8250;&#8250;</span></strong></a>
											<a name="articles_resource_tile" href="/student-banking/resources/overview.go"><strong>More articles <br />and resources <span class="raquo-link">&#8250;&#8250;</span></strong></a>
									</div>
									<div class="clearboth"></div>
								</div>						

								<div class="carousel-image">
									<img src="/content/images/ContextualSiteGraphics/Marketing/Banners/en_US/banner-hero-carousel-man-in-glasses.png" alt=""/>
								</div>
									<div class="slide-count"><span class="ada-hidden">Featured content</span>3 of 3</div>
							</div> 		
				</div>  
			<a href="javascript:void(0);" name="next_content" class="next"><span class="ada-hidden">Next featured content item</span></a>
		</div>
	</div>
</div>

</div>
					<div class="columns">
						<div class="flex-col lt-col" >




<!--debug -->


	<div class="text-img-module" style="padding-top:23px;">
  		<div class="alt-full-img-skin">
				<div class="afi-mainHeader">Products, services and resources to fit a student's lifestyle</div>
				<p class="afi-parafont">We're here to make your financial life as easy as possible&mdash;because signing up for a checking or savings account, downloading a Mobile Banking app or understanding how credit cards work shouldn't be more difficult than the classes you're taking.</p>
			
						<div id="Checking, savings &amp; credit cards" class="afi-section ">
				
							
							<div class="afi-col afi-left-col">
								<img alt="" src="/content/images/ContextualSiteGraphics/Marketing/Highlights/en_US/bac_cards_branded/content-image-creditcard.png">
							</div>	
							<div class="afi-col">
								<div class="afi-main-content">
									<div class="afi-header">
										<p>
										Checking, savings &amp; credit cards
										</p>
									</div>
									<p>Get Mobile Banking and debit card convenience with our checking and savings accounts&mdash;the <a href="/deposits/checking/personal-checking-account.go?STUDENT_IND=Y" target="_self">Bank of America Core Checking<sup>&reg;</sup></a> monthly maintenance fee is waived for eligible students under 23.<a name="student_under23_footnote" href="#footnote1"><span class="ada-hidden">footnote</span><sup>1</sup></a> Our credit cards for students include shopping and travel rewards&mdash;choose the card that's right for you.</p>
										<ul>
													<li>
														<a name="checking_and_savings" href="/student-banking/student-checking-savings-account.go">Checking and savings</a>
													</li>
													<li class="last">
														<a name="credit_cards" href="/student-banking/student-credit-cards.go">Credit cards</a>
													</li>
										</ul>
								</div>
							</div>
							<div class="clearboth"></div>
					
				
						</div>
						<div class="boa-brd-top"></div>
						<div id="Mobile &amp; Online Banking" class="afi-section ">
				
							<div class="afi-col afi-left-col">
								<div class="afi-main-content">
									<div class="afi-header">
										<p>	
											Mobile &amp; Online Banking
										</p>
									</div>
									<p>From our Mobile Banking app for your smartphone, to BankAmeriDeals<sup>&reg;</sup>,<a href="#footnote2" name="BankAmeriDeals"><span class="ada-hidden">Footnote</span><sup>2</sup></a> that give you cash back when you shop, our Mobile<a href="#footnote3" name="MobileBankingApp"><span class="ada-hidden">Footnote</span><sup>3</sup></a> &amp; Online Banking services are designed for your on-the-go lifestyle.</p>
											<a name="learn_more_mobile_online_banking" href="/student-banking/online-mobile-banking.go">Learn more about Mobile & Online Banking</a>
								</div>
						
							</div>	
							<div class="afi-col">
								<img alt="" src="/content/images/ContextualSiteGraphics/Marketing/Highlights/en_US/content-image-mobile-online-banking.png">	
							</div>
							<div class="clearboth"></div>
				
						</div>
						<div class="boa-brd-top"></div>
						<div id="Planning for college" class="afi-section ">
				
							
							<div class="afi-col afi-left-col">
								<img alt="" src="/content/images/ContextualSiteGraphics/Marketing/Highlights/en_US/content-image-planning-for-college.png">
							</div>	
							<div class="afi-col">
								<div class="afi-main-content">
									<div class="afi-header">
										<p>
										Planning for college
										</p>
									</div>
									<p>It's a busy time. We get that. Which is why we've assembled these resources about college applications and financing&mdash;so you can make sense of it all.</p>
										<ul>
													<li>
														<a name="applying_student_loans" href="/student-banking/resources/types-of-student-loans.go">Applying for student loans</a>
													</li>
													<li>
														<a name="understanding_fafsa_form" href="/student-banking/resources/fafsa-form.go">Understanding the FAFSA form</a>
													</li>
													<li class="last">
														<a name="more_resources" href="/student-banking/resources/overview.go">More resources</a>
													</li>
										</ul>
								</div>
							</div>
							<div class="clearboth"></div>
					
				
						</div>
					<div class="boa-brd-top last"></div>
					<div>
						<h2>Beyond college</h2>
						<p class="afi-parafont para-last-row">Once you've graduated, you still have all sorts of financial concerns. We're here to help, whether it's taking out an <a name="auto_loan" href="/student-banking/resources/getting-an-auto-loan.go" target="_self">auto loan</a>, <a name="repaying_your_college_loans" href="/student-banking/resources/repaying-student-loans.go" target="_self">repaying your college loans</a> or making <a name="your_first_investments" href="/student-banking/resources/understanding-investments.go" target="_self">your first investments</a>.</p>
					</div>
		</div>
	</div>

						
<div style="				margin:38px 0 38px;
" class="spacer-module-gray-dotted-skin boa-brd-top"></div>








<div class="carousel-lt-module">
	<div class="img-w-text-skin sup-ie">
		
		<script type="text/javascript">	
			$(document).ready(function(){
				if($(".carousel-lt-module .img-w-text-skin").length > 0){					
					$('#slides').slides({
						container: 'slides-container',
						play: 15000,
						pause: 2500,
						hoverPause: true,
						fadeSpeed: 0,
						prependPagination: true,
						rotation:false,
						paginationAdaTitle: 'Featured Article',
						paginationAdaPrep: 'of',
						animationComplete: function(current){
							var currentSlide = $('.carousel-slide:eq(0)');
							var $list = $('ul.pagination li a','#slides');
							if(current != undefined)
								currentSlide = $('.carousel-slide:eq('+eval(current-1)+')');
							$('.slide-count','.carousel-content').find('span.ada-hidden').hide();
							$('.slide-count', currentSlide).find('span.ada-hidden').show();
							$list.find('span').addClass('hide');
							$list.eq(current-1).find('span').removeClass('hide');
						}
							})
					.find("ul.pagination li a")
					.each(function(){
						var name = $(this).text();
						$(this).attr("name","marketing_carousel_top_radio_button_" + name.replace(/\s+/g,"_"));
						$(this).attr("title",name);
					});
		                   	normalizeHeight();
						var $navigationList = $('ul.pagination li a','#slides');
						$navigationList.each(function(){
							$(this).append('<span class="hide"> Active article </span>');
						});
						$navigationList.eq(0).find('span').removeClass('hide');
						$navigationList.click(function(){
							$navigationList.find('span').addClass('hide');
							$(this).find('span').removeClass('hide');
						});
					};
				});
		
		            function normalizeHeight() {
		                var normalizedHeight = 1;
		                $(".carousel-lt-module .img-w-text-skin #slides .carousel-slide").each(function() {
		                    if ($(this).is(":hidden")) $(this).addClass("normalization-hide").show();
		                    var candidateHeight = $(this).find(".carousel-content").height();
		                    normalizedHeight = (candidateHeight > normalizedHeight ? candidateHeight : normalizedHeight);
		                    if ($(this).hasClass("normalization-hide")) $(this).hide();
		                });
		                $(".carousel-lt-module .img-w-text-skin #slides .slides-container").height(normalizedHeight).css("min-height","110px");
		            }
		</script>
	   
	   <span class="ada-hidden">Press alt+ctrl+shift+s to stop, alt+ctrl+shift+n to move next slide, alt+ctrl+shift+p to move previous slide.</span> 
	 	<div id="slides">
			<div class="slides-container">
						<div class="carousel-slide image" tabindex="-1">
							<div class="carousel-image"><img src="/content/images/ContextualSiteGraphics/Marketing/Highlights/en_US/khan-100x100.png" alt=""/></div>
							<div class="carousel-content">
								<div class="slide-count"><span class="ada-hidden">Slide </span>1 of 3<span class="ada-hidden"> about Better Money Habits&trade;</span></div>
								<h2>Better Money Habits&trade;</h2>
									<p>Explore a wide range of informative videos about budgeting, credit and more&mdash;powered by Bank of America in partnership with Khan Academy.</p>
<p><a href="http://www.bettermoneyhabits.com/">Visit the Better Money Habits site <span class="raquo-link">&rsaquo;&rsaquo;</span></a></p>
							</div>
						</div>					
						<div class="carousel-slide image" tabindex="-1">
							<div class="carousel-image"><img src="/content/images/ContextualSiteGraphics/Marketing/Highlights/en_US/budget-100x100.png" alt=""/></div>
							<div class="carousel-content">
								<div class="slide-count"><span class="ada-hidden">Slide </span>2 of 3<span class="ada-hidden"> about Creating a budget</span></div>
								<h2>Creating a budget</h2>
									<p>Help get control of where your money is going by using a personal budget spreadsheet. We can help you get started.</p>
<p><a href="/deposits/manage/creating-a-budget.go">Learn more about budgeting <span class="raquo-link">&rsaquo;&rsaquo;</span></a></p>
							</div>
						</div>					
						<div class="carousel-slide image" tabindex="-1">
							<div class="carousel-image"><img src="/content/images/ContextualSiteGraphics/Marketing/Highlights/en_US/college-100x100.png" alt=""/></div>
							<div class="carousel-content">
								<div class="slide-count"><span class="ada-hidden">Slide </span>3 of 3<span class="ada-hidden"> about College planning resources</span></div>
								<h2>College planning resources</h2>
									<p>Find out what Bank of America saving and Merrill Edge investment choices help you pursue your college funding needs.</p>
<p><a href="/planning/college.go" name="sb-carousel-prepare-for-college">Prepare for college <span class="raquo-link">&rsaquo;&rsaquo;</span></a></p>
							</div>
						</div>					
			</div>
		</div>
	 </div>
</div>




	<div class="hide com-interstitial-modal">
     	<h3>Important notice</h3>
   		<div class="flex-modal-main-content">
   		
      		<p><strong>You are leaving the main Bank of America website.</strong></p>
      		<p>Select <strong>Continue</strong> to be taken to the Ultimate Money Skills education website owned by Bank of America and powered by Monster.</p><p>Select <strong>Cancel</strong> if you choose not to continue.</p>
   	
   	<div class="flex-modal-buttons">
	      	<a href="javascript:void(0);" class="button-common button-blue" name="leaving_bank_modal_continue"><span>Continue</span></a>
	         
	      	<a href="javascript:void(0);" class="button-common button-gray close-com-interstitial" name="leaving_bank_modal_cancel"><span>Cancel</span></a>
	         
          <div class="clearboth"></div>
      </div>
   </div>
</div>

</div>
						<div class="flex-col rt-col" >


 




<div class="cta-module target-sidewell">	
	<div class="cta focus-call">
		<div class="intro">
			<h3>We're here to help</h3>
		</div>		
		<ul class="options">
				<li class="call first">							
					<div class="details">							
						<p>Our banking specialists are standing by to assist you.</p>
							<p class="large">800.432.1000</p>								
							<p class="small">Mon.-Fri. 7 a.m.-10 p.m. ET<br />Sat.-Sun. 8 a.m.-5 p.m. ET</p>
					</div>						
				</li>
				<li class="find">
					<h4><a href="#" name="Schedule_an_appointment">
						<span class="ada-hidden ada-closed">Show details on how to </span><span class="ada-hidden ada-open" style="display:none;">Hide details on how to </span>Schedule an appointment</a></h4>
					<div class="details">
						<p>Discuss your student banking needs at a financial center near you.</p>						
						<p><a name="schedule_appointment" href="https://secure.bankofamerica.com/mycommunications/public/appointments/getTopics.go">Schedule an appointment<span class="ada-hidden"> to find a banking center</span></a></p>
					</div>
				</li>
				<li class="qualify">
					<h4><a href="#" name="Find_a_financial_center"><span class="ada-hidden ada-closed">Show details on how to </span><span class="ada-hidden ada-open" style="display:none;">Hide details on how to </span>Find a financial center<span class="ada-hidden"> to discuss about student banking</span></a></h4>
					<div class="details">
						<p>Find an ATM or financial center near you. Identify locations with drive-up facilities or other features.</p>
						<p><a name="search_financial_center" onclick="window.open('https://locators.bankofamerica.com', '','width=730,height=500,resizeable,scrollbars'); return false;" href="https://locators.bankofamerica.com">Search now for a financial center
						<span class="ada-hidden"> to discuss about student banking</span></a></p>
					</div>
				</li>
		</ul>
	</div>
</div>

<div class="side-well-module" style="padding-top:23px;"> </div>
		
<script type="text/javascript">	
	cta_module.skins = {
	"Side Well" : {
	"id" : "sidewell",
	"container" :  ".side-well-module:first",
	"bind" : ".side-well-module:first",
	"location" : "first"
	}
	};
</script>
	<div class="side-well-module">
	    <div class="acct-features-skin">        
	        <div class="sw-outer bg-none">
	            <div class="sw-inner">
			            <h2 class="h2-fsd-sw-red">Features for checking</h2>
			            <ul class="features">
					             <li class="card">
	
										  	<a href="javascript:void(0);" name="sw-acct-features-balances" id="789B0BD8-0E47-11E2-9EF9-00144F43F0C4" class="boa-action boa-com-task-layer-link dotted" rel="layer-id-789B0BD8-0E47-11E2-9EF9-00144F43F0C4" >Debit Card</a>
					             		<div class="hide" id="layer-id-789B0BD8-0E47-11E2-9EF9-00144F43F0C4"><h3>Debit cards</h3><p>Debit cards are a convenient way to access your account and pay for everyday purchases&mdash;in person or online. With security features such as $0 Liability Guarantee<a name="zero" href="#footnote4"><span class="ada-hidden">Footnote</span><sup>4</sup></a> and new <a title="Chip Technology" name="anc-more-chip-technology" href="/privacy/accounts-cards/emv-chip-card-technology.go" target="_blank">chip technology</a> you can rest easy knowing you&rsquo;re protected when making transactions at terminals or ATMs that are chip-enabled.</p></div> 				             		
					             </li>
		                    					             <li class="alerts">
	
										  	<a href="javascript:void(0);" name="sw-acct-features-balances" id="e00742dc-7b91-47f7-a8fd-48b58cbafd2a" class="boa-action boa-com-task-layer-link dotted" rel="layer-id-e00742dc-7b91-47f7-a8fd-48b58cbafd2a" >Alerts</a>
					             		<div class="hide" id="layer-id-e00742dc-7b91-47f7-a8fd-48b58cbafd2a"><h3>Online Banking Alerts</h3><p>Choose from email, text<a name="olb-alert" href="#footnote5"><span class="ada-hidden">footnote</span><sup>5</sup></a> or Mobile App alerts to help you stay on top of your checking accounts.</p></div> 				             		
					             </li>
		                    					             <li class="ebills">
	
										  	<a href="javascript:void(0);" name="sw-acct-features-balances" id="582afef0-b480-4f8d-bcf5-686694cd2038" class="boa-action boa-com-task-layer-link dotted" rel="layer-id-582afef0-b480-4f8d-bcf5-686694cd2038" >eBills</a>
					             		<div class="hide" id="layer-id-582afef0-b480-4f8d-bcf5-686694cd2038"><h3>eBills</h3><p>With eBills from Bank of America, your bills come right to your email inbox.</p></div> 				             		
					             </li>
		                    					             <li class="pointer">
	
										  	<a href="javascript:void(0);" name="sw-acct-features-balances" id="1ce7320f-d6e7-4c49-b41e-7f1c6fb12c26" class="boa-action boa-com-task-layer-link dotted" rel="layer-id-1ce7320f-d6e7-4c49-b41e-7f1c6fb12c26" >Mobile Banking</a>
					             		<div class="hide" id="layer-id-1ce7320f-d6e7-4c49-b41e-7f1c6fb12c26"><h3>Mobile Banking</h3><p>Use our free mobile app to deposit checks, check balances, pay bills, transfer money and locate ATMs and banking centers on the go.</p></div> 				             		
					             </li>
		                    					             <li class="green">
	
										  	<a href="javascript:void(0);" name="sw-acct-features-balances" id="e2d73918-5344-45d3-9cd6-5009293d82bc" class="boa-action boa-com-task-layer-link dotted" rel="layer-id-e2d73918-5344-45d3-9cd6-5009293d82bc" >Paperless statements</a>
					             		<div class="hide" id="layer-id-e2d73918-5344-45d3-9cd6-5009293d82bc"><h3>Paperless statements</h3><p>Get your statements and documents  faster and reduce clutter by receiving your monthly statements  online.</p><p>&nbsp;</p></div> 				             		
					             </li>
		                    					             <li class="x-fer">
	
										  	<a href="javascript:void(0);" name="sw-acct-features-balances" id="7360b1b9-271c-4245-b508-36a4a8ed638a" class="boa-action boa-com-task-layer-link dotted" rel="layer-id-7360b1b9-271c-4245-b508-36a4a8ed638a" >Transfers</a>
					             		<div class="hide" id="layer-id-7360b1b9-271c-4245-b508-36a4a8ed638a"><h3>Transfers</h3><p>Securely transfer money between your accounts &mdash; or to others&nbsp;&mdash; using Online Banking or the Mobile Banking App.<a name="MobileBankingTransfer" href="#footnote6"><span class="ada-hidden">footnote</span><sup>6</sup></a></p></div> 				             		
					             </li>
		                    					             <li class="direct-depo">
	
										  	<a href="javascript:void(0);" name="sw-acct-features-balances" id="7FE1D6D9-0E47-11E2-9EF9-00144F43F0C4" class="boa-action boa-com-task-layer-link dotted" rel="layer-id-7FE1D6D9-0E47-11E2-9EF9-00144F43F0C4" >Direct Deposit</a>
					             		<div class="hide" id="layer-id-7FE1D6D9-0E47-11E2-9EF9-00144F43F0C4"><h3>Direct deposit</h3><p>Recurring deposits are handled quickly and easily without you ever having to visit a bank.</p></div> 				             		
					             </li>
		                               
			            </ul>	
	        	</div>          
	        </div>
	    </div>
	</div>
 <!-- code for preferred rewards pages -->

<div class="olb-dsp-state-selector-module">
    <div class="no-href-skin">
        <div class="sw-outer bg-none">
            <div class="sw-inner">
                <div class="sw-corner sw-tleft"></div>
                <div class="sw-corner sw-tright"></div>
                <div class="sw-corner sw-bleft"></div>
                <div class="sw-corner sw-bright"></div>
				<p class="pbtm-5">Information for 
					Virginia
				</p>
			  	<a name="anc-change-state" class="show-state-select-modal" rel="state-select-modal" href="javascript:void(0)">Change State <span class="ada-hidden">layer</span></a>
			</div>
            <div class="sw-bottom"></div>
        </div>      
    </div>
</div>


<!-- XSS attack Prevention -->
<script type="text/javascript">
</script>	


<div class="modal-content-module">
   <div class="state-select-skin">
      
	  
	<div class="state-select-modal hide" id="state-select-modal" >
	  
		<div class="modal-content">
            <h2>
				Select Your State
				<span class="ada-hidden"></span>
			</h2>
			<p>Please tell us where you bank so we can give you accurate rate and fee information for your location.</p>
			<form method="post" action="" name="submitState" id="submitState">
				<fieldset>
					<legend><span class="ada-hidden">State Selection Form</span></legend>
					<input type="hidden" name="requestedUrl" value="" />
					<label for="stateListId">Current State</label> 
					
<select name="stateListName" id="stateListId" class="select-box" title="Select a state" required="true">
    <option value=" "
    >Select state</option>
    <option value="AL">Alabama</option>
    <option value="AK">Alaska</option>
    <option value="AZ">Arizona</option>
    <option value="AR">Arkansas</option>
    <option value="CA">California</option>
    <option value="CO">Colorado</option>
    <option value="CT">Connecticut</option>
    <option value="DE">Delaware</option>
    <option value="DC">District of Columbia</option>
    <option value="FL">Florida</option>
    <option value="GA">Georgia</option>
    <option value="HI">Hawaii</option>
    <option value="ID">Idaho</option>
    <option value="IL">Illinois</option>
    <option value="IN">Indiana</option>
    <option value="IA">Iowa</option>
    <option value="KS">Kansas</option>
    <option value="KY">Kentucky</option>
    <option value="LA">Louisiana</option>
    <option value="ME">Maine</option>
    <option value="MD">Maryland</option>
    <option value="MA">Massachusetts</option>
    <option value="MI">Michigan</option>
    <option value="MN">Minnesota</option>
    <option value="MS">Mississippi</option>
    <option value="MO">Missouri</option>
    <option value="MT">Montana</option>
    <option value="NE">Nebraska</option>
    <option value="NV">Nevada</option>
    <option value="NH">New Hampshire</option>
    <option value="NJ">New Jersey</option>
    <option value="NM">New Mexico</option>
    <option value="NY">New York</option>
    <option value="NC">North Carolina</option>
    <option value="ND">North Dakota</option>
    <option value="OH">Ohio</option>
    <option value="OK">Oklahoma</option>
    <option value="OR">Oregon</option>
    <option value="PA">Pennsylvania</option>
    <option value="RI">Rhode Island</option>
    <option value="SC">South Carolina</option>
    <option value="SD">South Dakota</option>
    <option value="TN">Tennessee</option>
    <option value="TX">Texas</option>
    <option value="UT">Utah</option>
    <option value="VT">Vermont</option>
    <option value="VA">Virginia</option>
    <option value="WA">Washington</option>
    <option value="WV">West Virginia</option>
    <option value="WI">Wisconsin</option>
    <option value="WY">Wyoming</option>


</select>

						<a name="state_select_submit" class="btn-bofa btn-bofa-small state-select-modal-go-button" href="javascript:void(0);" >
							Go<span class="ada-hidden"> Button to be used after you select your state.</span>
						</a>
				</fieldset>
			</form>
			<div class="clearboth"></div>
         </div>
      </div>
   </div>
</div>


</div>
						<div class="clearboth"></div>
					</div>
					<div class="footer">
						<div class="footer-top">&nbsp;</div>
						<div class="footer-inner">

<div class="footnote-com-module">
   <div class="fsd-layout-skin sup-ie">
   
   <script>
		$(function() {
			if ($('.footnote-com-module .fsd-layout-skin').text().length > 10) {
				$('.footnote-com-module .fsd-layout-skin').addClass('wfootnote');
			}
		});
	</script>
   
					<div class="h-100">
						<div class="footnote" id="footnote1">
							<div class="fn-num">1.</div>
							<div class="fn-text">Students under age 23 are eligible for a waiver of the monthly maintenance fee while enrolled in a high school or in a college, university or vocational program. Please refer to your Personal Schedule of Fees for details. </div>
							<div class="clearboth"></div>
						</div>
					</div>
					<div class="h-100">
						<div class="footnote" id="footnote2">
							<div class="fn-num">2.</div>
							<div class="fn-text">BankAmeriDeals currently available via the Bank of America Mobile Banking app for iPad, iPhone and Android phones and tablets. Not availble on the Merrill Edge<sup>&reg;</sup> App. Wireless carrier fees may apply. </div>
							<div class="clearboth"></div>
						</div>
					</div>
					<div class="h-100">
						<div class="footnote" id="footnote3">
							<div class="fn-num">3.</div>
							<div class="fn-text">Mobile Banking app requires enrollment through the Mobile app, mobile web or Online Banking. View the <a href="/online-banking/service-agreement.go" name="anc-online-banking-services-agreement" target="_self">Online Banking Services Agreement</a> for more information. Data connection required. Wireless carrier fees may apply. Enrollment not available through the Mobile app on all devices. </div>
							<div class="clearboth"></div>
						</div>
					</div>
					<div class="h-100">
						<div class="footnote" id="footnote4">
							<div class="fn-num">4.</div>
							<div class="fn-text">The $0 Liability Guarantee covers fraudulent transactions made by others using your Bank of America consumer debit cards. To be covered, report transactions made by others promptly, and don&rsquo;t share personal or account information with anyone. Access to funds next business day in most cases, pending resolution of claim. Consult customer and account agreements for full details. </div>
							<div class="clearboth"></div>
						</div>
					</div>
					<div class="h-100">
						<div class="footnote" id="footnote5">
							<div class="fn-num">5.</div>
							<div class="fn-text">Alerts received as text messages on your mobile access device may incur a charge from your mobile service provider. Mobile App alerts are not available on select devices. </div>
							<div class="clearboth"></div>
						</div>
					</div>
					<div class="h-100">
						<div class="footnote" id="footnote6">
							<div class="fn-num">6.</div>
							<div class="fn-text">Email and mobile transfers requires enrollment in service and must be made from a Bank of America consumer checking or savings account to a U.S.-based bank account. Recipients have 14 days to register to receive money or transfer will be canceled. Dollar and frequency limits apply.&nbsp;See the <a href="/online-banking/service-agreement.go" name="anc-online-banking-services-agreement" target="_self">Online Banking Service Agreement</a> for details, including cut-off and delivery times. Wireless carrier charges may apply. </div>
							<div class="clearboth"></div>
						</div>
					</div>
   </div>
</div>






<div class="power-footer-module">
	<div class="flex-microdata-skin sup-ie">
			<div class="breadcrumbs">
			<div itemscope itemtype="http://schema.org/BreadcrumbList">
				<!-- breadcrumbs div -->
					<!-- Inside 1st breadcrumb -->
					<div itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="bold-arrow">
								<a itemprop="item" href="/" name="bank_of_america_breadcrumb" target="_self"><span itemprop="name">Bank of America</span><meta itemprop="position" content="1"/></a>
					</div>
					
						<!-- Inside 2nd breadcrumb -->
						<div itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="arrow">
									<a itemprop="item" href="/student-banking/overview.go" name="student_banking_breadcrumb" target="_self"><span itemprop="name">Student Banking</span><meta itemprop="position" content="2"/></a>
						</div>
				
					<!-- Inside 3rd breadcrumb -->
					<div itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="arrow">
								<a itemprop="item" href="/student-banking/solutions-for-students.go" name="solutions_for_students_breadcrumb" target="_self">Solutions for Students</a>
					</div>
				
				<!-- Inside 4th breadcrumb -->
				<div itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
					<span itemprop="name">
						Solutions and Bank Accounts for Students
					</span>
					<meta itemprop="position" content="4" />
				</div>
				<div class="clearboth"></div>
			</div>
			</div>
		
			<!-- Inside power footer columns -->
			<div class="pf-columns">		   
						<div class="pf-col">
							<ul>
								<li>Solutions for Students</li>
										<li><a href="/student-banking/student-checking-savings-account.go" name="power_footer_checking_and_savings">Checking & Savings</a></li>
										<li><a href="/student-banking/student-credit-cards.go" name="power_footer_credit_cards">Credit Cards</a></li>
										<li><a href="/student-banking/online-mobile-banking.go" name="power_footer_mobile_and_online_banking">Mobile & Online Banking</a></li>
										<li><a href="/student-banking/solutions-for-students.go" name="power_footer_banking_options_students">Banking options for students</a></li>
							</ul>
						</div>
						<div class="pf-col">
							<ul>
								<li>Solutions for Parents</li>
										<li><a href="/student-banking/saving-for-college.go" name="saving_for_college">Saving for College</a></li>
										<li><a href="/student-banking/financial-aid.go" name="financial_aid">Financial Aid</a></li>
										<li><a href="/student-banking/managing-student-finances.go" name="managing_student_finances">Managing Student Finances</a></li>
							</ul>
						</div>
						<div class="pf-col">
							<ul>
								<li>Resources</li>
										<li><a href="/student-banking/resources/overview.go" name="sb-resource-loans-banking">Student loans & banking</a></li>
							</ul>
						</div>
					<div class="clearboth"></div>
			</div>
	</div>
</div>




 



		<div class="global-footer-module">
			<div class="fsd-skin">

				<div class="footer-bottom-left" style="float:left;max-width:66%;">
	    			<div class="gf-links">	          	
						
					
									
									<a  target="_self" href="/" 
									    name="global_footer_home">Home
									</a>
									
						
					
									
									<a  target="_self" href="/accessiblebanking/overview.go" 
									    name="global_footer_accessible_banking">Accessible Banking
									</a>
									
						
					
									
									<a  target="_self" href="/privacy/overview.go" 
									    name="global_footer_privacy_security">Privacy & Security
									</a>
									
						
					
									
									<a  target="_self" href="http://careers.bankofamerica.com/careershome.aspx" 
									    name="global_footer_careers">Careers
									</a>
									
						
					
									
									<a  target="_self" href="/sitemap/personal.go" 
									    name="global_footer_site_map">Site Map
									</a>
									
						
					
									<a href="javascript:void(0);" class="gf-last-link boa-dialog boa-com-info-layer-link" name="global_footer_advertising_practices_lnk" rel="global_footer_advertising_practices">Advertising Practices</a>
								<div id="global_footer_advertising_practices" class="hide">
									<h3>Advertising Practices</h3>
										<p>We strive to provide you with information about products and services you might find interesting and useful. Relationship-based ads and online behavioral advertising help us do that.</p>
<p>Here's how it works: We gather information about your online activities, such as the searches you conduct on our Sites and the pages you visit. This information may be used to deliver advertising on our Sites and offline (for example, by phone, email and direct mail) that's customized to meet specific interests you may have.</p>
<p>If you prefer that we do not use this information, you may <a onclick="$('.ui-dialog').remove();" name="WebsiteAdPractices_OptOut" href="/privacy/online-privacy-notice.go#advertising-on-our-sites" target="_blank">opt out of online behavioral advertising</a>. If you opt out, though, you may still receive generic advertising. In addition, financial advisors/Client Managers may continue to use information collected online to provide product and service information in accordance with account agreements.</p>
<p>Also, if you opt out of online behavioral advertising, you may still see ads when you sign in to your account, for example through Online Banking or MyMerrill. These ads are based on your specific account relationships with us.</p>
<p>To learn more about relationship-based ads, online behavioral advertising and our privacy practices, please review the <a onclick="$('.ui-dialog').remove();" name="WebsiteAdPractices_PrivacyNotice" href="/privacy/online-privacy-notice.go" target="_blank">Bank of America Online Privacy Notice</a> and our <a onclick="$('.ui-dialog').remove();" name="Online-privacy-faqs" href="/privacy/faq/online-privacy-faq.go" target="_blank">Online Privacy FAQs</a>.</p>
								</div>
						<div class="clearboth"></div>
	    			</div>
	      			<p>Bank of America, N.A. Member <acronym title="Federal Deposit Insurance Corporation">FDIC</acronym>. <a onclick="window.open('/help/equalhousing_popup.go','newwin','width=640,height=371,scrollbars=yes,resizable=yes,left=35,top=161'); return false;" name="equal_housing_lender" href="/help/equalhousing_popup.go" target="_blank">Equal Housing Lender<img src="https://www2.bac-assets.com/content/images/ContextualSiteGraphics/Logos/en_US/icon_equal_housing_lender.gif" alt="" width="14" height="9" /></a><br />&copy; 2017 Bank of America Corporation.</p>
         		</div>
         		<div class="footer-social-container" style="float:right;max-width:30%;padding-left:50px;padding-top:19px;">




<div class="boa-social-loader" data-loaded="false" data-platform="borneo"  data-options=''></div>

         		</div>
         		<div class="clearboth"></div>
  			</div>
		</div>




 
<script language="javascript" src="https://www2.bac-assets.com/pa/global-assets/external/coremetrics/hp/eluminate.js"></script>
<script language="javascript" src="https://www2.bac-assets.com/pa/global-assets/external/coremetrics/hp/cmdatatagutils.js"></script>


<script language="javascript">
	function cmSetDD(){var testString=window.location.href;if(testString.toLowerCase().indexOf('.bankofamerica.com')>-1){testString=testString.toLowerCase();var tempArr=testString.split('.bankofamerica.com');var tempStr=tempArr[0];if(tempStr.indexOf('\/\/')>-1){tempArr=tempStr.split('\/\/');tempStr=tempArr[1];if(tempStr.indexOf('.')>-1){tempArr=tempStr.split('.');tempStr=tempArr[0];var tempStrPt2=tempArr[1]}if(tempStr.indexOf('www')>-1){if(tempStr.indexOf('-')>-1){cmSetStaging()}else if(tempStrPt2!=null){if(tempStrPt2.indexOf('ecnp')>-1){cmSetStaging()}}else{cmSetProduction()}}else if(tempStr.indexOf('-')>-1){if(tempStr.indexOf('sitekey')>-1){if(tempStr=='sitekey'){cmSetProduction()}else{cmSetStaging()}}else{cmSetStaging()}}else if(tempStrPt2!=null){if(tempStrPt2.indexOf('ecnp')>-1){cmSetStaging()}}else{cmSetProduction()}}}}if(typeof cmSetStaging=='function'){cmSetDD()}
</script> 

		<script type="text/javascript">
			cmCreatePageviewTag('studentbanking:Content:students;solutions-for-students', null, null, 'studentbanking:Content:students', false, false, null, false, false, null, null, null, null, null, null, null, null, null, null, null, null);
		</script>

</div>
					</div>
				</div>
			</div>
		</div>
	</body>	
</html>

