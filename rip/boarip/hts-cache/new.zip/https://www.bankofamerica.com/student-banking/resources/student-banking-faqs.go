
 

				<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
				<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
				<head>



<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<title>Bank of America Student Banking FAQs for Students</title>


					<meta name="Keywords" CONTENT="student banking FAQs, student banking" />
					<meta name="Description" CONTENT="Review the Bank of America FAQ for students and find answers to your most frequently asked questions about student banking." />


<link rel="shortcut icon" href="https://www2.bac-assets.com/pa/global-assets/1.0/graphic/favicon.ico" type="image/ico" />


		<link rel="stylesheet" type="text/css" media="all" href="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/APS-deposits/2017.03.0/style/global-aps-dp-jawr.css"/>
		<link rel="stylesheet" type="text/css" media="all" href="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/APS-deposits/2017.03.0/style/sb-aps-dp-jawr.css"/>
		
		<script type="text/javascript" src="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/APS-deposits/2017.03.0/script/global-aps-dp-jawr.js"></script>
		<script type="text/javascript" src="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/APS-deposits/2017.03.0/script/sb-aps-dp-jawr.js"></script>
		
			<script type="text/javascript">
				$(window).load(function(){asyncPrintCssInclude('https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/APS-deposits/2017.03.0/style/global-aps-dp-jawr-print.css');});
				$(window).load(function(){asyncPrintCssInclude('https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/APS-deposits/2017.03.0/style/sb-aps-dp-jawr-print.css');});
			</script>
<script type="text/javascript">
(function() {
	if (typeof mboxUpdate == "function") {
		var windowURL = window.location.href
	    windowURL = windowURL.slice( windowURL.indexOf('.')+1);
		windowURL = windowURL.split( '?' )[0];
		windowURL = windowURL.toLowerCase();
		//alert(windowURL);
		if (
		    //If no mboxes on page, mbox count will be < 1
		    (mboxFactoryDefault.getMboxes().length() < 1) &&  
			
			//Also check for high-volume pages that do not need global logging
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go") &&
			(windowURL != "bankofamerica.com/myaccounts/signin/signin.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/entry/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signonscreen.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatechallengeanswer.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatePassword.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/mobile/banking.go")&&
			(windowURL != "bankofamerica.com/content/preload/olb-myaccount-preload-jawr-module.htm")
			)
		{

			var mboxDiv = document.createElement("div");
			mboxDiv.id = "adobe_touch_clarity_replacement";
			mboxDiv.style.display = "none";
			if (document.body && document.body.firstChild) document.body.insertBefore(mboxDiv,document.body.firstChild);
			mboxDefine(mboxDiv.id,'bac_global_bottom');
			mboxUpdate('bac_global_bottom');
		}
	}	
})();
</script>

		<script src="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/Global/1.0/script/tealeafbundle.js" type="text/javascript"></script>
			<script>
				var boaPageDataJS = {};
					boaPageDataJS.isLLE = "false";
			</script>
				<style>body{display:none;}</style>
	</head>		

	<body class="fsd-layout-body">	

				<script type="text/javascript">if(self == top){var theBody=document.getElementsByTagName("body")[0];theBody.style.display="block";}else{top.location=self.location;}</script>
				<noscript><style>body{display:block;}</style></noscript>
					<a class='ada-hidden ada-visible-focus' href='#skip-to-h1' id='ada-skip-link'>Skip to main content</a>
		<div class="fsd-layout fsd-2c-700lt-layout">
			<div class="fsd-border">
				<div class="center-content">
					<div class="header">
		  



<script language="javascript" src="/pa/components/modules/tag-manager-module/1.1/script/tag-manager-module-borneo-global-skin.js"></script>
<script>

(function() {
  var fireCallback = function( cb ) {
    if ( typeof cb === "function" ) cb();
  };
  
  function ddoPopulateBase( callback ) {
    try {
		  var DDO = window.digitalData,
		  	bactm_mergeDDO = function( newDDO, priorDDO ) {
		  		if( typeof priorDDO === "undefined" ) {
				  	priorDDO = digitalData || {};
				  }

			    for (var l in newDDO) {
			        if (typeof priorDDO[l] === "undefined") {
			            priorDDO[l] = newDDO[l];
			        }
			        if (newDDO[l] !== null) {
			            if (typeof newDDO[l] === "object") {
			                bactm_mergeDDO(newDDO[l], priorDDO[l]);
			            } else {
			                priorDDO[l] = bactm_validateValue( newDDO[l] ) ? newDDO[l] : priorDDO[l];
			            }
			        }
			    }

			    return priorDDO;
				},
				bactm_olb3rdPartyId = "null";

			if (typeof DDO === "undefined") {
				var simpleDDO = { page: { pageInfo:[{ pageID: null }], attributes: {}, category: { primaryCategory: null }}};

				DDO = (typeof digitalData === "object") ? digitalData : simpleDDO; 
			}

				DDO = bactm_mergeDDO( {pageInstanceID:"notprod",load_coremetrics:false,load_opinionlabs:false,load_touchcommerce:true,load_audiencemanager:true,page:{pageInfo:[{pageID:null,destinationURL:null,referringURL:null,issueDate:null,language:null,segmentValue:null,appName:null,appStepNumber:null,appStepName:null,attr:"-_--_--_--_--_--_--_--_--_--_--_--_--_--_-"}],category:{primaryCategory:null,addlCategory:null,pageType:null},attributes:{searchString:null,searchResults:null,olbSessionID:null,subCampaignCode:null,DARTUrl:null,stateCookie:null,SASIEnabled:false,needOLBcookie:false,standardDART:[],standardDARTes:[],clickDART:[],clickDARTes:[],gaId:[],chat:{account_type:null,boa_associate:null,boa_retiree:null,customer_lob:null,customer_segment:null,data:null,email_campaign:null,entitlement_code:null,error_category:null,error_count:null,first_login:null,inqSalesProductTypes:{},invitation_background:null,invitation_template:null,referral_campaign:null,getStateValue:false,cust_fn:null,cust_ln:null,target:null}}},user:{segment:null,online_id:null,preferred_rewards_tier:null,olb3rdpartyid:null},version:"BAC_0.12"}, DDO );

			DDO.page.pageInfo[0].pageID = "studentbanking:Content:resources:FAQ;student-banking-faqs";
			DDO.page.category.primaryCategory  = "studentbanking:Content:resources:FAQ";
			DDO.page.pageInfo[0].language = "en-US";
			DDO.page.attributes.olbSessionID = "null";
			DDO.page.attributes.SASIEnabled =  "false";
			if (typeof DDO.user != "undefined" && typeof DDO.user.olb3rdpartyid != "undefined") {
				DDO.user.olb3rdpartyid = bactm_olb3rdPartyId;
			}

			window.utag_data = {};
			window.bactm_envSelector = bactm_setTMLib();
			window.digitalData = DDO;

      return fireCallback( callback );

    } catch(e) { }
  }
	if( window.boa && window.boa.digitalData ) {
    window.boa.digitalData.register( ddoPopulateBase );
	}
	else {
	  // Handle scenario where the header isn't available (and thus the default digitalData object and utag loader are missing).
	  //
		var writeScript = function(a,b,c,d){
			a='//tags.tiqcdn.com/utag/bofa/main/' + bactm_envSelector + '/utag.js';
			b=document;
			c='script';
			d=b.createElement(c);
			d.src=a;
			d.type='text/java'+c;
			d.async=true;
			a=b.getElementsByTagName(c)[0];
			a.parentNode.insertBefore(d,a);
		};

		ddoPopulateBase( writeScript );
	}
})();			
</script>





	
	
				<noscript>
				
					<div class="fauxdal-overlay"></div>
					<div class="fauxdal-module">
						<div class="js-disabled-skin">
							<div class="fauxdal-top"></div>
							<div class="fauxdal-bottom">
								<div class="fauxdal-content">
										<div class="fauxdal-title">
											Please Use JavaScript
										</div>
											<p>You need a web browser that supports JavaScript to use our site. Without it, some pages won&rsquo;t work as designed. To make sure JavaScript is turned on, please adjust your browser settings and refresh.</p><p><a title="Browser Help and Tips" name="Browser_Help_and_Tips" href="/onlinebanking/online-banking-security-faqs.go">Browser Help and Tips</a></p>
										
								</div>        
								<div class="fauxdal-close"> 
									<a class="btn-bofa btn-bofa-small" href=?js=y>Close</a>
								</div>
								
							</div>
						</div>
					</div>
				</noscript>



 


<div class="header-module">
	<div class="text-w-logo-skin">
		<div class="header-left">
	  
			<div itemscope itemtype="http://schema.org/Corporation" class="bofa-logo">
				<a itemprop="url" name="anc-student-banking" title="Bank of America Logo" href="/">
					<img itemprop="logo" height="28" width="221" 
					     alt="Bank of America Logo" src="https://www2.bac-assets.com/content/images/ContextualSiteGraphics/Logos/en_US/boa_logo.gif"/>
				</a>
			</div>
				<div class="product" data-font="cnx-regular">Student Banking</div>
			
			<div class="clearboth"></div>

		</div>
		
		<div class="header-right">
			<ul class="header-links">
			
				
					
				
							<li class="sign-in">
		<a					href="/sitemap/hub/signin.go" target="_self"
		name="sign_in">Sign In</a> 
							</li>
					
				
							<li>		<a					href="/" target="_self"
		name="home">Home</a> 
</li>
					
				
							<li>		<a					href="https://locators.bankofamerica.com" target="_self"
		name="locations">Locations</a> 
</li>
					
				
							<li>		<a					href="/contactus/contactus.go" target="_self"
		name="contact_us">Contact Us</a> 
</li>
					
				
							<li class="last-link">	
		<a					href="/student-banking/resources/student-banking-faqs.go" target="_self"
		name="help">Help</a> 
							</li>
			</ul>
			
			<div class="clearboth"></div>

			<!-- include search-dotcom-util -->



<div class="header-search nlh">
  
  <div class="nav-search">
    <form class="search-form" action="https://secure.bankofamerica.com/myaccounts/public/search-results/unAuthenticatedSearch.go" data-js="/pa/components/utilities/search-util/1.0/script/nav-search.min.js" data-css="/pa/components/utilities/search-util/1.0/style/nav-search.css" data-text-unavailable="Search Currently Unavailable">
      <div class="search-input-container cf" data-icon="search">
        <label for="nav-search-query" class="ada-hidden">Search Term</label>
        <input type="text" placeholder="How can we help you?" name="query" class="search-query" id="nav-search-query" 
          maxlength="99" rel="Search" autocomplete="off"><input type="submit" alt="Search" title="Search" value="Submit Search" name="Search Module - Top Result – Search Button" class="submit track-me">
      </div>
    </form>
  </div>

</div>

		</div>

 		<div class="clearboth"></div>
 	</div>
</div>







	<div class="top-nav-module">
		<div class="fsd-skin sup-ie">
			<ul class="nav-list">
					
					
					<li>
						
									<a href="/student-banking/overview.go" class="top-menu-item"
									name="overview_topnav" id="overview_topnav">Overview</a>
					</li>
					
					
					<li>
						
								<a href="/student-banking/solutions-for-students.go" class="top-menu-item"
								name="accounts_for_students_topnav" id="accounts_for_students_topnav">Accounts for Students<span class="ada-hidden"> link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/student-banking/solutions-for-students.go"  name="solutions_for_students_topnav" id="solutions_for_students_topnav">Solutions for Students </a>
															<a href="/student-banking/student-checking-savings-account.go"  name="checking_and_savings_topnav" id="checking_and_savings_topnav">Checking & Savings </a>
															<a href="/student-banking/student-credit-cards.go"  name="credit_cards_topnav" id="credit_cards_topnav">Credit Cards </a>
									</div>
								
									<div class="hasSub">
														<a class="with-info" href="/student-banking/online-mobile-banking.go"  name="mobile_and_online_banking_topnav" id="mobile_and_online_banking_topnav"><strong>Mobile &amp; Online Banking</strong> 
															
															<span class="sub-nav-item-info">Services designed for a student's on-the-go lifestyle</span>
														</a>
														<a class="with-info" href="/student-banking/resources/types-of-student-loans.go"  name="college_planning_topnav" id="college_planning_topnav"><strong>Student Loan Options</strong> 
															
															<span class="sub-nav-item-info">Find out about different types of student loans
</span>
														</a>
									</div>
									<span class="ada-hidden"> End of Submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
					
					
					<li>
						
								<a href="/planning/college.go" class="top-menu-item"
								name="college_planning_topnav" id="college_planning_topnav">College Planning<span class="ada-hidden"> link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/planning/college.go"  name="preparing_for_college_topnav" id="preparing_for_college_topnav">Preparing for College </a>
															<a href="/student-banking/saving-for-college.go"  name="saving_for_college_topnav" id="saving_for_college_topnav">Saving for College </a>
															<a href="/student-banking/financial-aid.go"  name="financial_aid_topnav" id="financial_aid_topnav">Financial Aid </a>
															<a href="/student-banking/managing-student-finances.go"  name="managing_student_finances_topnav" id="managing_student_finances_topnav">Managing Student Finances </a>
															<a href="/student-banking/resources/fafsa-form.go"  name="understanding_the_fafsa_form_topnav" id="understanding_the_fafsa_form_topnav">Understanding the FAFSA form </a>
									</div>
								
									<div class="hasSub">
									</div>
									<span class="ada-hidden"> End of Submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
					
					
					<li>
						
								<a href="/student-banking/resources/overview.go" class="top-menu-item selected"
								name="resources_topnav" id="resources_topnav">Resources<span class="ada-hidden"> link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/student-banking/resources/overview.go"  name="resources_overview_topnav" id="resources_overview_topnav"><span class="ada-hidden">Resources </span>Overview </a>
															<a href="/student-banking/resources/glossary.go"  name="glossary_topnav" id="glossary_topnav">Glossary </a>
															<a href="/student-banking/resources/student-banking-faqs.go"  name="faqs_topnav" id="faqs_topnav">FAQs </a>
									</div>
								
									<div class="hasSub">
														<a class="with-info" href="/student-banking/resources/shared-credit-cards.go"  name="banking_basics_topnav" id="banking_basics_topnav"><strong>Banking basics</strong> 
															
															<span class="sub-nav-item-info">Shared credit card accounts</span>
														</a>
														<a class="with-info" href="/student-banking/resources/building-your-credit-history.go"  name="after_college_topnav" id="after_college_topnav"><strong>After college</strong> 
															
															<span class="sub-nav-item-info">Building your credit history</span>
														</a>
									</div>
									<span class="ada-hidden"> End of Submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
			</ul>
				<div class="clearboth"></div>
		</div>
	</div>



<div class="page-title-fsd-module h-100" id="skip-to-h1">
	<div class="standard-red-skin sup-ie">
			<h1 data-font="cnx-regular">FAQs: Questions About Student Banking</h1>
	</div>
</div>






			<!-- true testing -->

<div class="select-url-module">
	<div class="nav-anchor-skin"><div class="nav-anchor-inner">
				<h2 class="ada-hidden">Student banking</h2>
		<label for="faq-list" class="select-label">View questions about:</label>

		<div class="faq-menu-box" id="faq-selector-div">
				<form name="select-url-module-nav-anchor-skin">
					<select name="faq-list" id="faq-list" class="select-bofa">
						<option value="javascript:void(0);" selected="selected" >
							Student banking
						</option>
						<option value="/student-banking/resources/student-credit-card-faqs.go">
							Student credit cards
						</option>
						<option value="/student-banking/resources/student-loan-repayment-faqs.go">
							Student loan repayment
						</option>
							<option value="javascript:void(0);" disabled></option>
						<option value="/help/overview.go">
							Need more? Get all FAQs�
						</option>
					</select>
					<a class="btn-bofa btn-bofa-blue btn-bofa-small" href="javascript:void(0);" id="select-url-module-nav-anchor-skin-go-button">Go<span class="ada-hidden"> and view FAQ information.</span></a>
				</form>
		</div>
		<div class="clearboth"></div>
	</div></div>
</div>

<div class="print-module-browser-dialog-skin" style=""> 
	<a href="javascript:window.print();" name="print">PRINT<span class="ada-hidden"> this page</span></a>
</div></div>
					<div class="columns">
						<div class="flex-col lt-col" ><div class="main-well-content-module">	<div class="com-skin com-main-well-content" style="">					<p><a name="explore_our_faq_page_link" href="/help/overview.go" target="_self">Explore our FAQ page</a> for additional information about Online Banking, credit and debit cards, loans, investments and more</p><p>&nbsp;</p>	</div></div>	



			




			
<div id="tab-2" class="faq-module tabs-main-content">
    <div class="main-well-skin com-main-well-content table-vzd3-common table-vzd3-com ">
			<div class="show-hide-all ">
			   <a href="javascript:void(0);" class="faq-show-all" name="faqs_show_all" id="faqs_show_all">Show all<span class="ada-hidden"> answers</span></a>
			   &nbsp;|&nbsp;
			   <a href="javascript:void(0);" class="faq-hide-all" name="faqs_hide_all" id="faqs_hide_all">Hide all<span class="ada-hidden"> answers</span></a>
			</div>
      <ul class="faq-main">
						<li>
									<span class="question-link"><a href="javascript:void(0);" name="Do_you_offer_checking_accounts_for_students" id="Do_you_offer_checking_accounts_for_students">
									<span class="ada-hidden ada-action">Hide </span>Do you offer checking accounts for students?</a></span>
									<div class="faq-content-area">
										<p>Yes, we do: <a href="/deposits/checking/personal-checking-account.go?STUDENT_IND=Y">Bank of America Core Checking<sup>&reg;</sup></a> is a single, simple checking account that's well suited to students. It comes with Online Banking, Mobile Banking and access to thousands of Bank of America ATMs&mdash;and our monthly maintenance fee is waived for qualified students under 23.<a name="student_un23_footnote" href="#footnote1"><span class="ada-hidden">footnote</span><sup>1</sup></a> To apply, visit a banking center or call a Bank of America representative at 1.800.432.1000 (7 a.m. to 10 p.m.).</p>
									</div>
						</li>
						<li>
									<span class="question-link closed"><a href="javascript:void(0);" name="Can_I_open_an_account_for_my_child_who_is_going_to_college" id="Can_I_open_an_account_for_my_child_who_is_going_to_college">
									<span class="ada-hidden ada-action">Show </span>Can I open an account for my child who is going to college?</a></span>
									<div class="faq-content-area hide">
										<p>It&rsquo;s easy to open a checking account for your child who is going to college. Simply <a href="http://locators.bankofamerica.com/locator/locator/LocatorAction.do" target="_self">visit a&nbsp;financial center</a> or call a Bank of America representative at 800.432.1000 (7 a.m.-10 p.m. local time). If your child has not yet left for college, please use your home address as the mailing address for the account. If your child has already left for college, consider applying for a joint account with a parent as the primary account holder. You can then use your home address as the mailing address for the account, which will allow us to be able to verify your address faster and send all account opening materials to your home address.</p>
									</div>
						</li>
	  </ul>
	  
	  </div>
  </div>

</div>
						<div class="flex-col rt-col" > <!-- code for preferred rewards pages -->

<div class="olb-dsp-state-selector-module">
    <div class="no-href-skin">
        <div class="sw-outer bg-none">
            <div class="sw-inner">
                <div class="sw-corner sw-tleft"></div>
                <div class="sw-corner sw-tright"></div>
                <div class="sw-corner sw-bleft"></div>
                <div class="sw-corner sw-bright"></div>
				<p class="pbtm-5">Information for 
					Virginia
				</p>
			  	<a name="anc-change-state" class="show-state-select-modal" rel="state-select-modal" href="javascript:void(0)">Change State <span class="ada-hidden">layer</span></a>
			</div>
            <div class="sw-bottom"></div>
        </div>      
    </div>
</div>


<!-- XSS attack Prevention -->
<script type="text/javascript">
</script>	


<div class="modal-content-module">
   <div class="state-select-skin">
      
	  
	<div class="state-select-modal hide" id="state-select-modal" >
	  
		<div class="modal-content">
            <h2>
				Select Your State
				<span class="ada-hidden"></span>
			</h2>
			<p>Please tell us where you bank so we can give you accurate rate and fee information for your location.</p>
			<form method="post" action="" name="submitState" id="submitState">
				<fieldset>
					<legend><span class="ada-hidden">State Selection Form</span></legend>
					<input type="hidden" name="requestedUrl" value="" />
					<label for="stateListId">Current State</label> 
					
<select name="stateListName" id="stateListId" class="select-box" title="Select a state" required="true">
    <option value=" "
    >Select state</option>
    <option value="AL">Alabama</option>
    <option value="AK">Alaska</option>
    <option value="AZ">Arizona</option>
    <option value="AR">Arkansas</option>
    <option value="CA">California</option>
    <option value="CO">Colorado</option>
    <option value="CT">Connecticut</option>
    <option value="DE">Delaware</option>
    <option value="DC">District of Columbia</option>
    <option value="FL">Florida</option>
    <option value="GA">Georgia</option>
    <option value="HI">Hawaii</option>
    <option value="ID">Idaho</option>
    <option value="IL">Illinois</option>
    <option value="IN">Indiana</option>
    <option value="IA">Iowa</option>
    <option value="KS">Kansas</option>
    <option value="KY">Kentucky</option>
    <option value="LA">Louisiana</option>
    <option value="ME">Maine</option>
    <option value="MD">Maryland</option>
    <option value="MA">Massachusetts</option>
    <option value="MI">Michigan</option>
    <option value="MN">Minnesota</option>
    <option value="MS">Mississippi</option>
    <option value="MO">Missouri</option>
    <option value="MT">Montana</option>
    <option value="NE">Nebraska</option>
    <option value="NV">Nevada</option>
    <option value="NH">New Hampshire</option>
    <option value="NJ">New Jersey</option>
    <option value="NM">New Mexico</option>
    <option value="NY">New York</option>
    <option value="NC">North Carolina</option>
    <option value="ND">North Dakota</option>
    <option value="OH">Ohio</option>
    <option value="OK">Oklahoma</option>
    <option value="OR">Oregon</option>
    <option value="PA">Pennsylvania</option>
    <option value="RI">Rhode Island</option>
    <option value="SC">South Carolina</option>
    <option value="SD">South Dakota</option>
    <option value="TN">Tennessee</option>
    <option value="TX">Texas</option>
    <option value="UT">Utah</option>
    <option value="VT">Vermont</option>
    <option value="VA">Virginia</option>
    <option value="WA">Washington</option>
    <option value="WV">West Virginia</option>
    <option value="WI">Wisconsin</option>
    <option value="WY">Wyoming</option>


</select>

						<a name="state_select_submit" class="btn-bofa btn-bofa-small state-select-modal-go-button" href="javascript:void(0);" >
							Go<span class="ada-hidden"> Button to be used after you select your state.</span>
						</a>
				</fieldset>
			</form>
			<div class="clearboth"></div>
         </div>
      </div>
   </div>
</div>


</div>
						<div class="clearboth"></div>
					</div>
					<div class="footer">
						<div class="footer-top">&nbsp;</div>
						<div class="footer-inner">

<div class="footnote-com-module">
   <div class="fsd-layout-skin sup-ie">
   
   <script>
		$(function() {
			if ($('.footnote-com-module .fsd-layout-skin').text().length > 10) {
				$('.footnote-com-module .fsd-layout-skin').addClass('wfootnote');
			}
		});
	</script>
   
					<div class="h-100">
						<div class="footnote" id="footnote1">
							<div class="fn-num">1.</div>
							<div class="fn-text">Students under age 23 are eligible for a waiver of the monthly maintenance fee while enrolled in a high school or in a college, university or vocational program. Please refer to your <a href="/deposits/resources/personal-schedule-fees.go" target="_self">Personal Schedule of Fees</a> for details. </div>
							<div class="clearboth"></div>
						</div>
					</div>
   </div>
</div>






<div class="power-footer-module">
	<div class="flex-microdata-skin sup-ie">
			<div class="breadcrumbs">
			<div itemscope itemtype="http://schema.org/BreadcrumbList">
				<!-- breadcrumbs div -->
					<!-- Inside 1st breadcrumb -->
					<div itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="bold-arrow">
								<a itemprop="item" href="/" name="bank_of_america_breadcrumb" target="_self"><span itemprop="name">Bank of America</span><meta itemprop="position" content="1"/></a>
					</div>
					
						<!-- Inside 2nd breadcrumb -->
						<div itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="arrow">
									<a itemprop="item" href="/student-banking/overview.go" name="student_banking_breadcrumb" target="_self"><span itemprop="name">Student Banking</span><meta itemprop="position" content="2"/></a>
						</div>
				
					<!-- Inside 3rd breadcrumb -->
					<div itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="arrow">
								<a itemprop="item" name="resources_breadcrumb" href="/student-banking/resources/overview.go" target="_self">Resources</a>
					</div>
				
				<!-- Inside 4th breadcrumb -->
				<div itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
					<span itemprop="name">
						FAQs: Questions About Student Banking
					</span>
					<meta itemprop="position" content="4" />
				</div>
				<div class="clearboth"></div>
			</div>
			</div>
		
			<!-- Inside power footer columns -->
			<div class="pf-columns">		   
						<div class="pf-col">
							<ul>
								<li>Solutions for Students</li>
										<li><a href="/student-banking/student-checking-savings-account.go" name="power_footer_checking_and_savings">Checking & Savings</a></li>
										<li><a href="/student-banking/student-credit-cards.go" name="power_footer_credit_cards">Credit Cards</a></li>
										<li><a href="/student-banking/online-mobile-banking.go" name="power_footer_mobile_and_online_banking">Mobile & Online Banking</a></li>
										<li><a href="/student-banking/solutions-for-students.go" name="power_footer_banking_options_students">Banking options for students</a></li>
							</ul>
						</div>
						<div class="pf-col">
							<ul>
								<li>Solutions for Parents</li>
										<li><a href="/student-banking/saving-for-college.go" name="saving_for_college">Saving for College</a></li>
										<li><a href="/student-banking/financial-aid.go" name="financial_aid">Financial Aid</a></li>
										<li><a href="/student-banking/managing-student-finances.go" name="managing_student_finances">Managing Student Finances</a></li>
							</ul>
						</div>
						<div class="pf-col">
							<ul>
								<li>Resources</li>
										<li><a href="/student-banking/resources/overview.go" name="sb-resource-loans-banking">Student loans & banking</a></li>
							</ul>
						</div>
					<div class="clearboth"></div>
			</div>
	</div>
</div>




 



		<div class="global-footer-module">
			<div class="fsd-skin">

				<div class="footer-bottom-left" style="float:left;max-width:66%;">
	    			<div class="gf-links">	          	
						
					
									
									<a  target="_self" href="/" 
									    name="global_footer_home">Home
									</a>
									
						
					
									
									<a  target="_self" href="/accessiblebanking/overview.go" 
									    name="global_footer_accessible_banking">Accessible Banking
									</a>
									
						
					
									
									<a  target="_self" href="/privacy/overview.go" 
									    name="global_footer_privacy_security">Privacy & Security
									</a>
									
						
					
									
									<a  target="_self" href="http://careers.bankofamerica.com/careershome.aspx" 
									    name="global_footer_careers">Careers
									</a>
									
						
					
									
									<a  target="_self" href="/sitemap/personal.go" 
									    name="global_footer_site_map">Site Map
									</a>
									
						
					
									<a href="javascript:void(0);" class="gf-last-link boa-dialog boa-com-info-layer-link" name="global_footer_advertising_practices_lnk" rel="global_footer_advertising_practices">Advertising Practices</a>
								<div id="global_footer_advertising_practices" class="hide">
									<h3>Advertising Practices</h3>
										<p>We strive to provide you with information about products and services you might find interesting and useful. Relationship-based ads and online behavioral advertising help us do that.</p>
<p>Here's how it works: We gather information about your online activities, such as the searches you conduct on our Sites and the pages you visit. This information may be used to deliver advertising on our Sites and offline (for example, by phone, email and direct mail) that's customized to meet specific interests you may have.</p>
<p>If you prefer that we do not use this information, you may <a onclick="$('.ui-dialog').remove();" name="WebsiteAdPractices_OptOut" href="/privacy/online-privacy-notice.go#advertising-on-our-sites" target="_blank">opt out of online behavioral advertising</a>. If you opt out, though, you may still receive generic advertising. In addition, financial advisors/Client Managers may continue to use information collected online to provide product and service information in accordance with account agreements.</p>
<p>Also, if you opt out of online behavioral advertising, you may still see ads when you sign in to your account, for example through Online Banking or MyMerrill. These ads are based on your specific account relationships with us.</p>
<p>To learn more about relationship-based ads, online behavioral advertising and our privacy practices, please review the <a onclick="$('.ui-dialog').remove();" name="WebsiteAdPractices_PrivacyNotice" href="/privacy/online-privacy-notice.go" target="_blank">Bank of America Online Privacy Notice</a> and our <a onclick="$('.ui-dialog').remove();" name="Online-privacy-faqs" href="/privacy/faq/online-privacy-faq.go" target="_blank">Online Privacy FAQs</a>.</p>
								</div>
						<div class="clearboth"></div>
	    			</div>
	      			<p>Bank of America, N.A. Member <acronym title="Federal Deposit Insurance Corporation">FDIC</acronym>. <a onclick="window.open('/help/equalhousing_popup.go','newwin','width=640,height=371,scrollbars=yes,resizable=yes,left=35,top=161'); return false;" name="equal_housing_lender" href="/help/equalhousing_popup.go" target="_blank">Equal Housing Lender<img src="https://www2.bac-assets.com/content/images/ContextualSiteGraphics/Logos/en_US/icon_equal_housing_lender.gif" alt="" width="14" height="9" /></a><br />&copy; 2017 Bank of America Corporation.</p>
         		</div>
         		<div class="footer-social-container" style="float:right;max-width:30%;padding-left:50px;padding-top:19px;">




<div class="boa-social-loader" data-loaded="false" data-platform="borneo"  data-options=''></div>

         		</div>
         		<div class="clearboth"></div>
  			</div>
		</div>




 
<script language="javascript" src="https://www2.bac-assets.com/pa/global-assets/external/coremetrics/hp/eluminate.js"></script>
<script language="javascript" src="https://www2.bac-assets.com/pa/global-assets/external/coremetrics/hp/cmdatatagutils.js"></script>


<script language="javascript">
	function cmSetDD(){var testString=window.location.href;if(testString.toLowerCase().indexOf('.bankofamerica.com')>-1){testString=testString.toLowerCase();var tempArr=testString.split('.bankofamerica.com');var tempStr=tempArr[0];if(tempStr.indexOf('\/\/')>-1){tempArr=tempStr.split('\/\/');tempStr=tempArr[1];if(tempStr.indexOf('.')>-1){tempArr=tempStr.split('.');tempStr=tempArr[0];var tempStrPt2=tempArr[1]}if(tempStr.indexOf('www')>-1){if(tempStr.indexOf('-')>-1){cmSetStaging()}else if(tempStrPt2!=null){if(tempStrPt2.indexOf('ecnp')>-1){cmSetStaging()}}else{cmSetProduction()}}else if(tempStr.indexOf('-')>-1){if(tempStr.indexOf('sitekey')>-1){if(tempStr=='sitekey'){cmSetProduction()}else{cmSetStaging()}}else{cmSetStaging()}}else if(tempStrPt2!=null){if(tempStrPt2.indexOf('ecnp')>-1){cmSetStaging()}}else{cmSetProduction()}}}}if(typeof cmSetStaging=='function'){cmSetDD()}
</script> 

		<script type="text/javascript">
			cmCreatePageviewTag('studentbanking:Content:resources:FAQ;student-banking-faqs', null, null, 'studentbanking:Content:resources:FAQ', false, false, null, false, false, null, null, null, null, null, null, null, null, null, null, null, null);
		</script>

</div>
					</div>
				</div>
			</div>
		</div>
	</body>	
</html>

