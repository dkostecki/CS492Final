
 

				<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
				<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
				<head>



<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<meta http-equiv="content-type" content="text/html;charset=utf-8" />






			<link rel="canonical" href="https://www.bankofamerica.com/home-loans/faq-mortgage-refi.go"/>
		
	
	





<title>Mortgage and Home Refinance FAQs from Bank of America</title>
<link rel="shortcut icon" href="https://www2.bac-assets.com/pa/global-assets/1.0/graphic/favicon.ico" type="image/ico" />

				<meta name="Keywords" CONTENT="mortgage faqs, refinance faqs, mortgage frequently asked questions, refinance frequently asked questions, home refinance faqs, home refinance frequently asked questions" />
				<meta name="Description" CONTENT="Find answers to frequently asked questions about mortgages and home refinancing from Bank of America." />
				<meta name="twitter:title" CONTENT="Mortgage and Home Refinance FAQs from Bank of America" />
				<meta name="twitter:card" CONTENT="summary" />
				<meta name="twitter:url" CONTENT="https://www.bankofamerica.com/home-loans/faq-mortgage-refi.go" />
				<meta name="twitter:image" CONTENT="https://www.bankofamerica.com/content/images/ContextualSiteGraphics/Logos/en_US/Bank_of_America_Flagscape_71x71.gif" />
				<meta name="twitter:description" CONTENT="Find answers to frequently asked questions about mortgages and home refinancing from Bank of America." />
				<meta name="twitter:site" CONTENT="@BofA_Tips" />
				<meta property="og:title" CONTENT="Mortgage and Home Refinance FAQs from Bank of America" />
				<meta property="og:type" CONTENT="website" />
				<meta property="og:url" CONTENT="https://www.bankofamerica.com/home-loans/faq-mortgage-refi.go" />
				<meta property="og:image" CONTENT="https://www.bankofamerica.com/content/images/ContextualSiteGraphics/Logos/en_US/Bank_of_America_Flagscape_71x71.gif" />
				<meta property="og:description" CONTENT="Find answers to frequently asked questions about mortgages and home refinancing from Bank of America." />
				<meta property="og:site_name" CONTENT="Bank of America" />
	

        <script type="text/javascript">
			var boaTLTargetPage = "/home-loans";
  		</script>
			<script src="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/Global/1.0/script/tealeafbundle.js" type="text/javascript"></script>

	

		<link rel="stylesheet" type="text/css" href="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/APS-home-loans/2017.03.0/style/home-loans-jawr.css" media="all" />
		<link rel="stylesheet" type="text/css" href="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/APS-home-loans/2017.03.0/style/home-loans-jawr-print.css" media="print" />
		<script src="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/APS-home-loans/2017.03.0/script/home-loans-jawr.js" type="text/javascript"></script>	  
	
			<script src="https://www2.bac-assets.com/pa/components/modules/cta-module/2.1/script/cta-module-topnav-floating-skin.js" type="text/javascript"></script>
			<script src="https://www2.bac-assets.com/pa/components/modules/cta-module/2.1/script/cta-module.js" type="text/javascript"></script>
				<link href="https://www2.bac-assets.com/pa/components/modules/cta-module/2.1/style/cta-module-topnav-floating-skin.css" rel="stylesheet" type="text/css" />
				<link href="https://www2.bac-assets.com/pa/components/modules/cta-module/2.1/style/cta-module.css" rel="stylesheet" type="text/css" />
<script type="text/javascript">
(function() {
	if (typeof mboxUpdate == "function") {
		var windowURL = window.location.href
	    windowURL = windowURL.slice( windowURL.indexOf('.')+1);
		windowURL = windowURL.split( '?' )[0];
		windowURL = windowURL.toLowerCase();
		//alert(windowURL);
		if (
		    //If no mboxes on page, mbox count will be < 1
		    (mboxFactoryDefault.getMboxes().length() < 1) &&  
			
			//Also check for high-volume pages that do not need global logging
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go") &&
			(windowURL != "bankofamerica.com/myaccounts/signin/signin.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/entry/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signonscreen.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatechallengeanswer.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatePassword.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/mobile/banking.go")&&
			(windowURL != "bankofamerica.com/content/preload/olb-myaccount-preload-jawr-module.htm")
			)
		{

			var mboxDiv = document.createElement("div");
			mboxDiv.id = "adobe_touch_clarity_replacement";
			mboxDiv.style.display = "none";
			if (document.body && document.body.firstChild) document.body.insertBefore(mboxDiv,document.body.firstChild);
			mboxDefine(mboxDiv.id,'bac_global_bottom');
			mboxUpdate('bac_global_bottom');
		}
	}	
})();
</script>
         	

			<script>
				var boaPageDataJS = {};
					boaPageDataJS.isLLE = "false";
			</script>
				<style>body{display:none;}</style>
	</head>		

	<body class="fsd-layout-body">	

				<script type="text/javascript">if(self == top){var theBody=document.getElementsByTagName("body")[0];theBody.style.display="block";}else{top.location=self.location;}</script>
				<noscript><style>body{display:block;}</style></noscript>
					<a class='ada-hidden ada-visible-focus' href='#skip-to-h1' id='ada-skip-link'>Skip to main content</a>
		<div class="fsd-layout fsd-2c-700lt-layout">
			<div class="fsd-border">
				<div class="center-content">
					<div class="header">
		  



<script language="javascript" src="/pa/components/modules/tag-manager-module/1.1/script/tag-manager-module-borneo-global-skin.js"></script>
<script>

(function() {
  var fireCallback = function( cb ) {
    if ( typeof cb === "function" ) cb();
  };
  
  function ddoPopulateBase( callback ) {
    try {
		  var DDO = window.digitalData,
		  	bactm_mergeDDO = function( newDDO, priorDDO ) {
		  		if( typeof priorDDO === "undefined" ) {
				  	priorDDO = digitalData || {};
				  }

			    for (var l in newDDO) {
			        if (typeof priorDDO[l] === "undefined") {
			            priorDDO[l] = newDDO[l];
			        }
			        if (newDDO[l] !== null) {
			            if (typeof newDDO[l] === "object") {
			                bactm_mergeDDO(newDDO[l], priorDDO[l]);
			            } else {
			                priorDDO[l] = bactm_validateValue( newDDO[l] ) ? newDDO[l] : priorDDO[l];
			            }
			        }
			    }

			    return priorDDO;
				},
				bactm_olb3rdPartyId = "null";

			if (typeof DDO === "undefined") {
				var simpleDDO = { page: { pageInfo:[{ pageID: null }], attributes: {}, category: { primaryCategory: null }}};

				DDO = (typeof digitalData === "object") ? digitalData : simpleDDO; 
			}

				DDO = bactm_mergeDDO( {pageInstanceID:"notprod",load_coremetrics:false,load_opinionlabs:false,load_touchcommerce:true,load_audiencemanager:true,page:{pageInfo:[{pageID:null,destinationURL:null,referringURL:null,issueDate:null,language:null,segmentValue:null,appName:null,appStepNumber:null,appStepName:null,attr:"-_--_--_--_--_--_--_--_--_--_--_--_--_--_-"}],category:{primaryCategory:null,addlCategory:null,pageType:null},attributes:{searchString:null,searchResults:null,olbSessionID:null,subCampaignCode:null,DARTUrl:null,stateCookie:null,SASIEnabled:false,needOLBcookie:false,standardDART:[],standardDARTes:[],clickDART:[],clickDARTes:[],gaId:[],chat:{account_type:null,boa_associate:null,boa_retiree:null,customer_lob:null,customer_segment:null,data:null,email_campaign:null,entitlement_code:null,error_category:null,error_count:null,first_login:null,inqSalesProductTypes:{},invitation_background:null,invitation_template:null,referral_campaign:null,getStateValue:false,cust_fn:null,cust_ln:null,target:null}}},user:{segment:null,online_id:null,preferred_rewards_tier:null,olb3rdpartyid:null},version:"BAC_0.12"}, DDO );

			DDO.page.pageInfo[0].pageID = "HL:Content:Basics:FAQ;faq-mortgage-refi";
			DDO.page.category.primaryCategory  = "HL:Content:Basics:FAQ";
			DDO.page.pageInfo[0].language = "en-US";
			DDO.page.attributes.olbSessionID = "null";
			DDO.page.attributes.SASIEnabled =  "false";
			if (typeof DDO.user != "undefined" && typeof DDO.user.olb3rdpartyid != "undefined") {
				DDO.user.olb3rdpartyid = bactm_olb3rdPartyId;
			}

			window.utag_data = {};
			window.bactm_envSelector = bactm_setTMLib();
			window.digitalData = DDO;

      return fireCallback( callback );

    } catch(e) { }
  }
	if( window.boa && window.boa.digitalData ) {
    window.boa.digitalData.register( ddoPopulateBase );
	}
	else {
	  // Handle scenario where the header isn't available (and thus the default digitalData object and utag loader are missing).
	  //
		var writeScript = function(a,b,c,d){
			a='//tags.tiqcdn.com/utag/bofa/main/' + bactm_envSelector + '/utag.js';
			b=document;
			c='script';
			d=b.createElement(c);
			d.src=a;
			d.type='text/java'+c;
			d.async=true;
			a=b.getElementsByTagName(c)[0];
			a.parentNode.insertBefore(d,a);
		};

		ddoPopulateBase( writeScript );
	}
})();			
</script>




 


	 
<div class="header-module">
	<div class="home-loans-skin">
		<div class="header-left">
	  
			<div itemscope itemtype="http://schema.org/Corporation" class="bofa-logo">
				<a itemprop="url" name="anc-home-loans" title="Bank of America" href="/">
					<img itemprop="logo" height="28" width="221" alt="Bank of America" src="/content/images/ContextualSiteGraphics/Logos/en_US/boa_logo.gif" />
				</a>
			</div>
				<div class="product">Home Loans</div>
			<div class="clearboth"></div>
		</div>
	   	<div class="header-right">
			<ul class="header-links">
						<li class="sign-in"> 
							<a href="https://www.bankofamerica.com/hub/index.action?template=signin" title="Sign In" name="Sign_In_global_nav" target="_self">Sign In</a> 
						</li>
						<li> 
							<a href="/" title="Home" name="Home_Page_global_nav" target="_self">Home</a> 
						</li>
						<li> 
							<a href="https://locators.bankofamerica.com " title="Locations" name="Locations_Link_global_nav" target="_self">Locations</a> 
						</li>
						<li> 
							<a href="/contactus/contactus.go?topicId=mrtg_home_equity" title="Contact Us" name="Contact_Us_global_nav" target="_self">Contact Us</a> 
						</li>
						<li> 
							<a href="/home-loans/faq-mortgage-refi.go" title="help" name="help_global_nav" target="_self">Help</a> 
						</li>
						<li class="last-link">
									<a href="/home-loans/faq-mortgage-refi.go?request_locale=es_US"  title="En Espa&#241;ol" name="SpanishHLTS_global_nav" target="_self">En Espa&#241;ol</a> 				
						</li>
		  	</ul>
		  	<div class="clearboth"></div>

		  	<!-- include search-dotcom-util -->



<div class="header-search nlh">
  
  <div class="nav-search">
    <form class="search-form" action="https://secure.bankofamerica.com/myaccounts/public/search-results/unAuthenticatedSearch.go" data-js="/pa/components/utilities/search-util/1.0/script/nav-search.min.js" data-css="/pa/components/utilities/search-util/1.0/style/nav-search.css" data-text-unavailable="Search Currently Unavailable">
      <div class="search-input-container cf" data-icon="search">
        <label for="nav-search-query" class="ada-hidden">Search Term</label>
        <input type="text" placeholder="How can we help you?" name="query" class="search-query" id="nav-search-query" 
          maxlength="99" rel="Search" autocomplete="off"><input type="submit" alt="Search" title="Search" value="Submit Search" name="Search Module - Top Result – Search Button" class="submit track-me">
      </div>
    </form>
  </div>

</div>
	
	   	</div>
   		<div class="clearboth"></div>
	</div>
</div>







<div class="hl-navigation-module">
	<div class="fsd-skin sup-ie css3-pie">
		<ul class="nav-list">
				
									
					<li>
					<a name="rates-and-calculators_topnav" id="Rates & Calculators" href="/mortgage/" class="top-menu-item ">Rates & Calculators <span class="ada-hidden">link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>	
		
						 <div class="sub-nav-box">
								<div class="sub-nav-left">
						<div class="hasSub">
												<a name="todays-home-loan-rates_topnav" target="_self" href="/mortgage/">Today's Home Loan Rates</a>
												<a name="mortgage-calculator_topnav" target="_self" href="/home-loans/mortgage/mortgage-payment-calculator.go">Mortgage Calculator</a>
												<a name="refinance-rate-calculator_topnav" target="_self" href="/home-loans/refinance/custom-refinance-rates-today.go">Refinance Rate Calculator</a>
												<a name="home-equity-calculator_topnav" target="_self" href="/home-loans/home-equity/home-equity-loan-payment-calculator.go">Home Equity Calculator</a>
												<a name="closing-cost-calculator_topnav" target="_self" href="/home-loans/mortgage/closing-costs-calculator.go">Closing Cost Calculator</a>
						</div>
										<span class="ada-hidden">End of submenu</span>
									</div>
								</div>
							</li>
				
									
					<li>
					<a name="mortgage-link_topnav" id="Mortgage" href="/home-loans/mortgage/overview.go" class="top-menu-item ">Mortgage <span class="ada-hidden">link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>	
		
						 <div class="sub-nav-box">
								<div class="sub-nav-left">
						<div class="hasSub">
												<a name="todays-mortgage-rates_topnav" target="_self" href="/mortgage/mortgage-rates/">Today's Mortgage Rates</a>
												<a name="mortgage-calculator_topnav" target="_self" href="/home-loans/mortgage/mortgage-payment-calculator.go">Mortgage Calculator</a>
												<a name="closing-cost-calculator_topnav" target="_self" href="/home-loans/mortgage/closing-costs-calculator.go">Closing Cost Calculator</a>
												<div class="dot-border" tabindex="-1"></div>
												<a name="fixed-rate-mortgage_topnav" target="_self" href="/mortgage/fixed-rate-mortgage-loans/">Fixed-Rate Mortgage</a>
												<a name="adjustable-rate-mortgage_topnav" target="_self" href="/mortgage/adjustable-rate-mortgage-loans/">Adjustable-Rate Mortgage</a>
												<a name="jumbo-loan_topnav" target="_self" href="/mortgage/jumbo-loans/">Jumbo Loan</a>
												<a name="affordable-loan-solution _topnav" target="_self" href="/mortgage/affordable-loan-solution-mortgage/">Affordable Loan Solution </a>
												<a name="fha-and-va-loans_topnav" target="_self" href="/mortgage/fha-va-mortgage-loans/">FHA &amp; VA Loans</a>
						</div>
				
		
						<div class="hasSub">
												<span>Help When You Need It</span>
												<a name="first-time-homebuyer-tips_topnav" target="_self" href="/home-loans/mortgage/first-time-home-buyer.go">First-Time Homebuyer Tips</a>
												<a name="budgeting-for-a-home_topnav" target="_self" href="/home-loans/mortgage/budgeting-for-home.go">Budgeting for a Home</a>
												<a name="affordable-housing-assistance-programs_topnav" target="_self" href="/home-loans/mortgage/affordable-housing-programs.go">Affordable Housing Assistance Programs</a>
												<a name="find-a-house_topnav" target="_self" href="http://realestatecenter.bankofamerica.com/">Find a House</a>
						</div>
										<span class="ada-hidden">End of submenu</span>
									</div>
								</div>
							</li>
				
									
					<li>
					<a name="refinance-link_topnav" id="Refinance" href="/home-loans/refinance/overview.go" class="top-menu-item ">Refinance <span class="ada-hidden">link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>	
		
						 <div class="sub-nav-box">
								<div class="sub-nav-left">
						<div class="hasSub">
												<a name="todays-refinance-rates_topnav" target="_self" href="/mortgage/refinance-rates/">Today's Refinance Rates </a>
												<a name="refinance-calculator_topnav" target="_self" href="/home-loans/refinance/custom-refinance-rates-today.go">Refinance Calculator</a>
												<a name="home-value-estimator _topnav" target="_self" href="http://realestatecenter.bankofamerica.com/tools/marketvalue4.aspx">Home Value Estimator </a>
												<div class="dot-border" tabindex="-1"></div>
												<a name="fixed-rate-refinance-loans_topnav" target="_self" href="/mortgage/fixed-rate-refinance-loans/">Fixed-Rate Refinance Loans</a>
												<a name="adjustable-rate-refinance-loans_topnav" target="_self" href="/mortgage/adjustable-rate-refinance-loans/ ">Adjustable-Rate Refinance Loans</a>
												<a name="fha-and-va-refinance-loans_topnav" target="_self" href="/home-loans/refinance/fha-va-refinance.go">FHA &amp; VA Refinance Loans</a>
						</div>
				
		
						<div class="hasSub">
												<span>Help When You Need It</span>
												<a name="cash-out-refinance-info_topnav" target="_self" href="/home-loans/refinance/reasons-to-refinance/cash-out-refinance-loan.go">Cash-Out Refinance Info</a>
												<a name="reasons-to-refinance_topnav" target="_self" href="/home-loans/refinance/should-refinance-mortgage.go">Reasons to Refinance</a>
						</div>
										<span class="ada-hidden">End of submenu</span>
									</div>
								</div>
							</li>
				
									
					<li>
					<a name="home-equity_topnav" id="Home Equity" href="/home-loans/home-equity-loans/overview.go" class="top-menu-item ">Home Equity <span class="ada-hidden">link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>	
		
						 <div class="sub-nav-box">
								<div class="sub-nav-left">
						<div class="hasSub">
												<a name="home-equity-line-of-credit-rates_topnav" target="_self" href="/home-equity/home-equity-rates/">Home Equity Line of Credit Rates</a>
												<a name="fixed-rate-loan-option_topnav" target="_self" href="/home-equity/fixed-rate-loan/">Fixed-Rate Loan Option </a>
												<a name="home-equity-calculator_topnav" target="_self" href="/home-loans/home-equity/home-equity-loan-payment-calculator.go">Home Equity Calculator</a>
												<a name="home-value-estimator_topnav" target="_self" href="http://realestatecenter.bankofamerica.com/tools/marketvalue4.aspx">Home Value Estimator</a>
						</div>
				
		
						<div class="hasSub">
												<span>Help When You Need It</span>
												<a name="what-is-a-home-equity-line-of-credit_topnav" target="_self" href="/home-loans/home-equity/what-is-a-home-equity-line-of-credit.go">What Is a Home Equity Line of Credit? </a>
												<a name="evaluating-your-homes-equity_topnav" target="_self" href="/home-loans/home-equity/evaluating-home-equity.go">Evaluating Your Home's Equity</a>
												<a name="understanding-your-debt-to-income-ratio_topnav" target="_self" href="/home-loans/home-equity/owe-vs-make.go">Understanding Your Debt-to-Income Ratio</a>
												<a name="home-equity-or-cash-out-refinance_topnav" target="_self" href="/home-loans/home-equity/cash-out-refinance.go">Home Equity or Cash-out Refinance?</a>
						</div>
										<span class="ada-hidden">End of submenu</span>
									</div>
								</div>
							</li>
				
									
					<li>
					<a name="learn-about-home-loans_topnav" id="Learn About Home Loans" href="/home-loans/home-loan-guide.go" class="top-menu-item ">Learn About Home Loans <span class="ada-hidden">link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>	
		
						 <div class="sub-nav-box">
								<div class="sub-nav-left">
						<div class="hasSub">
												<a name="learn-about-home-buying_topnav" target="_self" href="/home-loans/mortgage/budgeting-for-home.go ">Learn About Home Buying </a>
												<a name="learn-about-refinancing_topnav" target="_self" href="/home-loans/refinance/should-refinance-mortgage.go">Learn About Refinancing</a>
												<a name="learn-about-home-equity_topnav" target="_self" href="/home-loans/home-equity/basics.go">Learn About Home Equity</a>
												<div class="dot-border" tabindex="-1"></div>
												<a name="home-loan-checklist_topnav" target="_self" href="/content/documents/mortgage/HomeLoanChecklist.pdf">Home Loan Checklist</a>
												<a name="faqs-link_topnav" target="_self" href="/home-loans/faq-mortgage-refi.go">FAQs</a>
												<a name="glossary-link_topnav" target="_self" href="/home-loans/glossary.go ">Glossary</a>
						</div>
										<span class="ada-hidden">End of submenu</span>
									</div>
								</div>
							</li>
				
									
					<li>
					<a name="manage-your-loan_topnav" id="Manage Your Loan" href="/home-loans/service.go" class="top-menu-item ">Manage Your Loan <span class="ada-hidden">link</span></a>	
		
							</li>
		</ul>
	</div>
</div>


<div class="page-title-fsd-module h-100" id="skip-to-h1">
	<div class="standard-red-skin sup-ie">
			<h1 data-font="cnx-regular">Mortgage and Refinance FAQs</h1>
	</div>
</div>


 

 







					<div class="cta-module topnav-floating-skin headline-number Mortgage">
						<div class="box">
							<p class="heading" data-font="cnx-bold">Get prequalified</p>
							<p class="subheading">Call now <span class="number">1.866.467.6490</span></p>
						</div>
						<div class="actions">


		
		
		
		
	
	
	

	<a id="topnav_cta_action_1" href="https://secure.bankofamerica.com/applynow/initialize-workflow.go?requesttype=MPQ&subCampCode=98975&loanPurpose=purchase" target='_self' class="bump-rt  dart-click" 	
	
	
	
	
	
	
	
	
		
	data-dart-type="hliip069" data-dart-src="1359940" data-dart-cat="hli_h434"
  >Start online<span class='ada-hidden'> application</span></a>



		
			
		
		
		
	
	
	

	<a id="topnav_cta_action_2" href="https://mortgage.bankofamerica.com" target='_blank' class=" dart-click" 	
	
	
	
	
	
	
	
	
		
	data-dart-type="hliip069" data-dart-src="1359940" data-dart-cat="hli_h834"
  >Meet face-to-face<span class='ada-hidden'> with a loan officer</span></a>

						</div>
					</div>	
			 
	
<script type="text/javascript">
$(document).ready(function() {
	floatingCtaModule.init();
});
</script>		
	
</div>
					<div class="columns">
						<div class="flex-col lt-col" >	<div class="generic-content-module">
		<div class="overview-skin com-main-well-content">
			<h2>Frequently asked questions</h2>
			
				<ul class="accordion">
					<li>
						<a class="accordion-link" name="Can_I_pay_my_mortgage_online" id="Can I pay my mortgage online?" href="javascript:void(0);">Can I pay my mortgage online?</a>
						<div class="accordion-content"><p>There are several ways to pay your mortgage online. If you have an eligible Bank of America account, you can make your mortgage payment using the <strong>Bill Pay</strong> tab or <strong>Transfers</strong> tab at no charge. You can use each of these tools to schedule automatic recurring payments or make a one-time payment.</p>
<p>PayPlan is a service that allows you to make automatic payments from your checking or savings account. There are 4 potential services available based on how often you would like your payment drafted from your account. To find out how to enroll in one of our PayPlan services or to see which service is available for your account, please call our customer service at 1.800.669.6607, Monday through Friday, 7 am to 7 pm local time. PayPlan is not available for FHA and VA loans.</p>
<p class="pad-adjust">MortgagePay on the Web is another online option for one-time mortgage payments. It can be used with eligible Bank of America accounts at no charge, as well as with checking or savings accounts from other financial institutions at no charge or with a fee, depending on when the payment is made relative to your grace period. To pay your mortgage account online using MortgagePay on the Web, follow these easy steps:</p>
<ul>
<li><a name="Enroll_in_Online_Banking" href="/onlinebanking/online-banking.go" target="_self">Enroll in Online Banking</a> for online access or, if you have already enrolled, <a name="Sign_in_to_Online_Banking" href="https://secure.bankofamerica.com/login/sign-in/signOnScreen.go" target="_self">sign in to Online Banking</a></li>
<li>On the <strong>Accounts Overview</strong> page, select <strong>Mortgage</strong></li>
<li>On the <strong>Account Details</strong> page, select <strong>Pay Now</strong> and follow the instructions</li>
</ul>
<p>For further assistance with online payments, please call Online Banking customer service at 1.800.933.6262.</p>
<p>In addition to the electronic payment options listed above, we offer additional no-cost and low-cost options for making your mortgage payment. To learn more please call 1.800.669.6607.</p></div>
					</li>

			
			
					<li class="closed">
						<a class="accordion-link" name="Do_I_need_to_get_a_home_appraisal_in_order_to_get_a_home_loan" id="Do I need to get a home appraisal in order to get a home loan?" href="javascript:void(0);">Do I need to get a home appraisal in order to get a home loan?</a>
						<div class="accordion-content"><p>Yes. We will schedule the appraisal as part of reviewing your home loan application and you will receive a copy of the appraisal at closing.</p></div>
					</li>

			
			
					<li class="closed">
						<a class="accordion-link" name="How_does_my_credit_rating_affect_my_home_loan_interest_rate" id="How does my credit rating affect my home loan interest rate?" href="javascript:void(0);">How does my credit rating affect my home loan interest rate?</a>
						<div class="accordion-content"><p>Because the way you&rsquo;ve handled your finances in the past can help predict how you may do so in the future, lenders will consider your credit rating when you apply for a mortgage or other loan. A higher credit score may help you qualify for better <a href="/mortgage/mortgage-rates/" name="rates" target="_self">mortgage interest rates</a>, and some lenders may lower their down payment requirement for a new home loan if you have a high credit score.</p>
<p><a href="https://www.bankofamerica.com/home-loans/mortgage/impact-of-your-credit/how-credit-affects-interest-rate.go" name="Intrest rate" target="_self">See how credit affects your interest rate</a></p></div>
					</li>

			
			
					<li class="closed">
						<a class="accordion-link" name="Can_I_pay_off_my_mortgage_early" id="Can I pay off my mortgage early?" href="javascript:void(0);">Can I pay off my mortgage early?</a>
						<div class="accordion-content"><p>After your loan is closed, if you'd like to pay it off early, please contact our Loan Servicing Department at 1.800.669.6607. Remember to have your loan number handy.</p></div>
					</li>

			
			
					<li class="closed">
						<a class="accordion-link" name="Can_I_make_additional_payments_to_the_principal_balance_of_my_loan" id="Can I make additional payments to the principal balance of my loan?" href="javascript:void(0);">Can I make additional payments to the principal balance of my loan?</a>
						<div class="accordion-content"><p>When you make your regular monthly mortgage payment, you may include an additional amount to be applied directly to principal. If paying by check, to ensure the money is credited correctly, write the amount of the extra principal payment where designated on your Mortgage Account Statement.</p><p>If you're an Online Banking customer using Bill Pay, use the Memo line to indicate you are including an additional payment toward the principal. Enter the amount of the extra principal payment and click <strong>Send Memo with Payment</strong>.</p><p>Additional principal payments will only be applied after the current month's full payment has posted to your account.<strong> Please note</strong>: if there is a prepayment penalty associated with your loan, you may be penalized for paying off your loan early. Review the terms of your mortgage to determine if this provision applies to you.</p></div>
					</li>

			
			
					<li class="closed">
						<a class="accordion-link" name="When_will_I_receive_my_yearend_statement_of_interest_paid_on_my_mortgage_for_tax_purposes" id="When will I receive my year-end statement of interest paid on my mortgage for tax purposes?" href="javascript:void(0);">When will I receive my year-end statement of interest paid on my mortgage for tax purposes?</a>
						<div class="accordion-content"><p>Year-end interest-paid statements (IRS Form 1098) are mailed out by the end of January. Contact us at 1.800.669.6607 if you do not receive it by February 15. You may also be able to access a copy of your IRS Form 1098 by going to the Account Details tab for your mortgage account in Online Banking.</p></div>
					</li>

			
			
					<li class="closed">
						<a class="accordion-link" name="How_long_does_the_whole_loan_process_take" id="How long does the whole loan process take?" href="javascript:void(0);">How long does the whole loan process take?</a>
						<div class="accordion-content"><p>Every home loan situation is different, so it&rsquo;s impossible to estimate how long your home mortgage process will take. Some of the factors that affect the timeline include the type and terms of the home loan you&rsquo;re requesting, the types of documentation required in order to secure the loan and the amount of time it takes to provide your lender with those documents. Your Bank of America's&nbsp;lending specialist will work closely with you to help you meet your timetable so that deadlines are met and your rate locks are honored.</p></div>
					</li>

			
			
					<li class="closed">
						<a class="accordion-link" name="When_refinancing_my_mortgage_can_I_get_extra_money_at_closing_so_I_can_pay_off_other_debt" id="When refinancing my mortgage, can I get extra money at closing so I can pay off other debt?" href="javascript:void(0);">When refinancing my mortgage, can I get extra money at closing so I can pay off other debt?</a>
						<div class="accordion-content"><p>Yes. A cash-out refinance enables you to pay off your existing mortgage(s) and also to take out some of your home equity in a lump-sum cash payment at closing.</p>
<p><a href="https://www.bankofamerica.com/home-loans/refinance/reasons-to-refinance/cash-out-refinance-loan.go" name="Cash out refinance" target="_self">Learn more about a cash-out refinance option</a></p></div>
					</li>

			
			
					<li class="closed">
						<a class="accordion-link" name="Which_financial_index_does_Bank_of_America_use_to_determine_adjustable_rates" id="Which financial index does Bank of America use to determine adjustable rates?" href="javascript:void(0);">Which financial index does Bank of America use to determine adjustable rates?</a>
						<div class="accordion-content"><p>Every adjustable-rate mortgage uses a financial rate index, such as the LIBOR index or the U.S. Prime Rate, to determine the loan rate. Lenders have no control over money rate indexes, and you can track the performance of each index in The Wall Street Journal. The rate you pay is set at each adjustment period by adding the rate of the index plus your margin (which remains the same from period to period).</p>
<p>Bank of America ARM rates are determined using the LIBOR index, which tracks the rate international banks charge each other for large loans in the London interbank market. Even though the LIBOR index adjusts frequently, Bank of America <a href="/mortgage/adjustable-rate-mortgage-loans/" name="adjustable rate" target="_self">adjustable-rate mortgages </a>only adjust annually after the introductory period expires.</p></div>
					</li>

			
			
					<li class="closed">
						<a class="accordion-link" name="I39m_a_veteran_Is_there_a_special_program_available_to_me" id="I&#39m a veteran. Is there a special program available to me?" href="javascript:void(0);">I&#39m a veteran. Is there a special program available to me?</a>
						<div class="accordion-content"><p>Yes.&nbsp;<a href="https://www.bankofamerica.com/mortgage/fha-va-mortgage-loans/" name="VA loans" target="_self">VA loans</a> provide up to 100% financing, providing qualified veterans the opportunity to purchase a home. To find out how Bank of America can assist you with a VA loan, <a href="https://secure.bankofamerica.com/mycommunications/public/appointments/discussionsubtopic.go?topicSelected=A5000" name="loan officer" target="_self">make an appointment to speak with a mortgage loan officer</a>.</p></div>
					</li>

			
			
					<li class="closed">
						<a class="accordion-link" name="What_types_of_affordable_housing_assistance_programs_are_available_to_me" id="What types of affordable housing assistance programs are available to me?" href="javascript:void(0);">What types of affordable housing assistance programs are available to me?</a>
						<div class="accordion-content"><p>Our mortgage loan officers can tell you about affordable housing assistance programs in which Bank of America participates. When combined with an eligible loan, these assistance programs can help qualified homebuyers achieve successful homeownership. <a href="#footnote1" name="1"><span class="ada-hidden">footnote</span><sup>1</sup></a></p>
<p>To find out how Bank of America can assist you with affordable housing assistance programs, <a href="https://secure.bankofamerica.com/mycommunications/public/appointments/discussionsubtopic.go?topicSelected=A5000" name="appointments" target="_self">make an appointment to speak with a mortgage loan officer</a>.</p>
<p><a href="https://www.bankofamerica.com/home-loans/mortgage/affordable-housing-programs.go" name="Learn more" target="_self">Learn more about affordable housing assistance programs</a></p></div>
					</li>

			
			
					<li class="closed">
						<a class="accordion-link" name="My_request_for_home_loan_assistance_was_denied_Can_I_dispute_that_decision" id="My request for home loan assistance was denied. Can I dispute that decision?" href="javascript:void(0);">My request for home loan assistance was denied. Can I dispute that decision?</a>
						<div class="accordion-content"><p class="pad-adjust">If you were denied home loan assistance, such as a request for a loan modification, short sale or deed in lieu, you may be able to dispute the decision. You can file an escalated case with us if you have reason to believe any of the following are true:</p>
<p>You met all the criteria for home loan assistance but were not properly evaluated for assistance or were improperly denied assistance. This may include:</p>
<ul>
<li>You did not receive adequate notice from us about your foreclosure alternatives</li>
<li>You were not given appropriate time to respond to communications from us during your loan review process</li>
</ul>
<ul>
<li>Your loan was referred to foreclosure prematurely, or we did not suspend foreclosure activities when we were required to do so</li>
</ul>
<p class="pad-adjust">You can also file an escalated case if either of these&nbsp;2 specific concerns apply to your loan:</p>
<ul>
<li>You have a reasonable belief that your mortgage loan is being serviced in a fraudulent manner</li>
<li>You have retained a lawyer to help you resolve a mortgage dispute with Bank of America</li>
</ul>
<p>If you have reason to believe that any of these concerns&nbsp;apply in connection with your loan review and affected your eligibility for home loan assistance, you may file an escalated case with us to review your concerns.</p>
<p>Please note that inquiries about a pending request for home loan assistance or general questions about the servicing of your mortgage do not meet the requirements for an escalated case. For general servicing questions, please call 800.669.6607, Monday through Friday 7 a.m. to 7 p.m. local time.</p>
<p>To file an escalated case, you or any third party representing you, such as a housing counselor or attorney, should send us a brief letter describing the specific reasons you believe one of the above scenarios applies to your loan or to your application for home loan assistance.</p>
<p>If you are represented by an attorney, please have your lawyer submit this request on your behalf.</p>
<p>Escalated case requests must be sent by mail to the following address:</p>
<div class="plt-15">Bank of America Corporate Center<br />Attn: BAC Escalated Case Unit<br />P.O. Box 940508<br />Simi Valley, CA 93094-0508</div>
<p>Please note that if a third party, such as an advisor or a nonprofit advocate, contacts us to submit an escalated case on your behalf, we must have your written authorization before we can communicate with them about you or your loan. Without your written authorization, we will not be able to discuss your home loan with them. We can provide you with an authorization form upon request.</p>
<p><strong>What to expect after submitting your request</strong></p>
<p>Within three business days after receipt:</p>
<p>If your submission meets the requirements for an escalated case, within three business days of the receipt of your request, we will send you a written acknowledgement that we have received your request. This acknowledgement will also include the estimated date by which your escalated case should be resolved, along with a toll-free number for the Escalated Case Unit.</p>
<p>Within 15 calendar days after receipt:</p>
<p>In most cases, within 15 calendar days of the receiving your request, we will mail you a written response describing the proposed resolution of your request and any next steps to be followed by you or by us. If your matter cannot be resolved within 15 calendar days, we will notify you of the delay and give you a new estimated resolution date. This new estimated resolution date, in most cases, will be no longer than 30 calendar days from the date we received your original escalated case.</p>
<p><strong>Checking the status of your escalated case</strong></p>
<p>Your written confirmation will include a toll-free number you can call for information about your escalated case.</p></div>
					</li>

			
			
					<li class="closed last-qn">
						<a class="accordion-link" name="What_happens_if_I_am_unable_to_make_my_payment" id="What happens if I am unable to make my payment?" href="javascript:void(0);">What happens if I am unable to make my payment?</a>
						<div class="accordion-content"><P>If you are unable to make your payment for any reason, please contact us at 1.800.451.6362, Monday through Friday 7 a.m. to 10 p.m. ET.</P><P>Visit <A class=mceItemAnchor href="https://secure.bankofamerica.com/login/sign-in/signOnScreen.go" target=_self name=Visit_Online_Banking mce_href="https://secure.bankofamerica.com/login/sign-in/signOnScreen.go">Online Banking</A>&nbsp;for more service information.</P></div>
					</li>
				</ul>
			
		</div>
	</div>


</div>
						<div class="flex-col rt-col" >












	


<div class="cta-module target-sidewell location-bottom">

			<div class="cta focus-call">
				<div class="intro">
					<h3>Call customer service</h3>
				</div>
		<ul class="options">		
							<li class="call  first ">

									<div class="details">

									<p>Mortgage accounts</p>
										<p class="large">1.800.669.6607</p>
	<p class="small smpad">Mon.&ndash;Fri.&nbsp;7 a.m.&ndash;7 p.m. <br />local time</p>
									</div>
							</li>
		</ul>
	</div>
</div>
<div class="side-well-module"> </div>
</div>
						<div class="clearboth"></div>
					</div>
					<div class="footer">
						<div class="footer-top">&nbsp;

	<div class="footnote-module">

	   <div class="fsd-skin">

						    <div class="footnote-link"><a name="footnote1">1.</a></div>
							<div class="footnote-text last-txt">Down payment assistance programs may not be available in your area. Down payment assistance amount may be due upon sale, refinance, transfer, repayment of the loan, or if the senior mortgage is assumed during the term of the loan. Some programs require repayment with interest and borrowers should become fully informed prior to closing. Not all applicants will qualify. Minimum credit scores may apply. Sales price restrictions and income requirements may apply. Homebuyer education may be required. Owner-occupied properties only. Maximum loan amounts may apply.</div>
							<div class="clearboth"></div>
	   </div>
	</div>
</div>
						<div class="footer-inner">






<div class="hl-power-footer-module">
	<div class="fsd-flex-skin sup-ie">
		<div class="breadcrumbs">
		<div itemscope itemtype="http://schema.org/BreadcrumbList">
								<div itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
										<a itemprop="item" class="bold-bc" href="/" name="bank-of-america-breadcrumbs" target="_self">
										<span itemprop="name">Bank of America</span>
										<meta itemprop="position" content="1" /></a>
								</div>
								<div itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
										<a itemprop="item" href="/home-loans/overview.go" name="home-loans-breadcrumbs" target="_self">
										<span itemprop="name">Home Loans</span>
										<meta itemprop="position" content="2" /></a>
								</div>
				   	  			    
				     
				    

				    		    
				    <div class="breadcrumb-last-item" itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
					<span itemprop="name">Mortgage and Refinance FAQs</span>
					<meta itemprop="position" content="3" />
				    </div>		
			
<div class="clearboth"></div>
</div>
</div>

<div class="pf-columns">
			  
			  
				  	<div class="pf-col">
				  
						<a href="/mortgage/home-mortgage/" name="mortgage-link-power-footer" class="bold" target="_self">Mortgage</a>
								
									<a href="/mortgage/mortgage-rates/"  name="todays-mortgage-rates-power-footer" target="_self">Today's Mortgage Rates</a>
								
									<a href="/home-loans/mortgage/mortgage-payment-calculator.go"  name="mortgage-calculator-power-footer" target="_self">Mortgage Calculator</a>
								
									<a href="/home-loans/mortgage/closing-costs-calculator.go"  name="closing-cost-calculator-power-footer" target="_self">Closing Cost Calculator</a>
								
									<a href="http://realestatecenter.bankofamerica.com/"  name="real-estate-center-power-footer" target="_self">Real Estate Center</a>
					</div>   
			  
			  
				  	<div class="pf-col">
				  
						<a href="/mortgage/refinance/" name="refinance-link-power-footer" class="bold" target="_self">Refinance</a>
								
									<a href="/mortgage/refinance-rates/"  name="todays-refinance-rates-power-footer" target="_self">Today's Refinance Rates</a>
								
									<a href="/home-loans/refinance/custom-refinance-rates-today.go"  name="refinance-calculator-power-footer" target="_self">Refinance Calculator</a>
								
									<a href="http://realestatecenter.bankofamerica.com/tools/marketvalue4.aspx"  name="home-value-estimator-power-footer" target="_self">Home Value Estimator</a>
					</div>   
			  
			  
				  	<div class="pf-col">
				  
						<a href="/home-equity/" name="home-equity-power-footer" class="bold" target="_self">Home Equity</a>
								
									<a href="/home-equity/home-equity-rates/"  name="home-equity-line-of-credit-rates-power-footer" target="_self">Home Equity Line of Credit Rates</a>
								
									<a href="/home-equity/fixed-rate-loan/"  name="fixed-rate-loan-option-power-footer" target="_self">Fixed-Rate Loan Option</a>
								
									<a href="/home-loans/home-equity/home-equity-loan-payment-calculator.go"  name="home-equity-calculator-power-footer" target="_self">Home Equity Calculator</a>
								
									<a href="http://realestatecenter.bankofamerica.com/tools/marketvalue4.aspx"  name="home-value-estimator-power-footer" target="_self">Home Value Estimator</a>
					</div>   
			  
			  
				  	<div class="pf-col">
				  
						<a href="/home-loans/service.go" name="manage-your-loan-power-footer" class="bold" target="_self">Manage Your Loan</a>
								
									<a href="/login/sign-in/signOnScreen.go" onClick="dartFireOnClick('1359940','hliip069','hli_h298');" name="sign-in-to-online-banking-power-footer" target="_self">Sign in to Online Banking</a>
								
									<a href="https://secure.bankofamerica.com/applynow/welcome.go"  name="continue-a-saved-application-power-footer" target="_self">Continue a Saved Application</a>
								
									<a href="/home-loans/service.go"  name="get-help-with-my-loan-or-application -power-footer" target="_self">Get Help with My Loan or Application </a>
								
									<a href="http://homeloanhelp.bankofamerica.com/en/index.html"  name="get-help-with-payment-difficulties-power-footer" target="_self">Get Help with Payment Difficulties</a>
					</div>   
			  
			  
			  
		  <div class="clearboth"></div>
    </div>

</div>
</div>



 



		<div class="global-footer-module">
			<div class="fsd-skin">

				<div class="footer-bottom-left" style="float:left;max-width:66%;">
	    			<div class="gf-links">	          	
						
					
									
									<a  target="_self" href="/" 
									    name="Home_Page">Home
									</a>
									
						
					
									
									<a  target="_self" href="/privacy/overview.go" 
									    name="Privacy_Security">Privacy & Security
									</a>
									
						
					
									
									<a  target="_self" href="http://www.bankofamerica.com/careers/" 
									    name="Careers_Link">Careers
									</a>
									
						
					
									
									<a  target="_self" href="/sitemap/personal.go" 
									    name="Site_Map">Site Map
									</a>
									
						
					
									<a href="javascript:void(0);" class="gf-last-link boa-dialog boa-com-info-layer-link" name="global_footer_ad_practices_lnk" rel="global_footer_ad_practices">Advertising Practices</a>
								<div id="global_footer_ad_practices" class="hide">
									<h3>Advertising Practices</h3>
										<p>We strive to provide you with information about products and services you might find interesting and useful. Relationship-based ads and online behavioral advertising help us do that.</p>
<p>Here's how it works: We gather information about your online activities, such as the searches you conduct on our Sites and the pages you visit. This information may be used to deliver advertising on our Sites and offline (for example, by phone, email and direct mail) that's customized to meet specific interests you may have.</p>
<p>If you prefer that we do not use this information, you may <a onclick="$('.ui-dialog').remove();" name="WebsiteAdPractices_OptOut" href="/privacy/online-privacy-notice.go#advertising-on-our-sites" target="_blank">opt out of online behavioral advertising</a>. If you opt out, though, you may still receive generic advertising. In addition, financial advisors/Client Managers may continue to use information collected online to provide product and service information in accordance with account agreements.</p>
<p>Also, if you opt out of online behavioral advertising, you may still see ads when you sign in to your account, for example through Online Banking or MyMerrill. These ads are based on your specific account relationships with us.</p>
<p>To learn more about relationship-based ads, online behavioral advertising and our privacy practices, please review the <a onclick="$('.ui-dialog').remove();" name="WebsiteAdPractices_PrivacyNotice" href="/privacy/online-privacy-notice.go" target="_blank">Bank of America Online Privacy Notice</a> and our <a onclick="$('.ui-dialog').remove();" name="Online-privacy-faqs" href="/privacy/faq/online-privacy-faq.go" target="_blank">Online Privacy FAQs</a>.</p>
								</div>
						<div class="clearboth"></div>
	    			</div>
	      			<p>Bank of America, N.A. Member FDIC. <a title=" Equal Housing Lender information. Link opens new window." onclick="window.open('/help/equalhousing_popup.go','newwin','width=640,height=371,scrollbars=yes,resizable=yes,left=35,top=161'); return false;" name="Equal_Housing_Lender" href="/help/equalhousing_popup.go" target="_blank">Equal Housing Lender<img src="https://www2.bac-assets.com/content/images/ContextualSiteGraphics/Logos/en_US/icon_equal_housing_lender.gif" alt="" width="14" height="9" /></a><br />&copy; 2017 Bank of America Corporation. All rights reserved. Credit and collateral are subject to approval. Terms and conditions apply. This is not a commitment to lend. Programs, rates, terms and conditions are subject to change without notice.</p>
         		</div>
         		<div class="footer-social-container" style="float:right;max-width:30%;padding-left:50px;padding-top:19px;">




<div class="boa-social-loader" data-loaded="false" data-platform="borneo"  data-options=''></div>

         		</div>
         		<div class="clearboth"></div>
  			</div>
		</div>




 

	
<script type="text/javascript" src="https://www2.bac-assets.com/pa/global-assets/external/coremetrics/hp/eluminate.js"></script>
<script type="text/javascript" src="https://www2.bac-assets.com/pa/global-assets/external/coremetrics/hp/cmdatatagutils.js"></script>
<script type="text/javascript" src="https://www2.bac-assets.com/pa/components/modules/coremetrics-module/4.0/script/coremetrics-module-hlts-skin.js"></script>
<script type="text/javascript">						
	var productViewTags = false;				
</script>
	
	
	
	
	
	
	
	
	
	
	
	
	
		
<script type="text/javascript">
	
	    	
	function createErrorCode(id)
	{
		errorCode = '';
		e1=id;
		e2=e1.indexOf('|');
		if(e2 != -1)
		{
			splitArray = e1.split('|');
			errorCode = splitArray[0];
			errorCode=errorCode.replace(/\[/g,"");
			return errorCode;
		}
	}
	
	function createErrorMsg(msg)
	{
		errorMessage = '';
		e1=msg;
		e2=e1.indexOf('|');
		if(e2 != -1)
		{
			splitArray = e1.split('|');
			errorMessage = splitArray[1];
			errorMessage=errorMessage.replace(/\]/g,"");
			if (errorMessage.length > 100) 
			{
			     errorMessage = errorMessage.substring(0, 100);
			}
			return errorMessage;
		}
	}
	
	function throwCustomError(errorText) {
	      errorMessage = '';
	      errorCode = '';
	      errorCode = createErrorCode(errorText);
	      errorMessage = createErrorMsg(errorText);
	      cmCreateCustomError('HL:Content:Basics:FAQ;faq-mortgage-refi', null, null, null, errorCode, boaCMdata.convCategoryID, errorMessage);
         }
		
	var boaCMdata = {
		eventID: 'App View to submit LF3a_Mkt_98975',
		eventIdStart:'App View to Start LF3a_Mkt_98975',
		pageID: 'HL:Content:Basics:FAQ;faq-mortgage-refi',
		convCategoryID:'HL:App:Purch',
		productId:'',
		productName:'',
		productCategoryId:''
	};
	
		try{
     	bofaCM('HL:Content:Basics:FAQ;faq-mortgage-refi', 'HL:Content:Basics:FAQ', 'false', 'false', 'false', 'false', '98975');	
     	}
     	catch(err){}
	

	
</script>


<script type="text/javascript">
var axel = Math.random()+"";var a = axel * 10000000000000;document.write('<iframe title="iFrame used for layout purpose" src="https://fls.doubleclick.net/activityi;src=1359940;type=hliip069;cat=hli_h949;ord=1;num=' + a + '?;num='+ a + '?" width="1" height="1" frameborder="0" style="display:none;"></iframe>');
</script>
<noscript>
	<iframe title="iFrame used for layout purpose" src="https://fls.doubleclick.net/activityi;src=1359940;type=hliip069;cat=hli_h949;ord=1;num=1?" width="0" height="0" frameborder="0" style="display:none;"></iframe>
</noscript>

			<div itemscope="itemscope" itemtype="http://schema.org/WebPage">
					<span style="display:none" itemprop="name">Mortgage and Home Refinance FAQs from Bank of America</span>
					<a style="display:none" itemprop="url" href="https://www.bankofamerica.com/home-loans/faq-mortgage-refi.go"></a>
					<span style="display:none" itemprop="description">Find answers to frequently asked questions about mortgages and home refinancing from Bank of America.</span>
					<img style="display:none" class="no-stretch" itemprop="image" alt="Mortgage and Home Refinance FAQs from Bank of America" src="https://www.bankofamerica.com/content/images/ContextualSiteGraphics/Logos/en_US/Bank_of_America_Flagscape_71x71.gif">
					<span style="display:none" itemprop="keywords">mortgage faqs, refinance faqs, mortgage frequently asked questions, refinance frequently asked questions, home refinance faqs, home refinance frequently asked questions</span>
			</div>
</div>
					</div>
				</div>
			</div>
		</div>
	</body>	
</html>

