
 

				<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
				<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
				<head>



<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<meta http-equiv="content-type" content="text/html;charset=utf-8" />






			<link rel="canonical" href="https://www.bankofamerica.com/home-loans/home-equity/evaluating-home-equity.go"/>
		
	
	
			<link rel="alternate" media="only screen and (max-width: 640px)" href="http://loans.bankofamerica.com/en/articles/evaluating-home-equity.html"/>
			<link rel="alternate" media="handheld" href="http://loans.bankofamerica.com/en/articles/evaluating-home-equity.html" />





<title>How to Calculate and Determine Equity in Your Home from Bank of America</title>
<link rel="shortcut icon" href="https://www2.bac-assets.com/pa/global-assets/1.0/graphic/favicon.ico" type="image/ico" />

				<meta name="Keywords" CONTENT="how to calculate home equity, how to determine home equity" />
				<meta name="Description" CONTENT="Learn how to calculate and determine the equity in your home before considering to refinance or take out a home equity loan or line of credit." />
				<meta name="twitter:title" CONTENT="How to Calculate and Determine Equity in Your Home from Bank of America" />
				<meta name="twitter:card" CONTENT="summary" />
				<meta name="twitter:url" CONTENT="https://www.bankofamerica.com/home-loans/home-equity/evaluating-home-equity.go" />
				<meta name="twitter:image" CONTENT="https://www.bankofamerica.com/content/images/ContextualSiteGraphics/Logos/en_US/Bank_of_America_Flagscape_71x71.gif" />
				<meta name="twitter:description" CONTENT="Learn how to calculate and determine the equity in your home before considering to refinance or take out a home equity loan or line of credit." />
				<meta name="twitter:site" CONTENT="@BofA_Tips" />
				<meta property="og:title" CONTENT="How to Calculate and Determine Equity in Your Home from Bank of America" />
				<meta property="og:type" CONTENT="website" />
				<meta property="og:url" CONTENT="https://www.bankofamerica.com/home-loans/home-equity/evaluating-home-equity.go" />
				<meta property="og:image" CONTENT="https://www.bankofamerica.com/content/images/ContextualSiteGraphics/Logos/en_US/Bank_of_America_Flagscape_71x71.gif" />
				<meta property="og:description" CONTENT="Learn how to calculate and determine the equity in your home before considering to refinance or take out a home equity loan or line of credit." />
				<meta property="og:site_name" CONTENT="Bank of America" />
	

        <script type="text/javascript">
			var boaTLTargetPage = "/home-loans";
  		</script>
			<script src="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/Global/1.0/script/tealeafbundle.js" type="text/javascript"></script>

	
 
		<link rel="stylesheet" type="text/css" href="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/APS-home-loans/2017.03.0/style/home-loans-he-jawr.css" media="all" />
		<link rel="stylesheet" type="text/css" href="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/APS-home-loans/2017.03.0/style/home-loans-he-jawr-print.css" media="print" />
		<script src="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/APS-home-loans/2017.03.0/script/home-loans-he-jawr.js" type="text/javascript"></script>	  
	
			<script src="https://www2.bac-assets.com/pa/components/modules/cta-module/2.1/script/cta-module-topnav-floating-skin.js" type="text/javascript"></script>
				<link href="https://www2.bac-assets.com/pa/components/modules/cta-module/2.1/style/cta-module-topnav-floating-skin.css" rel="stylesheet" type="text/css" />
<script type="text/javascript">
(function() {
	if (typeof mboxUpdate == "function") {
		var windowURL = window.location.href
	    windowURL = windowURL.slice( windowURL.indexOf('.')+1);
		windowURL = windowURL.split( '?' )[0];
		windowURL = windowURL.toLowerCase();
		//alert(windowURL);
		if (
		    //If no mboxes on page, mbox count will be < 1
		    (mboxFactoryDefault.getMboxes().length() < 1) &&  
			
			//Also check for high-volume pages that do not need global logging
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go") &&
			(windowURL != "bankofamerica.com/myaccounts/signin/signin.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/entry/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signonscreen.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatechallengeanswer.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatePassword.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/mobile/banking.go")&&
			(windowURL != "bankofamerica.com/content/preload/olb-myaccount-preload-jawr-module.htm")
			)
		{

			var mboxDiv = document.createElement("div");
			mboxDiv.id = "adobe_touch_clarity_replacement";
			mboxDiv.style.display = "none";
			if (document.body && document.body.firstChild) document.body.insertBefore(mboxDiv,document.body.firstChild);
			mboxDefine(mboxDiv.id,'bac_global_bottom');
			mboxUpdate('bac_global_bottom');
		}
	}	
})();
</script>
         	

			<script>
				var boaPageDataJS = {};
					boaPageDataJS.isLLE = "false";
			</script>
				<style>body{display:none;}</style>
	</head>		

	<body class="fsd-layout-body">	

				<script type="text/javascript">if(self == top){var theBody=document.getElementsByTagName("body")[0];theBody.style.display="block";}else{top.location=self.location;}</script>
				<noscript><style>body{display:block;}</style></noscript>
					<a class='ada-hidden ada-visible-focus' href='#skip-to-h1' id='ada-skip-link'>Skip to main content</a>
		<div class="fsd-layout fsd-2c-600lt-layout">
			<div class="fsd-border">
				<div class="center-content">
					<div class="header">
		  



<script language="javascript" src="/pa/components/modules/tag-manager-module/1.1/script/tag-manager-module-borneo-global-skin.js"></script>
<script>

(function() {
  var fireCallback = function( cb ) {
    if ( typeof cb === "function" ) cb();
  };
  
  function ddoPopulateBase( callback ) {
    try {
		  var DDO = window.digitalData,
		  	bactm_mergeDDO = function( newDDO, priorDDO ) {
		  		if( typeof priorDDO === "undefined" ) {
				  	priorDDO = digitalData || {};
				  }

			    for (var l in newDDO) {
			        if (typeof priorDDO[l] === "undefined") {
			            priorDDO[l] = newDDO[l];
			        }
			        if (newDDO[l] !== null) {
			            if (typeof newDDO[l] === "object") {
			                bactm_mergeDDO(newDDO[l], priorDDO[l]);
			            } else {
			                priorDDO[l] = bactm_validateValue( newDDO[l] ) ? newDDO[l] : priorDDO[l];
			            }
			        }
			    }

			    return priorDDO;
				},
				bactm_olb3rdPartyId = "null";

			if (typeof DDO === "undefined") {
				var simpleDDO = { page: { pageInfo:[{ pageID: null }], attributes: {}, category: { primaryCategory: null }}};

				DDO = (typeof digitalData === "object") ? digitalData : simpleDDO; 
			}

				DDO = bactm_mergeDDO( {pageInstanceID:"notprod",load_coremetrics:false,load_opinionlabs:false,load_touchcommerce:true,load_audiencemanager:true,page:{pageInfo:[{pageID:null,destinationURL:null,referringURL:null,issueDate:null,language:null,segmentValue:null,appName:null,appStepNumber:null,appStepName:null,attr:"-_--_--_--_--_--_--_--_--_--_--_--_--_--_-"}],category:{primaryCategory:null,addlCategory:null,pageType:null},attributes:{searchString:null,searchResults:null,olbSessionID:null,subCampaignCode:null,DARTUrl:null,stateCookie:null,SASIEnabled:false,needOLBcookie:false,standardDART:[],standardDARTes:[],clickDART:[],clickDARTes:[],gaId:[],chat:{account_type:null,boa_associate:null,boa_retiree:null,customer_lob:null,customer_segment:null,data:null,email_campaign:null,entitlement_code:null,error_category:null,error_count:null,first_login:null,inqSalesProductTypes:{},invitation_background:null,invitation_template:null,referral_campaign:null,getStateValue:false,cust_fn:null,cust_ln:null,target:null}}},user:{segment:null,online_id:null,preferred_rewards_tier:null,olb3rdpartyid:null},version:"BAC_0.12"}, DDO );

			DDO.page.pageInfo[0].pageID = "HL:Content:HE:Basics;evaluating-home-equity";
			DDO.page.category.primaryCategory  = "HL:Content:HE:Basics";
			DDO.page.pageInfo[0].language = "en-US";
			DDO.page.attributes.olbSessionID = "null";
			DDO.page.attributes.SASIEnabled =  "false";
			if (typeof DDO.user != "undefined" && typeof DDO.user.olb3rdpartyid != "undefined") {
				DDO.user.olb3rdpartyid = bactm_olb3rdPartyId;
			}

			window.utag_data = {};
			window.bactm_envSelector = bactm_setTMLib();
			window.digitalData = DDO;

      return fireCallback( callback );

    } catch(e) { }
  }
	if( window.boa && window.boa.digitalData ) {
    window.boa.digitalData.register( ddoPopulateBase );
	}
	else {
	  // Handle scenario where the header isn't available (and thus the default digitalData object and utag loader are missing).
	  //
		var writeScript = function(a,b,c,d){
			a='//tags.tiqcdn.com/utag/bofa/main/' + bactm_envSelector + '/utag.js';
			b=document;
			c='script';
			d=b.createElement(c);
			d.src=a;
			d.type='text/java'+c;
			d.async=true;
			a=b.getElementsByTagName(c)[0];
			a.parentNode.insertBefore(d,a);
		};

		ddoPopulateBase( writeScript );
	}
})();			
</script>




 


	 
<div class="header-module">
	<div class="home-loans-skin">
		<div class="header-left">
	  
			<div itemscope itemtype="http://schema.org/Corporation" class="bofa-logo">
				<a itemprop="url" name="anc-home-loans" title="Bank of America" href="/">
					<img itemprop="logo" height="28" width="221" alt="Bank of America" src="/content/images/ContextualSiteGraphics/Logos/en_US/boa_logo.gif" />
				</a>
			</div>
				<div class="product">Home Loans</div>
			<div class="clearboth"></div>
		</div>
	   	<div class="header-right">
			<ul class="header-links">
						<li class="sign-in"> 
							<a href="/hub/index.action?template=signin" title="Sign In" name="Sign_In_global_nav" target="_self">Sign In</a> 
						</li>
						<li> 
							<a href="/" title="Home" name="Home_Link_global_nav" target="_self">Home</a> 
						</li>
						<li> 
							<a href="https://locators.bankofamerica.com/" title="Locations" name="Locations_Link_global_nav" target="_self">Locations</a> 
						</li>
						<li> 
							<a href="/contactus/contactus.go?topicId=mrtg_home_equity" title="Contact Us" name="Contact_Us_global_nav" target="_self">Contact Us</a> 
						</li>
						<li> 
							<a href="/home-loans/faq-homeequity.go" title="help" name="help_global_nav" target="_self">Help</a> 
						</li>
						<li class="last-link">
									<a href="/home-loans/home-equity/evaluating-home-equity.go?request_locale=es_US"  title="En Espa&#241;ol" name="SpanishHLTS_global_nav" target="_self">En Espa&#241;ol</a> 				
						</li>
		  	</ul>
		  	<div class="clearboth"></div>

		  	<!-- include search-dotcom-util -->



<div class="header-search nlh">
  
  <div class="nav-search">
    <form class="search-form" action="https://secure.bankofamerica.com/myaccounts/public/search-results/unAuthenticatedSearch.go" data-js="/pa/components/utilities/search-util/1.0/script/nav-search.min.js" data-css="/pa/components/utilities/search-util/1.0/style/nav-search.css" data-text-unavailable="Search Currently Unavailable">
      <div class="search-input-container cf" data-icon="search">
        <label for="nav-search-query" class="ada-hidden">Search Term</label>
        <input type="text" placeholder="How can we help you?" name="query" class="search-query" id="nav-search-query" 
          maxlength="99" rel="Search" autocomplete="off"><input type="submit" alt="Search" title="Search" value="Submit Search" name="Search Module - Top Result – Search Button" class="submit track-me">
      </div>
    </form>
  </div>

</div>
	
	   	</div>
   		<div class="clearboth"></div>
	</div>
</div>






<div class="hl-navigation-module">
	<div class="fsd-skin sup-ie css3-pie">
		<ul class="nav-list">
				
									
					<li>
					<a name="rates-and-calculators_topnav" id="Rates & Calculators" href="/mortgage/" class="top-menu-item ">Rates & Calculators <span class="ada-hidden">link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>	
		
						 <div class="sub-nav-box">
								<div class="sub-nav-left">
						<div class="hasSub">
												<a name="todays-home-loan-rates_topnav" target="_self" href="/mortgage/">Today's Home Loan Rates</a>
												<a name="mortgage-calculator_topnav" target="_self" href="/home-loans/mortgage/mortgage-payment-calculator.go">Mortgage Calculator</a>
												<a name="refinance-rate-calculator_topnav" target="_self" href="/home-loans/refinance/custom-refinance-rates-today.go">Refinance Rate Calculator</a>
												<a name="home-equity-calculator_topnav" target="_self" href="/home-loans/home-equity/home-equity-loan-payment-calculator.go">Home Equity Calculator</a>
												<a name="closing-cost-calculator_topnav" target="_self" href="/home-loans/mortgage/closing-costs-calculator.go">Closing Cost Calculator</a>
						</div>
										<span class="ada-hidden">End of submenu</span>
									</div>
								</div>
							</li>
				
									
					<li>
					<a name="mortgage-link_topnav" id="Mortgage" href="/home-loans/mortgage/overview.go" class="top-menu-item ">Mortgage <span class="ada-hidden">link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>	
		
						 <div class="sub-nav-box">
								<div class="sub-nav-left">
						<div class="hasSub">
												<a name="todays-mortgage-rates_topnav" target="_self" href="/mortgage/mortgage-rates/">Today's Mortgage Rates</a>
												<a name="mortgage-calculator_topnav" target="_self" href="/home-loans/mortgage/mortgage-payment-calculator.go">Mortgage Calculator</a>
												<a name="closing-cost-calculator_topnav" target="_self" href="/home-loans/mortgage/closing-costs-calculator.go">Closing Cost Calculator</a>
												<div class="dot-border" tabindex="-1"></div>
												<a name="fixed-rate-mortgage_topnav" target="_self" href="/mortgage/fixed-rate-mortgage-loans/">Fixed-Rate Mortgage</a>
												<a name="adjustable-rate-mortgage_topnav" target="_self" href="/mortgage/adjustable-rate-mortgage-loans/">Adjustable-Rate Mortgage</a>
												<a name="jumbo-loan_topnav" target="_self" href="/mortgage/jumbo-loans/">Jumbo Loan</a>
												<a name="affordable-loan-solution _topnav" target="_self" href="/mortgage/affordable-loan-solution-mortgage/">Affordable Loan Solution </a>
												<a name="fha-and-va-loans_topnav" target="_self" href="/mortgage/fha-va-mortgage-loans/">FHA &amp; VA Loans</a>
						</div>
				
		
						<div class="hasSub">
												<span>Help When You Need It</span>
												<a name="first-time-homebuyer-tips_topnav" target="_self" href="/home-loans/mortgage/first-time-home-buyer.go">First-Time Homebuyer Tips</a>
												<a name="budgeting-for-a-home_topnav" target="_self" href="/home-loans/mortgage/budgeting-for-home.go">Budgeting for a Home</a>
												<a name="affordable-housing-assistance-programs_topnav" target="_self" href="/home-loans/mortgage/affordable-housing-programs.go">Affordable Housing Assistance Programs</a>
												<a name="find-a-house_topnav" target="_self" href="http://realestatecenter.bankofamerica.com/">Find a House</a>
						</div>
										<span class="ada-hidden">End of submenu</span>
									</div>
								</div>
							</li>
				
									
					<li>
					<a name="refinance-link_topnav" id="Refinance" href="/home-loans/refinance/overview.go" class="top-menu-item ">Refinance <span class="ada-hidden">link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>	
		
						 <div class="sub-nav-box">
								<div class="sub-nav-left">
						<div class="hasSub">
												<a name="todays-refinance-rates_topnav" target="_self" href="/mortgage/refinance-rates/">Today's Refinance Rates </a>
												<a name="refinance-calculator_topnav" target="_self" href="/home-loans/refinance/custom-refinance-rates-today.go">Refinance Calculator</a>
												<a name="home-value-estimator _topnav" target="_self" href="http://realestatecenter.bankofamerica.com/tools/marketvalue4.aspx">Home Value Estimator </a>
												<div class="dot-border" tabindex="-1"></div>
												<a name="fixed-rate-refinance-loans_topnav" target="_self" href="/mortgage/fixed-rate-refinance-loans/">Fixed-Rate Refinance Loans</a>
												<a name="adjustable-rate-refinance-loans_topnav" target="_self" href="/mortgage/adjustable-rate-refinance-loans/ ">Adjustable-Rate Refinance Loans</a>
												<a name="fha-and-va-refinance-loans_topnav" target="_self" href="/home-loans/refinance/fha-va-refinance.go">FHA &amp; VA Refinance Loans</a>
						</div>
				
		
						<div class="hasSub">
												<span>Help When You Need It</span>
												<a name="cash-out-refinance-info_topnav" target="_self" href="/home-loans/refinance/reasons-to-refinance/cash-out-refinance-loan.go">Cash-Out Refinance Info</a>
												<a name="reasons-to-refinance_topnav" target="_self" href="/home-loans/refinance/should-refinance-mortgage.go">Reasons to Refinance</a>
						</div>
										<span class="ada-hidden">End of submenu</span>
									</div>
								</div>
							</li>
				
									
					<li>
					<a name="home-equity_topnav" id="Home Equity" href="/home-loans/home-equity-loans/overview.go" class="top-menu-item ">Home Equity <span class="ada-hidden">link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>	
		
						 <div class="sub-nav-box">
								<div class="sub-nav-left">
						<div class="hasSub">
												<a name="home-equity-line-of-credit-rates_topnav" target="_self" href="/home-equity/home-equity-rates/">Home Equity Line of Credit Rates</a>
												<a name="fixed-rate-loan-option_topnav" target="_self" href="/home-equity/fixed-rate-loan/">Fixed-Rate Loan Option </a>
												<a name="home-equity-calculator_topnav" target="_self" href="/home-loans/home-equity/home-equity-loan-payment-calculator.go">Home Equity Calculator</a>
												<a name="home-value-estimator_topnav" target="_self" href="http://realestatecenter.bankofamerica.com/tools/marketvalue4.aspx">Home Value Estimator</a>
						</div>
				
		
						<div class="hasSub">
												<span>Help When You Need It</span>
												<a name="what-is-a-home-equity-line-of-credit_topnav" target="_self" href="/home-loans/home-equity/what-is-a-home-equity-line-of-credit.go">What Is a Home Equity Line of Credit? </a>
												<a name="evaluating-your-homes-equity_topnav" target="_self" href="/home-loans/home-equity/evaluating-home-equity.go">Evaluating Your Home's Equity</a>
												<a name="understanding-your-debt-to-income-ratio_topnav" target="_self" href="/home-loans/home-equity/owe-vs-make.go">Understanding Your Debt-to-Income Ratio</a>
												<a name="home-equity-or-cash-out-refinance_topnav" target="_self" href="/home-loans/home-equity/cash-out-refinance.go">Home Equity or Cash-out Refinance?</a>
						</div>
										<span class="ada-hidden">End of submenu</span>
									</div>
								</div>
							</li>
				
									
					<li>
					<a name="learn-about-home-loans_topnav" id="Learn About Home Loans" href="/home-loans/home-loan-guide.go" class="top-menu-item selected">Learn About Home Loans <span class="ada-hidden">link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>	
		
						 <div class="sub-nav-box">
								<div class="sub-nav-left">
						<div class="hasSub">
												<a name="learn-about-home-buying_topnav" target="_self" href="/home-loans/mortgage/budgeting-for-home.go ">Learn About Home Buying </a>
												<a name="learn-about-refinancing_topnav" target="_self" href="/home-loans/refinance/should-refinance-mortgage.go">Learn About Refinancing</a>
												<a name="learn-about-home-equity_topnav" target="_self" href="/home-loans/home-equity/basics.go">Learn About Home Equity</a>
												<div class="dot-border" tabindex="-1"></div>
												<a name="home-loan-checklist_topnav" target="_self" href="/content/documents/mortgage/HomeLoanChecklist.pdf">Home Loan Checklist</a>
												<a name="faqs-link_topnav" target="_self" href="/home-loans/faq-mortgage-refi.go">FAQs</a>
												<a name="glossary-link_topnav" target="_self" href="/home-loans/glossary.go ">Glossary</a>
						</div>
										<span class="ada-hidden">End of submenu</span>
									</div>
								</div>
							</li>
				
									
					<li>
					<a name="manage-your-loan_topnav" id="Manage Your Loan" href="/home-loans/service.go" class="top-menu-item ">Manage Your Loan <span class="ada-hidden">link</span></a>	
		
							</li>
		</ul>
	</div>
</div>


<div class="page-title-fsd-module h-100" id="skip-to-h1">
	<div class="standard-red-skin sup-ie">
			<h1 data-font="cnx-regular">Home Equity Line of Credit Basics</h1>
	</div>
</div>


 

 



<script type="text/javascript">
$(document).ready(function() {
	floatingCtaModule.init();
});
</script>



				
					<div class="cta-module topnav-floating-skin number box-height HomeEquity">
						<div class="box">
							<p class="subheading" data-font="cnx-bold">Call now <span class="number">1.866.290.4479</span></p>
						</div>
						<div class="actions">


	<a href="https://secure.bankofamerica.com/applynow/initialize-workflow.go?requesttype=HELOC&subCampCode=98963&loanPurpose=homeequity" target='_self' class="bump-rt  true same-window"  name="Start-online-for-Home-Equity">Start online<span class='ada-hidden'> for Home Equity</span></a>



	
		
	<a href="https://mortgage.bankofamerica.com/search.aspx" target='_blank' class="  false new-window"  name="Meet-face-to-face-with-a-loan-officer">Meet face-to-face<span class='ada-hidden'> with a loan officer</span></a>

						</div>
					</div>
			 
		
		
		
		
	<div id="cta-modal" class="hide">
		<div class="close-wrap"><a id="close-link"  href="javascript:void(0);"><span class="ada-hidden">close  menu</span></a></div>
		<p>Apply</p>
		<a href="
					https://secure.bankofamerica.com/applynow/initialize-workflow.go?requesttype=HELOC&subCampCode=98963&loanPurpose=purchase
" target='_self' class="btn-bofa btn-bofa-blue btn-bofa-small">apply-link</a>
		<p class="pushdown">Apply</p>
		<a href="
					https://secure.bankofamerica.com/applynow/initialize-workflow.go?requesttype=HELOC&subCampCode=98963&loanPurpose=purchase
" target='_blank' class="btn-bofa btn-bofa-blue btn-bofa-small">apply-link</a>	                          
	</div>
	
	<div id="cta-applyonline-details" class="hide cta-details-popup">
		<p>Get started online.</p>
		<p>Apply</p>
		<p><a href="
					https://secure.bankofamerica.com/applynow/initialize-workflow.go?requesttype=HELOC&subCampCode=98963&loanPurpose=purchase
" target='_self' class="">apply-link</a></p>
		<p>Apply</p>
		<p><a href="
					https://secure.bankofamerica.com/applynow/initialize-workflow.go?requesttype=HELOC&subCampCode=98963&loanPurpose=purchase
" target='_blank' class="">apply-link</a></p>	                          
	</div>
	

	
</div>
					<div class="columns">
						<div class="flex-col lt-col" >
	<div class="main-well-content-module">
		<div class="article-skin com-main-well-content">
				<h2 id="article-title" data-font="cnx-medium">Evaluating the equity in your home</h2>
			 	<p class="intro-text">
					If you&rsquo;re&nbsp;taking out a home equity line of credit, the amount of available <a href="javascript:void(0);" id="Equity" class="boa-dialog boa-com-info-layer-link dotted" name="glossary_equity" rel="glossary-popup-9"><span class="ada-hidden">Glossary Term: </span>equity</a> you have in your home plays an important role. Your home equity is the difference between the <a href="javascript:void(0);" id="Appraisal or appraised value " class="boa-dialog boa-com-info-layer-link dotted" name="glossary_appraised_value" rel="glossary-popup-7"><span class="ada-hidden">Glossary Term: </span>appraised value</a> of your home and your current mortgage balance(s). The more equity you have, the more financing options may be available to you.
			 	</p>
Your equity helps your <a href="javascript:void(0);" id="Lender" class="boa-dialog boa-com-info-layer-link dotted" name="glossary_lender" rel="glossary-popup-6"><span class="ada-hidden">Glossary Term: </span>lender</a> determine your <a href="javascript:void(0);" id="Loan-to-value ratio (LTV)" class="boa-dialog boa-com-info-layer-link dotted" name="glossary_loan_value_ratio" rel="glossary-popup-5"><span class="ada-hidden">Glossary Term: </span>loan-to-value ratio</a> (or LTV), which is one of the factors your lender will consider when deciding whether or not to approve your application. It also helps your lender determine whether or not you&rsquo;ll have to pay for <a href="javascript:void(0);" id="Private mortgage insurance (PMI)" class="boa-dialog boa-com-info-layer-link dotted" name="glossary_private_mortgage_insurance" rel="glossary-popup-4"><span class="ada-hidden">Glossary Term: </span>private mortgage insurance</a>&nbsp;(PMI). To avoid PMI, your LTV typically needs to be 80% or less,&nbsp;but PMI applies only to first <a href="javascript:void(0);" id="Glossary Term: Lien" class="boa-dialog boa-com-info-layer-link" rel="glossary-popup-11">liens</a>. So, if your home equity line of credit is a second lien against your house, you shouldn't have to worry about paying PMI.	
							<h3>Calculating your loan-to-value ratio</h3>
Your loan-to-value ratio is another way of expressing how much you still owe on your current mortgage. Here is the basic loan-to-value ratio formula:</p>
<p class="equ-cont"><strong>Current Loan Balance &divide; Current Appraised Value</strong></p>
<p><strong>Example:</strong> You currently have a loan balance of $140,000 (you can find this number on your monthly loan statement or online account). Your home currently appraises for $200,000. So your loan-to-value equation would look like this:</p>
<p class="equ-cont"><strong>$140,000 &divide; $200,000 = .70</strong></p>
<p><strong>Convert .70 to a percentage, and that gives you a loan-to-value ratio of 70%.</strong>	
							<h3>Combined loan-to-value (CLTV) for more than one loan</h3>
If you are considering a home equity line of credit, you would add the amount you want to borrow or the credit limit you want to establish to your current mortgage balance. This would give you your combined loan balance and your <a href="javascript:void(0);" id="Glossary Term: Combined Loan To Value Ratio" class="boa-dialog boa-com-info-layer-link" rel="glossary-popup-10">combined loan-to-value</a> formula would look like this:</p>
<p class="equ-cont"><strong>Current Combined Loan Balance &divide; Current Appraised Value</strong></p>
<p><strong>Example:</strong> You currently have a loan balance of $140,000 (you can find this number on your monthly loan statement or online account), and you want to take out a $25,000 home equity line of credit. Your home currently appraises for $200,000. So your combined loan-to-value equation would look like this:</p>
<p class="equ-cont"><strong>$165,000 &divide; $200,000 = .825</strong></p>
<p><strong>Convert .825 to a percentage, and that gives you a loan-to-value ratio of 82.5%.<br /></strong><br />Most lenders require your CLTV to be 85% or less for a home equity line of credit. If your CLTV is too high, you can either pay down your current loan amount or wait to see if your home&rsquo;s value increases.	
							<h3>The appraisal</h3>
A professional <a href="javascript:void(0);" id="Appraisal or appraised value " class="boa-dialog boa-com-info-layer-link dotted" name="glossary_appraisal" rel="glossary-popup-7"><span class="ada-hidden">Glossary Term: </span>appraisal</a> is an essential part of determining your loan-to-value ratio. If an onsite appraisal is needed, your lender will arrange for a certified <a href="javascript:void(0);" id="Appraiser" class="boa-dialog boa-com-info-layer-link dotted" name="glossary_appraiser" rel="glossary-popup-8"><span class="ada-hidden">Glossary Term: </span>appraiser</a> to come to your home and calculate its value.	
							<h3>How to impact your LTV ratio</h3>
One of the best ways to help reduce your loan-to-value ratio is to pay down your home loan&rsquo;s <a href="javascript:void(0);" id="Principal" class="boa-dialog boa-com-info-layer-link dotted" name="glossary_principal" rel="glossary-popup-12"><span class="ada-hidden">Glossary Term: </span>principal</a> on a regular basis. This happens over time simply by making your <a href="javascript:void(0);" id="Monthly payment" class="boa-dialog boa-com-info-layer-link dotted" name="glossary_monthly_payments" rel="glossary-popup-3"><span class="ada-hidden">Glossary Term: </span>monthly payments</a>, assuming that they are amortized (that is, based on a payment schedule by which you&rsquo;d repay your loan in full by the end of the <a href="javascript:void(0);" id="Loan term" class="boa-dialog boa-com-info-layer-link dotted" name="glossary_loan_term" rel="glossary-popup-2"><span class="ada-hidden">Glossary Term: </span>loan term</a>). You can reduce your loan principal faster by paying a little bit more than your amortized mortgage payment each month (ask your lender if you will have to pay <a href="javascript:void(0);" id="Prepayment penalty" class="boa-dialog boa-com-info-layer-link dotted" name="glossary_prepayment_penalties" rel="glossary-popup-1"><span class="ada-hidden">Glossary Term: </span>prepayment penalties</a> if you do this).</p>
<p>Another way to impact your loan-to-value ratio is by protecting the value of your home by keeping it neat and well maintained.</p>
<div class="tips-content tips-p-p">
<h3>Homeowner tip:</h3>
<span>Making smart improvements could positively affect an appraisal. It&rsquo;s a good idea to consult an appraiser or a real estate professional for advice before investing in any home improvements. And keep in mind that economic conditions can have a negative impact on home values regardless of improvements you make to your home.</span></div>
<p>Now that you know how to calculate your loan-to-value and combined loan to value ratios and how you can impact them, you can make more informed choices to help you reach your financial goals, whether you choose to borrow from the equity in your home, refinance, or simply continue to pay down any current home loan balances.	
		</div>
		
	</div>


</div>
						<div class="flex-col rt-col" >
<script type="text/javascript">	
	$(function($) {
		$('#recent-tab-content').recentActivity({
			cookieName : 'hlts_recent_activity',
			itemClass : 'tool-section tool-icon-save'
		});
    });
</script>

<div class="tab-rightrail-module">
    <div id="content-skin" class="content-skin">
        <ul class="tab-main-bdr">
            <li class="tab">
                <a href="#recommended-tab-content" id="recommended-tab" name="recommended-tab" title="Recommended">Recommended</a>
                <div class="clearboth"></div>
            </li>

            <li class="tab">
                <a href="#popular-tab-content" id="popular-tab" name="popular-tab" title="Popular">Popular</a>
                <div class="clearboth"></div>
            </li>

            <li class="tab">
                <a href="#recent-tab-content" id="recent-tab" name="recent-tab" title="Recent">Recent</a>
                <div class="clearboth"></div>
            </li> 
        </ul>    
        
        <div class="clearboth"></div>
        <div class="tab-panel">
        
        
         
                <ul id="recommended-tab-content" class="recommended-tab-content">
                    <h2 class="ada-hidden">Recommended</h2>
         
            <li class="tool-section tool-icon-save">
                <a id="understanding-your-debt-to-income-ratio-link" class="side-link doc-link" href="/home-loans/home-equity/owe-vs-make.go" title="Understanding your debt-to-income ratio"  >
                    <span>Understanding your debt-to-income ratio</span>
                    <span class="ada-hidden">Article</span>
                </a>
            <div class="clearboth"></div>
            </li>
         
         
            <li class="tool-section tool-icon-save">
                <a id="using-home-equity-link" class="side-link doc-link" href="/home-loans/home-equity/benefits-of-using-home-equity.go" title="Using home equity"  >
                    <span>Using home equity</span>
                    <span class="ada-hidden">Article</span>
                </a>
            <div class="clearboth"></div>
            </li>
         
         
            <li class="tool-section tool-icon-save">
                <a id="cash-out-refinance-article-link" class="side-link doc-link" href="/home-loans/home-equity/cash-out-refinance.go" title="Cash-out refinance or home equity?"  >
                    <span>Cash-out refinance or home equity?</span>
                    <span class="ada-hidden">Article</span>
                </a>
            <div class="clearboth"></div>
            </li>
         
               </ul>
                <ul id="popular-tab-content" class="popular-tab-content">
                    <h2 class="ada-hidden">Popular</h2>
         
            <li class="tool-section tool-icon-save">
                <a id="cash-out-refinance-home-equity-link" class="side-link doc-link" href="/home-loans/home-equity/cash-out-refinance.go" title="Cash-out refinance or home equity?"  >
                    <span>Cash-out refinance or home equity?</span>
                    <span class="ada-hidden">Article</span>
                </a>
            <div class="clearboth"></div>
            </li>
         
                </ul>
                <ul id="recent-tab-content" class="recent-tab-content">
                    <h2 class="ada-hidden">Recent</h2>
                </ul>
        </div>
    </div>
</div>
    
</div>
						<div class="clearboth"></div>
					</div>
					<div class="footer">
						<div class="footer-top">&nbsp;



</div>
						<div class="footer-inner">






<div class="hl-power-footer-module">
	<div class="fsd-flex-skin sup-ie">
		<div class="breadcrumbs">
		<div itemscope itemtype="http://schema.org/BreadcrumbList">
								<div itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
										<a itemprop="item" class="bold-bc" href="/" name="bank-of-america-breadcrumbs" target="_self">
										<span itemprop="name">Bank of America</span>
										<meta itemprop="position" content="1" /></a>
								</div>
								<div itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
										<a itemprop="item" href="/home-loans/overview.go" name="home-loans-breadcrumbs" target="_self">
										<span itemprop="name">Home Loans</span>
										<meta itemprop="position" content="2" /></a>
								</div>
				   	  			    
				     
				    
				    		
				    			<div itemprop="itemListElement" itemscope itemtype=http://schema.org/ListItem>
								<a itemprop="item" href="/home-loans/home-loan-guide.go" name="learn-about-home-loans-breadcrumbs" target="_self">
									<span itemprop="name">Learn About Home Loans</span>
									<meta itemprop="position" content="3"/>
								</a>
							</div>				    		
				    		    
				    <div class="breadcrumb-last-item" itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
					<span itemprop="name">Home Equity Line of Credit Basics</span>
					<meta itemprop="position" content="4" />
				    </div>		
			
<div class="clearboth"></div>
</div>
</div>

<div class="pf-columns">
			  
			  
				  	<div class="pf-col">
				  
						<a href="/home-equity/" name="rates-and-features-power-footer" class="bold" target="_self">Rates & Features</a>
								
									<a href="/home-equity/home-equity-rates/"  name="home-equity-line-of-credit-rates-power-footer" target="_self">Home Equity Line of Credit Rates</a>
								
									<a href="/home-equity/fixed-rate-loan/"  name="fixed-rate-loan-option-power-footer" target="_self">Fixed-Rate Loan Option</a>
								
									<a href="/home-loans/home-equity/home-equity-loan-payment-calculator.go"  name="home-equity-calculator-power-footer" target="_self">Home Equity Calculator</a>
								
									<a href="http://realestatecenter.bankofamerica.com/tools/marketvalue4.aspx"  name="home-value-estimator -power-footer" target="_self">Home Value Estimator </a>
					</div>   
			  
			  
				  	<div class="pf-col">
				  
						<a href="/home-loans/home-equity/basics.go" name="learn-about-home-equity-power-footer" class="bold" target="_self">Learn About Home Equity</a>
								
									<a href="/home-loans/home-equity/what-is-a-home-equity-line-of-credit.go"  name="what-is-a-home-equity-line-of-credit-HELOC-power-footer" target="_self">What Is a Home Equity Line of  Credit (HELOC)?</a>
								
									<a href="/home-loans/home-equity/evaluating-home-equity.go"  name="evaluating-the-equity-in-your-home-power-footer" target="_self">Evaluating the Equity in Your Home</a>
								
									<a href="/home-loans/home-equity/owe-vs-make.go"  name="understanding-your-debt-to-income-ratio-power-footer" target="_self">Understanding Your Debt-to-Income Ratio</a>
								
									<a href="/home-loans/home-equity/cash-out-refinance.go"  name="home-equity-or-cash-out-refinance-power-footer" target="_self">Home Equity or Cash-Out Refinance?</a>
					</div>   
			  
			  
				  	<div class="pf-col">
				  
						<a href="/home-loans/service.go" name="accounts-and-service-power-footer" class="bold" target="_self">Accounts & Service</a>
								
									<a href="https://services.secure.bankofamerica.com/loans/newapp.action" onClick="dartFireOnClick('1359940','hliip069','2013_526');" name="apply-now-power-footer" target="_self">Apply now</a>
								
									<a href="https://secure.bankofamerica.com/applynow/welcome.go"  name="continue-a-saved-application-power-footer" target="_self">Continue a Saved Application</a>
								
									<a href="/login/sign-in/signOnScreen.go" onClick="dartFireOnClick('1359940','hliip069','hli_h298');" name="sign-in-to-your-account-power-footer" target="_self">Sign in to Your Account</a>
								
									<a href="https://services.secure.bankofamerica.com/home-equity/status/status.go" onClick="dartFireOnClick('1359940','hliip069', 'hli_h034');" name="check-your-application-status-submit-documents-online-power-footer" target="_self">Check Your Application Status/Submit Documents Online</a>
								
									<a href="http://homeloanhelp.bankofamerica.com/"  name="get-help-with-payment-difficulties-power-footer" target="_self">Get Help with Payment Difficulties</a>
								
									<a href="/contactus/contactus.go?topicId=mrtg_home_equity" onClick="dartFireOnClick('1359940','hliip069','hli_h826');" name="contact-us-about-your-home-loan  -power-footer" target="_self">Contact Us About Your Home Loan  </a>
					</div>   
			  
			  
			  
		  <div class="clearboth"></div>
    </div>

</div>
</div>
			<div itemscope="itemscope" itemtype="http://schema.org/Article">
					<span style="display:none" itemprop="name">How to Calculate and Determine Equity in Your Home from Bank of America</span>
					<a style="display:none" itemprop="url" href="https://www.bankofamerica.com/home-loans/home-equity/evaluating-home-equity.go"></a>
					<span style="display:none" itemprop="description">Learn how to calculate and determine the equity in your home before considering to refinance or take out a home equity line of credit.</span>
					<img style="display:none" class="no-stretch" itemprop="image" alt="How to Calculate and Determine Equity in Your Home from Bank of America" src="https://www.bankofamerica.com/content/images/ContextualSiteGraphics/Logos/en_US/Bank_of_America_Flagscape_71x71.gif">
					<span style="display:none" itemprop="sourceOrganization">Bank of America</span>
					<span style="display:none" itemprop="articlebody">If you're taking out a home equity loan or line of credit, the amount of available equity you have in your home plays an important role. Your home equity is the difference between the appraised value of your home and your current mortgage balance(s). The more equity you have, the more refinancing options available to you.</span>
					<span style="display:none" itemprop="keywords">how to calculate home equity, how to determine home equity</span>
			</div>



 



		<div class="global-footer-module">
			<div class="fsd-skin">

				<div class="footer-bottom-left" style="float:left;max-width:66%;">
	    			<div class="gf-links">	          	
						
					
									
									<a  target="_self" href="/" 
									    name="Home_Page">Home
									</a>
									
						
					
									
									<a  target="_self" href="/privacy/overview.go" 
									    name="Privacy_Security">Privacy & Security
									</a>
									
						
					
									
									<a  target="_self" href="http://www.bankofamerica.com/careers/" 
									    name="Careers_Link">Careers
									</a>
									
						
					
									
									<a  target="_self" href="/sitemap/personal.go" 
									    name="Site_Map">Site Map
									</a>
									
						
					
									<a href="javascript:void(0);" class="gf-last-link boa-dialog boa-com-info-layer-link" name="global_footer_ad_practices_lnk" rel="global_footer_ad_practices">Advertising Practices</a>
								<div id="global_footer_ad_practices" class="hide">
									<h3>Advertising Practices</h3>
										<p>We strive to provide you with information about products and services you might find interesting and useful. Relationship-based ads and online behavioral advertising help us do that.</p>
<p>Here's how it works: We gather information about your online activities, such as the searches you conduct on our Sites and the pages you visit. This information may be used to deliver advertising on our Sites and offline (for example, by phone, email and direct mail) that's customized to meet specific interests you may have.</p>
<p>If you prefer that we do not use this information, you may <a onclick="$('.ui-dialog').remove();" name="WebsiteAdPractices_OptOut" href="/privacy/online-privacy-notice.go#advertising-on-our-sites" target="_blank">opt out of online behavioral advertising</a>. If you opt out, though, you may still receive generic advertising. In addition, financial advisors/Client Managers may continue to use information collected online to provide product and service information in accordance with account agreements.</p>
<p>Also, if you opt out of online behavioral advertising, you may still see ads when you sign in to your account, for example through Online Banking or MyMerrill. These ads are based on your specific account relationships with us.</p>
<p>To learn more about relationship-based ads, online behavioral advertising and our privacy practices, please review the <a onclick="$('.ui-dialog').remove();" name="WebsiteAdPractices_PrivacyNotice" href="/privacy/online-privacy-notice.go" target="_blank">Bank of America Online Privacy Notice</a> and our <a onclick="$('.ui-dialog').remove();" name="Online-privacy-faqs" href="/privacy/faq/online-privacy-faq.go" target="_blank">Online Privacy FAQs</a>.</p>
								</div>
						<div class="clearboth"></div>
	    			</div>
	      			<p>Bank of America, N.A. Member FDIC. <a title=" Equal Housing Lender information. Link opens new window." onclick="window.open('/help/equalhousing_popup.go','newwin','width=640,height=371,scrollbars=yes,resizable=yes,left=35,top=161'); return false;" name="Equal_Housing_Lender" href="/help/equalhousing_popup.go" target="_blank">Equal Housing Lender<img src="https://www2.bac-assets.com/content/images/ContextualSiteGraphics/Logos/en_US/icon_equal_housing_lender.gif" alt="" width="14" height="9" /></a><br />&copy; 2017 Bank of America Corporation. All rights reserved. Credit and collateral are subject to approval. Terms and conditions apply. This is not a commitment to lend. Programs, rates, terms and conditions are subject to change without notice.</p>
         		</div>
         		<div class="footer-social-container" style="float:right;max-width:30%;padding-left:50px;padding-top:19px;">




<div class="boa-social-loader" data-loaded="false" data-platform="borneo"  data-options=''></div>

         		</div>
         		<div class="clearboth"></div>
  			</div>
		</div>




 

					<div id="glossary-popup-1" class="hide tabs-main-content">
						<h3>Prepayment penalty</h3>
						<p>A penalty assessed by some lenders if a loan is paid off before the specified term. This is a lump-sum amount due and payable in addition to the loan balance, and is usually limited to the early years of a mortgage. A prepayment penalty is called a &ldquo;hard&rdquo; penalty if it applies when you sell or refinance your home or a &ldquo;soft&rdquo; penalty if it applies only to refinancing. Not all loans have prepayment penalties.</p>
					</div>
					<div id="glossary-popup-2" class="hide tabs-main-content">
						<h3>Loan term</h3>
						<p>The period of time during which a loan must be repaid. For example, a 30-year fixed loan has a term of 30 years. Also called term. See also: maturity date.</p>
					</div>
					<div id="glossary-popup-3" class="hide tabs-main-content">
						<h3>Monthly payment</h3>
						<p>The amount paid each month toward the principal and interest amount of a loan. The monthly payment may or may not include taxes and insurance.</p>
					</div>
					<div id="glossary-popup-4" class="hide tabs-main-content">
						<h3>Private mortgage insurance (PMI)</h3>
						<p>See: <a href="#M_id_6">Mortgage insurance</a></p>
					</div>
					<div id="glossary-popup-5" class="hide tabs-main-content">
						<h3>Loan-to-value ratio (LTV)</h3>
						<p>The ratio between the unpaid principal amount of your loan, or your credit limit in the case of a line of credit, and the appraised value of your collateral. Expressed as a percentage. For example, if you have an $80,000 first mortgage on a property with an appraised value of $100,000, the LTV is 80% ($80,000 / $100,000 = 80%).</p>
					</div>
					<div id="glossary-popup-6" class="hide tabs-main-content">
						<h3>Lender</h3>
						<p>An individual or business entity making a loan.</p>
					</div>
					<div id="glossary-popup-7" class="hide tabs-main-content">
						<h3>Appraisal or appraised value </h3>
						<p>An informed estimate of the value of a property. When made in connection with an application for a loan secured by a home, a professional appraiser usually performs the appraisal.</p>
					</div>
					<div id="glossary-popup-8" class="hide tabs-main-content">
						<h3>Appraiser</h3>
						<p>A person qualified by education, training, and experience to estimate the value of real estate.</p>
					</div>
					<div id="glossary-popup-9" class="hide tabs-main-content">
						<h3>Equity</h3>
						<p>The difference between the fair market value (appraised value) of your home and your outstanding mortgage balances and other liens.</p>
					</div>
					<div id="glossary-popup-10" class="hide tabs-main-content">
						<h3>Combined loan-to-value ratio (CLTV)</h3>
						<p>The ratio between the unpaid principal amount of your first mortgage, plus your credit limit if you have a home equity line of credit, and the appraised value of your home. Expressed as a percentage.</p>
					</div>
					<div id="glossary-popup-11" class="hide tabs-main-content">
						<h3>Lien</h3>
						<p>The legal claim of a creditor on a borrower&rsquo;s property, to be used as security for a debt.</p>
					</div>
					<div id="glossary-popup-12" class="hide tabs-main-content">
						<h3>Principal</h3>
						<p>The amount of money borrowed on a loan.</p>
					</div>
		

	
<script type="text/javascript" src="https://www2.bac-assets.com/pa/global-assets/external/coremetrics/hp/eluminate.js"></script>
<script type="text/javascript" src="https://www2.bac-assets.com/pa/global-assets/external/coremetrics/hp/cmdatatagutils.js"></script>
<script type="text/javascript" src="https://www2.bac-assets.com/pa/components/modules/coremetrics-module/4.0/script/coremetrics-module-hlts-skin.js"></script>
<script type="text/javascript">						
	var productViewTags = false;				
</script>
	
	
	
	
	
	
	
	
	
	
	
	
	
		
<script type="text/javascript">
	
	    	
	function createErrorCode(id)
	{
		errorCode = '';
		e1=id;
		e2=e1.indexOf('|');
		if(e2 != -1)
		{
			splitArray = e1.split('|');
			errorCode = splitArray[0];
			errorCode=errorCode.replace(/\[/g,"");
			return errorCode;
		}
	}
	
	function createErrorMsg(msg)
	{
		errorMessage = '';
		e1=msg;
		e2=e1.indexOf('|');
		if(e2 != -1)
		{
			splitArray = e1.split('|');
			errorMessage = splitArray[1];
			errorMessage=errorMessage.replace(/\]/g,"");
			if (errorMessage.length > 100) 
			{
			     errorMessage = errorMessage.substring(0, 100);
			}
			return errorMessage;
		}
	}
	
	function throwCustomError(errorText) {
	      errorMessage = '';
	      errorCode = '';
	      errorCode = createErrorCode(errorText);
	      errorMessage = createErrorMsg(errorText);
	      cmCreateCustomError('HL:Content:HE:Basics;evaluating-home-equity', null, null, null, errorCode, boaCMdata.convCategoryID, errorMessage);
         }
		
	var boaCMdata = {
		eventID: 'App View to submit LF3a_Mkt_98963',
		eventIdStart:'App View to Start LF3a_Mkt_98963',
		pageID: 'HL:Content:HE:Basics;evaluating-home-equity',
		convCategoryID:'HL:App:Purch',
		productId:'',
		productName:'',
		productCategoryId:''
	};
	
		try{
     	bofaCM('HL:Content:HE:Basics;evaluating-home-equity', 'HL:Content:HE:Basics', 'false', 'false', 'false', 'false', '98963');	
     	}
     	catch(err){}
	

	
</script>


<script type="text/javascript">
var axel = Math.random()+"";var a = axel * 10000000000000;document.write('<iframe title="iFrame used for layout purpose" src="https://fls.doubleclick.net/activityi;src=1359940;type=hliip069;cat=hli_h284;ord=' + a + '?;num='+ a + '?" width="1" height="1" frameborder="0" style="display:none;"></iframe>');
</script>
<noscript>
	<iframe title="iFrame used for layout purpose" src="https://fls.doubleclick.net/activityi;src=1359940;type=hliip069;cat=hli_h284;ord=1?" width="0" height="0" frameborder="0" style="display:none;"></iframe>
</noscript>

</div>
					</div>
				</div>
			</div>
		</div>
	</body>	
</html>

