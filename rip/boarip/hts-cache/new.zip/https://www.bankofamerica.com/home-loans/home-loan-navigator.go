
 

				<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
				<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
				<head>



<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<meta http-equiv="content-type" content="text/html;charset=utf-8" />






			<link rel="canonical" href="https://www.bankofamerica.com/home-loans/home-loan-navigator.go"/>
		
	
	
			<link rel="alternate" media="only screen and (max-width: 640px)" href="https://loans.bankofamerica.com/en/home-mortgages/manage-your-loan.html"/>
			<link rel="alternate" media="handheld" href="https://loans.bankofamerica.com/en/home-mortgages/manage-your-loan.html" />





<title>Home Loan Navigator from Bank of America</title>
<link rel="shortcut icon" href="https://www2.bac-assets.com/pa/global-assets/1.0/graphic/favicon.ico" type="image/ico" />

				<meta name="Keywords" CONTENT="home loan navigator" />
				<meta name="Description" CONTENT="Easily track your mortgage application progress every step of the way with Bank of America's Home Loan Navigator." />
				<meta name="twitter:title" CONTENT="Home Loan Navigator from Bank of America" />
				<meta name="twitter:card" CONTENT="summary" />
				<meta name="twitter:url" CONTENT="https://www.bankofamerica.com/home-loans/home-loan-navigator.go" />
				<meta name="twitter:image" CONTENT="https://www.bankofamerica.com/content/images/ContextualSiteGraphics/Logos/en_US/Bank_of_America_Flagscape_71x71.gif" />
				<meta name="twitter:description" CONTENT="Easily track your mortgage application progress every step of the way with Bank of America's Home Loan Navigator." />
				<meta name="twitter:site" CONTENT="@BofA_Tips" />
				<meta property="og:title" CONTENT="Home Loan Navigator from Bank of America" />
				<meta property="og:type" CONTENT="website" />
				<meta property="og:url" CONTENT="https://www.bankofamerica.com/home-loans/home-loan-navigator.go" />
				<meta property="og:image" CONTENT="https://www.bankofamerica.com/content/images/ContextualSiteGraphics/Logos/en_US/Bank_of_America_Flagscape_71x71.gif" />
				<meta property="og:description" CONTENT="Easily track your mortgage application progress every step of the way with Bank of America's Home Loan Navigator." />
				<meta property="og:site_name" CONTENT="Bank of America" />
	

        <script type="text/javascript">
			var boaTLTargetPage = "/home-loans";
  		</script>
			<script src="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/Global/1.0/script/tealeafbundle.js" type="text/javascript"></script>

	

		<link rel="stylesheet" type="text/css" href="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/APS-home-loans/2017.03.0/style/home-loans-jawr.css" media="all" />
		<link rel="stylesheet" type="text/css" href="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/APS-home-loans/2017.03.0/style/home-loans-jawr-print.css" media="print" />
		<script src="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/APS-home-loans/2017.03.0/script/home-loans-jawr.js" type="text/javascript"></script>	  
	
<script type="text/javascript">
(function() {
	if (typeof mboxUpdate == "function") {
		var windowURL = window.location.href
	    windowURL = windowURL.slice( windowURL.indexOf('.')+1);
		windowURL = windowURL.split( '?' )[0];
		windowURL = windowURL.toLowerCase();
		//alert(windowURL);
		if (
		    //If no mboxes on page, mbox count will be < 1
		    (mboxFactoryDefault.getMboxes().length() < 1) &&  
			
			//Also check for high-volume pages that do not need global logging
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go") &&
			(windowURL != "bankofamerica.com/myaccounts/signin/signin.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/entry/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signonscreen.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatechallengeanswer.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatePassword.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/mobile/banking.go")&&
			(windowURL != "bankofamerica.com/content/preload/olb-myaccount-preload-jawr-module.htm")
			)
		{

			var mboxDiv = document.createElement("div");
			mboxDiv.id = "adobe_touch_clarity_replacement";
			mboxDiv.style.display = "none";
			if (document.body && document.body.firstChild) document.body.insertBefore(mboxDiv,document.body.firstChild);
			mboxDefine(mboxDiv.id,'bac_global_bottom');
			mboxUpdate('bac_global_bottom');
		}
	}	
})();
</script>
         	

			<script>
				var boaPageDataJS = {};
					boaPageDataJS.isLLE = "false";
			</script>
				<style>body{display:none;}</style>
	</head>		

	<body class="fsd-layout-body">	

				<script type="text/javascript">if(self == top){var theBody=document.getElementsByTagName("body")[0];theBody.style.display="block";}else{top.location=self.location;}</script>
				<noscript><style>body{display:block;}</style></noscript>
					<a class='ada-hidden ada-visible-focus' href='#skip-to-h1' id='ada-skip-link'>Skip to main content</a>
		<div class="fsd-layout fsd-2c-700lt-layout">
			<div class="fsd-border">
				<div class="center-content">
					<div class="header">
		  



<script language="javascript" src="/pa/components/modules/tag-manager-module/1.1/script/tag-manager-module-borneo-global-skin.js"></script>
<script>

(function() {
  var fireCallback = function( cb ) {
    if ( typeof cb === "function" ) cb();
  };
  
  function ddoPopulateBase( callback ) {
    try {
		  var DDO = window.digitalData,
		  	bactm_mergeDDO = function( newDDO, priorDDO ) {
		  		if( typeof priorDDO === "undefined" ) {
				  	priorDDO = digitalData || {};
				  }

			    for (var l in newDDO) {
			        if (typeof priorDDO[l] === "undefined") {
			            priorDDO[l] = newDDO[l];
			        }
			        if (newDDO[l] !== null) {
			            if (typeof newDDO[l] === "object") {
			                bactm_mergeDDO(newDDO[l], priorDDO[l]);
			            } else {
			                priorDDO[l] = bactm_validateValue( newDDO[l] ) ? newDDO[l] : priorDDO[l];
			            }
			        }
			    }

			    return priorDDO;
				},
				bactm_olb3rdPartyId = "null";

			if (typeof DDO === "undefined") {
				var simpleDDO = { page: { pageInfo:[{ pageID: null }], attributes: {}, category: { primaryCategory: null }}};

				DDO = (typeof digitalData === "object") ? digitalData : simpleDDO; 
			}

				DDO = bactm_mergeDDO( {pageInstanceID:"notprod",load_coremetrics:true,load_opinionlabs:false,load_touchcommerce:true,load_audiencemanager:true,page:{pageInfo:[{pageID:null,destinationURL:null,referringURL:null,issueDate:null,language:null,segmentValue:null,appName:null,appStepNumber:null,appStepName:null,attr:"-_--_--_--_--_--_--_--_--_--_--_--_--_--_-"}],category:{primaryCategory:null,addlCategory:null,pageType:null},attributes:{searchString:null,searchResults:null,olbSessionID:null,subCampaignCode:null,DARTUrl:null,stateCookie:true,SASIEnabled:false,needOLBcookie:true,standardDART:[],standardDARTes:[],clickDART:[],clickDARTes:[],gaId:[],chat:{account_type:null,boa_associate:null,boa_retiree:null,customer_lob:null,customer_segment:null,data:null,email_campaign:null,entitlement_code:null,error_category:null,error_count:null,first_login:null,inqSalesProductTypes:{},invitation_background:null,invitation_template:null,referral_campaign:null,getStateValue:false,cust_fn:null,cust_ln:null,target:null}}},user:{segment:null,online_id:null,preferred_rewards_tier:null,olb3rdpartyid:null},version:"BAC_0.12"}, DDO );

			DDO.page.pageInfo[0].pageID = "HL:Content:Service;home_loan_navigator";
			DDO.page.category.primaryCategory  = "HL:Content:Service";
			DDO.page.pageInfo[0].language = "en-US";
			DDO.page.attributes.olbSessionID = "null";
			DDO.page.attributes.SASIEnabled =  "false";
			if (typeof DDO.user != "undefined" && typeof DDO.user.olb3rdpartyid != "undefined") {
				DDO.user.olb3rdpartyid = bactm_olb3rdPartyId;
			}

			window.utag_data = {};
			window.bactm_envSelector = bactm_setTMLib();
			window.digitalData = DDO;

      return fireCallback( callback );

    } catch(e) { }
  }
	if( window.boa && window.boa.digitalData ) {
    window.boa.digitalData.register( ddoPopulateBase );
	}
	else {
	  // Handle scenario where the header isn't available (and thus the default digitalData object and utag loader are missing).
	  //
		var writeScript = function(a,b,c,d){
			a='//tags.tiqcdn.com/utag/bofa/main/' + bactm_envSelector + '/utag.js';
			b=document;
			c='script';
			d=b.createElement(c);
			d.src=a;
			d.type='text/java'+c;
			d.async=true;
			a=b.getElementsByTagName(c)[0];
			a.parentNode.insertBefore(d,a);
		};

		ddoPopulateBase( writeScript );
	}
})();			
</script>

	<div class="mboxDefault"></div>	
				<script type="text/javascript">
					mboxCreate("bac_mort_global_top");
				</script>





 


	 
<div class="header-module">
	<div class="home-loans-skin">
		<div class="header-left">
	  
			<div itemscope itemtype="http://schema.org/Corporation" class="bofa-logo">
				<a itemprop="url" name="anc-home-loans" title="Bank of America" href="/">
					<img itemprop="logo" height="28" width="221" alt="Bank of America" src="/content/images/ContextualSiteGraphics/Logos/en_US/boa_logo.gif" />
				</a>
			</div>
				<div class="product">Home Loans</div>
			<div class="clearboth"></div>
		</div>
	   	<div class="header-right">
			<ul class="header-links">
						<li class="sign-in"> 
							<a href="/hub/index.action?template=signin" title="Sign In" name="Sign_In_global_nav" target="_self">Sign In</a> 
						</li>
						<li> 
							<a href="/" title="Home" name="Home_Page_global_nav" target="_self">Home</a> 
						</li>
						<li> 
							<a href="http://www.bankofamerica.com/findit/locator.cfm" title="Locations" name="Locations_Link_global_nav" target="_self">Locations</a> 
						</li>
						<li> 
							<a href="/contactus/contactus.go?topicId=mrtg_home_equity" title="Contact Us" name="Contact_Us_global_nav" target="_self">Contact Us</a> 
						</li>
						<li> 
							<a href="/home-loans/faq-mortgage-refi.go" title="help" name="help_global_nav" target="_self">Help</a> 
						</li>
						<li class="last-link">
									<a href="/home-loans/home-loan-navigator.go?request_locale=es_US"  title="En Espa&#241;ol" name="SpanishHLTS_global_nav" target="_self">En Espa&#241;ol</a> 				
						</li>
		  	</ul>
		  	<div class="clearboth"></div>

		  	<!-- include search-dotcom-util -->



<div class="header-search nlh">
  
  <div class="nav-search">
    <form class="search-form" action="https://secure.bankofamerica.com/myaccounts/public/search-results/unAuthenticatedSearch.go" data-js="/pa/components/utilities/search-util/1.0/script/nav-search.min.js" data-css="/pa/components/utilities/search-util/1.0/style/nav-search.css" data-text-unavailable="Search Currently Unavailable">
      <div class="search-input-container cf" data-icon="search">
        <label for="nav-search-query" class="ada-hidden">Search Term</label>
        <input type="text" placeholder="How can we help you?" name="query" class="search-query" id="nav-search-query" 
          maxlength="99" rel="Search" autocomplete="off"><input type="submit" alt="Search" title="Search" value="Submit Search" name="Search Module - Top Result – Search Button" class="submit track-me">
      </div>
    </form>
  </div>

</div>
	
	   	</div>
   		<div class="clearboth"></div>
	</div>
</div>







<div class="hl-navigation-module">
	<div class="fsd-skin sup-ie css3-pie">
		<ul class="nav-list">
				
									
					<li>
					<a name="rates-and-calculators_topnav" id="Rates & Calculators" href="/mortgage/" class="top-menu-item ">Rates & Calculators <span class="ada-hidden">link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>	
		
						 <div class="sub-nav-box">
								<div class="sub-nav-left">
						<div class="hasSub">
												<a name="todays-home-loan-rates_topnav" target="_self" href="/mortgage/">Today's Home Loan Rates</a>
												<a name="mortgage-calculator_topnav" target="_self" href="/home-loans/mortgage/mortgage-payment-calculator.go">Mortgage Calculator</a>
												<a name="refinance-rate-calculator_topnav" target="_self" href="/home-loans/refinance/custom-refinance-rates-today.go">Refinance Rate Calculator</a>
												<a name="home-equity-calculator_topnav" target="_self" href="/home-loans/home-equity/home-equity-loan-payment-calculator.go">Home Equity Calculator</a>
												<a name="closing-cost-calculator_topnav" target="_self" href="/home-loans/mortgage/closing-costs-calculator.go">Closing Cost Calculator</a>
						</div>
										<span class="ada-hidden">End of submenu</span>
									</div>
								</div>
							</li>
				
									
					<li>
					<a name="mortgage-link_topnav" id="Mortgage" href="/home-loans/mortgage/overview.go" class="top-menu-item ">Mortgage <span class="ada-hidden">link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>	
		
						 <div class="sub-nav-box">
								<div class="sub-nav-left">
						<div class="hasSub">
												<a name="todays-mortgage-rates_topnav" target="_self" href="/mortgage/mortgage-rates/">Today's Mortgage Rates</a>
												<a name="mortgage-calculator_topnav" target="_self" href="/home-loans/mortgage/mortgage-payment-calculator.go">Mortgage Calculator</a>
												<a name="closing-cost-calculator_topnav" target="_self" href="/home-loans/mortgage/closing-costs-calculator.go">Closing Cost Calculator</a>
												<div class="dot-border" tabindex="-1"></div>
												<a name="fixed-rate-mortgage_topnav" target="_self" href="/mortgage/fixed-rate-mortgage-loans/">Fixed-Rate Mortgage</a>
												<a name="adjustable-rate-mortgage_topnav" target="_self" href="/mortgage/adjustable-rate-mortgage-loans/">Adjustable-Rate Mortgage</a>
												<a name="jumbo-loan_topnav" target="_self" href="/mortgage/jumbo-loans/">Jumbo Loan</a>
												<a name="affordable-loan-solution _topnav" target="_self" href="/mortgage/affordable-loan-solution-mortgage/">Affordable Loan Solution </a>
												<a name="fha-and-va-loans_topnav" target="_self" href="/mortgage/fha-va-mortgage-loans/">FHA &amp; VA Loans</a>
						</div>
				
		
						<div class="hasSub">
												<span>Help When You Need It</span>
												<a name="first-time-homebuyer-tips_topnav" target="_self" href="/home-loans/mortgage/first-time-home-buyer.go">First-Time Homebuyer Tips</a>
												<a name="budgeting-for-a-home_topnav" target="_self" href="/home-loans/mortgage/budgeting-for-home.go">Budgeting for a Home</a>
												<a name="affordable-housing-assistance-programs_topnav" target="_self" href="/home-loans/mortgage/affordable-housing-programs.go">Affordable Housing Assistance Programs</a>
												<a name="find-a-house_topnav" target="_self" href="http://realestatecenter.bankofamerica.com/">Find a House</a>
						</div>
										<span class="ada-hidden">End of submenu</span>
									</div>
								</div>
							</li>
				
									
					<li>
					<a name="refinance-link_topnav" id="Refinance" href="/home-loans/refinance/overview.go" class="top-menu-item ">Refinance <span class="ada-hidden">link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>	
		
						 <div class="sub-nav-box">
								<div class="sub-nav-left">
						<div class="hasSub">
												<a name="todays-refinance-rates_topnav" target="_self" href="/mortgage/refinance-rates/">Today's Refinance Rates </a>
												<a name="refinance-calculator_topnav" target="_self" href="/home-loans/refinance/custom-refinance-rates-today.go">Refinance Calculator</a>
												<a name="home-value-estimator _topnav" target="_self" href="http://realestatecenter.bankofamerica.com/tools/marketvalue4.aspx">Home Value Estimator </a>
												<div class="dot-border" tabindex="-1"></div>
												<a name="fixed-rate-refinance-loans_topnav" target="_self" href="/mortgage/fixed-rate-refinance-loans/">Fixed-Rate Refinance Loans</a>
												<a name="adjustable-rate-refinance-loans_topnav" target="_self" href="/mortgage/adjustable-rate-refinance-loans/ ">Adjustable-Rate Refinance Loans</a>
												<a name="fha-and-va-refinance-loans_topnav" target="_self" href="/home-loans/refinance/fha-va-refinance.go">FHA &amp; VA Refinance Loans</a>
						</div>
				
		
						<div class="hasSub">
												<span>Help When You Need It</span>
												<a name="cash-out-refinance-info_topnav" target="_self" href="/home-loans/refinance/reasons-to-refinance/cash-out-refinance-loan.go">Cash-Out Refinance Info</a>
												<a name="reasons-to-refinance_topnav" target="_self" href="/home-loans/refinance/should-refinance-mortgage.go">Reasons to Refinance</a>
						</div>
										<span class="ada-hidden">End of submenu</span>
									</div>
								</div>
							</li>
				
									
					<li>
					<a name="home-equity_topnav" id="Home Equity" href="/home-loans/home-equity-loans/overview.go" class="top-menu-item ">Home Equity <span class="ada-hidden">link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>	
		
						 <div class="sub-nav-box">
								<div class="sub-nav-left">
						<div class="hasSub">
												<a name="home-equity-line-of-credit-rates_topnav" target="_self" href="/home-equity/home-equity-rates/">Home Equity Line of Credit Rates</a>
												<a name="fixed-rate-loan-option_topnav" target="_self" href="/home-equity/fixed-rate-loan/">Fixed-Rate Loan Option </a>
												<a name="home-equity-calculator_topnav" target="_self" href="/home-loans/home-equity/home-equity-loan-payment-calculator.go">Home Equity Calculator</a>
												<a name="home-value-estimator_topnav" target="_self" href="http://realestatecenter.bankofamerica.com/tools/marketvalue4.aspx">Home Value Estimator</a>
						</div>
				
		
						<div class="hasSub">
												<span>Help When You Need It</span>
												<a name="what-is-a-home-equity-line-of-credit_topnav" target="_self" href="/home-loans/home-equity/what-is-a-home-equity-line-of-credit.go">What Is a Home Equity Line of Credit? </a>
												<a name="evaluating-your-homes-equity_topnav" target="_self" href="/home-loans/home-equity/evaluating-home-equity.go">Evaluating Your Home's Equity</a>
												<a name="understanding-your-debt-to-income-ratio_topnav" target="_self" href="/home-loans/home-equity/owe-vs-make.go">Understanding Your Debt-to-Income Ratio</a>
												<a name="home-equity-or-cash-out-refinance_topnav" target="_self" href="/home-loans/home-equity/cash-out-refinance.go">Home Equity or Cash-out Refinance?</a>
						</div>
										<span class="ada-hidden">End of submenu</span>
									</div>
								</div>
							</li>
				
									
					<li>
					<a name="learn-about-home-loans_topnav" id="Learn About Home Loans" href="/home-loans/home-loan-guide.go" class="top-menu-item ">Learn About Home Loans <span class="ada-hidden">link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>	
		
						 <div class="sub-nav-box">
								<div class="sub-nav-left">
						<div class="hasSub">
												<a name="learn-about-home-buying_topnav" target="_self" href="/home-loans/mortgage/budgeting-for-home.go ">Learn About Home Buying </a>
												<a name="learn-about-refinancing_topnav" target="_self" href="/home-loans/refinance/should-refinance-mortgage.go">Learn About Refinancing</a>
												<a name="learn-about-home-equity_topnav" target="_self" href="/home-loans/home-equity/basics.go">Learn About Home Equity</a>
												<div class="dot-border" tabindex="-1"></div>
												<a name="home-loan-checklist_topnav" target="_self" href="/content/documents/mortgage/HomeLoanChecklist.pdf">Home Loan Checklist</a>
												<a name="faqs-link_topnav" target="_self" href="/home-loans/faq-mortgage-refi.go">FAQs</a>
												<a name="glossary-link_topnav" target="_self" href="/home-loans/glossary.go ">Glossary</a>
						</div>
										<span class="ada-hidden">End of submenu</span>
									</div>
								</div>
							</li>
				
									
					<li>
					<a name="manage-your-loan_topnav" id="Manage Your Loan" href="/home-loans/service.go" class="top-menu-item ">Manage Your Loan <span class="ada-hidden">link</span></a>	
		
							</li>
		</ul>
	</div>
</div>


<div class="page-title-fsd-module h-100" id="skip-to-h1">
	<div class="standard-red-skin sup-ie">
			<h1 data-font="cnx-regular">Home Loan Navigator</h1>
	</div>
</div>


 

	<style type="text/css">
		#hl-engagement-module-navigator-skin { background:url('/content/images/ContextualSiteGraphics/Instructional/en_US/HL_Nav_Photo.png') no-repeat; background-size:cover;}
	</style>
	
	
	<script type="text/javascript">				
		$(document).ready(function(){
		boaEqualHeight($('.gray-box'))
			});
	</script>
		
		
	
	<div id="hl-engagement-module-navigator-skin">
   		<div class="content-container">
						<div class="gray-box">
							<div class="content">
								<h2 data-font="cnx-regular">Track your loan</h2>
									 <p data-font="cnx-regular">Keep up to date on the status of your mortgage application. View your To-Do List and complete outstanding tasks.</p>

							</div>
							
						</div>
						<div class="gray-box middle">
							<div class="content">
								<h2 data-font="cnx-regular">Manage your documents</h2>
									 <p data-font="cnx-regular">Sign and submit documents electronically-it's fast, easy and secure. Also receive important documents and disclosures online.</p>

							</div>
							
						</div>
						<div class="gray-box">
							<div class="content">
								<h2 data-font="cnx-regular">Get started</h2>
									 <p data-font="cnx-regular"><a href="https://secure.bankofamerica.com/login/enroll/entry/olbEnroll.go" name="anc_enroll_now">Enroll now</a> in Online Banking to start using the Home Loan Navigator&trade;.</p>

									 <p data-font="cnx-regular">Already enrolled in Online Banking?</p>
									<a data-font="cnx-regular" name="anc-access-your-loan" href="https://secure.bankofamerica.com/login/sign-in/signOnV2Screen.go" class="btn-bofa btn-bofa-blue btn-bofa-large ">Access your loan</a>
							</div>
							
						</div>
	   	</div>
	</div>	


<div class="hl-banner-module">
	  <div class="center-img-skin">
			<h2 data-font="cnx-regular">See how easily you can track your mortgage application, and more</h2>
			<p data-font="cnx-regular">The Home Loan Navigator, along with your lending specialist, will help you know where your loan stands every step of the way. <br />The Home Loan Navigator is not currently available on certain loan types.<a href="#footnote1" name="footnote 1"><span class="ada-hidden">Footnote</span><sup>1</sup></a><br /><br />Note: The screen shot below does not contain real customer information and is for illustrative purposes only.<br /><br /><a href="/onlinebanking/education/home-loan-navigator.go" target="_self">Watch the video to learn more about the Home Loan Navigator</a> </p>
			<div id="centerimg" class="img">
			<img src="/content/images/ContextualSiteGraphics/Instructional/en_US/HL_Nav_Screenshot_new.png" alt="Home loans Navigator image" />
			</div>
		</div>
 	</div>
</div>
					<div class="columns">
						<div class="flex-col lt-col" ></div>
						<div class="flex-col rt-col" ></div>
						<div class="clearboth"></div>
					</div>
					<div class="footer">
						<div class="footer-top">&nbsp;</div>
						<div class="footer-inner">

<div class="footnote-com-module">
   <div class="fsd-layout-skin sup-ie">
   
   <script>
		$(function() {
			if ($('.footnote-com-module .fsd-layout-skin').text().length > 10) {
				$('.footnote-com-module .fsd-layout-skin').addClass('wfootnote');
			}
		});
	</script>
   
					<div class="h-100">
						<div class="footnote" id="footnote1">
							<div class="fn-num">1.</div>
							<div class="fn-text">The Home Loan Navigator is not currently available on certain loan types. Please contact a&nbsp;lending specialist for more information or to assist with questions about the status of your loan. Home Loan Navigator is a trademark of Bank of America Corporation. </div>
							<div class="clearboth"></div>
						</div>
					</div>
   </div>
</div>




 



		<div class="global-footer-module">
			<div class="fsd-skin">

				<div class="footer-bottom-left" style="float:left;max-width:66%;">
	    			<div class="gf-links">	          	
						
					
									
									<a  target="_self" href="/" 
									    name="Home_Page">Home
									</a>
									
						
					
									
									<a  target="_self" href="/privacy/overview.go" 
									    name="Privacy_Security">Privacy & Security
									</a>
									
						
					
									
									<a  target="_self" href="http://www.bankofamerica.com/careers/" 
									    name="Careers_Link">Careers
									</a>
									
						
					
									
									<a  target="_self" href="/sitemap/personal.go" 
									    name="Site_Map">Site Map
									</a>
									
						
					
									<a href="javascript:void(0);" class="gf-last-link boa-dialog boa-com-info-layer-link" name="global_footer_ad_practices_lnk" rel="global_footer_ad_practices">Advertising Practices</a>
								<div id="global_footer_ad_practices" class="hide">
									<h3>Advertising Practices</h3>
										<p>We strive to provide you with information about products and services you might find interesting and useful. Relationship-based ads and online behavioral advertising help us do that.</p>
<p>Here's how it works: We gather information about your online activities, such as the searches you conduct on our Sites and the pages you visit. This information may be used to deliver advertising on our Sites and offline (for example, by phone, email and direct mail) that's customized to meet specific interests you may have.</p>
<p>If you prefer that we do not use this information, you may <a onclick="$('.ui-dialog').remove();" name="WebsiteAdPractices_OptOut" href="/privacy/online-privacy-notice.go#advertising-on-our-sites" target="_blank">opt out of online behavioral advertising</a>. If you opt out, though, you may still receive generic advertising. In addition, financial advisors/Client Managers may continue to use information collected online to provide product and service information in accordance with account agreements.</p>
<p>Also, if you opt out of online behavioral advertising, you may still see ads when you sign in to your account, for example through Online Banking or MyMerrill. These ads are based on your specific account relationships with us.</p>
<p>To learn more about relationship-based ads, online behavioral advertising and our privacy practices, please review the <a onclick="$('.ui-dialog').remove();" name="WebsiteAdPractices_PrivacyNotice" href="/privacy/online-privacy-notice.go" target="_blank">Bank of America Online Privacy Notice</a> and our <a onclick="$('.ui-dialog').remove();" name="Online-privacy-faqs" href="/privacy/faq/online-privacy-faq.go" target="_blank">Online Privacy FAQs</a>.</p>
								</div>
						<div class="clearboth"></div>
	    			</div>
	      			<p>Bank of America, N.A. Member FDIC. <a title=" Equal Housing Lender information. Link opens new window." onclick="window.open('/help/equalhousing_popup.go','newwin','width=640,height=371,scrollbars=yes,resizable=yes,left=35,top=161'); return false;" name="Equal_Housing_Lender" href="/help/equalhousing_popup.go" target="_blank">Equal Housing Lender<img src="https://www2.bac-assets.com/content/images/ContextualSiteGraphics/Logos/en_US/icon_equal_housing_lender.gif" alt="" width="14" height="9" /></a><br />&copy; 2017 Bank of America Corporation. All rights reserved. Credit and collateral are subject to approval. Terms and conditions apply. This is not a commitment to lend. Programs, rates, terms and conditions are subject to change without notice.</p>
         		</div>
         		<div class="footer-social-container" style="float:right;max-width:30%;padding-left:50px;padding-top:19px;">




<div class="boa-social-loader" data-loaded="false" data-platform="borneo"  data-options=''></div>

         		</div>
         		<div class="clearboth"></div>
  			</div>
		</div>

			<div itemscope="itemscope" itemtype="http://schema.org/WebPage">
					<span style="display:none" itemprop="name">Home Loan Navigator from Bank of America</span>
					<a style="display:none" itemprop="url" href="https://www.bankofamerica.com/home-loans/home-loan-navigator.go "></a>
					<span style="display:none" itemprop="description">Easily track your mortgage application progress every step of the way with Bank of America's Home Loan Navigator. </span>
					<img style="display:none" class="no-stretch" itemprop="image" alt="Home Loan Navigator from Bank of America" src="https://www.bankofamerica.com/content/images/ContextualSiteGraphics/Logos/en_US/Bank_of_America_Flagscape_71x71.gif">
					<span style="display:none" itemprop="keywords">home loan navigator</span>
			</div>

<script type="text/javascript">
var axel = Math.random()+"";var a = axel * 10000000000000;document.write('<iframe title="iFrame used for layout purpose" src="https://fls.doubleclick.net/activityi;src=1359940;type=hliip069;cat=hli_h718;ord=1;num=' + a + '?;num='+ a + '?" width="1" height="1" frameborder="0" style="display:none;"></iframe>');
</script>
<noscript>
	<iframe title="iFrame used for layout purpose" src="https://fls.doubleclick.net/activityi;src=1359940;type=hliip069;cat=hli_h718;ord=1;num=1?" width="0" height="0" frameborder="0" style="display:none;"></iframe>
</noscript>




 




<div class="modal-content-bdf-module hide" id="cardEligibilityModal">
   <div class="flex-col-skin">
       <h3>Card eligibility guidelines</h3>
       			<p>Most Bank of America<sup>&reg;</sup> branded consumer credit cards (such as the <strong>BankAmericard Cash Rewards&trade; credit card </strong>and the <strong>BankAmericard Travel Rewards<sup>&reg;</sup> credit card</strong>) are eligible to receive the credit card rewards bonus. Listed below are the card types and programs that are <strong><span style="text-decoration: underline;">not</span></strong> eligible to receive the credit card rewards bonus. To receive the credit card rewards bonus, your eligible card account must be open and in good standing, as defined by the account Reward Program Rules.</p>
	       		<div class="column-box">
	           		<div class="column">
	               		<UL class=gray-sq-bullet>
<LI>Non-rewards credit cards</LI>
<LI>Business purpose credit cards</LI>
<LI>BankAmericard Privileges<SUP>�</SUP> (except Cash Rewards customers in the Platinum Honors tier)</LI>
<LI>Bank of America Accolades<SUP>�</SUP> </LI>
<LI>BankAmericard<SUP>�</SUP> Better Balance Rewards?</LI>
<LI>Merrill Lynch&nbsp;branded (including Merrill Accolades<SUP>�</SUP>, MERRILL+<SUP>�</SUP>, Total Merrill<SUP>�</SUP> Cash Back, Total Merrill Match<SUP>�</SUP> and Merrill Lynch<SUP>�</SUP> Octave?)</LI>
<LI>U.S. Trust branded (including Bank of America Accolades and U.S. Trust<SUP>�</SUP> Octave?)</LI></UL>
	           		</div>
	           		<div class="column">
	               		<ul class="gray-sq-bullet">
<li>AAA Dollars<sup>&reg;</sup> Visa credit card</li>
<li>AAA<sup>&reg;</sup> Gas Rebate</li>
<li>Alaska Airlines<sup>&reg;</sup></li>
<li>Amway&trade;</li>
<li>Asiana Airlines<sup>&reg;</sup></li>
<li>Azamara Club Cruises<sup>&reg;</sup></li>
<li>Bass Pro Shops<sup>&reg;</sup></li>
<li>Celebrity Cruises<sup>&reg;</sup></li>
<li>Elite Rewards<sup>&reg;</sup></li>
<li>Melaleuca<sup>SM</sup></li>
<li>Perks Advantage<sup>&reg;</sup></li>
<li>Royal Caribbean International<sup>&reg;</sup></li>
<li>Spirit Airlines<sup>&reg;</sup></li>
<li>US Airways<sup>&reg;</sup></li>
<li>Virgin Atlantic Airways<sup>&reg;</sup></li>
</ul>
	           		</div>
	       		</div>
       			<p>This list is subject to change without prior notice.</p>
   </div>
</div>
</div>
					</div>
				</div>
			</div>
		</div>
	</body>	
</html>

