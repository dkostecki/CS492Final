
 

				<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
				<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
				<head>



<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<meta http-equiv="content-type" content="text/html;charset=utf-8" />






		
	
	





<title>Mortgage Calculator with Monthly Payments from Bank of America</title>
<link rel="shortcut icon" href="https://www2.bac-assets.com/pa/global-assets/1.0/graphic/favicon.ico" type="image/ico" />

				<meta name="Keywords" CONTENT="mortgage payment calculator, monthly mortgage payment calculator, monthly mortgage calculator, calculate mortgage payment, mortgage calculator" />
				<meta name="Description" CONTENT="Calculate estimated rate and monthly payment options with our easy-to-use mortgage calculator." />
				<meta name="twitter:title" CONTENT="Mortgage Calculator with Monthly Payments from Bank of America" />
				<meta name="twitter:card" CONTENT="summary" />
				<meta name="twitter:url" CONTENT="https://www.bankofamerica.com/home-loans/mortgage/mortgage-payment-calculator.go" />
				<meta name="twitter:image" CONTENT="https://www.bankofamerica.com/content/images/ContextualSiteGraphics/Logos/en_US/Bank_of_America_Flagscape_71x71.gif" />
				<meta name="twitter:description" CONTENT="Calculate estimated rate and monthly payment options with our easy-to-use mortgage calculator." />
				<meta name="twitter:site" CONTENT="@BofA_Tips" />
				<meta property="og:title" CONTENT="Mortgage Calculator with Monthly Payments from Bank of America" />
				<meta property="og:type" CONTENT="website" />
				<meta property="og:url" CONTENT="https://www.bankofamerica.com/home-loans/mortgage/mortgage-payment-calculator.go" />
				<meta property="og:image" CONTENT="https://www.bankofamerica.com/content/images/ContextualSiteGraphics/Logos/en_US/Bank_of_America_Flagscape_71x71.gif" />
				<meta property="og:description" CONTENT="Calculate estimated rate and monthly payment options with our easy-to-use mortgage calculator." />
				<meta property="og:site_name" CONTENT="Bank of America" />
        <link REL="canonical" HREF="https://www.bankofamerica.com/home-loans/mortgage/mortgage-payment-calculator.go"/>                  
	

        <script type="text/javascript">
			var boaTLTargetPage = "/home-loans";
  		</script>
			<script src="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/Global/1.0/script/tealeafbundle.js" type="text/javascript"></script>

	
   
		<link rel="stylesheet" type="text/css" href="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/APS-home-loans/2017.03.0/style/home-loans-mort-jawr.css" media="all" />
		<link rel="stylesheet" type="text/css" href="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/APS-home-loans/2017.03.0/style/home-loans-mort-jawr-print.css" media="print" />
		<script src="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/APS-home-loans/2017.03.0/script/home-loans-mort-jawr.js" type="text/javascript"></script>	  
	
			<script src="https://www2.bac-assets.com/pa/components/modules/cta-module/2.1/script/cta-module-topnav-floating-skin.js" type="text/javascript"></script>
			<script src="https://www2.bac-assets.com/pa/components/modules/cta-module/2.1/script/cta-module.js" type="text/javascript"></script>
				<link href="https://www2.bac-assets.com/pa/components/modules/cta-module/2.1/style/cta-module-topnav-floating-skin.css" rel="stylesheet" type="text/css" />
				<link href="https://www2.bac-assets.com/pa/components/modules/cta-module/2.1/style/cta-module.css" rel="stylesheet" type="text/css" />
<script type="text/javascript">
(function() {
	if (typeof mboxUpdate == "function") {
		var windowURL = window.location.href
	    windowURL = windowURL.slice( windowURL.indexOf('.')+1);
		windowURL = windowURL.split( '?' )[0];
		windowURL = windowURL.toLowerCase();
		//alert(windowURL);
		if (
		    //If no mboxes on page, mbox count will be < 1
		    (mboxFactoryDefault.getMboxes().length() < 1) &&  
			
			//Also check for high-volume pages that do not need global logging
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go") &&
			(windowURL != "bankofamerica.com/myaccounts/signin/signin.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/entry/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signonscreen.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatechallengeanswer.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatePassword.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/mobile/banking.go")&&
			(windowURL != "bankofamerica.com/content/preload/olb-myaccount-preload-jawr-module.htm")
			)
		{

			var mboxDiv = document.createElement("div");
			mboxDiv.id = "adobe_touch_clarity_replacement";
			mboxDiv.style.display = "none";
			if (document.body && document.body.firstChild) document.body.insertBefore(mboxDiv,document.body.firstChild);
			mboxDefine(mboxDiv.id,'bac_global_bottom');
			mboxUpdate('bac_global_bottom');
		}
	}	
})();
</script>
         	

			<script>
				var boaPageDataJS = {};
					boaPageDataJS.isLLE = "false";
			</script>
				<style>body{display:none;}</style>
	</head>		

	<body class="fsd-layout-body">	

				<script type="text/javascript">if(self == top){var theBody=document.getElementsByTagName("body")[0];theBody.style.display="block";}else{top.location=self.location;}</script>
				<noscript><style>body{display:block;}</style></noscript>
					<a class='ada-hidden ada-visible-focus' href='#skip-to-h1' id='ada-skip-link'>Skip to main content</a>
		<div class="fsd-layout fsd-2c-700lt-layout">
			<div class="fsd-border">
				<div class="center-content">
					<div class="header">
		  



<script language="javascript" src="/pa/components/modules/tag-manager-module/1.1/script/tag-manager-module-borneo-global-skin.js"></script>
<script>

(function() {
  var fireCallback = function( cb ) {
    if ( typeof cb === "function" ) cb();
  };
  
  function ddoPopulateBase( callback ) {
    try {
		  var DDO = window.digitalData,
		  	bactm_mergeDDO = function( newDDO, priorDDO ) {
		  		if( typeof priorDDO === "undefined" ) {
				  	priorDDO = digitalData || {};
				  }

			    for (var l in newDDO) {
			        if (typeof priorDDO[l] === "undefined") {
			            priorDDO[l] = newDDO[l];
			        }
			        if (newDDO[l] !== null) {
			            if (typeof newDDO[l] === "object") {
			                bactm_mergeDDO(newDDO[l], priorDDO[l]);
			            } else {
			                priorDDO[l] = bactm_validateValue( newDDO[l] ) ? newDDO[l] : priorDDO[l];
			            }
			        }
			    }

			    return priorDDO;
				},
				bactm_olb3rdPartyId = "null";

			if (typeof DDO === "undefined") {
				var simpleDDO = { page: { pageInfo:[{ pageID: null }], attributes: {}, category: { primaryCategory: null }}};

				DDO = (typeof digitalData === "object") ? digitalData : simpleDDO; 
			}

				DDO = bactm_mergeDDO( {pageInstanceID:"notprod",load_coremetrics:false,load_opinionlabs:false,load_touchcommerce:true,load_audiencemanager:true,page:{pageInfo:[{pageID:null,destinationURL:null,referringURL:null,issueDate:null,language:null,segmentValue:null,appName:null,appStepNumber:null,appStepName:null,attr:"-_--_--_--_--_--_--_--_--_--_--_--_--_--_-"}],category:{primaryCategory:null,addlCategory:null,pageType:null},attributes:{searchString:null,searchResults:null,olbSessionID:null,subCampaignCode:null,DARTUrl:null,stateCookie:null,SASIEnabled:false,needOLBcookie:false,standardDART:[],standardDARTes:[],clickDART:[],clickDARTes:[],gaId:[],chat:{site_id:36532872,target:{"lpButtonDiv-Target-HomeLoans-SideWell":"Consumer-OASHL"},account_type:"Mortgage",customer_lob:"co"}}},user:{segment:null,online_id:null,preferred_rewards_tier:null,olb3rdpartyid:null},version:"BAC_0.12"}, DDO );

			DDO.page.pageInfo[0].pageID = "HL:Tool:Purch:Calc;mortgage-payment-calculator";
			DDO.page.category.primaryCategory  = "HL:Tool:Purch:Calc";
			DDO.page.pageInfo[0].language = "en-US";
			DDO.page.attributes.olbSessionID = "null";
			DDO.page.attributes.SASIEnabled =  "false";
			if (typeof DDO.user != "undefined" && typeof DDO.user.olb3rdpartyid != "undefined") {
				DDO.user.olb3rdpartyid = bactm_olb3rdPartyId;
			}

			window.utag_data = {};
			window.bactm_envSelector = bactm_setTMLib();
			window.digitalData = DDO;

      return fireCallback( callback );

    } catch(e) { }
  }
	if( window.boa && window.boa.digitalData ) {
    window.boa.digitalData.register( ddoPopulateBase );
	}
	else {
	  // Handle scenario where the header isn't available (and thus the default digitalData object and utag loader are missing).
	  //
		var writeScript = function(a,b,c,d){
			a='//tags.tiqcdn.com/utag/bofa/main/' + bactm_envSelector + '/utag.js';
			b=document;
			c='script';
			d=b.createElement(c);
			d.src=a;
			d.type='text/java'+c;
			d.async=true;
			a=b.getElementsByTagName(c)[0];
			a.parentNode.insertBefore(d,a);
		};

		ddoPopulateBase( writeScript );
	}
})();			
</script>




 


	 
<div class="header-module">
	<div class="home-loans-skin">
		<div class="header-left">
	  
			<div itemscope itemtype="http://schema.org/Corporation" class="bofa-logo">
				<a itemprop="url" name="anc-home-loans" title="Bank of America" href="/">
					<img itemprop="logo" height="28" width="221" alt="Bank of America" src="/content/images/ContextualSiteGraphics/Logos/en_US/boa_logo.gif" />
				</a>
			</div>
				<div class="product">Home Loans</div>
			<div class="clearboth"></div>
		</div>
	   	<div class="header-right">
			<ul class="header-links">
						<li class="sign-in"> 
							<a href="https://www.bankofamerica.com/hub/index.action?template=signin" title="Sign In" name="Sign_In_global_nav" target="_self">Sign In</a> 
						</li>
						<li> 
							<a href="/" title="Home" name="Home_Page_global_nav" target="_self">Home</a> 
						</li>
						<li> 
							<a href="https://locators.bankofamerica.com " title="Locations" name="Locations_Link_global_nav" target="_self">Locations</a> 
						</li>
						<li> 
							<a href="/contactus/contactus.go?topicId=mrtg_home_equity" title="Contact Us" name="Contact_Us_global_nav" target="_self">Contact Us</a> 
						</li>
						<li> 
							<a href="/home-loans/faq-mortgage-refi.go" title="help" name="help_global_nav" target="_self">Help</a> 
						</li>
						<li class="last-link">
									<a href="/home-loans/mortgage/mortgage-payment-calculator.go?request_locale=es_US"  title="En Espa&#241;ol" name="SpanishHLTS_global_nav" target="_self">En Espa&#241;ol</a> 				
						</li>
		  	</ul>
		  	<div class="clearboth"></div>

		  	<!-- include search-dotcom-util -->



<div class="header-search nlh">
  
  <div class="nav-search">
    <form class="search-form" action="https://secure.bankofamerica.com/myaccounts/public/search-results/unAuthenticatedSearch.go" data-js="/pa/components/utilities/search-util/1.0/script/nav-search.min.js" data-css="/pa/components/utilities/search-util/1.0/style/nav-search.css" data-text-unavailable="Search Currently Unavailable">
      <div class="search-input-container cf" data-icon="search">
        <label for="nav-search-query" class="ada-hidden">Search Term</label>
        <input type="text" placeholder="How can we help you?" name="query" class="search-query" id="nav-search-query" 
          maxlength="99" rel="Search" autocomplete="off"><input type="submit" alt="Search" title="Search" value="Submit Search" name="Search Module - Top Result – Search Button" class="submit track-me">
      </div>
    </form>
  </div>

</div>
	
	   	</div>
   		<div class="clearboth"></div>
	</div>
</div>






<div class="hl-navigation-module">
	<div class="fsd-skin sup-ie css3-pie">
		<ul class="nav-list">
				
									
					<li>
					<a name="rates-and-calculators_topnav" id="Rates & Calculators" href="/mortgage/" class="top-menu-item ">Rates & Calculators <span class="ada-hidden">link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>	
		
						 <div class="sub-nav-box">
								<div class="sub-nav-left">
						<div class="hasSub">
												<a name="todays-home-loan-rates_topnav" target="_self" href="/mortgage/">Today's Home Loan Rates</a>
												<a name="mortgage-calculator_topnav" target="_self" href="/home-loans/mortgage/mortgage-payment-calculator.go">Mortgage Calculator</a>
												<a name="refinance-rate-calculator_topnav" target="_self" href="/home-loans/refinance/custom-refinance-rates-today.go">Refinance Rate Calculator</a>
												<a name="home-equity-calculator_topnav" target="_self" href="/home-loans/home-equity/home-equity-loan-payment-calculator.go">Home Equity Calculator</a>
												<a name="closing-cost-calculator_topnav" target="_self" href="/home-loans/mortgage/closing-costs-calculator.go">Closing Cost Calculator</a>
						</div>
										<span class="ada-hidden">End of submenu</span>
									</div>
								</div>
							</li>
				
									
					<li>
					<a name="mortgage-link_topnav" id="Mortgage" href="/home-loans/mortgage/overview.go" class="top-menu-item selected">Mortgage <span class="ada-hidden">link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>	
		
						 <div class="sub-nav-box">
								<div class="sub-nav-left">
						<div class="hasSub">
												<a name="todays-mortgage-rates_topnav" target="_self" href="/mortgage/mortgage-rates/">Today's Mortgage Rates</a>
												<a name="mortgage-calculator_topnav" target="_self" href="/home-loans/mortgage/mortgage-payment-calculator.go">Mortgage Calculator</a>
												<a name="closing-cost-calculator_topnav" target="_self" href="/home-loans/mortgage/closing-costs-calculator.go">Closing Cost Calculator</a>
												<div class="dot-border" tabindex="-1"></div>
												<a name="fixed-rate-mortgage_topnav" target="_self" href="/mortgage/fixed-rate-mortgage-loans/">Fixed-Rate Mortgage</a>
												<a name="adjustable-rate-mortgage_topnav" target="_self" href="/mortgage/adjustable-rate-mortgage-loans/">Adjustable-Rate Mortgage</a>
												<a name="jumbo-loan_topnav" target="_self" href="/mortgage/jumbo-loans/">Jumbo Loan</a>
												<a name="affordable-loan-solution _topnav" target="_self" href="/mortgage/affordable-loan-solution-mortgage/">Affordable Loan Solution </a>
												<a name="fha-and-va-loans_topnav" target="_self" href="/mortgage/fha-va-mortgage-loans/">FHA &amp; VA Loans</a>
						</div>
				
		
						<div class="hasSub">
												<span>Help When You Need It</span>
												<a name="first-time-homebuyer-tips_topnav" target="_self" href="/home-loans/mortgage/first-time-home-buyer.go">First-Time Homebuyer Tips</a>
												<a name="budgeting-for-a-home_topnav" target="_self" href="/home-loans/mortgage/budgeting-for-home.go">Budgeting for a Home</a>
												<a name="affordable-housing-assistance-programs_topnav" target="_self" href="/home-loans/mortgage/affordable-housing-programs.go">Affordable Housing Assistance Programs</a>
												<a name="find-a-house_topnav" target="_self" href="http://realestatecenter.bankofamerica.com/">Find a House</a>
						</div>
										<span class="ada-hidden">End of submenu</span>
									</div>
								</div>
							</li>
				
									
					<li>
					<a name="refinance-link_topnav" id="Refinance" href="/home-loans/refinance/overview.go" class="top-menu-item ">Refinance <span class="ada-hidden">link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>	
		
						 <div class="sub-nav-box">
								<div class="sub-nav-left">
						<div class="hasSub">
												<a name="todays-refinance-rates_topnav" target="_self" href="/mortgage/refinance-rates/">Today's Refinance Rates </a>
												<a name="refinance-calculator_topnav" target="_self" href="/home-loans/refinance/custom-refinance-rates-today.go">Refinance Calculator</a>
												<a name="home-value-estimator _topnav" target="_self" href="http://realestatecenter.bankofamerica.com/tools/marketvalue4.aspx">Home Value Estimator </a>
												<div class="dot-border" tabindex="-1"></div>
												<a name="fixed-rate-refinance-loans_topnav" target="_self" href="/mortgage/fixed-rate-refinance-loans/">Fixed-Rate Refinance Loans</a>
												<a name="adjustable-rate-refinance-loans_topnav" target="_self" href="/mortgage/adjustable-rate-refinance-loans/ ">Adjustable-Rate Refinance Loans</a>
												<a name="fha-and-va-refinance-loans_topnav" target="_self" href="/home-loans/refinance/fha-va-refinance.go">FHA &amp; VA Refinance Loans</a>
						</div>
				
		
						<div class="hasSub">
												<span>Help When You Need It</span>
												<a name="cash-out-refinance-info_topnav" target="_self" href="/home-loans/refinance/reasons-to-refinance/cash-out-refinance-loan.go">Cash-Out Refinance Info</a>
												<a name="reasons-to-refinance_topnav" target="_self" href="/home-loans/refinance/should-refinance-mortgage.go">Reasons to Refinance</a>
						</div>
										<span class="ada-hidden">End of submenu</span>
									</div>
								</div>
							</li>
				
									
					<li>
					<a name="home-equity_topnav" id="Home Equity" href="/home-loans/home-equity-loans/overview.go" class="top-menu-item ">Home Equity <span class="ada-hidden">link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>	
		
						 <div class="sub-nav-box">
								<div class="sub-nav-left">
						<div class="hasSub">
												<a name="home-equity-line-of-credit-rates_topnav" target="_self" href="/home-equity/home-equity-rates/">Home Equity Line of Credit Rates</a>
												<a name="fixed-rate-loan-option_topnav" target="_self" href="/home-equity/fixed-rate-loan/">Fixed-Rate Loan Option </a>
												<a name="home-equity-calculator_topnav" target="_self" href="/home-loans/home-equity/home-equity-loan-payment-calculator.go">Home Equity Calculator</a>
												<a name="home-value-estimator_topnav" target="_self" href="http://realestatecenter.bankofamerica.com/tools/marketvalue4.aspx">Home Value Estimator</a>
						</div>
				
		
						<div class="hasSub">
												<span>Help When You Need It</span>
												<a name="what-is-a-home-equity-line-of-credit_topnav" target="_self" href="/home-loans/home-equity/what-is-a-home-equity-line-of-credit.go">What Is a Home Equity Line of Credit? </a>
												<a name="evaluating-your-homes-equity_topnav" target="_self" href="/home-loans/home-equity/evaluating-home-equity.go">Evaluating Your Home's Equity</a>
												<a name="understanding-your-debt-to-income-ratio_topnav" target="_self" href="/home-loans/home-equity/owe-vs-make.go">Understanding Your Debt-to-Income Ratio</a>
												<a name="home-equity-or-cash-out-refinance_topnav" target="_self" href="/home-loans/home-equity/cash-out-refinance.go">Home Equity or Cash-out Refinance?</a>
						</div>
										<span class="ada-hidden">End of submenu</span>
									</div>
								</div>
							</li>
				
									
					<li>
					<a name="learn-about-home-loans_topnav" id="Learn About Home Loans" href="/home-loans/home-loan-guide.go" class="top-menu-item ">Learn About Home Loans <span class="ada-hidden">link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>	
		
						 <div class="sub-nav-box">
								<div class="sub-nav-left">
						<div class="hasSub">
												<a name="learn-about-home-buying_topnav" target="_self" href="/home-loans/mortgage/budgeting-for-home.go ">Learn About Home Buying </a>
												<a name="learn-about-refinancing_topnav" target="_self" href="/home-loans/refinance/should-refinance-mortgage.go">Learn About Refinancing</a>
												<a name="learn-about-home-equity_topnav" target="_self" href="/home-loans/home-equity/basics.go">Learn About Home Equity</a>
												<div class="dot-border" tabindex="-1"></div>
												<a name="home-loan-checklist_topnav" target="_self" href="/content/documents/mortgage/HomeLoanChecklist.pdf">Home Loan Checklist</a>
												<a name="faqs-link_topnav" target="_self" href="/home-loans/faq-mortgage-refi.go">FAQs</a>
												<a name="glossary-link_topnav" target="_self" href="/home-loans/glossary.go ">Glossary</a>
						</div>
										<span class="ada-hidden">End of submenu</span>
									</div>
								</div>
							</li>
				
									
					<li>
					<a name="manage-your-loan_topnav" id="Manage Your Loan" href="/home-loans/service.go" class="top-menu-item ">Manage Your Loan <span class="ada-hidden">link</span></a>	
		
							</li>
		</ul>
	</div>
</div>


<div class="page-title-fsd-module h-100" id="skip-to-h1">
	<div class="standard-red-skin sup-ie">
			<h1 data-font="cnx-regular">Mortgage Calculator with Monthly Payments</h1>
	</div>
</div>


 

 







					<div class="cta-module topnav-floating-skin headline-number Mortgage">
						<div class="box">
							<p class="heading" data-font="cnx-bold">Get prequalified</p>
							<p class="subheading">Call now <span class="number">1.866.467.6491</span></p>
						</div>
						<div class="actions">


		
		
		
		
	
	
	

	<a id="topnav_cta_action_1" href="https://secure.bankofamerica.com/applynow/initialize-workflow.go?requesttype=MPQ&subCampCode=98976&loanPurpose=purchase" target='_self' class="bump-rt  dart-click" 	
	
	
	
	
	
	
	
	
		
	data-dart-type="hliip069" data-dart-src="1359940" data-dart-cat="hli_h434"
  >Start online<span class='ada-hidden'> application</span></a>



		
			
		
		
		
	
	
	

	<a id="topnav_cta_action_2" href="https://mortgage.bankofamerica.com" target='_blank' class=" dart-click" 	
	
	
	
	
	
	
	
	
		
	data-dart-type="hliip069" data-dart-src="1359940" data-dart-cat="hli_h834"
  >Meet face-to-face<span class='ada-hidden'> with a loan officer</span></a>

						</div>
					</div>	
			 
	
<script type="text/javascript">
$(document).ready(function() {
	floatingCtaModule.init();
});
</script>		
	
	<div class="mboxDefault"></div>	
				<script type="text/javascript">
					mboxCreate("bac_mort_global_top");
				</script>


</div>
					<div class="columns">
						<div class="flex-col lt-col" >





 




	<div id="purchase-calc-module-input-skin" class=" ">
		<div class="input-skin ">
			<img src="https://www2.bac-assets.com/pa/components/modules-app/APS-home-loans/purchase-calc-module/1.0/graphic/grabber_shadow.png" id="blue-ball" style="position:absolute; left:-4000px;" />
			<div class="header">
				<h2 data-font="cnx-regular">What would you pay each month?</h2>
				<p>Use this mortgage calculator to calculate estimated monthly mortgage payments and rate options.</p>
			</div>
			<div class="input-row">
				
				<form name="mort-purchase-calc-form" id="mort-calc-form" action="mortgage-payment-calculator-results.go" method="post">
					<input name="todaysRateRequestDTO.financeType" type="hidden" value="Purchase">
				
					<div class="purchaseprice-input">
						<label for="purchasepr" class="calc-main">Purchase price</label>
						<div class="input-wrapper row">
							<a id="minus" href="javascript:void(0);" class="adj-buttons"><div class="minus-icon"></div><span class="ada-hidden">Lower Purchase Price by $5,000 increments.</span></a>
							<input name="todaysRateRequestDTO.purchasePrice" type="text" class="error-top" value="" id="purchasepr" />
							<a id="plus" href="javascript:void(0);" class="adj-buttons"><div class="plus-icon"></div><span class="ada-hidden">Increase Purchase Price by $5,000 increments.</span></a>
						</div>
					</div>
				
					<div class="downpayment-input">
						<div class="input-wrapper row">
							<label for="downpmt" class="calc-main">Down payment</label>
							<input id="downpmt-amount" name="todaysRateRequestDTO.downPayment" class="error-top" type="text" value="">
						</div>
						<div id="dwn-help" >
							<a href="javascript:void(0);" id="How much should you put down?" class="boa-dialog boa-com-info-layer-link dotted" rel="glossary-popup-2" name="glossary_how_much_should_you_put_down"><span class="ada-hidden">Glossary Term: </span>How much should you put down?</a>
						</div>
						
						<label for="downpmt-percent" class="ada-hidden dial-wrap">Down payment percentage</label>
						<input id="downpmt-percent" name="dp-percent" type="text" value="" class="dial dial-wrap error-top" data-fgColor="#000" data-width="112"  data-height="112" data-ticks="5" data-thickness=".53" data-displayInput="true" >
					</div>
				
					<div class="zipcode-input row">
						<label for="zipcode" class="calc-main">Property ZIP code</label>
						<input name="todaysRateRequestDTO.postalCode" value="" type="text" maxlength="5" class="error-top" id="purchcalc-zipcode-fld" />
						<div class="finder-wrapper">
							<a href="javascript:void(0);" id="zipcodefinder" class="boa-dialog hl-trm-tooltip boa-com-info-layer-link boa-com-info-layer-width-250 dotted zcf-anchor" rel="zcf-todays-rates-hl-module">ZIP code finder</a>
						</div>
					</div>
				</form>
			</div>
		
			<div style="clear:both;"></div>
			<div class="action-row">
				<a id="payment-calc-submit" href="javascript:void(0);" 
				data-dart-type="hliip069" data-dart-src="1359940" data-dart-cat="hlpe_376"
 class="cm-conv-start btn-bofa btn-bofa-blue btn-bofa-large  dart-click">See payment</a>
			</div>
				<div class="notes">
					<p>With the mortgage payment calculator you can estimate monthly mortgage payments with different loan types, interest rates, <a href="javascript:void(0);" id="Annual percentage rate (APR) " class="boa-dialog boa-com-info-layer-link dotted" rel="glossary-popup-3" name="glossary_APRs"><span class="ada-hidden">Glossary Term: </span>APRs</a>, <a href="javascript:void(0);" id="Points" class="boa-dialog boa-com-info-layer-link dotted" rel="glossary-popup-6" name="glossary_points"><span class="ada-hidden">Glossary Term: </span>points</a> and <a href="javascript:void(0);" id="Closing costs" class="boa-dialog boa-com-info-layer-link dotted" rel="glossary-popup-5" name="glossary_closingcosts"><span class="ada-hidden">Glossary Term: </span>closing costs</a>. You may be able to afford more (or less) depending on your down payment and/or the purchase price.</p>
<p><a href="javascript:void(0);" id="Principal & interest" class="boa-dialog boa-com-info-layer-link dotted" rel="glossary-popup-7" name="glossary_monthlyprincipalandinterest"><span class="ada-hidden">Glossary Term: </span>Monthly principal and interest</a> payment estimates make up only a part of your total monthly home expenses. Additional monthly costs may include <a href="javascript:void(0);" id="Real estate tax" class="boa-dialog boa-com-info-layer-link dotted" rel="glossary-popup-8" name="glossary_realestatetaxes"><span class="ada-hidden">Glossary Term: </span>real estate taxes</a>, <a href="javascript:void(0);" id="Insurance" class="boa-dialog boa-com-info-layer-link dotted" rel="glossary-popup-4" name="glossary_insurance"><span class="ada-hidden">Glossary Term: </span>insurance</a> and condominium fees (if applicable), plus home maintenance services and utility bills.</p>
				</div>
		</div>
	</div>
	
	<script type="text/javascript">
		var pciValidation = {
			onsubmit: false,
			rules : {
				
					"todaysRateRequestDTO.postalCode" : {
						required : true,
						zipcodeUS : true
					},
					"todaysRateRequestDTO.purchasePrice" : {
						required : true,
						number : true,
						LTVTooHigh : ["input[name='todaysRateRequestDTO.purchasePrice']","input[name='todaysRateRequestDTO.downPayment']",0.95,417000],
						LTVRange : ["input[name='todaysRateRequestDTO.purchasePrice']","input[name='todaysRateRequestDTO.downPayment']",0.8,0.951,417000,'warning'],
						range : [0,2500000],
						LTVRange2 : ["input[name='todaysRateRequestDTO.purchasePrice']","input[name='todaysRateRequestDTO.downPayment']",0.85,0.951,30000000,'warning'],
						LVMax : ["input[name='todaysRateRequestDTO.purchasePrice']","input[name='todaysRateRequestDTO.downPayment']",2000001],
						LVMin : ["input[name='todaysRateRequestDTO.purchasePrice']","input[name='todaysRateRequestDTO.downPayment']",60000]
					},
					
					"todaysRateRequestDTO.downPayment" : {
						required : true,
						number : true,
						LTVTooHigh : ["input[name='todaysRateRequestDTO.purchasePrice']","input[name='todaysRateRequestDTO.downPayment']",0.95,417000],
						LTVRange : ["input[name='todaysRateRequestDTO.purchasePrice']","input[name='todaysRateRequestDTO.downPayment']",0.8,0.951,417000,'warning'],
						LTVRange2 : ["input[name='todaysRateRequestDTO.purchasePrice']","input[name='todaysRateRequestDTO.downPayment']",0.85,0.951,30000000,'warning'],
							LVMax : ["input[name='todaysRateRequestDTO.purchasePrice']","input[name='todaysRateRequestDTO.downPayment']",2000001],
						LVMin : ["input[name='todaysRateRequestDTO.purchasePrice']","input[name='todaysRateRequestDTO.downPayment']",60000]
					
						
					},
				
					"dp-percent" : {
						required : true,
						range : [0,99],
						LTVTooHigh : ["input[name='todaysRateRequestDTO.purchasePrice']","input[name='todaysRateRequestDTO.downPayment']",0.95,417000],
						LTVRange : ["input[name='todaysRateRequestDTO.purchasePrice']","input[name='todaysRateRequestDTO.downPayment']",0.8,0.951,417000,'warning'],
						LTVRange2 : ["input[name='todaysRateRequestDTO.purchasePrice']","input[name='todaysRateRequestDTO.downPayment']",0.85,0.951,30000000,'warning']
						}
				},
				messages : {
					"todaysRateRequestDTO.postalCode" : {
						zipcodeUS: 'Mort_Purch_Calc_Error_1||<span class="ada-hidden">Zip Code: </span>Please re-enter a <br />5-digit ZIP code.',   
						required:  'Mort_Purch_Calc_Error_2||<span class="ada-hidden">Zip Code: </span>This field is required.'
					},
					"todaysRateRequestDTO.purchasePrice" : {
						required: 'Mort_Purch_Calc_Error_3||<span class="ada-hidden">Purchase Price: </span>This field is required.',
						number : 'Mort_Purch_Calc_Error_4||<span class="ada-hidden">Purchase Price: </span>Please enter an amount using only numbers.',
						LTVTooHigh : 'Mort_Purch_Calc_Error_5||<span class="ada-hidden">Purchase Price: </span>5% ($XX,XXX) or more is required', 
						LTVRange : 'Mort_Purch_Calc_Error_6||<span class="ada-hidden">Purchase Price: </span>PMI is required. <br /><a id="Private mortgage insurance (PMI)" class="boa-dialog boa-com-info-layer-link dotted" rel="glossary-popup-1" name="glossary_pmi" href="JavaScript:void;"><span class="ada-hidden">Glossary Term: </span>What is PMI?</a>', 
						LTVRange2 : 'Mort_Purch_Calc_Error_7||<span class="ada-hidden">Purchase Price: </span>PMI is required. <br /><a id="Private mortgage insurance (PMI)" class="boa-dialog boa-com-info-layer-link dotted" rel="glossary-popup-1" name="glossary_pmi" href="JavaScript:void;"><span class="ada-hidden">Glossary Term: </span>What is PMI?</a>',   
						range : 'Mort_Purch_Calc_Error_8||<span class="ada-hidden">Purchase Price: </span>For a home value more than $2,500,000, please contact a&nbsp;mortgage specialist for rate information.',
						LVMax : 'Mort_Purch_Calc_Error_9||<span class="ada-hidden">Purchase Price: </span>To get rates from this calculator, your loan balance needs to be $2,000,000 or less. You can change your estimate or contact a&nbsp;mortgage specialist for assistance with a loan balance over $2,000,000.',
						LVMin : 'Mort_Purch_Calc_Error_10||<span class="ada-hidden">Purchase Price: </span>To get results, your loan amount (purchase price minus down payment) needs to be $60,000 or more. Please change your estimates or contact us for other options.'
					},
					
					"todaysRateRequestDTO.downPayment" : {
						required: 'Mort_Purch_Calc_Error_11||<span class="ada-hidden">Down Payment Amount: </span>This field is required.',
						number : 'Mort_Purch_Calc_Error_12||<span class="ada-hidden">Down Payment Amount: </span>Please enter an amount using only numbers.',
						LTVTooHigh : 'Mort_Purch_Calc_Error_13||<span class="ada-hidden">Down Payment Amount: </span>5% ($XX,XXX) or more is required', 
						LTVRange : 'Mort_Purch_Calc_Error_14||<span class="ada-hidden">Down Payment Amount: </span>PMI is required. <br /><a id="Private mortgage insurance (PMI)" class="boa-dialog boa-com-info-layer-link dotted" rel="glossary-popup-1" name="glossary_pmi" href="JavaScript:void;"><span class="ada-hidden">Glossary Term: </span>What is PMI?</a>', 
						LTVRange2 : 'Mort_Purch_Calc_Error_15||<span class="ada-hidden">Down Payment Amount: </span>PMI is required. <br /><a id="Private mortgage insurance (PMI)" class="boa-dialog boa-com-info-layer-link dotted" rel="glossary-popup-1" name="glossary_pmi" href="JavaScript:void;"><span class="ada-hidden">Glossary Term: </span>What is PMI?</a>',   
						LVMax : 'Mort_Purch_Calc_Error_16||<span class="ada-hidden">Down Payment Amount: </span>To get rates from this calculator, your loan balance needs to be $2,000,000 or less. You can change your estimate or contact a&nbsp;mortgage specialist for assistance with a loan balance over $2,000,000.',
						LVMin : 'Mort_Purch_Calc_Error_17||<span class="ada-hidden">Down Payment Amount: </span>To get results, your loan amount (purchase price minus down payment) needs to be $60,000 or more. Please change your estimates or contact us for other options.' 
			
						
					},
				
					"dp-percent" : {
						required: 'Mort_Purch_Calc_Error_18||<span class="ada-hidden">Down Payment Percentage: </span>This field is required.',
						number : 'Mort_Purch_Calc_Error_19||<span class="ada-hidden">Down Payment Percentage: </span>Please enter an amount using only numbers.',
						range : 'Mort_Purch_Calc_Error_20||<span class="ada-hidden">Down Payment Percentage: </span>Please enter less than 100%.', 
						LTVTooHigh : 'Mort_Purch_Calc_Error_21||<span class="ada-hidden">Down Payment Percentage: </span>5% ($XX,XXX) or more is required', 
						LTVRange : 'Mort_Purch_Calc_Error_22||<span class="ada-hidden">Down Payment Percentage: </span>PMI is required. <br /><a id="Private mortgage insurance (PMI)" class="boa-dialog boa-com-info-layer-link dotted" rel="glossary-popup-1" name="glossary_pmi" href="JavaScript:void;"><span class="ada-hidden">Glossary Term: </span>What is PMI?</a>',
						LTVRange2 : 'Mort_Purch_Calc_Error_23||<span class="ada-hidden">Down Payment Percentage: </span>PMI is required. <br /><a id="Private mortgage insurance (PMI)" class="boa-dialog boa-com-info-layer-link dotted" rel="glossary-popup-1" name="glossary_pmi" href="JavaScript:void;"><span class="ada-hidden">Glossary Term: </span>What is PMI?</a>'   
						
					}
					
				} 
				
			};
		
		var pci = purchaseCalcInput;
		
		$(window).load(function () { pci.init(); });
	</script>

   <div id="zcf-todays-rates-hl-module" class="hide" rel="hl-trm-purchform-zipcode" style="display: none;">
		<span class="ada-hidden">Beginning of zip code finder dialog layer</span>
   		<h3>ZIP code finder</h3>   
		<div id="zcf-panel-one"> 
		 	<p>Please enter your city and state to find your ZIP code.</p>
			<form id="findzipcode" name="findzipcode" method="post" action="/home-loans/find-zip-code.go">
				<p id="zcf-error">   <span id="zcf-error-response"></span></p>
				<div class="zcf-inputs">
			 		<div class="zcf-city-label">   
			 			<label class="zcf-city" for="zcf-city"><span class="ada-hidden">Look up for </span>City <span class="ada-hidden">in Zip Code Finder</span></label>  
						<input type="text" id="zcf-city" name="zipCodeInfo.city" size="12" />   
					</div>
					
			 		<div class="zcf-state-label">
						<label class="zcf-state" for="zcf-state"><span class="ada-hidden">Look up for </span>State <span class="ada-hidden">in Zip Code Finder</span></label>

<select name="zipCodeInfo.state" id="zcf-state">


    <option value=""
    >(Select)</option>

        <option value="AL">AL</option>
        <option value="AK">AK</option>
        <option value="AZ">AZ</option>
        <option value="AR">AR</option>
        <option value="CA">CA</option>
        <option value="CO">CO</option>
        <option value="CT">CT</option>
        <option value="DE">DE</option>
        <option value="DC">DC</option>
        <option value="FL">FL</option>
        <option value="GA">GA</option>
        <option value="HI">HI</option>
        <option value="ID">ID</option>
        <option value="IL">IL</option>
        <option value="IN">IN</option>
        <option value="IA">IA</option>
        <option value="KS">KS</option>
        <option value="KY">KY</option>
        <option value="LA">LA</option>
        <option value="ME">ME</option>
        <option value="MD">MD</option>
        <option value="MA">MA</option>
        <option value="MI">MI</option>
        <option value="MN">MN</option>
        <option value="MS">MS</option>
        <option value="MO">MO</option>
        <option value="MT">MT</option>
        <option value="NE">NE</option>
        <option value="NV">NV</option>
        <option value="NH">NH</option>
        <option value="NJ">NJ</option>
        <option value="NM">NM</option>
        <option value="NY">NY</option>
        <option value="NC">NC</option>
        <option value="ND">ND</option>
        <option value="OH">OH</option>
        <option value="OK">OK</option>
        <option value="OR">OR</option>
        <option value="PA">PA</option>
        <option value="RI">RI</option>
        <option value="SC">SC</option>
        <option value="SD">SD</option>
        <option value="TN">TN</option>
        <option value="TX">TX</option>
        <option value="UT">UT</option>
        <option value="VT">VT</option>
        <option value="VA">VA</option>
        <option value="WA">WA</option>
        <option value="WV">WV</option>
        <option value="WI">WI</option>
        <option value="WY">WY</option>


</select>					</div>
					
			 		<div class="zcf-mutiple-zip-label">  <label class="zcf-multiple-zip" for="zcf-multiple-zip">County </label>  

<select name="zipCodeInfo.zipcodes" id="zcf-multiple-zip" class="select-bofa">



        <option value="AL">AL</option>
        <option value="AK">AK</option>
        <option value="AZ">AZ</option>
        <option value="AR">AR</option>
        <option value="CA">CA</option>
        <option value="CO">CO</option>
        <option value="CT">CT</option>
        <option value="DE">DE</option>
        <option value="DC">DC</option>
        <option value="FL">FL</option>
        <option value="GA">GA</option>
        <option value="HI">HI</option>
        <option value="ID">ID</option>
        <option value="IL">IL</option>
        <option value="IN">IN</option>
        <option value="IA">IA</option>
        <option value="KS">KS</option>
        <option value="KY">KY</option>
        <option value="LA">LA</option>
        <option value="ME">ME</option>
        <option value="MD">MD</option>
        <option value="MA">MA</option>
        <option value="MI">MI</option>
        <option value="MN">MN</option>
        <option value="MS">MS</option>
        <option value="MO">MO</option>
        <option value="MT">MT</option>
        <option value="NE">NE</option>
        <option value="NV">NV</option>
        <option value="NH">NH</option>
        <option value="NJ">NJ</option>
        <option value="NM">NM</option>
        <option value="NY">NY</option>
        <option value="NC">NC</option>
        <option value="ND">ND</option>
        <option value="OH">OH</option>
        <option value="OK">OK</option>
        <option value="OR">OR</option>
        <option value="PA">PA</option>
        <option value="RI">RI</option>
        <option value="SC">SC</option>
        <option value="SD">SD</option>
        <option value="TN">TN</option>
        <option value="TX">TX</option>
        <option value="UT">UT</option>
        <option value="VT">VT</option>
        <option value="VA">VA</option>
        <option value="WA">WA</option>
        <option value="WV">WV</option>
        <option value="WI">WI</option>
        <option value="WY">WY</option>


</select>			 		</div>
		 		</div>
				 <div class="ex-button-spacer">  
			 		<a class="button-common button-blue" href="javascript:void(0);" rel="zcf-screen-two" id="zcf-screen-two-link"><span>Find <span class="ada-hidden"> Zip Code</span></span></a>  
			 		<a class="button-common button-blue" href="javascript:void(0);" rel="zcf-find-county" id="zcf-find-county-link"><span>Find <span class="ada-hidden"> Zip Code</span></span></a>   
					<a class="button-common button-blue" href="javascript:void(0);" rel="zcf-find-city" id="zcf-find-city-link"><span>Find <span class="ada-hidden"> Zip Code</span></span></a>   
			 		<a class="button-common button-blue" href="javascript:void(0);" rel="zcf-add-zip" id="zcf-add-zip-link"><span>Select</span></a>   
				 </div> 
			</form>   
		</div>   
		<div id="zcf-panel-two"> 
			<p>
				<img src="https://www2.bac-assets.com/pa/global-assets/1.0/graphic/processing-large.gif" alt="Please wait..." />
				Please wait...
			</p>
		</div>
	</div>   
</div>
						<div class="flex-col rt-col" >












	


<div class="cta-module target-sidewell location-bottom">

			<div class="cta focus-find">
				<div class="intro">
					<h3>Start today</h3>
				</div>
		<ul class="options">		
							<li class="find  first ">

									
								<div class="details">
									<p>Find a lending specialist</p>
									<form action="https://mortgage.bankofamerica.com/search.aspx" method="GET" id="MLO-sidewell-form" name="MLO-sidewell-form">						
									<label class="ada-hidden" for="cta-find-location">Find a lending specialist</label>
									<input type="hidden" name="mode" value="direct">
									<input name="location" placeholder="Enter city or ZIP" type="text" class="text" id="cta-find-location" />
									<input onClick="dartFireOnClick('1359940','hliip069','hli_h834');" type="submit" class="submit" value="" title="Find a loan officer" />
								</form>
								</div>
							</li>
							<li class="call ">
										<h4><a href="#" name="side-well-call" onClick="dartFireOnClick('1359940','hliip069','2013_310');">
											<span class="ada-hidden ada-closed">Show details on how to </span>
											<span class="ada-hidden ada-open" style="display:none;">Hide details on how to </span>
												Talk to us
											<span class="ada-hidden">a mortgage specialist</span>
										</a></h4>

									<div class="details">

									<p></p>
										<p class="large">1.866.467.6491</p>
	<p class="small smpad">Mon.&ndash;Fri. 8 a.m.&ndash;10 p.m. ET <br />Sat.&nbsp;8 a.m.&ndash;6:30 p.m. ET</p>
									</div>
							</li>
								<li class="chat ">

										<h4><a href="#" name="side-well-chat" onClick="dartFireOnClick('1359940','hliip069','hli_h555');">
											<span class="ada-hidden ada-closed">Show details on how to </span>
											<span class="ada-hidden ada-open" style="display:none;">Hide details on how to </span>
											Chat with us
											 <span class="ada-hidden">with a mortgage specialist</span>
										</a></h4>

										 <div class="details">
											<div id="lpButtonDiv-Target-HomeLoans-SideWell"></div>							
										 </div>
								</li>
							<li class="email ">
								
									<h4><a href="#" name="side-well-getacallback">
									<span class="ada-hidden ada-closed">Show details on how to </span>
									<span class="ada-hidden ada-open" style="display:none;">Hide details on how to </span>
									Get a call back
									 <span class="ada-hidden">from a mortgage specialist</span> 
									</a></h4>
						
								<div class="details">
									<p></p>
	<p class="small"></p>
									<p><a onClick="dartFireOnClick('1359940','hliip069','hli_h106');" name="side-well-getacallback" href="/home-loans/home-loan-contact-form-B.go?subCampCode=98976&loanPurpose=purchase">Have a lending specialist call you on your schedule
									<span class="ada-hidden"> from a mortgage loan officer</span></a></p>
								</div>
							</li>


							<li class="qualify ">
										<h4><a href="#" name="side-well-applyonline">
											<span class="ada-hidden ada-closed">Show details on how to </span>
											<span class="ada-hidden ada-open" style="display:none;">Hide details on how to </span>
											Begin online now
										</a></h4>

									<div class="details">
										<p></p>									
											<p class="cta btn"><a name="side-well-applyonline1" onClick="dartFireOnClick('1359940','hliip069','hli_h434');" href="https://secure.bankofamerica.com/applynow/initialize-workflow.go?requesttype=MPQ&subCampCode=98976&loanPurpose=purchase" class='btn-bofa btn-bofa-blue btn-bofa-small btn-bofa-noRight click-normal'>Get prequalified
										<span class="ada-hidden"> for a mortgage</span></a></p>
									</div>
							</li>
		</ul>
	</div>
</div>
<div class="side-well-module"> </div>
</div>
						<div class="clearboth"></div>
					</div>
					<div class="footer">
						<div class="footer-top">&nbsp;</div>
						<div class="footer-inner">

	<div class="disclosure-module">
		<div class="footer-skin">
			<div class="container">
				<p>This is for illustrative purposes only, and is based on information you provided. Accuracy is not guaranteed and products may not be available for your situation. Results assume a borrower with excellent credit. <a class="new-window-hover boa-window force-large" name="loan-assumptions-and-disclosures" href="/home-loans/pop-up/rates/loan-assumptions.go" target="_blank">Loan assumptions and disclosures<img src="https://www2.bac-assets.com/content/images/ContextualSiteGraphics/Logos/en_US/new_window_icon.png" alt="Opens in a new window" /></a></p>
			</div>
		</div>
	</div>

<div class="footnote-com-module">
   <div class="fsd-layout-skin sup-ie">
   
   <script>
		$(function() {
			if ($('.footnote-com-module .fsd-layout-skin').text().length > 10) {
				$('.footnote-com-module .fsd-layout-skin').addClass('wfootnote');
			}
		});
	</script>
   
   </div>
</div>








<div class="hl-power-footer-module">
	<div class="fsd-flex-skin sup-ie">
		<div class="breadcrumbs">
		<div itemscope itemtype="http://schema.org/BreadcrumbList">
								<div itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
										<a itemprop="item" class="bold-bc" href="http://www.bankofamerica.com/" name="bank-of-america-breadcrumbs" target="_self">
										<span itemprop="name">Bank of America</span>
										<meta itemprop="position" content="1" /></a>
								</div>
								<div itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
										<a itemprop="item" href="/home-loans/overview.go" name="home_loans-breadcrumbs" target="_self">
										<span itemprop="name">Home Loans</span>
										<meta itemprop="position" content="2" /></a>
								</div>
				   	  			    
				     
				    
				    		
				    			<div itemprop="itemListElement" itemscope itemtype=http://schema.org/ListItem>
								<a itemprop="item" href="/home-loans/mortgage/overview.go" name="mortgage-link-breadcrumbs" target="_self">
									<span itemprop="name">Mortgage</span>
									<meta itemprop="position" content="3"/>
								</a>
							</div>				    		
				    		    
				    <div class="breadcrumb-last-item" itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
					<span itemprop="name">Mortgage Calculator with Monthly Payments</span>
					<meta itemprop="position" content="4" />
				    </div>		
			
<div class="clearboth"></div>
</div>
</div>

<div class="pf-columns">
			  
			  
				  	<div class="pf-col">
				  
						<a href="/mortgage/" name="rates-and-loans-power-footer" class="bold" target="_self">Rates & Loans</a>
								
									<a href="/mortgage/mortgage-rates/"  name="mortgage-rates-power-footer" target="_self">Mortgage Rates</a>
								
									<a href="/mortgage/fixed-rate-mortgage-loans/"  name="fixed-rate-mortgages-power-footer" target="_self">Fixed-Rate Mortgages</a>
								
									<a href="/mortgage/adjustable-rate-mortgage-loans/"  name="adjustable-rate-mortgages-power-footer" target="_self">Adjustable-Rate Mortgages</a>
								
									<a href="/mortgage/jumbo-loans/"  name="jumbo-loans-power-footer" target="_self">Jumbo Loans</a>
								
									<a href="/home-loans/mortgage/affordable-housing-programs.go"  name="affordable-housing-assistance-programs-power-footer" target="_self">Affordable Housing Assistance Programs</a>
								
									<a href="/mortgage/affordable-loan-solution-mortgage/"  name="Affordable-Loan-Solution -power-footer" target="_self">Affordable Loan Solution<sup>�</sup></a>
								
									<a href="/mortgage/fha-va-mortgage-loans/"  name="fha-and-va-loans-power-footer" target="_self">FHA & VA Loans</a>
					</div>   
			  
			  
				  	<div class="pf-col">
				  
									<span class="bold">Calculators</span>
								
									<a href="/home-loans/mortgage/mortgage-payment-calculator.go"  name="mortgage-calculator-power-footer" target="_self">Mortgage Calculator</a>
								
									<a href="http://loans.bankofamerica.com/en/tools/affordability-snapshot.html?standalone=y" name="affordability-snapshot-power-footer" target="Pop-up medium" onClick="return displayPopup('http://loans.bankofamerica.com/en/tools/affordability-snapshot.html?standalone=y');":Affordability Snapshot"> Affordability Snapshot</a>
								
									<a href="/home-loans/mortgage/closing-costs-calculator.go"  name="closing-costs-calculator-power-footer" target="_self">Closing Costs Calculator</a>
					</div>   
			  
			  
				  	<div class="pf-col">
				  
									<span class="bold">Learn About Mortgages</span>
								
									<a href="/home-loans/mortgage/first-time-home-buyer.go"  name="first-time-homebuyer-power-footer" target="_self">First-Time Homebuyer</a>
								
									<a href="/home-loans/mortgage/budgeting-for-home.go#1"  name="budgeting-for-a-home-power-footer" target="_self">Budgeting for a Home</a>
								
									<a href="/home-loans/mortgage/home-mortgage-loan-options.go#3"  name="finding-the-right-loan-power-footer" target="_self">Finding the Right Loan</a>
								
									<a href="/home-loans/mortgage/applying-for-mortgage-loan.go#4"  name="applying-for-a-mortgage-loan-power-footer" target="_self">Applying for a Mortgage Loan</a>
								
									<a href="http://realestatecenter.bankofamerica.com/"  name="Real Estate Center-power-footer" target="_self">Real Estate Center</a>
					</div>   
			  
			  
				  	<div class="pf-col">
				  
						<a href="/home-loans/service.go" name="manage-your-loan-power-footer" class="bold" target="_self">Manage Your Loan</a>
									<a onClick="dartFireOnClick('1359940','hliip069','hli_h434');" href="https://secure.bankofamerica.com/applynow/initialize-workflow.go?requesttype=MPQ&subCampCode=98976&loanPurpose=purchase" name="get-prequalified-power-footer" target="_self">Get prequalified</a>
									<a href="https://secure.bankofamerica.com/applynow/welcome.go"  name="continue-a-saved-application-power-footer" target="_self">Continue a Saved Application</a>
								
									<a href="https://secure.bankofamerica.com/login/sign-in/signOnScreen.go" onClick="dartFireOnClick('1359940','hliip069','hli_h298');" name="sign-in-to-your-account-power-footer" target="_self">Sign in to Your Account</a>
								
									<a href="/home-loans/home-loan-navigator.go" onClick="dartFireOnClick('1359940','hliip069', 'hli_h743');" name="check-your-application-status-or-submit-documents-online-power-footer" target="_self">Check Your Application Status/Submit Documents Online</a>
								
									<a href="http://homeloanhelp.bankofamerica.com/"  name="get-help-with-payment-difficulties-power-footer" target="_self">Get Help with Payment Difficulties</a>
								
									<a href="https://www.bankofamerica.com/contactus/contactus.go?topicId=mrtg_home_equity" onClick="dartFireOnClick('1359940','hliip069','hli_h826');" name="contact-us-about-your-home-loan-power-footer" target="_self">Contact Us About Your Home Loan</a>
					</div>   
			  
			  
			  
		  <div class="clearboth"></div>
    </div>

</div>
</div>



 



		<div class="global-footer-module">
			<div class="fsd-skin">

				<div class="footer-bottom-left" style="float:left;max-width:66%;">
	    			<div class="gf-links">	          	
						
					
									
									<a  target="_self" href="/" 
									    name="Home_Page">Home
									</a>
									
						
					
									
									<a  target="_self" href="/privacy/overview.go" 
									    name="Privacy_Security">Privacy & Security
									</a>
									
						
					
									
									<a  target="_self" href="http://www.bankofamerica.com/careers/" 
									    name="Careers_Link">Careers
									</a>
									
						
					
									
									<a  target="_self" href="/sitemap/personal.go" 
									    name="Site_Map">Site Map
									</a>
									
						
					
									<a href="javascript:void(0);" class="gf-last-link boa-dialog boa-com-info-layer-link" name="global_footer_ad_practices_lnk" rel="global_footer_ad_practices">Advertising Practices</a>
								<div id="global_footer_ad_practices" class="hide">
									<h3>Advertising Practices</h3>
										<p>We strive to provide you with information about products and services you might find interesting and useful. Relationship-based ads and online behavioral advertising help us do that.</p>
<p>Here's how it works: We gather information about your online activities, such as the searches you conduct on our Sites and the pages you visit. This information may be used to deliver advertising on our Sites and offline (for example, by phone, email and direct mail) that's customized to meet specific interests you may have.</p>
<p>If you prefer that we do not use this information, you may <a onclick="$('.ui-dialog').remove();" name="WebsiteAdPractices_OptOut" href="/privacy/online-privacy-notice.go#advertising-on-our-sites" target="_blank">opt out of online behavioral advertising</a>. If you opt out, though, you may still receive generic advertising. In addition, financial advisors/Client Managers may continue to use information collected online to provide product and service information in accordance with account agreements.</p>
<p>Also, if you opt out of online behavioral advertising, you may still see ads when you sign in to your account, for example through Online Banking or MyMerrill. These ads are based on your specific account relationships with us.</p>
<p>To learn more about relationship-based ads, online behavioral advertising and our privacy practices, please review the <a onclick="$('.ui-dialog').remove();" name="WebsiteAdPractices_PrivacyNotice" href="/privacy/online-privacy-notice.go" target="_blank">Bank of America Online Privacy Notice</a> and our <a onclick="$('.ui-dialog').remove();" name="Online-privacy-faqs" href="/privacy/faq/online-privacy-faq.go" target="_blank">Online Privacy FAQs</a>.</p>
								</div>
						<div class="clearboth"></div>
	    			</div>
	      			<p>Bank of America, N.A. Member FDIC. <a title=" Equal Housing Lender information. Link opens new window." onclick="window.open('/help/equalhousing_popup.go','newwin','width=640,height=371,scrollbars=yes,resizable=yes,left=35,top=161'); return false;" name="Equal_Housing_Lender" href="/help/equalhousing_popup.go" target="_blank">Equal Housing Lender<img src="https://www2.bac-assets.com/content/images/ContextualSiteGraphics/Logos/en_US/icon_equal_housing_lender.gif" alt="" width="14" height="9" /></a><br />&copy; 2017 Bank of America Corporation. All rights reserved. Credit and collateral are subject to approval. Terms and conditions apply. This is not a commitment to lend. Programs, rates, terms and conditions are subject to change without notice.</p>
         		</div>
         		<div class="footer-social-container" style="float:right;max-width:30%;padding-left:50px;padding-top:19px;">




<div class="boa-social-loader" data-loaded="false" data-platform="borneo"  data-options=''></div>

         		</div>
         		<div class="clearboth"></div>
  			</div>
		</div>




 

<script type="text/javascript">
var axel = Math.random()+"";var a = axel * 10000000000000;document.write('<iframe title="iFrame used for layout purpose" src="https://1359940.fls.doubleclick.net/activityi;src=1359940;type=hliip069;cat=2013_580;ord=1;num=' + a + '?;num='+ a + '?" width="1" height="1" frameborder="0" style="display:none;"></iframe>');
</script>
<noscript>
	<iframe title="iFrame used for layout purpose" src="https://1359940.fls.doubleclick.net/activityi;src=1359940;type=hliip069;cat=2013_580;ord=1;num=1?" width="0" height="0" frameborder="0" style="display:none;"></iframe>
</noscript>


					<div id="glossary-popup-1" class="hide tabs-main-content">
						<h3>Private mortgage insurance (PMI)</h3>
						<p>See: <a href="#M_id_6">Mortgage insurance</a></p>
					</div>
					<div id="glossary-popup-2" class="hide tabs-main-content">
						<h3>How much should you put down?</h3>
						<p>If you put down at least 20% of the purchase price, you typically won't have to pay for private mortgage insurance (PMI). And when you put down more, you're more likely to qualify for lower interest rates. Putting down more money will likely save you more money over the life of the loan. Learn more about <a id="mortgage-down-payments-lnk" title="Mortgage Down Payments" name="mortgage-down-payments-link" href="/home-loans/mortgage/budgeting-for-home/mortgage-down-payment-amount.go" target="_self">mortgage down payments.</a></p>
					</div>
					<div id="glossary-popup-3" class="hide tabs-main-content">
						<h3>Annual percentage rate (APR) </h3>
						<p>The annual cost of a loan to a borrower. Like an interest rate, the APR is expressed as a percentage. Unlike an interest rate, however, it includes other charges or fees (such as mortgage insurance, most closing costs, discounts points and loan origination fees) to reflect the total cost of the loan. The Federal Truth in Lending Act requires that every consumer loan agreement disclose the APR. Since all lenders must follow the same rules to ensure the accuracy of the APR, borrowers can use the APR as a good basis for comparing the costs of similar credit transactions.</p>
					</div>
					<div id="glossary-popup-4" class="hide tabs-main-content">
						<h3>Insurance</h3>
						<p>A contract that provides compensation for specific losses in exchange for a periodic payment. An individual contract is known as an insurance policy, and the periodic payment is known as an insurance premium.</p>
					</div>
					<div id="glossary-popup-5" class="hide tabs-main-content">
						<h3>Closing costs</h3>
						<p>Closing costs, also known as settlement costs, are the costs incurred when obtaining your loan. For new purchases, these costs also include ownership transfer of any collateral property from the seller to you. Costs may include and are not limited to: attorney's fees, preparation and title search fees, discount points, appraisal fees, title insurance, and credit report charges. They are typically about 3% of your loan amount, and are often paid at closing or just before your loan closes.</p> <p>Funds often needed to close a loan, such as homeowners insurance, property taxes, and <a href="/home-loans/home-equity/glossary.go#alp-E">escrow impound account</a> funds, aren't included in closing costs and are considered separate. You should be prepared to pay these costs before your loan closes.</p>
					</div>
					<div id="glossary-popup-6" class="hide tabs-main-content">
						<h3>Points</h3>
						<p>An amount paid to the lender, typically at closing, to lower (or buy down) the interest rate. One discount point equals one percentage point of the loan amount. For example, 2 points on a $100,000 mortgage would cost $2,000. Negative points indicate the amount to be credited at closing to reduce closing costs. Also called discount points or mortgage points.</p>
					</div>
					<div id="glossary-popup-7" class="hide tabs-main-content">
						<h3>Principal & interest</h3>
						<p>The principal is the amount of money borrowed on a loan. The interest is the charge paid for borrowing money. Principal and interest account for the majority of your mortgage payment, which may also include escrow payments for property taxes, homeowners insurance, mortgage insurance and any other costs that are paid monthly, or fees that may come due.</p>
					</div>
					<div id="glossary-popup-8" class="hide tabs-main-content">
						<h3>Real estate tax</h3>
						<p>Typically, a fixed percentage based on the appraised value of your home that you pay to the county, the school district and the municipality where your property is located. The taxes may be assessed annually or semiannually, and you may pay them as part of your monthly mortgage payments. Depending on when you close your loan, some of this property tax may be due at the time of closing. Each local tax assessor&rsquo;s office can give you the tax rate. Also known as property tax.</p>
					</div>
		



 

	<script type="text/javascript" src="https://www2.bac-assets.com/pa/global-assets/external/coremetrics/hp/eluminate.js"></script>
	<script type="text/javascript" src="https://www2.bac-assets.com/pa/global-assets/external/coremetrics/hp/cmdatatagutils.js"></script>
	<script type="text/javascript" src="https://www2.bac-assets.com/pa/components/modules-app/APS-home-loans/hl-coremetrics-module/1.0/script/hl-coremetrics-module-site-skin.js"></script>   


	
	
	
	
	
	
	
	
	
	
	
	
			
    

    
    
	<script type="text/javascript">
		var Options = {
			state : getCookie("state"),
			preferred_customer : getCookie("Hp_pf_exp"),
			olb_customer : getCookie("BA_0021"),
			cust_id : getCookie("BA_0020"),
			eventID: 'App View to submit LF3a_Mkt_98976',
			eventIdStart:'App View to Start LF3a_Mkt_98976',
			pageID: 'HL:Tool:Purch:Calc;mortgage-payment-calculator',
			convCategoryID:'HL:Tool:Purch:Calc;mortgage-payment-calculator',
			productId:'',
			productName:'',
			cmCategoryId:'HL:Tool:Purch:Calc',
			productCategoryId:'',
			cmEventID:'Monthly Purch Paymt Calc',
			ALT_CM_eventID:'',
			showProductViewTag : 'false',
			showShop5Tag : 'false',
			showConvEventTag1 : 'true',
			showConvEventTag2 : 'false',
			CM_help : 'false',
			CM_error : 'false',
			CM_tool : 'false',
			CM_flash : 'false',
			CM_subcmpgnCode : '98976',
			CM_pageCount : 'false',
			selectedProduct : '',
			popupPageID : 'PVParamsMissing',
			popupCmCategoryID:'PVParamsMissing',
			errorObj : new Array()
			
		};
		    			
		$(function(){ 
			$.extend( true, hl_calc_coremetrics_module.options, Options );
			hl_calc_coremetrics_module.init(); 
		});
	</script>
			<div itemscope="itemscope" itemtype="http://schema.org/WebPage">
					<span style="display:none" itemprop="name">Mortgage Calculator with Monthly Payments from Bank of America</span>
					<a style="display:none" itemprop="url" href="https://www.bankofamerica.com/home-loans/mortgage/mortgage-payment-calculator.go"></a>
					<span style="display:none" itemprop="description">Calculate estimated rate and monthly payment options with our easy-to-use mortgage calculator.</span>
					<img style="display:none" class="no-stretch" itemprop="image" alt="Mortgage Calculator with Monthly Payments from Bank of America" src="https://www.bankofamerica.com/content/images/ContextualSiteGraphics/Logos/en_US/Bank_of_America_Flagscape_71x71.gif">
					<span style="display:none" itemprop="keywords">mortgage calculator, mortgage payment calculator, monthly mortgage payment calculator, monthly mortgage calculator, calculate mortgage payment</span>
			</div>
</div>
					</div>
				</div>
			</div>
		</div>
	</body>	
</html>

