
 

				<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
				<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
				<head>



<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<meta http-equiv="content-type" content="text/html;charset=utf-8" />






			<link rel="canonical" href="https://www.bankofamerica.com/home-loans/refinance/custom-refinance-rates-today.go"/>
		
	
	





<title>Refinance Rates Today from Bank of America</title>
<link rel="shortcut icon" href="https://www2.bac-assets.com/pa/global-assets/1.0/graphic/favicon.ico" type="image/ico" />

				<meta name="Keywords" CONTENT="refinancing rates, refinance rates today, refinancing rates today, refinance rate today" />
				<meta name="Description" CONTENT="Get a custom refinance mortgage rate and estimated payment based on today's refinance rates from Bank of America." />
				<meta name="twitter:title" CONTENT="Refinance Rates Today from Bank of America" />
				<meta name="twitter:url" CONTENT="https://www.bankofamerica.com/home-loans/refinance/custom-refinance-rates-today.go" />
				<meta name="twitter:image" CONTENT="https://www.bankofamerica.com/content/images/ContextualSiteGraphics/Logos/en_US/Bank_of_America_Flagscape_71x71.gif" />
				<meta name="twitter:description" CONTENT="Get a custom refinance mortgage rate and estimated payment based on today's refinance rates from Bank of America." />
				<meta property="og:title" CONTENT="Refinance Rates Today from Bank of America" />
				<meta property="og:url" CONTENT="https://www.bankofamerica.com/home-loans/refinance/custom-refinance-rates-today.go" />
				<meta property="og:description" CONTENT="Get a custom refinance mortgage rate and estimated payment based on today's refinance rates from Bank of America." />
	

        <script type="text/javascript">
			var boaTLTargetPage = "/home-loans";
  		</script>
			<script src="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/Global/1.0/script/tealeafbundle.js" type="text/javascript"></script>

	
   
		<link rel="stylesheet" type="text/css" href="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/APS-home-loans/2017.03.0/style/home-loans-refi-jawr.css" media="all" />
		<link rel="stylesheet" type="text/css" href="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/APS-home-loans/2017.03.0/style/home-loans-refi-jawr-print.css" media="print" />
		<script src="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/APS-home-loans/2017.03.0/script/home-loans-refi-jawr.js" type="text/javascript"></script>	  
	
			<script src="https://www2.bac-assets.com/pa/components/modules/cta-module/2.1/script/cta-module-topnav-floating-skin.js" type="text/javascript"></script>
			<script src="https://www2.bac-assets.com/pa/components/modules/cta-module/2.1/script/cta-module.js" type="text/javascript"></script>
				<link href="https://www2.bac-assets.com/pa/components/modules/cta-module/2.1/style/cta-module-topnav-floating-skin.css" rel="stylesheet" type="text/css" />
				<link href="https://www2.bac-assets.com/pa/components/modules/cta-module/2.1/style/cta-module.css" rel="stylesheet" type="text/css" />
<script type="text/javascript">
(function() {
	if (typeof mboxUpdate == "function") {
		var windowURL = window.location.href
	    windowURL = windowURL.slice( windowURL.indexOf('.')+1);
		windowURL = windowURL.split( '?' )[0];
		windowURL = windowURL.toLowerCase();
		//alert(windowURL);
		if (
		    //If no mboxes on page, mbox count will be < 1
		    (mboxFactoryDefault.getMboxes().length() < 1) &&  
			
			//Also check for high-volume pages that do not need global logging
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go") &&
			(windowURL != "bankofamerica.com/myaccounts/signin/signin.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/entry/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signonscreen.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatechallengeanswer.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatePassword.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/mobile/banking.go")&&
			(windowURL != "bankofamerica.com/content/preload/olb-myaccount-preload-jawr-module.htm")
			)
		{

			var mboxDiv = document.createElement("div");
			mboxDiv.id = "adobe_touch_clarity_replacement";
			mboxDiv.style.display = "none";
			if (document.body && document.body.firstChild) document.body.insertBefore(mboxDiv,document.body.firstChild);
			mboxDefine(mboxDiv.id,'bac_global_bottom');
			mboxUpdate('bac_global_bottom');
		}
	}	
})();
</script>
         	

			<script>
				var boaPageDataJS = {};
					boaPageDataJS.isLLE = "false";
			</script>
				<style>body{display:none;}</style>
	</head>		

	<body class="fsd-layout-body">	

				<script type="text/javascript">if(self == top){var theBody=document.getElementsByTagName("body")[0];theBody.style.display="block";}else{top.location=self.location;}</script>
				<noscript><style>body{display:block;}</style></noscript>
					<a class='ada-hidden ada-visible-focus' href='#skip-to-h1' id='ada-skip-link'>Skip to main content</a>
		<div class="fsd-layout fsd-2c-700lt-layout">
			<div class="fsd-border">
				<div class="center-content">
					<div class="header">
		  



<script language="javascript" src="/pa/components/modules/tag-manager-module/1.1/script/tag-manager-module-borneo-global-skin.js"></script>
<script>

(function() {
  var fireCallback = function( cb ) {
    if ( typeof cb === "function" ) cb();
  };
  
  function ddoPopulateBase( callback ) {
    try {
		  var DDO = window.digitalData,
		  	bactm_mergeDDO = function( newDDO, priorDDO ) {
		  		if( typeof priorDDO === "undefined" ) {
				  	priorDDO = digitalData || {};
				  }

			    for (var l in newDDO) {
			        if (typeof priorDDO[l] === "undefined") {
			            priorDDO[l] = newDDO[l];
			        }
			        if (newDDO[l] !== null) {
			            if (typeof newDDO[l] === "object") {
			                bactm_mergeDDO(newDDO[l], priorDDO[l]);
			            } else {
			                priorDDO[l] = bactm_validateValue( newDDO[l] ) ? newDDO[l] : priorDDO[l];
			            }
			        }
			    }

			    return priorDDO;
				},
				bactm_olb3rdPartyId = "null";

			if (typeof DDO === "undefined") {
				var simpleDDO = { page: { pageInfo:[{ pageID: null }], attributes: {}, category: { primaryCategory: null }}};

				DDO = (typeof digitalData === "object") ? digitalData : simpleDDO; 
			}

				DDO = bactm_mergeDDO( {pageInstanceID:"notprod",load_coremetrics:false,load_opinionlabs:false,load_touchcommerce:true,load_audiencemanager:true,page:{pageInfo:[{pageID:null,destinationURL:null,referringURL:null,issueDate:null,language:null,segmentValue:null,appName:null,appStepNumber:null,appStepName:null,attr:"-_--_--_--_--_--_--_--_--_--_--_--_--_--_-"}],category:{primaryCategory:null,addlCategory:null,pageType:null},attributes:{searchString:null,searchResults:null,olbSessionID:null,subCampaignCode:null,DARTUrl:null,stateCookie:null,SASIEnabled:false,needOLBcookie:false,standardDART:[],standardDARTes:[],clickDART:[],clickDARTes:[],gaId:[],chat:{site_id:36532906,target:{"lpButtonDiv-Target-HomeLoans-SideWell":"Consumer-OASHL"},account_type:"Refinance",customer_lob:"co"}}},user:{segment:null,online_id:null,preferred_rewards_tier:null,olb3rdpartyid:null},version:"BAC_0.12"}, DDO );

			DDO.page.pageInfo[0].pageID = "HL:Tool:Refi:Rates;TodaysRates";
			DDO.page.category.primaryCategory  = "HL:Tool:Refi:Rates";
			DDO.page.pageInfo[0].language = "en-US";
			DDO.page.attributes.olbSessionID = "null";
			DDO.page.attributes.SASIEnabled =  "false";
			if (typeof DDO.user != "undefined" && typeof DDO.user.olb3rdpartyid != "undefined") {
				DDO.user.olb3rdpartyid = bactm_olb3rdPartyId;
			}

			window.utag_data = {};
			window.bactm_envSelector = bactm_setTMLib();
			window.digitalData = DDO;

      return fireCallback( callback );

    } catch(e) { }
  }
	if( window.boa && window.boa.digitalData ) {
    window.boa.digitalData.register( ddoPopulateBase );
	}
	else {
	  // Handle scenario where the header isn't available (and thus the default digitalData object and utag loader are missing).
	  //
		var writeScript = function(a,b,c,d){
			a='//tags.tiqcdn.com/utag/bofa/main/' + bactm_envSelector + '/utag.js';
			b=document;
			c='script';
			d=b.createElement(c);
			d.src=a;
			d.type='text/java'+c;
			d.async=true;
			a=b.getElementsByTagName(c)[0];
			a.parentNode.insertBefore(d,a);
		};

		ddoPopulateBase( writeScript );
	}
})();			
</script>

	<div class="mboxDefault"></div>	
				<script type="text/javascript">
					mboxCreate("bac_mort_global_top");
				</script>





 


	 
<div class="header-module">
	<div class="home-loans-skin">
		<div class="header-left">
	  
			<div itemscope itemtype="http://schema.org/Corporation" class="bofa-logo">
				<a itemprop="url" name="anc-home-loans" title="Bank of America" href="/">
					<img itemprop="logo" height="28" width="221" alt="Bank of America" src="/content/images/ContextualSiteGraphics/Logos/en_US/boa_logo.gif" />
				</a>
			</div>
				<div class="product">Home Loans</div>
			<div class="clearboth"></div>
		</div>
	   	<div class="header-right">
			<ul class="header-links">
						<li class="sign-in"> 
							<a href="/hub/index.action?template=signin" title="Sign In" name="Sign_In_global_nav" target="_self">Sign In</a> 
						</li>
						<li> 
							<a href="/" title="Home" name="Home_Page_global_nav" target="_self">Home</a> 
						</li>
						<li> 
							<a href="https://locators.bankofamerica.com" title="Locations" name="Locations_Link_global_nav" target="_self">Locations</a> 
						</li>
						<li> 
							<a href="/contactus/contactus.go?topicId=mrtg_home_equity" title="Contact Us" name="Contact_Us_global_nav" target="_self">Contact Us</a> 
						</li>
						<li> 
							<a href="/home-loans/faq-mortgage-refi.go" title="help" name="help_global_nav" target="_self">Help</a> 
						</li>
						<li class="last-link">
									<a href="/home-loans/refinance/custom-refinance-rates-today.go?request_locale=es_US"  title="En Espa&#241;ol" name="SpanishHLTS_global_nav" target="_self">En Espa&#241;ol</a> 				
						</li>
		  	</ul>
		  	<div class="clearboth"></div>

		  	<!-- include search-dotcom-util -->



<div class="header-search nlh">
  
  <div class="nav-search">
    <form class="search-form" action="https://secure.bankofamerica.com/myaccounts/public/search-results/unAuthenticatedSearch.go" data-js="/pa/components/utilities/search-util/1.0/script/nav-search.min.js" data-css="/pa/components/utilities/search-util/1.0/style/nav-search.css" data-text-unavailable="Search Currently Unavailable">
      <div class="search-input-container cf" data-icon="search">
        <label for="nav-search-query" class="ada-hidden">Search Term</label>
        <input type="text" placeholder="How can we help you?" name="query" class="search-query" id="nav-search-query" 
          maxlength="99" rel="Search" autocomplete="off"><input type="submit" alt="Search" title="Search" value="Submit Search" name="Search Module - Top Result – Search Button" class="submit track-me">
      </div>
    </form>
  </div>

</div>
	
	   	</div>
   		<div class="clearboth"></div>
	</div>
</div>






<div class="hl-navigation-module">
	<div class="fsd-skin sup-ie css3-pie">
		<ul class="nav-list">
				
									
					<li>
					<a name="rates-and-calculators_topnav" id="Rates & Calculators" href="/mortgage/" class="top-menu-item ">Rates & Calculators <span class="ada-hidden">link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>	
		
						 <div class="sub-nav-box">
								<div class="sub-nav-left">
						<div class="hasSub">
												<a name="todays-home-loan-rates_topnav" target="_self" href="/mortgage/">Today's Home Loan Rates</a>
												<a name="mortgage-calculator_topnav" target="_self" href="/home-loans/mortgage/mortgage-payment-calculator.go">Mortgage Calculator</a>
												<a name="refinance-rate-calculator_topnav" target="_self" href="/home-loans/refinance/custom-refinance-rates-today.go">Refinance Rate Calculator</a>
												<a name="home-equity-calculator_topnav" target="_self" href="/home-loans/home-equity/home-equity-loan-payment-calculator.go">Home Equity Calculator</a>
												<a name="closing-cost-calculator_topnav" target="_self" href="/home-loans/mortgage/closing-costs-calculator.go">Closing Cost Calculator</a>
						</div>
										<span class="ada-hidden">End of submenu</span>
									</div>
								</div>
							</li>
				
									
					<li>
					<a name="mortgage-link_topnav" id="Mortgage" href="/home-loans/mortgage/overview.go" class="top-menu-item ">Mortgage <span class="ada-hidden">link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>	
		
						 <div class="sub-nav-box">
								<div class="sub-nav-left">
						<div class="hasSub">
												<a name="todays-mortgage-rates_topnav" target="_self" href="/mortgage/mortgage-rates/">Today's Mortgage Rates</a>
												<a name="mortgage-calculator_topnav" target="_self" href="/home-loans/mortgage/mortgage-payment-calculator.go">Mortgage Calculator</a>
												<a name="closing-cost-calculator_topnav" target="_self" href="/home-loans/mortgage/closing-costs-calculator.go">Closing Cost Calculator</a>
												<div class="dot-border" tabindex="-1"></div>
												<a name="fixed-rate-mortgage_topnav" target="_self" href="/mortgage/fixed-rate-mortgage-loans/">Fixed-Rate Mortgage</a>
												<a name="adjustable-rate-mortgage_topnav" target="_self" href="/mortgage/adjustable-rate-mortgage-loans/">Adjustable-Rate Mortgage</a>
												<a name="jumbo-loan_topnav" target="_self" href="/mortgage/jumbo-loans/">Jumbo Loan</a>
												<a name="affordable-loan-solution _topnav" target="_self" href="/mortgage/affordable-loan-solution-mortgage/">Affordable Loan Solution </a>
												<a name="fha-and-va-loans_topnav" target="_self" href="/mortgage/fha-va-mortgage-loans/">FHA &amp; VA Loans</a>
						</div>
				
		
						<div class="hasSub">
												<span>Help When You Need It</span>
												<a name="first-time-homebuyer-tips_topnav" target="_self" href="/home-loans/mortgage/first-time-home-buyer.go">First-Time Homebuyer Tips</a>
												<a name="budgeting-for-a-home_topnav" target="_self" href="/home-loans/mortgage/budgeting-for-home.go">Budgeting for a Home</a>
												<a name="affordable-housing-assistance-programs_topnav" target="_self" href="/home-loans/mortgage/affordable-housing-programs.go">Affordable Housing Assistance Programs</a>
												<a name="find-a-house_topnav" target="_self" href="http://realestatecenter.bankofamerica.com/">Find a House</a>
						</div>
										<span class="ada-hidden">End of submenu</span>
									</div>
								</div>
							</li>
				
									
					<li>
					<a name="refinance-link_topnav" id="Refinance" href="/home-loans/refinance/overview.go" class="top-menu-item selected">Refinance <span class="ada-hidden">link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>	
		
						 <div class="sub-nav-box">
								<div class="sub-nav-left">
						<div class="hasSub">
												<a name="todays-refinance-rates_topnav" target="_self" href="/mortgage/refinance-rates/">Today's Refinance Rates </a>
												<a name="refinance-calculator_topnav" target="_self" href="/home-loans/refinance/custom-refinance-rates-today.go">Refinance Calculator</a>
												<a name="home-value-estimator _topnav" target="_self" href="http://realestatecenter.bankofamerica.com/tools/marketvalue4.aspx">Home Value Estimator </a>
												<div class="dot-border" tabindex="-1"></div>
												<a name="fixed-rate-refinance-loans_topnav" target="_self" href="/mortgage/fixed-rate-refinance-loans/">Fixed-Rate Refinance Loans</a>
												<a name="adjustable-rate-refinance-loans_topnav" target="_self" href="/mortgage/adjustable-rate-refinance-loans/ ">Adjustable-Rate Refinance Loans</a>
												<a name="fha-and-va-refinance-loans_topnav" target="_self" href="/home-loans/refinance/fha-va-refinance.go">FHA &amp; VA Refinance Loans</a>
						</div>
				
		
						<div class="hasSub">
												<span>Help When You Need It</span>
												<a name="cash-out-refinance-info_topnav" target="_self" href="/home-loans/refinance/reasons-to-refinance/cash-out-refinance-loan.go">Cash-Out Refinance Info</a>
												<a name="reasons-to-refinance_topnav" target="_self" href="/home-loans/refinance/should-refinance-mortgage.go">Reasons to Refinance</a>
						</div>
										<span class="ada-hidden">End of submenu</span>
									</div>
								</div>
							</li>
				
									
					<li>
					<a name="home-equity_topnav" id="Home Equity" href="/home-loans/home-equity-loans/overview.go" class="top-menu-item ">Home Equity <span class="ada-hidden">link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>	
		
						 <div class="sub-nav-box">
								<div class="sub-nav-left">
						<div class="hasSub">
												<a name="home-equity-line-of-credit-rates_topnav" target="_self" href="/home-equity/home-equity-rates/">Home Equity Line of Credit Rates</a>
												<a name="fixed-rate-loan-option_topnav" target="_self" href="/home-equity/fixed-rate-loan/">Fixed-Rate Loan Option </a>
												<a name="home-equity-calculator_topnav" target="_self" href="/home-loans/home-equity/home-equity-loan-payment-calculator.go">Home Equity Calculator</a>
												<a name="home-value-estimator_topnav" target="_self" href="http://realestatecenter.bankofamerica.com/tools/marketvalue4.aspx">Home Value Estimator</a>
						</div>
				
		
						<div class="hasSub">
												<span>Help When You Need It</span>
												<a name="what-is-a-home-equity-line-of-credit_topnav" target="_self" href="/home-loans/home-equity/what-is-a-home-equity-line-of-credit.go">What Is a Home Equity Line of Credit? </a>
												<a name="evaluating-your-homes-equity_topnav" target="_self" href="/home-loans/home-equity/evaluating-home-equity.go">Evaluating Your Home's Equity</a>
												<a name="understanding-your-debt-to-income-ratio_topnav" target="_self" href="/home-loans/home-equity/owe-vs-make.go">Understanding Your Debt-to-Income Ratio</a>
												<a name="home-equity-or-cash-out-refinance_topnav" target="_self" href="/home-loans/home-equity/cash-out-refinance.go">Home Equity or Cash-out Refinance?</a>
						</div>
										<span class="ada-hidden">End of submenu</span>
									</div>
								</div>
							</li>
				
									
					<li>
					<a name="learn-about-home-loans_topnav" id="Learn About Home Loans" href="/home-loans/home-loan-guide.go" class="top-menu-item ">Learn About Home Loans <span class="ada-hidden">link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>	
		
						 <div class="sub-nav-box">
								<div class="sub-nav-left">
						<div class="hasSub">
												<a name="learn-about-home-buying_topnav" target="_self" href="/home-loans/mortgage/budgeting-for-home.go ">Learn About Home Buying </a>
												<a name="learn-about-refinancing_topnav" target="_self" href="/home-loans/refinance/should-refinance-mortgage.go">Learn About Refinancing</a>
												<a name="learn-about-home-equity_topnav" target="_self" href="/home-loans/home-equity/basics.go">Learn About Home Equity</a>
												<div class="dot-border" tabindex="-1"></div>
												<a name="home-loan-checklist_topnav" target="_self" href="/content/documents/mortgage/HomeLoanChecklist.pdf">Home Loan Checklist</a>
												<a name="faqs-link_topnav" target="_self" href="/home-loans/faq-mortgage-refi.go">FAQs</a>
												<a name="glossary-link_topnav" target="_self" href="/home-loans/glossary.go ">Glossary</a>
						</div>
										<span class="ada-hidden">End of submenu</span>
									</div>
								</div>
							</li>
				
									
					<li>
					<a name="manage-your-loan_topnav" id="Manage Your Loan" href="/home-loans/service.go" class="top-menu-item ">Manage Your Loan <span class="ada-hidden">link</span></a>	
		
							</li>
		</ul>
	</div>
</div>


<div class="page-title-fsd-module h-100" id="skip-to-h1">
	<div class="standard-red-skin sup-ie">
			<h1 data-font="cnx-regular">Today's Refinance Rates & Payments Calculator</h1>
	</div>
</div>


 

 







					<div class="cta-module topnav-floating-skin headline-number Refinance">
						<div class="box">
							<p class="heading" data-font="cnx-bold">Start now</p>
							<p class="subheading">Call now <span class="number">1.866.800.3221</span></p>
						</div>
						<div class="actions">


		
		
		
		
	
	
	

	<a id="topnav_cta_action_1" href="/home-loans/home-loan-contact-form-A.go?subCampCode=98983&loanPurpose=refinance" target='_self' class="bump-rt  dart-click" 	
	
	
	
	
	
	
	
	
		
	data-dart-type="hliip069" data-dart-src="1359940" data-dart-cat="hli_h434"
  >Start online<span class='ada-hidden'> application</span></a>



		
			
		
		
		
	
	
	

	<a id="topnav_cta_action_2" href="https://mortgage.bankofamerica.com/search.aspx" target='_blank' class=" dart-click" 	
	
	
	
	
	
	
	
	
		
	data-dart-type="hliip069" data-dart-src="1359940" data-dart-cat="hli_h834"
  >Meet face-to-face<span class='ada-hidden'> with a loan officer</span></a>

						</div>
					</div>	
			 
	
<script type="text/javascript">
$(document).ready(function() {
	floatingCtaModule.init();
});
</script>		
	
</div>
					<div class="columns">
						<div class="flex-col lt-col" >





 




		

		
		





	<div id="todays-rates-hl-module"  >
	
			<h2 class="hl-trm-h2 toggle purchform"  style="display:none;" >Get today's mortgage rates</h2>
			<h2 class="hl-trm-h2 toggle refiform" >Get today's refinance rates</h2>	
		<p class="hl-trm-title toggle purchform"  style="display:none;" >For quick custom rates, please tell us a little about your home buying plans.
</p>
		<p class="hl-trm-title toggle refiform" >For quick custom rates, please tell us a little about your refinancing plans.
</p>
		
			<form id="hl-trm-form" class="validate" name="todaysrate" method="post" action="/home-loans/refinance/custom-refinance-rates-today-results.go">


			<ul>
				<li class="row">
					<fieldset class="for-radio-buttons">
						<legend class="show-legend form-label">
							Mortgage type
						</legend>
						<ul>				
							<li>
								<input class="radio noreset" id="hl-trm-refiform-Purchase" name="todaysRateRequestDTO.financeType" type="radio" value="Purchase" 
 />
								
		
								<label for="hl-trm-refiform-Purchase" class="form-label">
									Purchase
								</label>
							</li>
							<li>
								<input class="radio noreset error-top" id="hl-trm-refiform-Refinance" name="todaysRateRequestDTO.financeType" type="radio" value="Refinance" 
									checked="checked" 
								 />
		
								<label for="hl-trm-refiform-Refinance" class="form-label">
									Refinance
								</label>
							</li>					
						</ul>
					</fieldset>
					<div class="clearboth"></div>
				</li>
		
		
				<li class="row"> 
					<label id="l-trm-purchform-zipcode-label" for="hl-trm-purchform-zipcode" class="form-label">
						Property ZIP code
					</label>
					<input class="required numeric no-dollar-pre noreset error-top" id="hl-trm-purchform-zipcode" name="todaysRateRequestDTO.postalCode" maxlength="5" type="text" value="" />
					<a id="hl-trm-purchform-zipcode-finder" class="boa-dialog hl-trm-tooltip boa-com-info-layer-link boa-com-info-layer-width-250" rel="zcf-todays-rates-hl-module" href="javascript:void(0);">ZIP code finder</a>
					<div class="clearboth"></div>
				</li>
		
				<li class="row toggle purchform"  style="display:none;" >
					<label id="hl-trm-purchform-purchaseprice-label" for="hl-trm-purchform-purchaseprice" class="form-label money">
						<a id="Purchase price/sales price" class="boa-dialog boa-com-info-layer-link dotted" rel="glossary-popup-2" name="glossary_purchase_price" href="javascript:void(0);"><span class="ada-hidden">Glossary Term: </span>Purchase price</a>
						<span class="ada-hidden">$</span>
					</label>
					<span class="dollar-pre">
</span>
					<input class="required numeric number-grouping" id="hl-trm-purchform-purchaseprice" name="todaysRateRequestDTO.purchasePrice" type="text" value="" />
					<div class="clearboth"></div>
				</li>
				
		
				 <li class="row toggle refiform" >
					<label for="hl-trm-refiform-purchaseprice" class="form-label money" id="hl-trm-refiform-purchaseprice-label">Home value
					<span class="ada-hidden">$</span> </label>
					<span class="dollar-pre">
</span>
					<input class="required numeric number-grouping" id="hl-trm-refiform-purchaseprice" name="todaysRateRequestDTO.refinancePurchasePrice" type="text" value="" />
					<div class="clearboth"></div>
		            	</li>
		
				<li class="row toggle purchform"  style="display:none;" >
					<label id="hl-trm-purchform-downpayment-label" for="hl-trm-purchform-downpayment" class="form-label money">
						<a id="Down payment " class="boa-dialog boa-com-info-layer-link dotted"  rel="glossary-popup-8" name="glossary_down_payment" href="javascript:void(0);"><span class="ada-hidden">Glossary Term: </span>Down payment</a>
						<span class="ada-hidden">$</span>
					</label>
					<span class="dollar-pre">
</span>
					<input class="required numeric number-grouping" id="hl-trm-purchform-downpayment" name="todaysRateRequestDTO.downPayment" type="text" value="" />
					
						<a id="How much should you put down?" class="boa-dialog boa-com-info-layer-link dotted hl-trm-tooltip" rel="glossary-popup-1" name="glossary_how_much_should_you_put_down" href="javascript:void(0);"><span class="ada-hidden">Glossary Term: </span>How much should you put down?</a>
					<div class="clearboth"></div>  
				</li>
		
		 		<li class="row toggle refiform" >
					<label for="hl-trm-refiform-downpayment" class="form-label money" id="hl-trm-refiform-downpayment-label">Current loan balance
					<span class="ada-hidden">$</span> </label>
					<span class="dollar-pre">
</span>
					<input class="required numeric number-grouping" id="hl-trm-refiform-downpayment" name="todaysRateRequestDTO.refinanceDownPayment" type="text" value="" />
					<div class="clearboth"></div>
		            	</li>
		
				<li class="row">
						<p class="p-hl-form toggle purchform"  style="display:none;" >(It's OK to estimate the purchase price and down payment.)</p>			
						<p class="p-hl-form toggle refiform" >(It's OK to estimate your home value and current loan balance.)</p>
					<a id="get-custom-rates" name="get-custom-rates" class="btn-bofa btn-bofa-blue btn-bofa-noRight action-buttons cm-conv-start" href="javascript:document.todaysrate.submit();" rel="" onClick="dartFireOnClick('1359940','hliip069','hli_t448');">
					<span>Get rates</span>
					</a>
					<div class="clearboth"></div>
				</li>
			</ul>
			
				<div class="fineprint toggle purchform"  style="display:none;" >What should you know when comparing today's mortgage rates? One thing to understand is the difference between an interest rate and an annual percentage rate (APR). The mortgage interest rate is the interest rate stated on the <a id="Promissory note" class="boa-dialog boa-com-info-layer-link dotted"  rel="glossary-popup-6" name="glossary_promissory_note" href="javascript:void(0);"><span class="ada-hidden">Glossary Term: </span>promissory note</a> which determines your monthly payment amount (<a id="Principal & interest" class="boa-dialog boa-com-info-layer-link dotted"  rel="glossary-popup-9" name="glossary_principal_and_interest" href="javascript:void(0);"><span class="ada-hidden">Glossary Term: </span>principal and interest</a>). An annual percentage rate (or APR) is a measure of the total cost of credit to the borrower over the life of the loan, expressed as a yearly rate. It includes <a id="Closing costs" class="boa-dialog boa-com-info-layer-link dotted" rel="glossary-popup-10" name="glossary_closing_or_settlement_fees" href="javascript:void(0);"><span class="ada-hidden">Glossary Term: </span>closing or settlement fees</a> charged to the borrower in connection with the services provided by the closing agents. Lender's fees, mortgage insurance and other closing costs (&#8220;loan fees&#8221;) are calculated into the loan amount and then spread out over the length of the loan (or the <a id="Term" class="boa-dialog boa-com-info-layer-link dotted" rel="glossary-popup-4" name="glossary_term" href="javascript:void(0);"><span class="ada-hidden">Glossary Term: </span>term</a>) to reach the APR. By making estimated loan fees part of the equation, homebuyers can use APR to better see the true cost of a loan and make a better comparison between mortgage products offered by each lender.<br><br><p>Our mortgage rate tool will give you results for different loan types and allow you to compare mortgage interest rates, APR, <a id="Discount points" class="boa-dialog boa-com-info-layer-link dotted" rel="glossary-popup-5" name="glossary_points" href="javascript:void(0);"><span class="ada-hidden">Glossary Term: </span>points</a> and monthly payments based on the information you entered.</p><p>Reminders about mortgage rates:<ul class="gray-bullet"><li>Mortgage rates can change from day to day, or may even change during the course of a day, depending on economic conditions</li><li>The amount you put down (the <a id="Down payment " class="boa-dialog boa-com-info-layer-link dotted" rel="glossary-popup-8" name="glossary_down_payment" href="javascript:void(0);"><span class="ada-hidden">Glossary Term: </span>down payment</a>) can affect the interest rate you may be offered. Find out about the down payment by reading. <a name="How_much_should_you_put_down" href="/home-loans/mortgage/budgeting-for-home/mortgage-down-payment-amount.go" target="_self">How much should you put down?</a></li><li>Be sure to read the loan assumptions for any advertised mortgage rate. Know the type and term of the loan that may be offered, points, <a id="Credit rating" class="boa-dialog boa-com-info-layer-link dotted" rel="glossary-popup-7" name="glossary_credit_rating" href="javascript:void(0);"><span class="ada-hidden">Glossary Term: </span>credit rating</a> and more.</li></ul></p></div>	
				<div class="fineprint toggle refiform" >What should you know when comparing today's refinance rates? Refinance mortgage rates are just one part of what you should consider when you're thinking about whether refinancing is right for you. First, make sure you've considered why refinancing may benefit you, and then consider other fees you may have to pay as part of the closing process in your overall decision. You can get an idea of your closing costs by comparing <a id="Annual percentage rate (APR) " class="boa-dialog boa-com-info-layer-link dotted" rel="glossary-popup-3" name="glossary_annual_percentage_rates" href="javascript:void(0);"><span class="ada-hidden">Glossary Term: </span>annual percentage rates</a> (APRs), which consist of refinance rates plus estimated loan fees. Our refinance rates calculator will show you mortgage refinance rates, <a id="Discount points" class="boa-dialog boa-com-info-layer-link dotted"  rel="glossary-popup-5" name="glossary_points" href="javascript:void(0);"><span class="ada-hidden">Glossary Term: </span>points</a> and APR for a variety of loan types.<br><br>Remember that home refinance rates can change as market conditions change. In addition, the actual mortgage refinance rate you may be offered will take into account factors specific to your situation, such as your <a id="Credit rating" class="boa-dialog boa-com-info-layer-link dotted"  rel="glossary-popup-7" name="glossary_credit_rating" href="javascript:void(0);"><span class="ada-hidden">Glossary Term: </span>credit rating</a> and points you may pay.</div>
		</form>
	
		<script type="text/javascript">
		
		$(function() {		
			/* Validation rules for the form  */
		
			var hl_trm_form_validation = {
			rules : {
				
					"todaysRateRequestDTO.postalCode" : {
						required : true,
						zipcodeUS : true
					},
					"todaysRateRequestDTO.purchasePrice" : {
						required : true,
						number : true,
						range : [0,2500000],
						LVMax : ["input[name='todaysRateRequestDTO.purchasePrice']","input[name='todaysRateRequestDTO.downPayment']",2000001],
						LVMin : ["input[name='todaysRateRequestDTO.purchasePrice']","input[name='todaysRateRequestDTO.downPayment']",60000],
						LTVWarn : ["input[name='todaysRateRequestDTO.purchasePrice']","input[name='todaysRateRequestDTO.downPayment']",0.8,417000]
						},
					"todaysRateRequestDTO.refinancePurchasePrice" : {
						required : true,
						number : true,
						range : [0,2500000],
						LVMin : ["input[name='todaysRateRequestDTO.refinanceDownPayment']",0,60000],
						LTVRefiWarn : ["input[name='todaysRateRequestDTO.refinancePurchasePrice']","input[name='todaysRateRequestDTO.refinanceDownPayment']",0.8,417000]
						},
					"todaysRateRequestDTO.downPayment" : {
						required : true,
						number : true,
						LVMax : ["input[name='todaysRateRequestDTO.purchasePrice']","input[name='todaysRateRequestDTO.downPayment']",2000001],
						LVMin : ["input[name='todaysRateRequestDTO.purchasePrice']","input[name='todaysRateRequestDTO.downPayment']",60000],
						LTVWarn : ["input[name='todaysRateRequestDTO.purchasePrice']","input[name='todaysRateRequestDTO.downPayment']",0.8,417000]
						},
					"todaysRateRequestDTO.refinanceDownPayment" : {
						required : true,
						number : true,
						range : [0,2000000],
						LVMin : ["input[name='todaysRateRequestDTO.refinanceDownPayment']",0,60000],
						LTVRefiWarn : ["input[name='todaysRateRequestDTO.refinancePurchasePrice']","input[name='todaysRateRequestDTO.refinanceDownPayment']",0.8,417000]
						}
				},
				messages : {
					"todaysRateRequestDTO.postalCode" : {
						zipcodeUS: "Todays_Rates_Full_Error_1||Please enter a ZIP code consisting of exactly 5 numbers.",
						required: 'Todays_Rates_Full_Error_2||<span class="ada-hidden">Property ZIP code: </span>'+'This field is required.'
					},
					"todaysRateRequestDTO.purchasePrice" : {
						required : 'Todays_Rates_Full_Error_3||<span class="ada-hidden"><a id="Purchase price/sales price" class="boa-dialog boa-com-info-layer-link dotted" rel="glossary-popup-2" name="glossary_purchase_price" href="javascript:void(0);"><span class="ada-hidden">Glossary Term: </span>Purchase price</a>: </span>'+'This field is required.',
						number : "Todays_Rates_Full_Error_4||Please enter an amount using only numbers.",
						range : "Todays_Rates_Full_Error_5||For a purchase price more than $2,500,000, please contact a home loans specialist for rate information.",
						LVMax : "Todays_Rates_Full_Error_6||To get rates from this calculator, your loan amount (purchase price minus down payment) needs to be $2,000,000 or less. You can change your estimates or contact a home loans specialist for assistance with a loan amount over $2,000,000.",
						LVMin : "Todays_Rates_Full_Error_7||To get rates from this calculator, your loan amount (purchase price minus down payment) must be at least $60,000. You can change your estimates or contact a home loans specialist for assistance with a loan amount less than $60,000.",
						LTVWarn : "Todays_Rates_Full_Error_8||If you put down at least 20% of the purchase price, you typically won't have to pay for private mortgage insurance (PMI). Also, the amount you put down can influence the interest rate you may be offered."				
					},
					"todaysRateRequestDTO.refinancePurchasePrice" : {
						required : 'Todays_Rates_Full_Error_9||<span class="ada-hidden">Home value: </span>'+'This field is required.',
						number : "Todays_Rates_Full_Error_10||Please enter an amount using only numbers.",
						range : "Todays_Rates_Full_Error_11||For a home value more than $2,500,000, please contact a home loans specialist for rate information.",
						LVMin : "Todays_Rates_Full_Error_12||To get rates from this calculator, your loan balance must be at least $60,000. You can change your estimates or contact a home loans specialist for assistance with a loan balance less than $60,000.",
						LTVRefiWarn : "Todays_Rates_Full_Error_13||Note: This loan balance combined with this home value may require you to carry private mortgage insurance, because the current loan balance is more than 80% of the estimated home value. You can change your estimates or contact a home loans specialist for assistance with a loan balance over 80%."		
					},
					"todaysRateRequestDTO.downPayment" : {
						required : 'Todays_Rates_Full_Error_14||<span class="ada-hidden"><a id="Down payment " class="boa-dialog boa-com-info-layer-link dotted"  rel="glossary-popup-8" name="glossary_down_payment" href="javascript:void(0);"><span class="ada-hidden">Glossary Term: </span>Down payment</a>: </span>'+'This field is required.',
						number : "Todays_Rates_Full_Error_15||Please enter an amount using only numbers.",
		
						LVMax : "Todays_Rates_Full_Error_19||To get rates from this calculator, your loan amount (purchase price minus down payment) needs to be $2,000,000 or less. You can change your estimates or contact a home loans specialist for assistance with a loan amount over $2,000,000. <a target='_self' href='/home-loans/mortgage/budgeting-for-home/mortgage-down-payment-amount.go' name='Mortgage Basics - Budgeting for a Home: How much should you put down?' >Learn about how much you should put down</a>",
						LVMin : "Todays_Rates_Full_Error_20||To get rates from this calculator, your loan amount (purchase price minus down payment) needs to be more than $60,000. You can change your estimates or contact a home loans specialist for assistance with a loan amount less than $60,000. <a target='_self' href='/home-loans/mortgage/budgeting-for-home/mortgage-down-payment-amount.go' name='Mortgage Basics - Budgeting for a Home: How much should you put down?' >Learn about how much you should put down</a>",
						LTVWarn : "Todays_Rates_Full_Error_21||If you put down at least 20% of the purchase price, you typically won't have to pay for private mortgage insurance (PMI). Also, the amount you put down can influence the interest rate you may be offered."
						
					},
					"todaysRateRequestDTO.refinanceDownPayment" : {
						required : 'Todays_Rates_Full_Error_22||<span class="ada-hidden">Current loan balance: </span>'+'This field is required.',
						number : "Todays_Rates_Full_Error_23||Please enter an amount using only numbers.",
						range : "Todays_Rates_Full_Error_24||To get rates from this calculator, your loan balance needs to be $2,000,000 or less. You can change your estimate or contact a home loans specialist for assistance with a loan balance over $2,000,000.",
						LVMin : "Todays_Rates_Full_Error_25||To get rates from this calculator, your loan balance must be at least $60,000. You can change your estimates or contact a home loans specialist for assistance with a loan balance less than $60,000.",
						LTVRefiWarn : "Todays_Rates_Full_Error_26||Note: This loan balance combined with this home value may require you to carry private mortgage insurance, because the current loan balance is more than 80% of the estimated home value. You can change your estimates or contact a home loans specialist for assistance with a loan balance over 80%."
								
					}
				}
				
			};
			
			/** client side validation is a piece of cake */
				$("#hl-trm-form").boaValidate( hl_trm_form_validation );
			
		});
		</script>

	</div>

   <div id="zcf-todays-rates-hl-module" class="hide" rel="hl-trm-purchform-zipcode" style="display: none;">
		<span class="ada-hidden">Beginning of zip code finder dialog layer</span>
   		<h3>ZIP code finder</h3>   
		<div id="zcf-panel-one"> 
		 	<p>Please enter your city and state to find your ZIP code.</p>
			<form id="findzipcode" name="findzipcode" method="post" action="/home-loans/find-zip-code.go">
				<p id="zcf-error">   <span id="zcf-error-response"></span></p>
				<div class="zcf-inputs">
			 		<div class="zcf-city-label">   
			 			<label class="zcf-city" for="zcf-city"><span class="ada-hidden">Look up for </span>City <span class="ada-hidden">in Zip Code Finder</span></label>  
						<input type="text" id="zcf-city" name="zipCodeInfo.city" size="12" />   
					</div>
					
			 		<div class="zcf-state-label">
						<label class="zcf-state" for="zcf-state"><span class="ada-hidden">Look up for </span>State <span class="ada-hidden">in Zip Code Finder</span></label>

<select name="zipCodeInfo.state" id="zcf-state">


    <option value=""
    >(Select)</option>

        <option value="AL">AL</option>
        <option value="AK">AK</option>
        <option value="AZ">AZ</option>
        <option value="AR">AR</option>
        <option value="CA">CA</option>
        <option value="CO">CO</option>
        <option value="CT">CT</option>
        <option value="DE">DE</option>
        <option value="DC">DC</option>
        <option value="FL">FL</option>
        <option value="GA">GA</option>
        <option value="HI">HI</option>
        <option value="ID">ID</option>
        <option value="IL">IL</option>
        <option value="IN">IN</option>
        <option value="IA">IA</option>
        <option value="KS">KS</option>
        <option value="KY">KY</option>
        <option value="LA">LA</option>
        <option value="ME">ME</option>
        <option value="MD">MD</option>
        <option value="MA">MA</option>
        <option value="MI">MI</option>
        <option value="MN">MN</option>
        <option value="MS">MS</option>
        <option value="MO">MO</option>
        <option value="MT">MT</option>
        <option value="NE">NE</option>
        <option value="NV">NV</option>
        <option value="NH">NH</option>
        <option value="NJ">NJ</option>
        <option value="NM">NM</option>
        <option value="NY">NY</option>
        <option value="NC">NC</option>
        <option value="ND">ND</option>
        <option value="OH">OH</option>
        <option value="OK">OK</option>
        <option value="OR">OR</option>
        <option value="PA">PA</option>
        <option value="RI">RI</option>
        <option value="SC">SC</option>
        <option value="SD">SD</option>
        <option value="TN">TN</option>
        <option value="TX">TX</option>
        <option value="UT">UT</option>
        <option value="VT">VT</option>
        <option value="VA">VA</option>
        <option value="WA">WA</option>
        <option value="WV">WV</option>
        <option value="WI">WI</option>
        <option value="WY">WY</option>


</select>					</div>
					
			 		<div class="zcf-mutiple-zip-label">  <label class="zcf-multiple-zip" for="zcf-multiple-zip">County </label>  

<select name="zipCodeInfo.zipcodes" id="zcf-multiple-zip" class="select-bofa">



        <option value="AL">AL</option>
        <option value="AK">AK</option>
        <option value="AZ">AZ</option>
        <option value="AR">AR</option>
        <option value="CA">CA</option>
        <option value="CO">CO</option>
        <option value="CT">CT</option>
        <option value="DE">DE</option>
        <option value="DC">DC</option>
        <option value="FL">FL</option>
        <option value="GA">GA</option>
        <option value="HI">HI</option>
        <option value="ID">ID</option>
        <option value="IL">IL</option>
        <option value="IN">IN</option>
        <option value="IA">IA</option>
        <option value="KS">KS</option>
        <option value="KY">KY</option>
        <option value="LA">LA</option>
        <option value="ME">ME</option>
        <option value="MD">MD</option>
        <option value="MA">MA</option>
        <option value="MI">MI</option>
        <option value="MN">MN</option>
        <option value="MS">MS</option>
        <option value="MO">MO</option>
        <option value="MT">MT</option>
        <option value="NE">NE</option>
        <option value="NV">NV</option>
        <option value="NH">NH</option>
        <option value="NJ">NJ</option>
        <option value="NM">NM</option>
        <option value="NY">NY</option>
        <option value="NC">NC</option>
        <option value="ND">ND</option>
        <option value="OH">OH</option>
        <option value="OK">OK</option>
        <option value="OR">OR</option>
        <option value="PA">PA</option>
        <option value="RI">RI</option>
        <option value="SC">SC</option>
        <option value="SD">SD</option>
        <option value="TN">TN</option>
        <option value="TX">TX</option>
        <option value="UT">UT</option>
        <option value="VT">VT</option>
        <option value="VA">VA</option>
        <option value="WA">WA</option>
        <option value="WV">WV</option>
        <option value="WI">WI</option>
        <option value="WY">WY</option>


</select>			 		</div>
		 		</div>
				 <div class="ex-button-spacer">  
			 		<a class="button-common button-blue" href="javascript:void(0);" rel="zcf-screen-two" id="zcf-screen-two-link"><span>Find <span class="ada-hidden"> Zip Code</span></span></a>  
			 		<a class="button-common button-blue" href="javascript:void(0);" rel="zcf-find-county" id="zcf-find-county-link"><span>Find <span class="ada-hidden"> Zip Code</span></span></a>   
					<a class="button-common button-blue" href="javascript:void(0);" rel="zcf-find-city" id="zcf-find-city-link"><span>Find <span class="ada-hidden"> Zip Code</span></span></a>   
			 		<a class="button-common button-blue" href="javascript:void(0);" rel="zcf-add-zip" id="zcf-add-zip-link"><span>Select</span></a>   
				 </div> 
			</form>   
		</div>   
		<div id="zcf-panel-two"> 
			<p>
				<img src="https://www2.bac-assets.com/pa/global-assets/1.0/graphic/processing-large.gif" alt="Please wait..." />
				Please wait...
			</p>
		</div>
	</div>   
</div>
						<div class="flex-col rt-col" >












	


<div class="cta-module target-sidewell location-bottom">

			<div class="cta focus-call">
				<div class="intro">
					<h3>Start today</h3>
				</div>
		<ul class="options">		
							<li class="call  first ">

									<div class="details">

									<p></p>
										<p class="large">1.866.800.3221</p>
	<p class="small smpad">Mon.&ndash;Fri. 8 a.m.&ndash;10 p.m. ET <br />Sat.&nbsp;8 a.m.&ndash;6:30 p.m. ET</p>
									</div>
							</li>
							<li class="find ">

									<h4><a href="#" name="side-well-find">
									<span class="ada-hidden ada-closed">Show details on how to </span>
									<span class="ada-hidden ada-open" style="display:none;">Hide details on how to </span>
										Meet with us
									<span class="ada-hidden">a mortgage specialist near you</span>
									</a></h4>
									
								<div class="details">
									<p>Find a Lending Specialist</p>
									<form action="https://mortgage.bankofamerica.com/search.aspx" method="GET" id="MLO-sidewell-form" name="MLO-sidewell-form">						
									<label class="ada-hidden" for="cta-find-location">Find a Lending Specialist</label>
									<input type="hidden" name="mode" value="direct">
									<input name="location" placeholder="Enter city or ZIP" type="text" class="text" id="cta-find-location" />
									<input onClick="dartFireOnClick('1359940','hliip069','hli_h834');" type="submit" class="submit" value="" title="Find a loan officer" />
								</form>
								</div>
							</li>
								<li class="chat ">

										<h4><a href="#" name="side-well-chat" onClick="dartFireOnClick('1359940','hliip069','hli_h555');">
											<span class="ada-hidden ada-closed">Show details on how to </span>
											<span class="ada-hidden ada-open" style="display:none;">Hide details on how to </span>
											Chat with us
											 <span class="ada-hidden">with a mortgage specialist</span>
										</a></h4>

										 <div class="details">
											<div id="lpButtonDiv-Target-HomeLoans-SideWell"></div>							
										 </div>
								</li>
							<li class="email ">
								
									<h4><a href="#" name="side-well-getacallback">
									<span class="ada-hidden ada-closed">Show details on how to </span>
									<span class="ada-hidden ada-open" style="display:none;">Hide details on how to </span>
									Get a call back 
									 <span class="ada-hidden">from a mortgage specialist</span> 
									</a></h4>
						
								<div class="details">
									<p></p>
	<p class="small"></p>
									<p><a onClick="dartFireOnClick('1359940','hliip069','hli_h106');" name="side-well-getacallback" href="/home-loans/home-loan-contact-form-A.go?subCampCode=98983&loanPurpose=refinance">Have a lending specialist call you on your schedule
									<span class="ada-hidden"> from a mortgage loan officer</span></a></p>
								</div>
							</li>


							<li class="qualify ">
										<h4><a href="#" name="side-well-applyonline">
											<span class="ada-hidden ada-closed">Show details on how to </span>
											<span class="ada-hidden ada-open" style="display:none;">Hide details on how to </span>
											Begin online
										</a></h4>

									<div class="details">
										<p></p>									
											<p class="cta btn"><a name="side-well-applyonline1" onClick="dartFireOnClick('1359940','hliip069','hli_h434');" href="https://secure.bankofamerica.com/applynow/initialize-workflow.go?requesttype=MPQ&subCampCode=98983&loanPurpose=refinance" class='btn-bofa btn-bofa-blue btn-bofa-small btn-bofa-noRight click-normal'>Start now
										<span class="ada-hidden"> for a mortgage</span></a></p>
									</div>
							</li>
		</ul>
	</div>
</div>
<div class="side-well-module"> </div>
</div>
						<div class="clearboth"></div>
					</div>
					<div class="footer">
						<div class="footer-top">&nbsp;</div>
						<div class="footer-inner">






<div class="hl-power-footer-module">
	<div class="fsd-flex-skin sup-ie">
		<div class="breadcrumbs">
		<div itemscope itemtype="http://schema.org/BreadcrumbList">
								<div itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
										<a itemprop="item" class="bold-bc" href="http://www.bankofamerica.com/" name="bank-of-america-breadcrumbs" target="_self">
										<span itemprop="name">Bank of America</span>
										<meta itemprop="position" content="1" /></a>
								</div>
								<div itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
										<a itemprop="item" href="/home-loans/overview.go" name="home-loans-breadcrumbs" target="_self">
										<span itemprop="name">Home Loans</span>
										<meta itemprop="position" content="2" /></a>
								</div>
				   	  			    
				     
				    
				    		
				    			<div itemprop="itemListElement" itemscope itemtype=http://schema.org/ListItem>
								<a itemprop="item" href="/home-loans/refinance/overview.go" name="refinance-link-breadcrumbs" target="_self">
									<span itemprop="name">Refinance</span>
									<meta itemprop="position" content="3"/>
								</a>
							</div>				    		
				    		    
				    <div class="breadcrumb-last-item" itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
					<span itemprop="name">Today's Refinance Rates & Payments Calculator</span>
					<meta itemprop="position" content="4" />
				    </div>		
			
<div class="clearboth"></div>
</div>
</div>

<div class="pf-columns">
			  
			  
				  	<div class="pf-col">
				  
						<a href="/mortgage/refinance/" name="rates-and-loans-power-footer" class="bold" target="_self">Rates & Loans</a>
								
									<a href="/mortgage/refinance-rates/"  name="refinance-rates-power-footer" target="_self">Refinance Rates</a>
								
									<a href="/mortgage/fixed-rate-refinance-loans/"  name="fixed-rate-refinance-loans-power-footer" target="_self">Fixed-Rate Refinance Loans</a>
								
									<a href="/mortgage/adjustable-rate-refinance-loans/"  name="adjustable-rate-refinance-loans-power-footer" target="_self">Adjustable-Rate Refinance Loans</a>
								
									<a href="/home-loans/refinance/fha-va-refinance.go"  name="fha-and-va-refinance-loans-power-footer" target="_self">FHA & VA Refinance Loans</a>
					</div>   
			  
			  
				  	<div class="pf-col">
				  
									<span class="bold">Calculators</span>
								
									<a href="/home-loans/refinance/custom-refinance-rates-today.go"  name="refinance-calculator-power-footer" target="_self">Refinance Calculator</a>
								
									<a href="http://loans.bankofamerica.com/en/tools/affordability-snapshot.html?standalone=y" name="affordability-snapshot-power-footer" target="Pop-up medium" onClick="return displayPopup('http://loans.bankofamerica.com/en/tools/affordability-snapshot.html?standalone=y');":Affordability Snapshot"> Affordability Snapshot</a>
								
									<a href="http://realestatecenter.bankofamerica.com/tools/marketvalue4.aspx"  name="home-value-estimator-power-footer" target="_self">Home Value Estimator</a>
					</div>   
			  
			  
				  	<div class="pf-col">
				  
									<span class="bold">Learn About Refinancing</span>
								
									<a href="/home-loans/refinance/should-refinance-mortgage.go#0"  name="reasons-to-refinance-power-footer" target="_self">Reasons to Refinance</a>
								
									<a href="/home-loans/refinance/refinance-tips-before-you-refinance.go#1"  name="before-you-refinance-power-footer" target="_self">Before You Refinance</a>
								
									<a href="/home-loans/refinance/understanding-new-payment.go#2"  name="understanding-your-new-payment-power-footer" target="_self">Understanding Your New Payment</a>
								
									<a href="/home-loans/refinance/how-to-refinance-mortgage-applying-refinance.go#3"  name="applying-for-a-refinance-loan-power-footer" target="_self">Applying for a Refinance Loan</a>
					</div>   
			  
			  
				  	<div class="pf-col">
				  
						<a href="/home-loans/service.go" name="manage-your-loan-power-footer" class="bold" target="_self">Manage Your Loan</a>
									<a onClick="dartFireOnClick('1359940','hliip069','hli_h434');" href="https://secure.bankofamerica.com/applynow/initialize-workflow.go?requesttype=MPQ&subCampCode=98983&loanPurpose=refinance" name="get-prequalified-power-footer" target="_self">Get prequalified</a>
									<a href="/login/sign-in/signOnScreen.go" onClick="dartFireOnClick('1359940','hliip069','hli_h298');" name="sign-in-t-your-account-power-footer" target="_self">Sign in to Your Account</a>
								
									<a href="/home-loans/home-loan-navigator.go" onClick="dartFireOnClick('1359940','hliip069', 'hli_h743');" name="check-your-application-status-submit-documents-online-power-footer" target="_self">Check Your Application Status/Submit Documents Online</a>
								
									<a href="http://homeloanhelp.bankofamerica.com/"  name="get-help-with-payment-difficulties-power-footer" target="_self">Get Help with Payment Difficulties</a>
								
									<a href="/contactus/contactus.go?topicId=mrtg_home_equity" onClick="dartFireOnClick('1359940','hliip069','hli_h826');" name="contact-us-about-your-home-loan-power-footer" target="_self">Contact Us About Your Home Loan</a>
					</div>   
			  
			  
			  
		  <div class="clearboth"></div>
    </div>

</div>
</div>



 



		<div class="global-footer-module">
			<div class="fsd-skin">

				<div class="footer-bottom-left" style="float:left;max-width:66%;">
	    			<div class="gf-links">	          	
						
					
									
									<a  target="_self" href="/" 
									    name="Home_Page">Home
									</a>
									
						
					
									
									<a  target="_self" href="/privacy/overview.go" 
									    name="Privacy_Security">Privacy & Security
									</a>
									
						
					
									
									<a  target="_self" href="http://www.bankofamerica.com/careers/" 
									    name="Careers_Link">Careers
									</a>
									
						
					
									
									<a  target="_self" href="/sitemap/personal.go" 
									    name="Site_Map">Site Map
									</a>
									
						
					
									<a href="javascript:void(0);" class="gf-last-link boa-dialog boa-com-info-layer-link" name="global_footer_ad_practices_lnk" rel="global_footer_ad_practices">Advertising Practices</a>
								<div id="global_footer_ad_practices" class="hide">
									<h3>Advertising Practices</h3>
										<p>We strive to provide you with information about products and services you might find interesting and useful. Relationship-based ads and online behavioral advertising help us do that.</p>
<p>Here's how it works: We gather information about your online activities, such as the searches you conduct on our Sites and the pages you visit. This information may be used to deliver advertising on our Sites and offline (for example, by phone, email and direct mail) that's customized to meet specific interests you may have.</p>
<p>If you prefer that we do not use this information, you may <a onclick="$('.ui-dialog').remove();" name="WebsiteAdPractices_OptOut" href="/privacy/online-privacy-notice.go#advertising-on-our-sites" target="_blank">opt out of online behavioral advertising</a>. If you opt out, though, you may still receive generic advertising. In addition, financial advisors/Client Managers may continue to use information collected online to provide product and service information in accordance with account agreements.</p>
<p>Also, if you opt out of online behavioral advertising, you may still see ads when you sign in to your account, for example through Online Banking or MyMerrill. These ads are based on your specific account relationships with us.</p>
<p>To learn more about relationship-based ads, online behavioral advertising and our privacy practices, please review the <a onclick="$('.ui-dialog').remove();" name="WebsiteAdPractices_PrivacyNotice" href="/privacy/online-privacy-notice.go" target="_blank">Bank of America Online Privacy Notice</a> and our <a onclick="$('.ui-dialog').remove();" name="Online-privacy-faqs" href="/privacy/faq/online-privacy-faq.go" target="_blank">Online Privacy FAQs</a>.</p>
								</div>
						<div class="clearboth"></div>
	    			</div>
	      			<p>Bank of America, N.A. Member FDIC. <a title=" Equal Housing Lender information. Link opens new window." onclick="window.open('/help/equalhousing_popup.go','newwin','width=640,height=371,scrollbars=yes,resizable=yes,left=35,top=161'); return false;" name="Equal_Housing_Lender" href="/help/equalhousing_popup.go" target="_blank">Equal Housing Lender<img src="https://www2.bac-assets.com/content/images/ContextualSiteGraphics/Logos/en_US/icon_equal_housing_lender.gif" alt="" width="14" height="9" /></a><br />&copy; 2017 Bank of America Corporation. All rights reserved. Credit and collateral are subject to approval. Terms and conditions apply. This is not a commitment to lend. Programs, rates, terms and conditions are subject to change without notice.</p>
         		</div>
         		<div class="footer-social-container" style="float:right;max-width:30%;padding-left:50px;padding-top:19px;">




<div class="boa-social-loader" data-loaded="false" data-platform="borneo"  data-options=''></div>

         		</div>
         		<div class="clearboth"></div>
  			</div>
		</div>




 

<script type="text/javascript">
var axel = Math.random()+"";var a = axel * 10000000000000;document.write('<iframe title="iFrame used for layout purpose" src="https://1359940.fls.doubleclick.net/activityi;src=1359940;type=hliip069;cat=hli_t231;ord=1;num=' + a + '?;num='+ a + '?" width="1" height="1" frameborder="0" style="display:none;"></iframe>');
</script>
<noscript>
	<iframe title="iFrame used for layout purpose" src="https://1359940.fls.doubleclick.net/activityi;src=1359940;type=hliip069;cat=hli_t231;ord=1;num=1?" width="0" height="0" frameborder="0" style="display:none;"></iframe>
</noscript>


					<div id="glossary-popup-1" class="hide tabs-main-content">
						<h3>How much should you put down?</h3>
						<p>If you put down at least 20% of the purchase price, you typically won't have to pay for private mortgage insurance (PMI). And when you put down more, you're more likely to qualify for lower interest rates. Putting down more money will likely save you more money over the life of the loan. Learn more about <a id="mortgage-down-payments-lnk" title="Mortgage Down Payments" name="mortgage-down-payments-link" href="/home-loans/mortgage/budgeting-for-home/mortgage-down-payment-amount.go" target="_self">mortgage down payments.</a></p>
					</div>
					<div id="glossary-popup-2" class="hide tabs-main-content">
						<h3>Purchase price/sales price</h3>
						<p>The total amount paid by a buyer to a seller for the purchase of property.</p>
					</div>
					<div id="glossary-popup-3" class="hide tabs-main-content">
						<h3>Annual percentage rate (APR) </h3>
						<p>The annual cost of a loan to a borrower. Like an interest rate, the APR is expressed as a percentage. Unlike an interest rate, however, it includes other charges or fees (such as mortgage insurance, most closing costs, discounts points and loan origination fees) to reflect the total cost of the loan. The Federal Truth in Lending Act requires that every consumer loan agreement disclose the APR. Since all lenders must follow the same rules to ensure the accuracy of the APR, borrowers can use the APR as a good basis for comparing the costs of similar credit transactions.</p>
					</div>
					<div id="glossary-popup-4" class="hide tabs-main-content">
						<h3>Term</h3>
						<p>The number of years it will take to pay off a loan. The loan term is used to determine the payment amount, repayment schedule and total interest paid over the life of the loan.</p>
					</div>
					<div id="glossary-popup-5" class="hide tabs-main-content">
						<h3>Discount points</h3>
						<p>See: <a href="#P_id_5">Points</a></p>
					</div>
					<div id="glossary-popup-6" class="hide tabs-main-content">
						<h3>Promissory note</h3>
						<p>A written promise to repay a specified amount over a specified period of time.</p>
					</div>
					<div id="glossary-popup-7" class="hide tabs-main-content">
						<h3>Credit rating</h3>
						<p>A numeric expression of creditworthiness based upon an individual&rsquo;s present financial condition and past credit history.</p>
					</div>
					<div id="glossary-popup-8" class="hide tabs-main-content">
						<h3>Down payment </h3>
						<p>The amount of cash you pay toward the purchase of your home to make up the difference between the purchase price and your mortgage loan. Down payments often range between 5% and 20% of the sales price depending on many factors, including your loan, your lender and your credit history. <a href="https://www.bankofamerica.com/home-loans/mortgage/budgeting-for-home/mortgage-down-payment-amount.go" name="down pay" target="_self">How much of a down payment should you make?</a></p>
					</div>
					<div id="glossary-popup-9" class="hide tabs-main-content">
						<h3>Principal & interest</h3>
						<p>The principal is the amount of money borrowed on a loan. The interest is the charge paid for borrowing money. Principal and interest account for the majority of your mortgage payment, which may also include escrow payments for property taxes, homeowners insurance, mortgage insurance and any other costs that are paid monthly, or fees that may come due.</p>
					</div>
					<div id="glossary-popup-10" class="hide tabs-main-content">
						<h3>Closing costs</h3>
						<p>Closing costs, also known as settlement costs, are the costs incurred when obtaining your loan. For new purchases, these costs also include ownership transfer of any collateral property from the seller to you. Costs may include and are not limited to: attorney's fees, preparation and title search fees, discount points, appraisal fees, title insurance, and credit report charges. They are typically about 3% of your loan amount, and are often paid at closing or just before your loan closes.</p> <p>Funds often needed to close a loan, such as homeowners insurance, property taxes, and <a href="/home-loans/home-equity/glossary.go#alp-E">escrow impound account</a> funds, aren't included in closing costs and are considered separate. You should be prepared to pay these costs before your loan closes.</p>
					</div>
					<div id="glossary-popup-11" class="hide tabs-main-content">
						<h3>How much should you put down?</h3>
						<p>If you put down at least 20% of the purchase price, you typically won&rsquo;t have to pay for private mortgage insurance (PMI). Also, the amount you put down can influence the interest rate you may be offered.</p>
					</div>
					<div id="glossary-popup-12" class="hide tabs-main-content">
						<h3>Private mortgage insurance (PMI)</h3>
						<p>See: <a href="#M_id_6">Mortgage insurance</a></p>
					</div>
					<div id="glossary-popup-13" class="hide tabs-main-content">
						<h3>Fixed-rate mortgage</h3>
						<p>A home loan with a predetermined fixed interest rate for the entire term of the loan.</p>
					</div>
					<div id="glossary-popup-14" class="hide tabs-main-content">
						<h3>Interest rate</h3>
						<p>Cost for the use of a loan, usually expressed as a percentage of the loan, paid over a specific period of time. The interest rate does not include fees charged for the loan. See also: annual percentage rate (APR).</p>
					</div>
					<div id="glossary-popup-15" class="hide tabs-main-content">
						<h3>Closing costs</h3>
						<p>Closing costs, also known as settlement costs, are the costs incurred when obtaining your loan. For new purchases, these costs also include ownership transfer of any collateral property from the seller to you. Costs may include and are not limited to: attorney's fees, preparation and title search fees, discount points, appraisal fees, title insurance and credit report charges. They are typically about 3% of your loan amount, and are often paid at or just before your loan closes.</p> <p>Funds often needed to close a loan, such as homeowners insurance, property taxes, and escrow impound account funds, aren't included in closing costs and are considered separate. You should be prepared to pay these costs before your loan closes.</p>
					</div>
					<div id="glossary-popup-16" class="hide tabs-main-content">
						<h3>Adjustable-rate mortgage (ARM)</h3>
						<p>A mortgage or home equity loan in which your interest rate and monthly payments may change periodically during the life of the loan, based on the fluctuation of an index. Lenders may charge a lower interest rate for the initial period of the loan. Most ARMs have a rate cap that limits the amount the interest rate can change, both in an adjustment period, and over the life of the loan. Also called a variable-rate mortgage.</p>
					</div>
					<div id="glossary-popup-17" class="hide tabs-main-content">
						<h3>Federal Housing Administration (FHA)</h3>
						<p>An agency of the Department of Housing and Urban Development. The FHA provides mortgage insurance for certain residential mortgages. It also sets standards for underwriting these mortgages and for construction of homes secured by these mortgages. <a href="javascript:void(0);" class="com-interstitial-modal-link" name="FHA" rel="https://www.fha.com/fha_requirements_debt" target="_self">Visit the FHA website</a></p>
					</div>
					<div id="glossary-popup-18" class="hide tabs-main-content">
						<h3>Department of Veterans Affairs</h3>
						<p>An agency of the federal government that guarantees residential mortgages made to eligible veterans of the military services. The guarantee protects the lender against loss and thus encourages lenders to make mortgages to veterans.</p>
					</div>
		



 

	<script type="text/javascript" src="https://www2.bac-assets.com/pa/global-assets/external/coremetrics/hp/eluminate.js"></script>
	<script type="text/javascript" src="https://www2.bac-assets.com/pa/global-assets/external/coremetrics/hp/cmdatatagutils.js"></script>
	<script type="text/javascript" src="https://www2.bac-assets.com/pa/components/modules-app/APS-home-loans/hl-coremetrics-module/1.0/script/hl-coremetrics-module-site-skin.js"></script>   


	
	
	
	
	
	
	
	
	
	
	
	
			
    

    
    
	<script type="text/javascript">
		var Options = {
			state : getCookie("state"),
			preferred_customer : getCookie("Hp_pf_exp"),
			olb_customer : getCookie("BA_0021"),
			cust_id : getCookie("BA_0020"),
			eventID: 'App View to submit LF3a_Mkt_98983',
			eventIdStart:'App View to Start LF3a_Mkt_98983',
			pageID: 'HL:Tool:Refi:Rates;TodaysRates',
			convCategoryID:'HL:Tool:Refi:Rates;TodaysRates',
			productId:'Refinance',
			productName:'Refinance',
			cmCategoryId:'HL:Tool:Refi:Rates',
			productCategoryId:'HL:Refi',
			cmEventID:'Todays Refi Rates',
			ALT_CM_eventID:'',
			showProductViewTag : 'false',
			showShop5Tag : 'false',
			showConvEventTag1 : 'true',
			showConvEventTag2 : 'false',
			CM_help : 'false',
			CM_error : 'false',
			CM_tool : 'false',
			CM_flash : 'false',
			CM_subcmpgnCode : '98983',
			CM_pageCount : 'false',
			selectedProduct : '',
			popupPageID : 'PVParamsMissing',
			popupCmCategoryID:'PVParamsMissing',
			errorObj : new Array()
			
		};
		    			
		$(function(){ 
			$.extend( true, hl_calc_coremetrics_module.options, Options );
			hl_calc_coremetrics_module.init(); 
		});
	</script>
			<div itemscope="itemscope" itemtype="http://schema.org/WebPage">
					<span style="display:none" itemprop="name">Refinance Rates Today from Bank of America</span>
					<a style="display:none" itemprop="url" href="https://www.bankofamerica.com/home-loans/refinance/custom-refinance-rates-today.go"></a>
					<span style="display:none" itemprop="description">Get a custom refinance mortgage rate and estimated payment based on today's refinance rates from Bank of America.</span>
					<img style="display:none" class="no-stretch" itemprop="image" alt="Refinance Rates Today from Bank of America" src="https://www.bankofamerica.com/content/images/ContextualSiteGraphics/Logos/en_US/Bank_of_America_Flagscape_71x71.gif">
					<span style="display:none" itemprop="keywords">refinancing rates, refinance rates today, refinancing rates today, refinance rate today</span>
			</div>
</div>
					</div>
				</div>
			</div>
		</div>
	</body>	
</html>

