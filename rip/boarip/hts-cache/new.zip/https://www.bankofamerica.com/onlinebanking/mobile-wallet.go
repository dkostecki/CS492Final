
 

				<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
				<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
				<head>


<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta http-equiv="content-type" content="text/html;charset=utf-8">


			<link rel="canonical" href="https://www.bankofamerica.com/onlinebanking/mobile-wallet.go"/>
        <link REL="alternate" HREF="http://mobilewallet.bankofamerica.com/" MEDIA="only screen and (max-width: 640px)"/>                  
        <link REL="alternate" HREF="http://mobilewallet.bankofamerica.com/" MEDIA="handheld"/>                  







<title>Use Bank of America Credit and Debit Cards with Apple Pay�</title>

<meta name="Description" CONTENT="It's easy to add your Bank of America credit and debit cards to Apple Pay� to securely make purchases with your mobile device.">
<meta name="Keywords" CONTENT="mobile wallet, virtual credit card, virtual debit card, Apple Pay�">

					<meta name="twitter:title" CONTENT="Use Bank of America Credit and Debit Cards with Apple Pay�" />
					<meta name="twitter:card" CONTENT="summary" />
					<meta name="twitter:url" CONTENT="https://www.bankofamerica.com/onlinebanking/mobile-wallet.go" />
					<meta name="twitter:image" CONTENT="https://www.bankofamerica.com/content/images/ContextualSiteGraphics/Logos/en_US/Bank_of_America_Flagscape_71x71.gif" />
					<meta name="twitter:description" CONTENT="It's easy to add your Bank of America credit and debit cards to Apple Pay� to securely make purchases with your mobile device." />
					<meta name="twitter:site" CONTENT="@BofA_Tips" />
				<meta property="og:title" CONTENT="Use Bank of America Credit and Debit Cards with Apple Pay�" />
				<meta property="og:type" CONTENT="website" />
				<meta property="og:url" CONTENT="https://www.bankofamerica.com/onlinebanking/mobile-wallet.go" />
				<meta property="og:image" CONTENT="https://www.bankofamerica.com/content/images/ContextualSiteGraphics/Logos/en_US/Bank_of_America_Flagscape_71x71.gif" />
				<meta property="og:description" CONTENT="It's easy to add your Bank of America credit and debit cards to Apple Pay� to securely make purchases with your mobile device." />
				<meta property="og:site_name" CONTENT="Bank of America" />
<link rel="shortcut icon" href="https://www2.bac-assets.com/pa/global-assets/1.0/graphic/favicon.ico" type="image/ico" />


	


			<script src="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/Global/1.0/script/tealeafbundle.js" type="text/javascript"></script>
	
	   
			<link rel="stylesheet" type="text/css" href="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/PBI-WEB/2017.03.0/style/pbi-web-jawr.css" media="all" />
			<link rel="stylesheet" type="text/css" href="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/PBI-WEB/2017.03.0/style/pbi-web-jawr-print.css" media="print" />
			<script src="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/PBI-WEB/2017.03.0/script/pbi-web-jawr.js" type="text/javascript"></script>

<script type="text/javascript">
(function() {
	if (typeof mboxUpdate == "function") {
		var windowURL = window.location.href
	    windowURL = windowURL.slice( windowURL.indexOf('.')+1);
		windowURL = windowURL.split( '?' )[0];
		windowURL = windowURL.toLowerCase();
		//alert(windowURL);
		if (
		    //If no mboxes on page, mbox count will be < 1
		    (mboxFactoryDefault.getMboxes().length() < 1) &&  
			
			//Also check for high-volume pages that do not need global logging
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go") &&
			(windowURL != "bankofamerica.com/myaccounts/signin/signin.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/entry/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signonscreen.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatechallengeanswer.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatePassword.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/mobile/banking.go")&&
			(windowURL != "bankofamerica.com/content/preload/olb-myaccount-preload-jawr-module.htm")
			)
		{

			var mboxDiv = document.createElement("div");
			mboxDiv.id = "adobe_touch_clarity_replacement";
			mboxDiv.style.display = "none";
			if (document.body && document.body.firstChild) document.body.insertBefore(mboxDiv,document.body.firstChild);
			mboxDefine(mboxDiv.id,'bac_global_bottom');
			mboxUpdate('bac_global_bottom');
		}
	}	
})();
</script>

	
			<script>
				var boaPageDataJS = {};
					boaPageDataJS.isLLE = "false";
			</script>
				<style>body{display:none;}</style>
	</head>		

	<body class="fsd-layout-body">	

				<script type="text/javascript">if(self == top){var theBody=document.getElementsByTagName("body")[0];theBody.style.display="block";}else{top.location=self.location;}</script>
				<noscript><style>body{display:block;}</style></noscript>
					<a class='ada-hidden ada-visible-focus' href='#skip-to-h1' id='ada-skip-link'>Skip to main content</a>
		<div class="fsd-layout fsd-2c-700lt-layout fsd-full-width">
			<div class="fsd-border">
				<div class="center-content">
					<div class="header">
		  



<script language="javascript" src="/pa/components/modules/tag-manager-module/1.1/script/tag-manager-module-borneo-global-skin.js"></script>
<script>

(function() {
  var fireCallback = function( cb ) {
    if ( typeof cb === "function" ) cb();
  };
  
  function ddoPopulateBase( callback ) {
    try {
		  var DDO = window.digitalData,
		  	bactm_mergeDDO = function( newDDO, priorDDO ) {
		  		if( typeof priorDDO === "undefined" ) {
				  	priorDDO = digitalData || {};
				  }

			    for (var l in newDDO) {
			        if (typeof priorDDO[l] === "undefined") {
			            priorDDO[l] = newDDO[l];
			        }
			        if (newDDO[l] !== null) {
			            if (typeof newDDO[l] === "object") {
			                bactm_mergeDDO(newDDO[l], priorDDO[l]);
			            } else {
			                priorDDO[l] = bactm_validateValue( newDDO[l] ) ? newDDO[l] : priorDDO[l];
			            }
			        }
			    }

			    return priorDDO;
				},
				bactm_olb3rdPartyId = "null";

			if (typeof DDO === "undefined") {
				var simpleDDO = { page: { pageInfo:[{ pageID: null }], attributes: {}, category: { primaryCategory: null }}};

				DDO = (typeof digitalData === "object") ? digitalData : simpleDDO; 
			}

				DDO = bactm_mergeDDO( {pageInstanceID:"notprod",load_coremetrics:false,load_opinionlabs:false,load_touchcommerce:true,load_audiencemanager:true,page:{pageInfo:[{pageID:null,destinationURL:null,referringURL:null,issueDate:null,language:null,segmentValue:null,appName:null,appStepNumber:null,appStepName:null,attr:"-_--_--_--_--_--_--_--_--_--_--_--_--_--_-"}],category:{primaryCategory:null,addlCategory:null,pageType:null},attributes:{searchString:null,searchResults:null,olbSessionID:null,subCampaignCode:null,DARTUrl:null,stateCookie:null,SASIEnabled:false,needOLBcookie:false,standardDART:[],standardDARTes:[],clickDART:[],clickDARTes:[],gaId:[],chat:{account_type:null,boa_associate:null,boa_retiree:null,customer_lob:null,customer_segment:null,data:null,email_campaign:null,entitlement_code:null,error_category:null,error_count:null,first_login:null,inqSalesProductTypes:{},invitation_background:null,invitation_template:null,referral_campaign:null,getStateValue:false,cust_fn:null,cust_ln:null,target:null}}},user:{segment:null,online_id:null,preferred_rewards_tier:null,olb3rdpartyid:null},version:"BAC_0.12"}, DDO );

			DDO.page.pageInfo[0].pageID = "OSP:Content:OLB;mobile-wallet";
			DDO.page.category.primaryCategory  = "OSP:Content:OLB";
			DDO.page.pageInfo[0].language = "en-US";
			DDO.page.attributes.olbSessionID = "null";
			DDO.page.attributes.SASIEnabled =  "false";
			if (typeof DDO.user != "undefined" && typeof DDO.user.olb3rdpartyid != "undefined") {
				DDO.user.olb3rdpartyid = bactm_olb3rdPartyId;
			}

			window.utag_data = {};
			window.bactm_envSelector = bactm_setTMLib();
			window.digitalData = DDO;

      return fireCallback( callback );

    } catch(e) { }
  }
	if( window.boa && window.boa.digitalData ) {
    window.boa.digitalData.register( ddoPopulateBase );
	}
	else {
	  // Handle scenario where the header isn't available (and thus the default digitalData object and utag loader are missing).
	  //
		var writeScript = function(a,b,c,d){
			a='//tags.tiqcdn.com/utag/bofa/main/' + bactm_envSelector + '/utag.js';
			b=document;
			c='script';
			d=b.createElement(c);
			d.src=a;
			d.type='text/java'+c;
			d.async=true;
			a=b.getElementsByTagName(c)[0];
			a.parentNode.insertBefore(d,a);
		};

		ddoPopulateBase( writeScript );
	}
})();			
</script>




 


<div class="header-module">
	<div class="text-w-logo-skin">
		<div class="header-left">
	  
			<div itemscope itemtype="http://schema.org/Corporation" class="bofa-logo">
				<a itemprop="url" name="anc-digital-wallet" title="Bank of America" href="/">
					<img itemprop="logo" height="28" width="221" 
					     alt="Bank of America" src="https://www2.bac-assets.com/content/images/ContextualSiteGraphics/Logos/en_US/boa_logo.gif"/>
				</a>
			</div>
				<div class="product" data-font="cnx-regular">Digital Wallet</div>
			
			<div class="clearboth"></div>

		</div>
		
		<div class="header-right">
			<ul class="header-links">
			
				
					
				
							<li class="sign-in">
		<a					href="/sitemap/hub/signin.go" target="_self"
		name="Sign_In">Sign In</a> 
							</li>
					
				
							<li>		<a					href="/" target="_self"
		name="Home_Header">Home</a> 
</li>
					
				
							<li>		<a					href="http://locators.bankofamerica.com/locator/locator/LocatorAction.do" target="_self"
		name="Locations">Locations</a> 
</li>
					
				
							<li>		<a					href="/contactus/contactus.go" target="_self"
		name="Contact_Us">Contact Us</a> 
</li>
					
				
							<li class="last-link">	
		<a					href="/onlinebanking/apple-pay-faqs.go" target="_self"
		name="Help">Help</a> 
							</li>
			</ul>
			
			<div class="clearboth"></div>

			<!-- include search-dotcom-util -->



<div class="header-search nlh">
  
  <div class="nav-search">
    <form class="search-form" action="https://secure.bankofamerica.com/myaccounts/public/search-results/unAuthenticatedSearch.go" data-js="/pa/components/utilities/search-util/1.0/script/nav-search.min.js" data-css="/pa/components/utilities/search-util/1.0/style/nav-search.css" data-text-unavailable="Search Currently Unavailable">
      <div class="search-input-container cf" data-icon="search">
        <label for="nav-search-query" class="ada-hidden">Search Term</label>
        <input type="text" placeholder="How can we help you?" name="query" class="search-query" id="nav-search-query" 
          maxlength="99" rel="Search" autocomplete="off"><input type="submit" alt="Search" title="Search" value="Submit Search" name="Search Module - Top Result – Search Button" class="submit track-me">
      </div>
    </form>
  </div>

</div>

		</div>

 		<div class="clearboth"></div>
 	</div>
</div>

<div class="page-title-fsd-module h-100" id="skip-to-h1">
	<div class="standard-red-skin sup-ie">
			<h1 data-font="cnx-regular">Apple Pay�</h1>
	</div>
</div>



<div class="digital-wallet-module">
	<div class="banner-bg-skin">
        <div class="content-wrapper" style="background-image:url(/content/images/ContextualSiteGraphics/CreditCardArt/en_US/CardImages/_bac_cards/digital-wallet-apple-pay-banner4.png)">
		<img src="/content/images/ContextualSiteGraphics/CreditCardArt/en_US/CardImages/_bac_cards/apple_pay_logo.jpg" alt="Apple Pay Logo"/>
           <h2 data-font="cnx-medium">Shop on the go with Apple Pay&reg;</h2>
          <p>It&rsquo;s easy to add your Bank of America<sup>&reg;</sup> credit and debit<br />cards to Apple Pay to conveniently make purchases using your<br />iPhone<sup>&reg;</sup> and Apple Watch<sup>&reg;</sup>.<a href="#footnote1" name="1"><span class="ada-hidden">Footnote</span><sup>1</sup></a></p>
			<a href="javascript:void(0);" onclick="return dartFireOnClickSpecial('1359940','bacal484','2014_03z',this.href);" class="btn-bofa btn-bofa-large btn-bofa-red btn-bofa-noRight new-window-hover mrt-10 vendor-interstitial-modal-link" name="Interstitial_Open_Learn_More_About_Apple_Pay_On_iPhone_6" rel="/onlinebanking/nickel-wallet.go"><span>Learn more about Apple Pay</span></a>
			</div>
    </div>
</div>




<div class="digital-wallet-module">
			<div id="dwm-twocol-txt" class="details-skin">
				<div class="lt-col">
					<h3 class="cnx-light">Convenient</h3>
				</div>
				<div class="rt-col">With Apple Pay, you can easily make purchases at participating merchants with virtual cards on your iPhone<sup>&reg;</sup> and Apple Watch<sup>&reg;</sup>. While Apple Pay offers an exciting way to make purchases on the go, you still get all the rewards, benefits and protections your card may provide.</div>
				<img alt="" src="/content/images/ContextualSiteGraphics/CreditCardArt/en_US/CardImages/_bac_cards/Convenient.png"/>
				<div class="clear-both"></div>
			</div>
			<div id="dwm-three-col-info" class="details-skin">
					<h3 class="cnx-light">Simple</h3>
				<div class="three-col-image first">
					<h4 data-font="cnx-light">1. Add</h4>
					<p>your eligible Bank of America credit and debit cards from our Mobile Banking app<a href="#footnote2" name="2"><span class="ada-hidden">footnote</span><sup>2</sup></a> or to Apple Wallet on your iPhone.</p>
					<img src="/content/images/ContextualSiteGraphics/CreditCardArt/en_US/CardImages/_bac_cards/Simple1.jpg"/>
				</div>
				 <div class="three-col-image center">
					<h4 data-font="cnx-light">2. Pay</h4>
					<p>by holding your iPhone or<br />Apple Watch near the reader<br />at participating merchants.</p>
					<img src="/content/images/ContextualSiteGraphics/CreditCardArt/en_US/CardImages/_bac_cards/Simple2.jpg"/>
				</div>
				 <div class="three-col-image last">
					<h4 data-font="cnx-light">3. Manage</h4>
					<p>your <a href="javascript:void(0);" id="virtual-cards" class="boa-dialog boa-com-info-layer-link" rel="glossary-popup-1">virtual cards</a> and control access in Apple Pay; review card activity in <a href="/login/sign-in/signOnScreen.go" name="Online_Banking" target="_new">Online</a> or Mobile Banking.</p>
					<img src="/content/images/ContextualSiteGraphics/CreditCardArt/en_US/CardImages/_bac_cards/Simple-graphic-3.png"/>
				</div>
				<div class="clear-both"></div>
			</div>
			<div id="dwm-image-txt" class="details-skin">
				<div class="dw-secure-img-txt">
					<h3 class="cnx-light">Secure</h3>
					<p class="dw-secure-text">Your credit and debit card information in Apple Pay is stored with enhanced security<a href="#footnote3" name="3"><span class="ada-hidden">footnote</span><sup>3</sup></a>. And, if your iPhone is ever lost or stolen, you can use Apple&rsquo;s Find My iPhone to quickly put your device in Lost Mode to lock or erase the device.<br /><br />Plus, all Bank of America consumer credit and debit cards and small business debit cards are protected by our <a href="/privacy/accounts-cards/credit-debit-card-security.go" name="Zero-Liability-Guarantee" target="_new">$0 Liability Guarantee</a><a href="#footnote4" name="4"><span class="ada-hidden">footnote</span><sup>4</sup></a> and fraud monitoring.</p>
					<img class="dw-secure-img" src="/content/images/ContextualSiteGraphics/CreditCardArt/en_US/CardImages/_bac_cards/Secure-graphic.png" />
					<!-- Updated -->
				</div>
				<div class="clear-both"></div>
			</div>
		<!-- new -->
</div>


					<div id="glossary-popup-1" class="hide tabs-main-content">
						<h3>Virtual cards</h3>
						<p>Adding a card to Apple Pay&trade; converts your physical card to a virtual card.<br /><br />You&rsquo;ll have a unique virtual card number that is only associated with Apple Pay.</p>
					</div>
		



			<div itemscope="itemscope" itemtype="http://schema.org/WebPage">
					<span style="display:none" itemprop="name">Use Bank of America Credit and Debit Cards with Apple Pay&trade;</span>
					<a style="display:none" itemprop="url" href="https://www.bankofamerica.com/onlinebanking/mobile-wallet.go"></a>
					<span style="display:none" itemprop="description">It's easy to add your Bank of America credit and debit cards to Apple Pay? to securely make purchases with your mobile device.</span>
					<img style="display:none" class="no-stretch" itemprop="image" alt="Use Bank of America Credit and Debit Cards with Apple Pay&trade;" src="https://www.bankofamerica.com/content/images/ContextualSiteGraphics/Logos/en_US/Bank_of_America_Flagscape_71x71.gif">
			</div>
</div>
					<div class="columns">
						<div class="flex-col lt-col" >
  
<div class="generic-content-module tabs-main-content">
  <div class="overview-nickel-skin com-main-well-content" style="">
        <h3 class="cnx-medium">What credit or debit cards are eligible?</h3>
      
      
      


      
            <p>Your Bank of America<sup>&reg;</sup>, Merrill Lynch<sup>&reg;</sup> and U.S. Trust<sup>&reg;</sup> consumer credit cards and your Bank of America consumer and small business debit cards are eligible.<a href="#footnote5" name="5"><span class="ada-hidden">footnote</span><sup>5</sup></a>&nbsp;U.S. Trust debit cards also qualify. There&rsquo;s no cost to create a virtual card or to use Apple Pay.<a href="#footnote6" name="6"><span class="ada-hidden">footnote</span><sup>6</sup></a></p>
      
      


        <h3 class="cnx-medium">Need an eligible card to get started?</h3>
      
      
      


      
            <p>Open a <a href="/deposits/checking/checking-accounts.go" onclick="return dartFireOnClickSpecial('1359940','bacal484','2014_03_');" name="personal_checking_account" target="_blank">personal checking account</a>, a <a href="/smallbusiness/checking-accounts.go" onclick="return dartFireOnClickSpecial('1359940','bacal484','2014_04');" name="business_checking_account" target="_blank">business checking account</a> or apply for a <a href="/credit-cards/overview.go" onclick="return dartFireOnClickSpecial('1359940','bacal484','2014_040');" name="credit_cards" target="_blank">credit card</a>.<a href="#footnote7" name="7"><span class="ada-hidden">footnote</span><sup>7</sup></a></p>
      
      


  </div>
</div>

</div>
						<div class="flex-col rt-col" >



<div class="hide vendor-interstitial-modal">
	<div class="image-container">
            	<div class="boa-logo">
                	<img src="/content/images/ContextualSiteGraphics/Logos/en_US/bofa-logo.jpg"  />
                </div>
                <div class="path">
                	<img src="/content/images/ContextualSiteGraphics/Logos/en_US/path.png"  />
                </div>
                
                <div class="vendor-logo">
                	<img src="/content/images/ContextualSiteGraphics/Logos/en_US/vendor-logo.png"  />
                </div>
               <div class="clear-both"></div>
    </div>
	<div class="modal-content">
			<h3>You're leaving our site to learn how Apple Pay<sup>&reg;</sup> makes shopping convenient.</h3>
			<p>Please keep in mind you&rsquo;re continuing to another website that Bank of America doesn&rsquo;t own or operate. Its owner is solely responsible for the website&rsquo;s content, offering and level of security, so please refer to the website&rsquo;s posted privacy policy and terms of use.</p>
<p>By selecting <strong>Continue</strong>, you agree that <strong>when </strong>and <strong>if </strong>you load your eligible credit or debit card into a digital wallet, you&rsquo;ll be requesting that a virtual card number be created on your behalf. You also agree that any future use of your virtual card number will be subject to the terms of your Credit Card Agreement for your Bank of America<sup>&reg;</sup>, Merrill Lynch<sup>&reg;</sup> or U.S. Trust<sup>&reg;</sup> credit card or your existing Important Information Brochure for your Bank of America or U.S. Trust debit card, as may be amended.</p>

			<div class="buttons">
				<a name="modal-continue" class="btn-bofa btn-bofa-red btn-bofa-small" id="btnContinue" href="https://support.apple.com/en-us/HT201239">
				<span>Continue to Apple</span></a>
				<a name="modal-return" class="close-vendor-interstitial" href="javascript:void(0);">
				<span>Return to Bank of America</span></a>
				<div class="clearboth"></div>
			</div>
	</div>
</div>



<!-- FTL :Module code starts here . All anchor names should begin with prefix 'anc' -->
<div class="side-well-module">  
   <div class="generic-content-skin">
      <div class="sm-top-cap"></div>
      <div class="sm-body">	  
         <h3 class="sm-title-bar">
			We're here to help
		 </h3>
         <div class="sm-main">
		
					
									<p>Learn more by reading our <a href="/onlinebanking/apple-pay-faqs.go" target="_self">Apple Pay FAQs</a>. If you have specific questions, please call us using the number on the back of your card.</p>							
         </div>
      </div>
      <div class="sm-btm-cap"></div>
   </div>   
</div>
</div>
						<div class="clearboth"></div>
					</div>
					<div class="footer">
						<div class="footer-top">&nbsp;



<div class="digital-wallet-module">
		<!-- new -->
		<!-- new1 APPLY-NOW -->
		    <div id="dwm-cta" class="details-skin">
				<!-- new2 -->
				<p><a class="btn-bofa btn-bofa-large btn-bofa-red btn-bofa-noRight new-window-hover mrt-10 vendor-interstitial-modal-link" onclick="return dartFireOnClickSpecial('1359940','bacal484','2014_042',this.href);" rel="/onlinebanking/mobile-wallet.go" name="Interstitial_Learn_More_About_ApplePay_On_Iphone6" href="javascript:void(0);">Learn more about Apple Pay</a></p>
				<div class="cta-txt" data-font="cnx-light"></div>
				<div class="clear-both"></div>
			</div>
</div>

</div>
						<div class="footer-inner">
<div class="footnote-com-module">
   <div class="fsd-layout-skin sup-ie">
					<div class="h-100">
						<div class="footnote" id="footnote1">
							<div class="fn-num">1.</div>
							<div class="fn-text">Available on select Apple<sup>&reg;</sup> devices. See&nbsp;<a href="javascript:void(0);" onclick="return dartFireOnClickSpecial('1359940','bacal484','2014_03z',this.href);" class="new-window-hover vendor-interstitial-modal-link" name="Interstitial_Open_Learn_More_About_Apple_Pay_On_iPhone_6" rel="/onlinebanking/nickel-wallet.go">Apple site</a> for complete list. </div>
							<div class="clearboth"></div>
						</div>
					</div>
					<div class="h-100">
						<div class="footnote" id="footnote2">
							<div class="fn-num">2.</div>
							<div class="fn-text">Requires app version 7.3 or above. </div>
							<div class="clearboth"></div>
						</div>
					</div>
					<div class="h-100">
						<div class="footnote" id="footnote3">
							<div class="fn-num">3.</div>
							<div class="fn-text">MasterCard, Visa and American Express will process transactions similar to how they process your physical card transactions today except most merchants won&rsquo;t have access to your actual card number; they will receive the unique virtual card number associated with your credit or debit card. MasterCard must provide your actual card number to certain transit merchants (e.g., subway systems) in order to process real-time decisions. </div>
							<div class="clearboth"></div>
						</div>
					</div>
					<div class="h-100">
						<div class="footnote" id="footnote4">
							<div class="fn-num">4.</div>
							<div class="fn-text">The $0 Liability Guarantee covers fraudulent transactions made by others using your Bank of America consumer credit, debit and ATM cards. To be covered, report transactions made by others promptly, and don&rsquo;t share personal or account information with anyone. Access to funds next business day in most cases, pending resolution of claim. Consult customer and account agreements for full details. </div>
							<div class="clearboth"></div>
						</div>
					</div>
					<div class="h-100">
						<div class="footnote" id="footnote5">
							<div class="fn-num">5.</div>
							<div class="fn-text">Cards issued to residents of Puerto Rico and U.S. Virgin Islands will not be eligible for Apple Pay. </div>
							<div class="clearboth"></div>
						</div>
					</div>
					<div class="h-100">
						<div class="footnote" id="footnote6">
							<div class="fn-num">6.</div>
							<div class="fn-text">About fees: Your usual wireless carrier fees may apply. Your standard fees associated with the use of your physical credit or debit card also apply to your virtual card. </div>
							<div class="clearboth"></div>
						</div>
					</div>
					<div class="h-100">
						<div class="footnote" id="footnote7">
							<div class="fn-num">7.</div>
							<div class="fn-text">For information about rates, fees, other costs and benefits associated with the use of a credit card, or to apply, click on the link above and refer to the disclosures accompanying an online credit application.</p>
<p>&nbsp;</p>
<p>Apple, the Apple logo, iPhone and Apple Watch are trademarks of Apple Inc., registered in the U.S. and other countries. Apple Pay and Touch ID are a trademarks of Apple Inc.</p>
<p>&nbsp;</p>
<p>Merrill Lynch, U.S. Trust, Bank of America and the Bank of America logo are registered trademarks of Bank of America Corporation. </div>
							<div class="clearboth"></div>
						</div>
					</div>
   </div>
</div>





 



		<div class="global-footer-module">
			<div class="fsd-skin">

				<div class="footer-bottom-left" style="float:left;max-width:66%;">
	    			<div class="gf-links">	          	
						
					
									
									<a  target="_self" href="/" 
									    name="global_footer_home">Home
									</a>
									
						
					
									
									<a  target="_self" href="/privacy/overview.go" 
									    name="global_footer_privacy_security">Privacy & Security
									</a>
									
						
					
									
									<a  target="_self" href="http://careers.bankofamerica.com/careershome.aspx" 
									    name="global_footer_careers">Careers
									</a>
									
						
					
									<a	target="_self" href="/sitemap/personal.go" 
										name="global_footer_site_map" class="gf-last-link ">Site Map
									</a> 
						<div class="clearboth"></div>
	    			</div>
	      			<p>Bank of America, N.A. Member FDIC. <a id="equal_housing_footer" title="Equal Housing Lender information. Link opens in new window." onclick="window.open('/help/equalhousing_popup.go','newwin','width=640,height=371,scrollbars=yes,resizable=yes,left=35,top=161'); return false;" href="/help/equalhousing_popup.go" target="_blank">Equal Housing Lender <img src="https://www2.bac-assets.com/content/images/ContextualSiteGraphics/Logos/en_US/icon_equal_housing_lender.gif" alt="Opens in new window" width="14" height="9" /></a><br />&copy; 2017 Bank of America Corporation.</p>
         		</div>
         		<div class="footer-social-container" style="float:right;max-width:30%;padding-left:50px;padding-top:19px;">




<div class="boa-social-loader" data-loaded="false" data-platform="borneo"  data-options=''></div>

         		</div>
         		<div class="clearboth"></div>
  			</div>
		</div>

<script language="javascript" src="https://www2.bac-assets.com/pa/global-assets/external/coremetrics/hp/eluminate.js"></script>
<script language="javascript" src="https://www2.bac-assets.com/pa/global-assets/external/coremetrics/hp/cmdatatagutils.js"></script>
<script type="text/javascript" src="https://www2.bac-assets.com/pa/components/modules/coremetrics-bi-bdf-module/1.2/script/coremetrics-bi-bdf-module-def-skin.js"></script>

<script type="text/javascript">
	var cmPageId = "OSP:Content:OLB;mobile-wallet";
	var cmFailId = "OSP:Content:OLB;mobile-wallet_Error";
	
	var cmCategoryId = "OSP:Content:OLB"; 
	var cmPageViewSessionIDForConf = "DAPm-zZaxN5eb4rTLRvfSHr" ;
		var cmAffinityVal = null;
	var cmAdlob;
	var cmAttrParam;
	if (cmAffinityVal !== null) {
		cmAdlob = '|aff_'+cmAffinityVal+'|';
		cmAttrParam = cmAdlob + '-_--_--_--_--_--_--_--_--_--_--_--_--_--_-';
	} else {
		cmAdlob = null;
		cmAttrParam = null;
	}
function cmGetReqParameter(queryString, parameterName) {
	var parameterName = parameterName + "=";
	if (queryString.length > 0) {
		begin = queryString.indexOf(parameterName);
		if (begin != -1) {
			begin += parameterName.length;
			end = queryString.indexOf ( "&" , begin );
			if ( end == -1 ) {
				end = queryString.length
			}
			return unescape ( queryString.substring ( begin, end ) );
		}
		return null;
	}
}

var testString = window.location.href;

if (cmGetReqParameter(testString, 'sessionid') !== null) {
	cmPageViewSessionIDForConf = cmGetReqParameter(testString, 'sessionid');
}	

var cmAdlink;
if (cmGetReqParameter(testString, 'adlink') !== null) {
	cmAdlink = cmGetReqParameter(testString, 'adlink');
} else {
	cmAdlink = null;
}

var cmFailure = $('body').find('.error-page-level:visible').length;
var cmErrorMsg = '';

var cmReqLocale = $('html').attr('lang');
var locAppendage;
if (cmReqLocale.toLowerCase().indexOf('en') !== -1) {
	locAppendage = '';
} else if (cmReqLocale.toLowerCase().indexOf('es') !== -1) {
	locAppendage = '_ES';
}

if (cmFailure === 0) {
		cmCreatePageviewTag(cmPageId+locAppendage, null, null, cmCategoryId, false, false, null, false, false, cmAdlink, null, cmAdlob, null, cmPageViewSessionIDForConf, null, null, null, cmAttrParam, null, null, null);
	} else if (cmFailure > 0) {
		cmCreatePageviewTag(cmFailId+locAppendage, null, null, cmCategoryId, false, false, null, false, false, cmAdlink, null, cmAdlob, null, cmPageViewSessionIDForConf, null, null, null, cmAttrParam, null, null, null);
		if ($('.error-page-level').find('.error-content-list').length > 0) {
			$('.error-page-level .error-content-list ul li').each(function() {
				cmErrorMsg += $(this).html() + ' - ';
			});
			cmCreateCustomError(cmFailId+locAppendage, null, null, null, 'not_specific', cmCategoryId, cmErrorMsg);
		}
	}	

</script>




 

<script type="text/javascript">
var axel = Math.random()+"";var a = axel * 10000000000000;document.write('<iframe title="iFrame used for layout purpose" src="https://1359940.fls.doubleclick.net/activityi;src=1359940;type=bacal484;cat=2014_03y;ord=1;num='+ a + '?" width="1" height="1" frameborder="0" style="display:none;"></iframe>');
</script>
<noscript>
	<iframe title="iFrame used for layout purpose" src="https://1359940.fls.doubleclick.net/activityi;src=1359940;type=bacal484;cat=2014_03y;ord=1;num=1?" width="0" height="0" frameborder="0" style="display:none;"></iframe>
</noscript>
</div>
					</div>
				</div>
			</div>
		</div>
	</body>	
</html>

