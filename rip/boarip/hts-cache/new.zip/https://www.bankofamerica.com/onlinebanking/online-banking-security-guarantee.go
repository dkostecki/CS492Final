
 

				<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
				<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
				<head>


<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta http-equiv="content-type" content="text/html;charset=utf-8">


			<link rel="canonical" href="https://www.bankofamerica.com/onlinebanking/online-banking-security-guarantee.go"/>







<title>Online and Mobile Banking Security Guarantee from Bank of America</title>

<meta name="Description" CONTENT="Online Banking Security Guarantee">
<meta name="Keywords" CONTENT="Online Banking Security Guarantee">

				<meta property="og:title" CONTENT="Online Banking Security Guarantee from Bank of America" />
				<meta property="og:type" CONTENT="website" />
				<meta property="og:url" CONTENT="https://www.bankofamerica.com/onlinebanking/online-banking-security-guarantee.go" />
				<meta property="og:image" CONTENT="https://www.bankofamerica.com/content/images/ContextualSiteGraphics/Logos/en_US/Bank_of_America_Flagscape_71x71.gif" />
				<meta property="og:description" CONTENT="Review the Online Banking Security Guarantee to understand how Bank of America works hard to protect your privacy." />
				<meta property="og:site_name" CONTENT="Bank of America" />
<link rel="shortcut icon" href="https://www2.bac-assets.com/pa/global-assets/1.0/graphic/favicon.ico" type="image/ico" />


	


			<script src="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/Global/1.0/script/tealeafbundle.js" type="text/javascript"></script>
	
	   
			<link rel="stylesheet" type="text/css" href="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/PBI-WEB/2017.03.0/style/pbi-web-jawr.css" media="all" />
			<link rel="stylesheet" type="text/css" href="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/PBI-WEB/2017.03.0/style/pbi-web-jawr-print.css" media="print" />
			<script src="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/PBI-WEB/2017.03.0/script/pbi-web-jawr.js" type="text/javascript"></script>

<script type="text/javascript">
(function() {
	if (typeof mboxUpdate == "function") {
		var windowURL = window.location.href
	    windowURL = windowURL.slice( windowURL.indexOf('.')+1);
		windowURL = windowURL.split( '?' )[0];
		windowURL = windowURL.toLowerCase();
		//alert(windowURL);
		if (
		    //If no mboxes on page, mbox count will be < 1
		    (mboxFactoryDefault.getMboxes().length() < 1) &&  
			
			//Also check for high-volume pages that do not need global logging
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go") &&
			(windowURL != "bankofamerica.com/myaccounts/signin/signin.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/entry/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signonscreen.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatechallengeanswer.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatePassword.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/mobile/banking.go")&&
			(windowURL != "bankofamerica.com/content/preload/olb-myaccount-preload-jawr-module.htm")
			)
		{

			var mboxDiv = document.createElement("div");
			mboxDiv.id = "adobe_touch_clarity_replacement";
			mboxDiv.style.display = "none";
			if (document.body && document.body.firstChild) document.body.insertBefore(mboxDiv,document.body.firstChild);
			mboxDefine(mboxDiv.id,'bac_global_bottom');
			mboxUpdate('bac_global_bottom');
		}
	}	
})();
</script>

	
			<script>
				var boaPageDataJS = {};
					boaPageDataJS.isLLE = "false";
			</script>
				<style>body{display:none;}</style>
	</head>	

	<body class="fsd-layout-body">	

				<script type="text/javascript">if(self == top){var theBody=document.getElementsByTagName("body")[0];theBody.style.display="block";}else{top.location=self.location;}</script>
				<noscript><style>body{display:block;}</style></noscript>
					<a class='ada-hidden ada-visible-focus' href='#skip-to-h1' id='ada-skip-link'>Skip to main content</a>
		<div class="fsd-layout fsd-1c-layout fsd-full-width">
			<div class="center-content">
				<div class="header">
		  



<script language="javascript" src="/pa/components/modules/tag-manager-module/1.1/script/tag-manager-module-borneo-global-skin.js"></script>
<script>

(function() {
  var fireCallback = function( cb ) {
    if ( typeof cb === "function" ) cb();
  };
  
  function ddoPopulateBase( callback ) {
    try {
		  var DDO = window.digitalData,
		  	bactm_mergeDDO = function( newDDO, priorDDO ) {
		  		if( typeof priorDDO === "undefined" ) {
				  	priorDDO = digitalData || {};
				  }

			    for (var l in newDDO) {
			        if (typeof priorDDO[l] === "undefined") {
			            priorDDO[l] = newDDO[l];
			        }
			        if (newDDO[l] !== null) {
			            if (typeof newDDO[l] === "object") {
			                bactm_mergeDDO(newDDO[l], priorDDO[l]);
			            } else {
			                priorDDO[l] = bactm_validateValue( newDDO[l] ) ? newDDO[l] : priorDDO[l];
			            }
			        }
			    }

			    return priorDDO;
				},
				bactm_olb3rdPartyId = "null";

			if (typeof DDO === "undefined") {
				var simpleDDO = { page: { pageInfo:[{ pageID: null }], attributes: {}, category: { primaryCategory: null }}};

				DDO = (typeof digitalData === "object") ? digitalData : simpleDDO; 
			}

				DDO = bactm_mergeDDO( {pageInstanceID:"notprod",load_coremetrics:true,load_opinionlabs:false,load_touchcommerce:true,load_audiencemanager:true,page:{pageInfo:[{pageID:null,destinationURL:null,referringURL:null,issueDate:null,language:null,segmentValue:null,appName:null,appStepNumber:null,appStepName:null,attr:"-_--_--_--_--_--_--_--_--_--_--_--_--_--_-"}],category:{primaryCategory:null,addlCategory:null,pageType:null},attributes:{searchString:null,searchResults:null,olbSessionID:null,subCampaignCode:null,DARTUrl:null,stateCookie:null,SASIEnabled:false,needOLBcookie:false,standardDART:[],standardDARTes:[],clickDART:[],clickDARTes:[],gaId:[],chat:{account_type:null,boa_associate:null,boa_retiree:null,customer_lob:null,customer_segment:null,data:null,email_campaign:null,entitlement_code:null,error_category:null,error_count:null,first_login:null,inqSalesProductTypes:{},invitation_background:null,invitation_template:null,referral_campaign:null,getStateValue:false,cust_fn:null,cust_ln:null,target:null}}},user:{segment:null,online_id:null,preferred_rewards_tier:null,olb3rdpartyid:null},version:"BAC_0.12"}, DDO );

			DDO.page.pageInfo[0].pageID = "OSP:Content:OLB;Online_Banking_Security_Guarantee";
			DDO.page.category.primaryCategory  = "OSP:Content:OLB";
			DDO.page.pageInfo[0].language = "en-US";
			DDO.page.attributes.olbSessionID = "null";
			DDO.page.attributes.SASIEnabled =  "false";
			if (typeof DDO.user != "undefined" && typeof DDO.user.olb3rdpartyid != "undefined") {
				DDO.user.olb3rdpartyid = bactm_olb3rdPartyId;
			}

			window.utag_data = {};
			window.bactm_envSelector = bactm_setTMLib();
			window.digitalData = DDO;

      return fireCallback( callback );

    } catch(e) { }
  }
	if( window.boa && window.boa.digitalData ) {
    window.boa.digitalData.register( ddoPopulateBase );
	}
	else {
	  // Handle scenario where the header isn't available (and thus the default digitalData object and utag loader are missing).
	  //
		var writeScript = function(a,b,c,d){
			a='//tags.tiqcdn.com/utag/bofa/main/' + bactm_envSelector + '/utag.js';
			b=document;
			c='script';
			d=b.createElement(c);
			d.src=a;
			d.type='text/java'+c;
			d.async=true;
			a=b.getElementsByTagName(c)[0];
			a.parentNode.insertBefore(d,a);
		};

		ddoPopulateBase( writeScript );
	}
})();			
</script>




 


<div class="header-module">
	<div class="text-w-logo-skin">
		<div class="header-left">
	  
			<div itemscope itemtype="http://schema.org/Corporation" class="bofa-logo">
				<a itemprop="url" name="anc-online-banking" title="Bank of America" href="/">
					<img itemprop="logo" height="28" width="221" 
					     alt="Bank of America" src="https://www2.bac-assets.com/content/images/ContextualSiteGraphics/Logos/en_US/boa_logo.gif"/>
				</a>
			</div>
				<div class="product" data-font="cnx-regular">Online Banking</div>
			
			<div class="clearboth"></div>

		</div>
		
		<div class="header-right">
			<ul class="header-links">
			
				
					
				
							<li class="sign-in">
		<a					href="/sitemap/hub/signin.go" target="_self"
		name="Sign_In">Sign In</a> 
							</li>
					
				
							<li>		<a					href="/" target="_self"
		name="Home_Header">Home</a> 
</li>
					
				
							<li>		<a					href="https://locators.bankofamerica.com" target="_self"
		name="Locations">Locations</a> 
</li>
					
				
							<li>		<a					href="/contactus/contactus.go" target="_self"
		name="Contact_Us">Contact Us</a> 
</li>
					
				
							<li>		<a					href="/help/overview.go " target="_self"
		name="Help">Help</a> 
</li>
					
				
							<li class="last-link">	
									<a href="/onlinebanking/online-banking-security-guarantee.go?request_locale=es_US" name="en_espanol" target="_self">En espa&#241;ol</a> 				
							</li>
			</ul>
			
			<div class="clearboth"></div>

			<!-- include search-dotcom-util -->



<div class="header-search nlh">
  
  <div class="nav-search">
    <form class="search-form" action="https://secure.bankofamerica.com/myaccounts/public/search-results/unAuthenticatedSearch.go" data-js="/pa/components/utilities/search-util/1.0/script/nav-search.min.js" data-css="/pa/components/utilities/search-util/1.0/style/nav-search.css" data-text-unavailable="Search Currently Unavailable">
      <div class="search-input-container cf" data-icon="search">
        <label for="nav-search-query" class="ada-hidden">Search Term</label>
        <input type="text" placeholder="How can we help you?" name="query" class="search-query" id="nav-search-query" 
          maxlength="99" rel="Search" autocomplete="off"><input type="submit" alt="Search" title="Search" value="Submit Search" name="Search Module - Top Result – Search Button" class="submit track-me">
      </div>
    </form>
  </div>

</div>

		</div>

 		<div class="clearboth"></div>
 	</div>
</div>

	<div class="top-nav-module">
		<div class="fsd-skin sup-ie">
			<ul class="nav-list">
					
					
					<li>
						
									<a href="/onlinebanking/online-banking.go" class="top-menu-item"
									name="overview_topnav" id="overview_topnav">Overview</a>
					</li>
					
					
					<li>
						
									<a href="/onlinebanking/online-bank-account.go" class="top-menu-item"
									name="manage_accounts_topnav" id="manage_accounts_topnav">Manage Accounts</a>
					</li>
					
					
					<li>
						
									<a href="/onlinebanking/online-bill-pay.go" class="top-menu-item"
									name="pay_and_transfer_topnav" id="pay_and_transfer_topnav">Pay and Transfer</a>
					</li>
					
					
					<li>
						
									<a href="/onlinebanking/financial-management-tools.go" class="top-menu-item"
									name="budget_and_track_topnav" id="budget_and_track_topnav">Budget and Track</a>
					</li>
					
					
					<li>
						
									<a href="/onlinebanking/learning-center.go" class="top-menu-item"
									name="get_answers_topnav" id="get_answers_topnav">Get Answers <span class="ada-hidden"> for your Online Banking questions</span></a>
					</li>
					
					
					<li>
						
									<a href="https://secure.bankofamerica.com/login/enroll/entry/olbEnroll.go?reason=model_enroll" class="top-menu-item"
									name="enroll_in_online_banking_topnav" id="enroll_in_online_banking_topnav">Enroll in Online Banking</a>
					</li>
			</ul>
				<div class="clearboth"></div>
		</div>
	</div>



<div class="page-title-fsd-module h-100" id="skip-to-h1">
	<div class="standard-red-skin sup-ie">
			<h1 data-font="cnx-regular">Online and Mobile Banking Security Guarantee</h1>
	</div>
</div>			<div itemscope="itemscope" itemtype="http://schema.org/WebPage">
					<span style="display:none" itemprop="name">Online and Mobile Banking Security Guarantee from Bank of America</span>
					<a style="display:none" itemprop="url" href="https://www.bankofamerica.com/onlinebanking/online-banking-security-guarantee.go"></a>
					<span style="display:none" itemprop="description">Review the Online Banking Security Guarantee to understand how Bank of America works hard to protect your privacy.</span>
					<img style="display:none" class="no-stretch" itemprop="image" alt="Online and Mobile Banking Security Guarantee from Bank of America" src="https://www.bankofamerica.com/content/images/ContextualSiteGraphics/Logos/en_US/Bank_of_America_Flagscape_71x71.gif">
			</div>
</div>
				<div class="columns">
					<div class="one-col">
<link type="text/css" rel="stylesheet" media="all" href="https://www2.bac-assets.com/pa/components/modules/service-agreement-module/1.2/style/service-agreement-module-com-skin.css">
<script type="text/javascript" src="https://www2.bac-assets.com/pa/components/modules/service-agreement-module/1.2/script/service-agreement-module-com-skin.js"></script>


<div class="service-agreement-module">
<div class="com-skin com-main-well-content table-vzd3-common embed-bullet">
<script type="text/javascript">
	var ADAShowTopicsText = "Show Topics for ";  
	var ADAHideTopicsText = "Hide Topics for ";  
</script>
<div class="intro-link"><a href="/onlinebanking/online-banking.go">
<span class="guillemet">&#8249;&#8249;&nbsp;</span>
Go to Online Banking Overview
</a></div>

<div class="h-100"><h2 id="back-to-top-anchor">
</h2></div>
<p class="eff-date">
</p>
<p><strong>
</strong>	
<a href="javascript:void(0);" class="topic-toggle" id="show-topics">Show all Topics</a>
<a href="javascript:void(0);" class="hide topic-toggle">Hide all Topics</a>
</p>
<ol class="cat-list">
	
	
			<li><a href="#cat1" class="category-link">
			Our Online and Mobile Banking Security Guarantee
	   		 </a>
	   		 </li>
	
			<li><a href="#cat2" class="category-link">
			How you are protected with our guarantee
	   		 </a>
	   		 </li>
	
			<li><a href="#cat3" class="category-link">
			What you need to do
	   		 </a>
	   		 </li>
	
			<li><a href="#cat4" class="category-link">
			More ways we help to keep your information safe
	   		 </a>
	   		 </li>
</ol>
<div class="sa-main-content">
<!--First Heading-->
	<div class="h-100">
		<h3 id="cat1">
				Our Online and Mobile Banking Security Guarantee
		</h3>
	</div>
	
		<p>Consumers can confidently use Online or Mobile Banking because we guarantee that you will not be liable for fraudulent transfers or bill pay transactions*, we will help keep your financial information safe and we will process your payments based on your online or mobile banking instructions. Protection is a shared responsibility so be sure to understand your role.</p>
		<div class="h-100">
			<h4 id="cat1_topic1">
			</h4>
		</div>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor"> </a> 
        </div>
	<div class="h-100">
		<h3 id="cat2">
				How you are protected with our guarantee
		</h3>
	</div>
	
		<div class="h-100">
			<h4 id="cat2_topic1">
			</h4>
		</div>
			<p style="margin-left: 40px"><strong>When You Make a Payment</strong></p>
<p style="margin-left: 40px">When you make a bill payment using Online or Mobile Banking you can be confident that it will be processed correctly. In the unlikely event that we fail to process your payment in accordance to the payee, amount and date you specified, Bank of America will reimburse you for any late-payment-related charges incurred.</p>
<p style="margin-left: 40px"><strong>When You Notice Fraudulent Transactions</strong></p>
<p style="margin-left: 40px">We are committed to keeping your financial information safe and making sure you can bank with us securely, which is why you are not liable for fraudulent transfers or bill pay transactions made via online or mobile when they are reported promptly.</p>
<p style="margin-left: 40px"><strong>Protection is a Shared Responsibility </strong></p>
<p style="margin-left: 40px">While we always offer you a high level of banking security, you do play a significant role in keeping your financial information safe. Please read <strong>What you need to do</strong> to preserve your rights under the Online and Mobile Banking Security Guarantee. These responsibilities are important to follow and help you safely access your account and quickly report fraudulent transactions.</p>
<p style="margin-left: 40px">Consumers have different rights and responsibilities than businesses. These differences are outlined below in the <strong>What you need to do</strong> section. Please see the <a name="service-agreement" href="/online-banking/service-agreement.go" target="_self">Online Banking Service Agreement</a> for full details and exceptions.</p>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor"> </a> 
        </div>
	<div class="h-100">
		<h3 id="cat3">
				What you need to do
		</h3>
	</div>
	
		<p style="margin-left: 40px;"><strong>Routinely Review your Account Transactions</strong></p>
<p style="margin-left: 40px;">Online and Mobile Banking makes it easier to stay on top of your account activity. Review your transactions and account statements regularly, sign up for alerts, assess and update your settings in the <a href="/privacy/online-mobile-banking-privacy/security-center.go" name="security-center" target="_self">Security Center</a>, and promptly report any fraudulent activity.</p>
<p style="margin-left: 60px;"><strong>Consumers:</strong></p>
<p style="margin-left: 60px;">Notify us within 60 days of the fraudulent transaction first appearing on your statement or online and we will provisionally credit you for funds transferred from your accounts up to the amount of the fraudulent transaction. Following our investigation, we will promptly notify you of the final status of any provisional credit.</p>
<p style="margin-left: 60px;"><strong>Businesses:</strong></p>
<p style="margin-left: 60px;">All fraudulent electronic payment transactions should be reported to the bank immediately. Any delay by customers in reporting transactions initiated by an authorized user ID and passcode affects the bank&rsquo;s ability to recover funds for a customer and may result in customer liability and losses.</p>
<p style="margin-left: 40px;">Please see the <a href="/online-banking/service-agreement.go" name="service-agreement" target="_self">Online Banking Service Agreement</a> for further details on how we handle fraudulent transactions for consumers and businesses.</p>
<p style="margin-left: 40px;"><strong>Call us immediately if you suspect fraud</strong></p>
<p style="margin-left: 40px;">Call 1.800.933.6262 if you notice any fraudulent activity in your account, or need to report a card or passcode lost or stolen.</p>
<p style="margin-left: 40px;"><strong>Do not share your Online ID and Passcode</strong></p>
<p style="margin-left: 40px;">If you do share your sign-in information with someone, you will be responsible for all transactions they initiate with your information, even those you did not intend them to make. These transactions will be considered authorized by you so it&rsquo;s important that you always guard your Online ID and Passcode from unauthorized use. If your device allows access to anyone other than you via fingerprint, that person will also be able to access your Bank of America Mobile Banking app on the same device when Touch ID or fingerprint is enabled, and their transactions will be considered authorized.</p>
<p style="margin-left: 40px;"><strong>Sign off before leaving</strong></p>
<p style="margin-left: 40px;">Never leave your computer or mobile device unattended while you are signed in to Online or Mobile Banking. It's easy to protect your information by signing off when you are finished with each banking session. In general, confidential information from the Mobile Banking app is not stored on your phone, so when you sign off, your information stays secure. If you opted to save certain information, such as your Online ID, or if you receive push notifications, some information may remain.</p>
		<div class="h-100">
			<h4 id="cat3_topic1">
			</h4>
		</div>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor"> </a> 
        </div>
	<div class="h-100">
		<h3 id="cat4">
				More ways we help to keep your information safe
		</h3>
	</div>
	
		<p style="margin-left: 40px;"><strong>We encrypt your data</strong></p>
<p style="margin-left: 40px;">Keeping financial information secure and confidential, including within Online and Mobile Banking, is one of our most important responsibilities. Whenever personal information is requested or displayed on our website we use encryption technology to help prevent unauthorized access to data. Visit our <a href="/privacy/overview.go" name="privacy" target="_self">Privacy &amp; Security</a> site for more information on how Bank of America protects your accounts and information.</p>
<p style="margin-left: 40px;"><strong>Your privacy is our priority</strong></p>
<p style="margin-left: 40px;">Be assured that Bank of America safeguards your privacy however you choose to bank with us. Our <a href="/privacy/consumer-privacy-notice.go" name="consumer-privacy-notice" target="_self">Consumer Privacy Notice</a> explains our commitment to your privacy and our practices to protect and manage your personal information. It identifies what we collect and hold, and describes how it is used, shared and secured.</p>
		<div class="h-100">
			<h4 id="cat4_topic1">
			</h4>
		</div>
			<p>For 9 years in a row, Bank of America has earned the respected and coveted Best Overall Identity Safety in Banking Award by Javelin Strategy &amp; Research, the nation's leading provider of financial institution insights. The award is based on strong performance in the categories of fraud prevention, detection and resolution.</p>
<p>*Mobile Check Deposits are not covered by the Online and Mobile Banking Security Guarantee. In the Mobile Banking app, select Get Help, then Mobile Check Deposit for details, including restrictions and terms and conditions related to the use of Mobile Check Deposit.</p>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor"> </a> 
        </div>
</div>
</div>
</div>

</div>
				</div>
				<div class="footer">
					<div class="footer-top">&nbsp;</div>
					<div class="footer-inner">







<div class="power-footer-module">
	<div class="fsd-flex-skin sup-ie">
		<div class="breadcrumbs">
		<div itemscope itemtype="http://schema.org/BreadcrumbList">
								<div itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
										<a itemprop="item" class="bold-bc" href="/" name="bank_of_america_online_banking_security_guarantee_breadcrumbs" target="_self">
										<span itemprop="name">Bank of America</span>
										<meta itemprop="position" content="1" /></a>
								</div>
								<div itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
										<a itemprop="item" href="/onlinebanking/online-banking.go" name="online_banking_online_banking_security_guarantee_breadcrumbs" target="_self">
										<span itemprop="name">Online Banking</span>
										<meta itemprop="position" content="2" /></a>
								</div>
				   				    
				    

				    
				    
				    
				    <div class="breadcrumb-last-item" itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
					 <span itemprop="name">Online Banking Security Guarantee</span>
					 <meta itemprop="position" content="3" />
			            </div>		 
			
<div class="clearboth"></div>
</div>
</div>

<div class="pf-columns">
			  
				  	<div class="pf-col">
				  
				  
						<a href="/onlinebanking/online-banking.go" name="online_banking_overview_online_banking_security_guarantee_power_footer" class="bold" target="_self">Online Banking Overview</a>
				   
									<a href="https://secure.bankofamerica.com/login/enroll/entry/olbEnroll.go?reason=model_enroll"  name="enroll_in_online_banking_online_banking_security_guarantee_power_footer" target="_self">Enroll in Online Banking</a>
									<a href="/online-banking/service-agreement.go"  name="service_agreement_online_banking_security_guarantee_power_footer" target="_self">Service Agreement</a>
									<a href="/online-banking/eComm-Disclosure.go"  name="ecommunications_disclosure_online_banking_security_guarantee_power_footer" target="_self">eCommunications Disclosure</a>
									<a href="/onlinebanking/online-banking-security-guarantee.go"  name="online_banking_security_guarantee_online_banking_security_guarantee_power_footer" target="_self">Online Banking Security Guarantee</a>
					</div>   
			  
			  
				  	<div class="pf-col">
				  
				  
						<a href="/onlinebanking/online-bank-account.go" name="manage__accounts_online_banking_security_guarantee_power_footer" class="bold" target="_self">Manage Accounts</a>
				   
									<a href="/onlinebanking/online-bank-account.go#account-activity"  name="activity_online_banking_security_guarantee_power_footer" target="_self"><span class="ada-hidden">Manage accounts </span>Activity</a>
									<a href="/onlinebanking/online-bank-account.go#alerts"  name="alerts_online_banking_security_guarantee_power_footer" target="_self"><span class="ada-hidden">Manage accounts </span>Alerts</a>
									<a href="/onlinebanking/online-bank-account.go#statements"  name="statements_online_banking_security_guarantee_power_footer" target="_self"><span class="ada-hidden">Manage accounts </span>Statements</a>
									<a href="/onlinebanking/online-bank-account.go#bankamerideals"  name="bankamerideals_online_banking_security_guarantee_power_footer" target="_self"><span class="ada-hidden">Manage accounts </span>BankAmeriDeals<sup>&reg;</sup></a>
					</div>   
			  
			  
				  	<div class="pf-col">
				  
				  
						<a href="/onlinebanking/online-bill-pay.go" name="pay_and_transfer_online_banking_security_guarantee_power_footer" class="bold" target="_self">Pay and Transfer</a>
				   
									<a href="/onlinebanking/online-bill-pay.go#payments"  name="payments_online_banking_security_guarantee_power_footer" target="_self">Payments</a>
									<a href="/onlinebanking/online-bill-pay.go#transfers"  name="transfers_account_online_banking_security_guarantee_power_footer" target="_self">Transfers</a>
					</div>   
			  
			  
				  	<div class="pf-col">
				  
				  
						<a href="/onlinebanking/financial-management-tools.go" name="budget_and_track_online_banking_security_guarantee_power_footer" class="bold" target="_self">Budget and Track</a>
				   
									<a href="/onlinebanking/financial-management-tools.go#my-portfolio"  name="my_portfolio_online_banking_security_guarantee_power_footer" target="_self">My Portfolio<sup>&reg;</sup></a>
					</div>   
			  
			  
				  	<div class="pf-col">
				  
				  
						<a href="/onlinebanking/learning-center.go" name="get_answers_online_banking_security_guarantee_power_footer" class="bold" target="_self">Get Answers <span class="ada-hidden"> for your Online Banking questions</span></a>
				   
									<a href="/onlinebanking/online-banking-services-faqs.go"  name="faqs_online_banking_security_guarantee_power_footer" target="_self"><span class="ada-hidden">Get Answers </span>FAQs</a>
					</div>   
			  
			  
		  <div class="clearboth"></div>
    </div>

</div>
</div>



 



		<div class="global-footer-module">
			<div class="fsd-skin">

				<div class="footer-bottom-left" style="float:left;max-width:66%;">
	    			<div class="gf-links">	          	
						
					
									
									<a  target="_self" href="/" 
									    name="global_footer_home">Home
									</a>
									
						
					
									
									<a  target="_self" href="/privacy/overview.go" 
									    name="global_footer_privacy_security">Privacy & Security
									</a>
									
						
					
									
									<a  target="_self" href="http://careers.bankofamerica.com/careershome.aspx" 
									    name="global_footer_careers">Careers
									</a>
									
						
					
									
									<a  target="_self" href="/sitemap/personal.go" 
									    name="global_footer_site_map">Site Map
									</a>
									
						
					
									<a href="javascript:void(0);" class="gf-last-link boa-dialog boa-com-info-layer-link" name="global_footer_ad_practices_lnk" rel="global_footer_ad_practices">Advertising Practices</a>
								<div id="global_footer_ad_practices" class="hide">
									<h3>Advertising Practices</h3>
										<p>We strive to provide you with information about products and services you might find interesting and useful. Relationship-based ads and online behavioral advertising help us do that.</p>
<p>Here's how it works: We gather information about your online activities, such as the searches you conduct on our Sites and the pages you visit. This information may be used to deliver advertising on our Sites and offline (for example, by phone, email and direct mail) that's customized to meet specific interests you may have.</p>
<p>If you prefer that we do not use this information, you may <a onclick="$('.ui-dialog').remove();" name="WebsiteAdPractices_OptOut" href="/privacy/online-privacy-notice.go#advertising-on-our-sites" target="_blank">opt out of online behavioral advertising</a>. If you opt out, though, you may still receive generic advertising. In addition, financial advisors/Client Managers may continue to use information collected online to provide product and service information in accordance with account agreements.</p>
<p>Also, if you opt out of online behavioral advertising, you may still see ads when you sign in to your account, for example through Online Banking or MyMerrill. These ads are based on your specific account relationships with us.</p>
<p>To learn more about relationship-based ads, online behavioral advertising and our privacy practices, please review the <a onclick="$('.ui-dialog').remove();" name="WebsiteAdPractices_PrivacyNotice" href="/privacy/online-privacy-notice.go" target="_blank">Bank of America Online Privacy Notice</a> and our <a onclick="$('.ui-dialog').remove();" name="Online-privacy-faqs" href="/privacy/faq/online-privacy-faq.go" target="_blank">Online Privacy FAQs</a>.</p>
								</div>
						<div class="clearboth"></div>
	    			</div>
	      			<p>BankAmeriDeals, My portfolio, Merrill Lynch, Bank of America and the Bank of America logo are registered trademarks of Bank of America Corporation.</p>
<p>Some accounts, services and fees vary from state to state. Please review the <a name="footer-personal-schedule-of-fees" href="/deposits/bank-account-fees.go" target="_blank">Personal Schedule of Fees</a> for your state, also available at your local financial center.</p>
<p>Bank of America, N.A. Member FDIC. <a title="Equal Housing Lender information." onclick="window.open('/help/equalhousing_popup.go','newwin','width=640,height=371,scrollbars=yes,resizable=yes,left=35,top=161'); return false;" name="Equal_Housing_Lender" href="/help/equalhousing_popup.go" target="_blank">Equal Housing Lender<img src="https://www2.bac-assets.com/content/images/ContextualSiteGraphics/Logos/en_US/icon_equal_housing_lender.gif" alt="" width="14" height="9" /></a><br />&copy; 2017 Bank of America Corporation.</p>
         		</div>
         		<div class="footer-social-container" style="float:right;max-width:30%;padding-left:50px;padding-top:19px;">




<div class="boa-social-loader" data-loaded="false" data-platform="borneo"  data-options=''></div>

         		</div>
         		<div class="clearboth"></div>
  			</div>
		</div>




 
</div>
				</div>
			</div>
		</div>	
	</body>	
</html>

