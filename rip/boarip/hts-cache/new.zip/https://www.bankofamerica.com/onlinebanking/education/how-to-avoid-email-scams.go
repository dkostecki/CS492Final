
 

				<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
				<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
				<head prefix="OG:http://ogp.me/ns#">


<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta http-equiv="content-type" content="text/html;charset=utf-8">


			<link rel="canonical" href="https://www.bankofamerica.com/onlinebanking/education/how-to-avoid-email-scams.go"/>







<title>How to Avoid Email Scams - Advice from Bank of America</title>

<meta name="Description" CONTENT="Sometimes phishing and email scams can be hard to identify. Get tips from Bank of America on how to avoid email scams.">
<meta name="Keywords" CONTENT="phishing scams, email scams, how to avoid phishing, how to avoid email scams">

					<meta name="twitter:title" CONTENT="How to Avoid Email Scams - Advice from Bank of America" />
					<meta name="twitter:card" CONTENT="summary" />
					<meta name="twitter:url" CONTENT="https://www-preview.ecnp.bankofamerica.com/onlinebanking/education/how-to-avoid-email-scams.go" />
					<meta name="twitter:image" CONTENT="https://www.bankofamerica.com/content/images/ContextualSiteGraphics/Instructional/en_US/financial-education/how_to_avoid_email_scams_288x216.jpg" />
					<meta name="twitter:description" CONTENT="Sometimes phishing and email scams can be hard to identify. Get tips from Bank of America on how to avoid email scams." />
					<meta name="twitter:site" CONTENT="@BofA_Tips" />
				<meta property="og:title" CONTENT="How to Avoid Email Scams - Advice from Bank of America" />
				<meta property="og:type" CONTENT="website" />
				<meta property="og:url" CONTENT="https://www-preview.ecnp.bankofamerica.com/onlinebanking/education/how-to-avoid-email-scams.go" />
				<meta property="og:image" CONTENT="https://www.bankofamerica.com/content/images/ContextualSiteGraphics/Instructional/en_US/financial-education/how_to_avoid_email_scams_288x216.jpg" />
				<meta property="og:description" CONTENT="Sometimes phishing and email scams can be hard to identify. Get tips from Bank of America on how to avoid email scams." />
				<meta property="og:site_name" CONTENT="Bank of America" />
<link rel="shortcut icon" href="https://www2.bac-assets.com/pa/global-assets/1.0/graphic/favicon.ico" type="image/ico" />


	


			<script src="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/Global/1.0/script/tealeafbundle.js" type="text/javascript"></script>
	
	   
			<link rel="stylesheet" type="text/css" href="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/PBI-WEB/2017.03.0/style/pbi-web-jawr.css" media="all" />
			<link rel="stylesheet" type="text/css" href="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/PBI-WEB/2017.03.0/style/pbi-web-jawr-print.css" media="print" />
			<script src="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/PBI-WEB/2017.03.0/script/pbi-web-jawr.js" type="text/javascript"></script>

<script type="text/javascript">
(function() {
	if (typeof mboxUpdate == "function") {
		var windowURL = window.location.href
	    windowURL = windowURL.slice( windowURL.indexOf('.')+1);
		windowURL = windowURL.split( '?' )[0];
		windowURL = windowURL.toLowerCase();
		//alert(windowURL);
		if (
		    //If no mboxes on page, mbox count will be < 1
		    (mboxFactoryDefault.getMboxes().length() < 1) &&  
			
			//Also check for high-volume pages that do not need global logging
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go") &&
			(windowURL != "bankofamerica.com/myaccounts/signin/signin.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/entry/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signonscreen.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatechallengeanswer.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatePassword.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/mobile/banking.go")&&
			(windowURL != "bankofamerica.com/content/preload/olb-myaccount-preload-jawr-module.htm")
			)
		{

			var mboxDiv = document.createElement("div");
			mboxDiv.id = "adobe_touch_clarity_replacement";
			mboxDiv.style.display = "none";
			if (document.body && document.body.firstChild) document.body.insertBefore(mboxDiv,document.body.firstChild);
			mboxDefine(mboxDiv.id,'bac_global_bottom');
			mboxUpdate('bac_global_bottom');
		}
	}	
})();
</script>

	
			<script>
				var boaPageDataJS = {};
					boaPageDataJS.isLLE = "false";
			</script>
				<style>body{display:none;}</style>
	</head>		

	<body class="fsd-layout-body">	

				<script type="text/javascript">if(self == top){var theBody=document.getElementsByTagName("body")[0];theBody.style.display="block";}else{top.location=self.location;}</script>
				<noscript><style>body{display:block;}</style></noscript>
					<a class='ada-hidden ada-visible-focus' href='#skip-to-h1' id='ada-skip-link'>Skip to main content</a>
		<div class="fsd-layout fsd-2c-600lt-layout fsd-full-width">
			<div class="fsd-border">
				<div class="center-content">
					<div class="header">
		  



<script language="javascript" src="/pa/components/modules/tag-manager-module/1.1/script/tag-manager-module-borneo-global-skin.js"></script>
<script>

(function() {
  var fireCallback = function( cb ) {
    if ( typeof cb === "function" ) cb();
  };
  
  function ddoPopulateBase( callback ) {
    try {
		  var DDO = window.digitalData,
		  	bactm_mergeDDO = function( newDDO, priorDDO ) {
		  		if( typeof priorDDO === "undefined" ) {
				  	priorDDO = digitalData || {};
				  }

			    for (var l in newDDO) {
			        if (typeof priorDDO[l] === "undefined") {
			            priorDDO[l] = newDDO[l];
			        }
			        if (newDDO[l] !== null) {
			            if (typeof newDDO[l] === "object") {
			                bactm_mergeDDO(newDDO[l], priorDDO[l]);
			            } else {
			                priorDDO[l] = bactm_validateValue( newDDO[l] ) ? newDDO[l] : priorDDO[l];
			            }
			        }
			    }

			    return priorDDO;
				},
				bactm_olb3rdPartyId = "null";

			if (typeof DDO === "undefined") {
				var simpleDDO = { page: { pageInfo:[{ pageID: null }], attributes: {}, category: { primaryCategory: null }}};

				DDO = (typeof digitalData === "object") ? digitalData : simpleDDO; 
			}

				DDO = bactm_mergeDDO( {pageInstanceID:"notprod",load_coremetrics:false,load_opinionlabs:false,load_touchcommerce:true,load_audiencemanager:true,page:{pageInfo:[{pageID:null,destinationURL:null,referringURL:null,issueDate:null,language:null,segmentValue:null,appName:null,appStepNumber:null,appStepName:null,attr:"-_--_--_--_--_--_--_--_--_--_--_--_--_--_-"}],category:{primaryCategory:null,addlCategory:null,pageType:null},attributes:{searchString:null,searchResults:null,olbSessionID:null,subCampaignCode:null,DARTUrl:null,stateCookie:null,SASIEnabled:false,needOLBcookie:false,standardDART:[],standardDARTes:[],clickDART:[],clickDARTes:[],gaId:[],chat:{account_type:null,boa_associate:null,boa_retiree:null,customer_lob:null,customer_segment:null,data:null,email_campaign:null,entitlement_code:null,error_category:null,error_count:null,first_login:null,inqSalesProductTypes:{},invitation_background:null,invitation_template:null,referral_campaign:null,getStateValue:false,cust_fn:null,cust_ln:null,target:null}}},user:{segment:null,online_id:null,preferred_rewards_tier:null,olb3rdpartyid:null},version:"BAC_0.12"}, DDO );

			DDO.page.pageInfo[0].pageID = "OSP:Content:OLB:OLB_Education;how-to-avoid-email-scams";
			DDO.page.category.primaryCategory  = "OSP:Content:OLB:OLB_Education";
			DDO.page.pageInfo[0].language = "en-US";
			DDO.page.attributes.olbSessionID = "null";
			DDO.page.attributes.SASIEnabled =  "false";
			if (typeof DDO.user != "undefined" && typeof DDO.user.olb3rdpartyid != "undefined") {
				DDO.user.olb3rdpartyid = bactm_olb3rdPartyId;
			}

			window.utag_data = {};
			window.bactm_envSelector = bactm_setTMLib();
			window.digitalData = DDO;

      return fireCallback( callback );

    } catch(e) { }
  }
	if( window.boa && window.boa.digitalData ) {
    window.boa.digitalData.register( ddoPopulateBase );
	}
	else {
	  // Handle scenario where the header isn't available (and thus the default digitalData object and utag loader are missing).
	  //
		var writeScript = function(a,b,c,d){
			a='//tags.tiqcdn.com/utag/bofa/main/' + bactm_envSelector + '/utag.js';
			b=document;
			c='script';
			d=b.createElement(c);
			d.src=a;
			d.type='text/java'+c;
			d.async=true;
			a=b.getElementsByTagName(c)[0];
			a.parentNode.insertBefore(d,a);
		};

		ddoPopulateBase( writeScript );
	}
})();			
</script>





	
	
				<noscript>
				
					<div class="fauxdal-overlay"></div>
					<div class="fauxdal-module">
						<div class="js-disabled-skin">
							<div class="fauxdal-top"></div>
							<div class="fauxdal-bottom">
								<div class="fauxdal-content">
										<div class="fauxdal-title">
											Please Use JavaScript
										</div>
											<p>You need a web browser that supports JavaScript to use our site. Without it, some pages won&rsquo;t work as designed. To make sure JavaScript is turned on, please adjust your browser settings.</p>
<p><a name="Browser_Help_And_Tips" href="/onlinebanking/online-banking-security-faqs.go" target="_blank">Browser Help and Tips</a></p>
										
								</div>        
								<div class="fauxdal-close"> 
									<a class="btn-bofa btn-bofa-small" href=?js=y>Close</a>
								</div>
							
							</div>
						</div>
					</div>
				</noscript>



 


<div class="header-module">
	<div class="text-w-logo-skin">
		<div class="header-left">
	  
			<div itemscope itemtype="http://schema.org/Corporation" class="bofa-logo">
				<a itemprop="url" name="anc-online-banking" title="Bank of America" href="/">
					<img itemprop="logo" height="28" width="221" 
					     alt="Bank of America" src="https://www2.bac-assets.com/content/images/ContextualSiteGraphics/Logos/en_US/boa_logo.gif"/>
				</a>
			</div>
				<div class="product" data-font="cnx-regular">Online Banking</div>
			
			<div class="clearboth"></div>

		</div>
		
		<div class="header-right">
			<ul class="header-links">
			
				
					
				
							<li class="sign-in">
		<a					href="/sitemap/hub/signin.go" target="_self"
		name="Sign_In">Sign In</a> 
							</li>
					
				
							<li>		<a					href="/" target="_self"
		name="Home_Header">Home</a> 
</li>
					
				
							<li>		<a					href="https://locators.bankofamerica.com" target="_self"
		name="Locations">Locations</a> 
</li>
					
				
							<li>		<a					href="/contactus/contactus.go" target="_self"
		name="Contact_Us">Contact Us</a> 
</li>
					
				
							<li class="last-link">	
		<a					href="/help/overview.go" target="_self"
		name="Help">Help</a> 
							</li>
			</ul>
			
			<div class="clearboth"></div>

			<!-- include search-dotcom-util -->



<div class="header-search nlh">
  
  <div class="nav-search">
    <form class="search-form" action="https://secure.bankofamerica.com/myaccounts/public/search-results/unAuthenticatedSearch.go" data-js="/pa/components/utilities/search-util/1.0/script/nav-search.min.js" data-css="/pa/components/utilities/search-util/1.0/style/nav-search.css" data-text-unavailable="Search Currently Unavailable">
      <div class="search-input-container cf" data-icon="search">
        <label for="nav-search-query" class="ada-hidden">Search Term</label>
        <input type="text" placeholder="How can we help you?" name="query" class="search-query" id="nav-search-query" 
          maxlength="99" rel="Search" autocomplete="off"><input type="submit" alt="Search" title="Search" value="Submit Search" name="Search Module - Top Result – Search Button" class="submit track-me">
      </div>
    </form>
  </div>

</div>

		</div>

 		<div class="clearboth"></div>
 	</div>
</div>

	<div class="top-nav-module">
		<div class="fsd-skin sup-ie">
			<ul class="nav-list">
					
					
					<li>
						
									<a href="/onlinebanking/online-banking.go" class="top-menu-item"
									name="overview_topnav" id="overview_topnav">Overview</a>
					</li>
					
					
					<li>
						
									<a href="/onlinebanking/online-bank-account.go" class="top-menu-item"
									name="manage_accounts_topnav" id="manage_accounts_topnav">Manage Accounts</a>
					</li>
					
					
					<li>
						
									<a href="/onlinebanking/online-bill-pay.go" class="top-menu-item"
									name="pay_and_transfer_topnav" id="pay_and_transfer_topnav">Pay and Transfer</a>
					</li>
					
					
					<li>
						
									<a href="/onlinebanking/financial-management-tools.go" class="top-menu-item"
									name="budget_and_track_topnav" id="budget_and_track_topnav">Budget and Track</a>
					</li>
					
					
					<li>
						
									<a href="/onlinebanking/learning-center.go" class="top-menu-item selected"
									name="get_answers_topnav" id="get_answers_topnav">Get Answers <span class="ada-hidden"> for your Online Banking questions</span></a>
					</li>
					
					
					<li>
						
									<a href="https://secure.bankofamerica.com/login/enroll/entry/olbEnroll.go?reason=model_enroll" class="top-menu-item"
									name="enroll_in_online_banking_topnav" id="enroll_in_online_banking_topnav">Enroll in Online Banking</a>
					</li>
			</ul>
				<div class="clearboth"></div>
		</div>
	</div>



		<div class="page-title-pbi-web-module h-100">
			<div class="std-red-noh1-skin sup-ie">
				<div class="wrapper">
					<p data-font="cnx-regular">Get Answers</p>
				</div>
			</div>				
		</div>					

<SCRIPT language="JavaScript">

if (document.referrer){
var ord = Math.random()*1000000000000;
document.write('<SCRIPT language="JavaScript1.1" SRC="https://ad.doubleclick.net/adj/N4359.nso.codesrv/B7578164;dcadv=4104884;sz=1x2;ord;ord=' + ord + '?"><\/SCRIPT>');
}
var naturalSearchComplete = true;

</SCRIPT>

			<div itemscope="itemscope" itemtype="http://schema.org/Webpage">
					<span style="display:none" itemprop="name">How to Avoid Email Scams - Advice from Bank of America</span>
					<a style="display:none" itemprop="url" href="https://www.bankofamerica.com/onlinebanking/education/how-to-avoid-email-scams.go"></a>
					<span style="display:none" itemprop="description">Sometimes phishing and email scams can be hard to identify. Get tips from Bank of America on how to avoid email scams.</span>
					<img style="display:none" class="no-stretch" itemprop="image" alt="How to Avoid Email Scams - Advice from Bank of America" src="https://www.bankofamerica.com/content/images/ContextualSiteGraphics/Instructional/en_US/financial-education/how_to_avoid_email_scams_288x216.jpg">
					<span style="display:none" itemprop="sourceOrganization">Bank of America</span>
					<span style="display:none" itemprop="keywords">phishing scams, email scams, how to avoid phishing, how to avoid email scams</span>
			</div>
</div>
					<div class="columns">
						<div class="flex-col lt-col" >


		<div class="page-title-fsd-module h-100" id="skip-to-h1">
			<div class="main-well-skin sup-ie">
				<h2 data-font="cnx-regular" class="mtop-20">How to spot an email scam</h2>
			</div>
		</div>

	<script type="text/javascript" src="https://www.bankofamerica.com/pa/components/modules/social-widget-module/1.2.5/script/socialplugin.js"></script>
	





<div class="social-widget-module">
	<div class="social-widget-inner" style="height:22px;;">
		
			<div id="sharebar">
				 <script type="text/javascript">
				new com.bofa.socialplugin.core.ShareBarPlugin().display({
						"socialplugin_apppath" : "https://www.bankofamerica.com/pa/components/modules/social-widget-module/1.2.5",
						"socialconfig_apppath" : "https://www.bankofamerica.com/content/social",
						"gigyaApiKey" : "3_tIhxOOqZ3o4KC8r_VvalOR-b72A08kp4a1vdf6uyaSH4VTdeKCqMmAwh7n7AX4gz",
						"elementId" : "sharebar",
						"type" : "leftArticle",
						"showCounters" : true,
						"enablePrint" : true,
						"contentOverride"	: {
							"facebook" : { "showCounter": false , "tinyUrlCode": '8g3jr' },
							"twitter"  : { "showCounter": false , "tinyUrlCode": 'rtmwg' },
							"linkedin"  : { "showCounter": false , "tinyUrlCode": 'r2ryd' },
							"digg"  : { "showCounter": false },
							"delicious"  : { "showCounter": false },
							"reddit"  : { "showCounter": false },
							"stumbleupon"  : { "showCounter": false },
							"pinterest"  : { "showCounter": false }
						}
					});
				 </script>
			</div>

	</div>
</div>





	<div class="main-well-content-pbi-web-module">
		<div class="article-skin">
			<div class="article-main com-main-well-content sup-ie  table-vzd3-common">
			
						
				
						<div class="h1-border"></div>
					
				
					<div class="text-container-full-width">
					
						
									<p>A 2015 study of 235 billion email messages<a href="#Footnote 1" name="1"><span class="ada-hidden">Footnote</span><sup>1</sup></a> found nearly 10% were suspicious. As phishing scams and email scams get more sophisticated, it&rsquo;s important to know how to spot them so you can avoid them.</p>
					</div>
		</div>	
		</div>
	</div>







	<div class="main-well-content-pbi-web-module">
		<div class="article-skin">
			<div class="article-main com-main-well-content sup-ie  table-vzd3-common">
			
						
				
					<div class="sprite-A1">
					
						
					</div>
				
					<div class="sprite-C1">
					
						
					</div>
				
					<div class="sprite-G3">
					
						
					</div>
				
					<div class="">
					
						
					</div>
		</div>	
		</div>
	</div>





		<div class="main-well-content-pbi-web-module">
			<div class="img-toggle-txt-skin com-main-well-content sup-ie ">				
				<div class="image-wrapper">					
						<img src="https://www2.bac-assets.com/content/images/ContextualSiteGraphics/Instructional/en_US/financial-education/how_to_avoid_email_scams_288x216.png" alt="How to Avoid Email Scams" usemap="#email-scam"/>
						<map name="email-scam">
							<area coords="50,1605,550,1650" href="/privacy/online-mobile-banking-privacy/online-banking-security.go" alt="" />
						</map>
									<span class="text-version-link toggle-info-graphic closed">
										<a name="anc-show-text-version" href="javascript:void(0);"><span class="show-hide-txt">Show </span><span class="ada-hidden">infographic </span>Text Version</a>
									</span>	
					<div class="text-version table-vzd3-common hide">		
								<div class="text-container-block">							
										<h2><span class="h3-styling"> Can you spot a fraudulent email?</span></h2>	
										<p>While over half of Internet users get at least one phishing email per day ... <strong>80%</strong> of those surveyed failed to identify fraudulent emails.<sup>1</sup></p>
									<div class="">
													<p><strong>So how can you spot an email that&rsquo;s attempting to trick you?</strong></p>
<p>Start with the subject line.</p>
<p>If the name looks odd or unfamiliar, be on alert. <br /> If the message suggests urgent or immediate action, that&rsquo;s another red flag.</p>																																
													<p><strong>But don&rsquo;t stop with the subject line; there are other signs too.</strong></p>
<p>The body of a phishing or fraudulent email can be full of clues.</p>
<p>Does not display last log-in date.*<br /> Does not address the customer by name.<br /> Legitimate sites will not ask you to verify your information.<br /> Specific instructions not to call are a bad sign.<br /> Does not display the last 4 digits of the account in question.*<br /> Service messages, marketing outreach and alerts should never have attachments.<br /> UK spellings, simple misspellings or awkward word choices should give you pause.<br /> Be suspicious of URLs that are unusual or appear to have been altered.</p>																																
													<p><strong>What to do next if you flag a fraudulent email ...</strong></p>
<p>First, do not click on any links, reply to the message or download any items.</p>
<p>Second, forward the email to spam@uce.gov (Bank of America customers can send to abuse@bankofamerica.com)&mdash;and then delete it.</p>
<p>Last, but always: Stay vigilant&mdash;your best shield against phishing attacks is to be on the lookout at all times. And remember, <a href="/privacy/online-mobile-banking-privacy/online-banking-security.go" name="protecting-you">Bank of America is always working to help protect you online</a>.</p>																																
													<p><sup>1</sup>http://www.cbsnews.com/news/majority-of-americans-fall-for-email-phishing-scams-cbs-intel-security-quiz/</p>
<p><i>*Note: The information presented here may not be applicable to all financial institutions.</i></p>
<p>Bank of America</p>																																
									</div>				
								</div>
										<span class="close-link toggle-info-graphic">
											<span class="ada-hidden">End of infographic text version</span>
										<a name="anc-close-infographics" href="javascript:void(0);">Close<span class="ada-hidden"> Infographic Text Version</span></a>							
										</span>	
					</div>
					<p class="bottom-copy">Bank of America customers have free access to <a href="/privacy/online-mobile-banking-privacy/trusteer-rapport.go" name="trusteer-rapport">IBM&rsquo;s Trusteer Rapport</a>, a service that helps protect your account information and helps keep you safe while you browse the internet.</p>
				</div>			
			</div>		
		</div>
</div>
						<div class="flex-col rt-col" >



<style type="text/css">
			.rom-ss .sprite .spr {
				background-image: url(/content/images/ContextualSiteGraphics/Instructional/en_US/digital-signature-sprite-1x.png);
				background-size: 750px 500px;
			}
            @media
            only screen and (-webkit-min-device-pixel-ratio: 2),
            only screen and (   min--moz-device-pixel-ratio: 2),
            only screen and (     -o-min-device-pixel-ratio: 2/1),
            only screen and (        min-device-pixel-ratio: 2),
            only screen and (                min-resolution: 192dpi),
            only screen and (                min-resolution: 2dppx) { 
            	.rom-ss .sprite .spr {
			        background-image: url(/content/images/ContextualSiteGraphics/Instructional/en_US/digital-signature-sprite-2x.png);
            	}
            }
				html.lt-ie9 .rom-ss .sprite .spr {
					background-image: url(/content/images/ContextualSiteGraphics/Instructional/en_US/digital-signature-sprite-1x.png8.png);
				}
</style>



 

<!-- 010716_1607 -->



	<!--Debug deploy issue-->

    <div class="research-options-module rom research-options-module-sidewell-skin rom-ss" data-component="module" data-module="research-options" data-skin="sidewell">
		<ul class="rom-container toggle-one" data-font="cnx-regular" data-toggle-speed="300">

	<li id="rom-learn" class="toggled" >
	    <h3 data-font="cnx-regular" class="sprite sprite-a1">
	        <a href="#rom-learn-content" id="showhide-rom-learn-content">
	            <span class="closed ada-hidden">I would like to</span>
	            <span class="open ada-hidden">I no longer want to</span>
	            Learn <span>more about this topic</span>
	        </a>
	    </h3>
	    <div id="rom-learn-content" class="section section-list-small">
			        <ul>

				
				<!-- This section has to be removed -->

	    	        	<li class="sprite sprite-B6 ">
	    	        		<a id="strong-password" href="/deposits/manage/how-to-create-a-strong-password.go">How to create a strong password</a>
	    	        	</li>
				
				<!-- This section has to be removed -->

	    	        	<li class="sprite sprite-B6 ">
	    	        		<a id="secure-smartphone" href="/deposits/manage/advantages-of-online-banking.go">How to secure your smartphone</a>
	    	        	</li>
				
				<!-- This section has to be removed -->

	    	        	<li class="sprite sprite-B6 ">
	    	        		<a id="online-security-tips" href="/deposits/manage/online-security-tips.go">10 online and mobile security tips</a>
	    	        	</li>
				
				<!-- This section has to be removed -->

	            		<li class="sprite sprite-A6 more">
	            			<a id="more-in-get-answers" href="/onlinebanking/learning-center.go">More in <strong>Get Answers</strong></a>
	            		</li>

                        <li class="content-link template template-default sprite sprite-{{sprite}} nosprite">
                            <a href="{{link}}" id="{{id}}">
                                {{title}}
                            </a>
                        </li>

			        </ul>
		</div>
	 </li>

	<li id="rom-talk"  >
	    <h3 data-font="cnx-regular" class="sprite sprite-c1">
	        <a href="#rom-talk-content" id="showhide-rom-talk-content">
	            <span class="closed ada-hidden">I would like to</span>
	            <span class="open ada-hidden">I no longer want to</span>
	            Talk <span>to a solutions expert</span>
	        </a>
	    </h3>
	    <div id="rom-talk-content" class="section section-list-medium">
			        <ul>

				
				<!-- This section has to be removed -->



                        <li data-font="cnx-regular">
                            <p>To make an appointment online to meet with a banking specialist</p>
                            <h4 class="sprite sprite-B5">
                                Visit
                            </h4>
                            <a class="btn-bofa btn-bofa-blue btn-bofa-flat" data-font="cnx-medium" href="https://secure.bankofamerica.com/mycommunications/public/appointments/getTopics.go?marketingCode=2014FINEDU_ECBBA&cm_sp=OLB-General-_-DigitalSigTalk-_-OG16LT005C_rh_BBAOLB_Schedule_an_appointment_OLB&orig=landing" id="rom-talk-visit">
                                Schedule an appointment
                            </a>
                        </li>

                        <li data-font="cnx-regular" class="content-call template template-call">
                            <p>{{message}}</p>
                            <h4 class="sprite sprite-{{sprite}} nosprite">
                                <a class="phone" href="tel:{{phone}}" id="{{id}}">{{phone}}</a>
                            </h4>
                        </li>
                        <li data-font="cnx-regular" class="content-visit template template-visit">
                            <p>{{message}}</p>
                            <h4 class="sprite sprite-{{sprite}} nosprite">{{title}}</h4>
                            <a class="btn-bofa btn-bofa-blue btn-bofa-flat" href="{{link}}" id="{{id}}">{{linkText}}</a>
                        </li>

			        </ul>
		</div>
	 </li>

	<li id="rom-find"  >
	    <h3 data-font="cnx-regular" class="sprite sprite-g3">
	        <a href="#rom-find-content" id="showhide-rom-find-content">
	            <span class="closed ada-hidden">I would like to</span>
	            <span class="open ada-hidden">I no longer want to</span>
	            Find <span>our related products</span>
	        </a>
	    </h3>
	    <div id="rom-find-content" class="section section-flexible">

				
				<!-- This section has to be removed -->

	                    <div class="content content-standard">
	                    	<p><a href="/onlinebanking/online-banking.go?cm_sp=OLB-General-_-DigitalSigFind-_-OG16LT0059_rh_OLB_Online_banking_265.png" title="Online Banking: Bank how, when and where you want. Learn more" name="learn-more-promo-research" target="_self"><img src="https://www2.bac-assets.com/content/images/ContextualSiteGraphics/Instructional/en_US/Online_banking_265.png" alt="" /></a></p>
	                    </div>

	                    <div class="content template template-default">
	                        {{message}}
	                    </div>
	                    <div class="content template template-image">
	                        {{message}}
	                        {{image}}
	                        <a class="btn-bofa btn-bofa-blue btn-bofa-flat" data-font="cnx-medium" href="{{link}}" id="{{id}}">{{title}}</a>
	                    </div>
	                    <div class="content content-image-left template template-image-left sprite sprite-{{sprite}} nosprite">
	                        <p>{{message}}</p>
	                        <a class="btn-bofa btn-bofa-blue btn-bofa-flat" data-font="cnx-medium" href="{{link}}" id="{{id}}">{{title}}</a>
	                    </div>

		</div>
	 </li>
	    </ul>
	</div>
</div>
						<div class="clearboth"></div>
					</div>
					<div class="footer">
						<div class="footer-top">&nbsp;




	<div class="hide com-interstitial-modal">
     	<h3>Continuar en ingl&eacute;s</h3>
   		<div class="flex-modal-main-content">
   		
      		<p><strong></strong></p>
      		<p>La informaci&oacute;n que se encuentra a continuaci&oacute;n est&aacute; disponible s&oacute;lo en ingl&eacute;s en la actualidad.</p><p>Las solicitudes y los documentos asociados con productos y servicios espec&iacute;ficos podr&iacute;an estar disponibles s&oacute;lo en ingl&eacute;s. Antes de escoger un producto, por favor aseg&uacute;rese de haber le&iacute;do y entendido todos los t&eacute;rminos y condiciones provistas.</p><p>Seleccione Continuar en ingl&eacute;s para obtener m&aacute;s informaci&oacute;n.</p>
   	
   	<div class="flex-modal-buttons">
	      	<a href="javascript:void(0);" class="button-common button-blue" name="anc-continue"><span>Continuar en ingl&eacute;s</span></a>
	         
	      	<a href="javascript:void(0);" class="button-common button-gray close-com-interstitial" name="anc-cancel-btn"><span>Cancelar</span></a>
	         
          <div class="clearboth"></div>
      </div>
   </div>
</div>






<!-- Interstitial modal window starts-->
<div class="modal-content-module">
  <div class="interstitial-fsd-skin">
  
		
      <div class="boa-interstitial-layer hide" id="boa-interstitial-layer" > 
          <a id="boa-interstitial-layer-close" name="boa-interstitial-layer-close" class="ui-dialog-titlebar-close" href="javascript:void(0);"><span class="ui-icon"></span><span class="ada-hidden">close</span></a>
          <div class="modal-container">
             <h2>You Are Leaving Bank of America</h2>
			 <div class="modal-main-content">               
                <p>By clicking <strong>Continue</strong>, you will be taken to a Web site that is not affiliated with Bank of America and may offer a different privacy policy and level of security. Bank of America is not responsible for and does not endorse, guarantee or monitor content, availability, viewpoints, products or services that are offered or expressed on other Web sites.</p>
<p>For your security, Online Banking may automatically sign off while you are visiting another Web site. You will receive a pop-up message notifying you before your Online Banking session ends.</p>
             </div>
          </div>
      </div>
  </div>
</div>           
<!-- Interstitial modal window ends-->
   </div>
						<div class="footer-inner">
<div class="footnote-com-module">
   <div class="fsd-layout-skin sup-ie">
					<div class="h-100">
						<div class="footnote" id="footnote1">
							<div class="fn-num">1.</div>
							<div class="fn-text"><a href="javascript:void(0);" class="boa-interstitial" rel="https://returnpath165.newswire.com/press-release/billions-of-email-messages-attributed-to-global-brands-potentially-fraudulent" name="global-brand" target="_self">https://returnpath165.newswire.com/press-release/billions-of-email-messages-attributed-to-global-brands-potentially-fraudulent</a> </div>
							<div class="clearboth"></div>
						</div>
					</div>
   </div>
</div>










<div class="power-footer-module">
	<div class="fsd-flex-skin sup-ie">
		<div class="breadcrumbs">
		<div itemscope itemtype="http://schema.org/BreadcrumbList">
								<div itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
										<a itemprop="item" class="bold-bc" href="/" name="bank_of_america_how_to_avoid_email_scams_breadcrumbs" target="_self">
										<span itemprop="name">Bank of America</span>
										<meta itemprop="position" content="1" /></a>
								</div>
								<div itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
										<a itemprop="item" href="/onlinebanking/online-banking.go" name="online_banking_how_to_avoid_email_scams_breadcrumbs" target="_self">
										<span itemprop="name">Online Banking</span>
										<meta itemprop="position" content="2" /></a>
								</div>
				   				    
								<div itemprop="itemListElement" itemscope itemtype=http://schema.org/ListItem>
									<a itemprop="item" href="/onlinebanking/learning-center.go" name="get_answers_how_to_avoid_email_scams_breadcrumbs" target="_self">
										<span itemprop="name">Get Answers <span class="ada-hidden"> for your Online Banking questions</span></span>
										<meta itemprop="position" content="3"/>
									</a>
								</div>
				    

				    
				    
				    
				    <div class="breadcrumb-last-item" itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
					<span itemprop="name">How to spot an email scam</span>
					<meta itemprop="position" content="4" />
				    </div>		
			
<div class="clearboth"></div>
</div>
</div>

<div class="pf-columns">
			  
				  	<div class="pf-col">
				  
				  
						<a href="/onlinebanking/online-banking.go" name="online_banking_overview_how_to_avoid_email_scams_power_footer" class="bold" target="_self">Online Banking Overview</a>
				   
									<a href="https://secure.bankofamerica.com/login/enroll/entry/olbEnroll.go?reason=model_enroll"  name="enroll_in_online_banking_how_to_avoid_email_scams_power_footer" target="_self">Enroll in Online Banking</a>
									<a href="/online-banking/service-agreement.go"  name="service_agreement_how_to_avoid_email_scams_power_footer" target="_self">Service Agreement</a>
									<a href="/online-banking/eComm-Disclosure.go"  name="ecommunications_disclosure_how_to_avoid_email_scams_power_footer" target="_self">eCommunications Disclosure</a>
									<a href="/onlinebanking/online-banking-security-guarantee.go"  name="online_banking_security_guarantee_how_to_avoid_email_scams_power_footer" target="_self">Online Banking Security Guarantee</a>
					</div>   
			  
			  
				  	<div class="pf-col">
				  
				  
						<a href="/onlinebanking/online-bank-account.go" name="manage__accounts_how_to_avoid_email_scams_power_footer" class="bold" target="_self">Manage Accounts</a>
				   
									<a href="/onlinebanking/online-bank-account.go#account-activity"  name="activity_how_to_avoid_email_scams_power_footer" target="_self"><span class="ada-hidden">Manage accounts </span>Activity</a>
									<a href="/onlinebanking/online-bank-account.go#alerts"  name="alerts_how_to_avoid_email_scams_power_footer" target="_self"><span class="ada-hidden">Manage accounts </span>Alerts</a>
									<a href="/onlinebanking/online-bank-account.go#statements"  name="statements_how_to_avoid_email_scams_power_footer" target="_self"><span class="ada-hidden">Manage accounts </span>Statements</a>
									<a href="/onlinebanking/online-bank-account.go#bankamerideals"  name="bankamerideals_how_to_avoid_email_scams_power_footer" target="_self"><span class="ada-hidden">Manage accounts </span>BankAmeriDeals<sup>&reg;</sup></a>
					</div>   
			  
			  
				  	<div class="pf-col">
				  
				  
						<a href="/onlinebanking/online-bill-pay.go" name="pay_and_transfer_how_to_avoid_email_scams_power_footer" class="bold" target="_self">Pay and Transfer</a>
				   
									<a href="/onlinebanking/online-bill-pay.go#payments"  name="payments_how_to_avoid_email_scams_power_footer" target="_self">Payments</a>
									<a href="/onlinebanking/online-bill-pay.go#transfers"  name="transfers_account_how_to_avoid_email_scams_power_footer" target="_self">Transfers</a>
					</div>   
			  
			  
				  	<div class="pf-col">
				  
				  
						<a href="/onlinebanking/financial-management-tools.go" name="budget_and_track_how_to_avoid_email_scams_power_footer" class="bold" target="_self">Budget and Track</a>
				   
									<a href="/onlinebanking/financial-management-tools.go#my-portfolio"  name="my_portfolio_how_to_avoid_email_scams_power_footer" target="_self">My Portfolio<sup>&reg;</sup></a>
					</div>   
			  
			  
				  	<div class="pf-col">
				  
				  
						<a href="/onlinebanking/learning-center.go" name="get_answers_how_to_avoid_email_scams_power_footer" class="bold" target="_self">Get Answers <span class="ada-hidden"> for your Online Banking questions</span></a>
				   
									<a href="/onlinebanking/online-banking-services-faqs.go"  name="faqs_how_to_avoid_email_scams_power_footer" target="_self"><span class="ada-hidden">Get Answers </span>FAQs</a>
					</div>   
			  
			  
		  <div class="clearboth"></div>
    </div>

</div>
</div>



 



		<div class="global-footer-module">
			<div class="fsd-skin">

				<div class="footer-bottom-left" style="float:left;max-width:66%;">
	    			<div class="gf-links">	          	
						
					
									
									<a  target="_self" href="/" 
									    name="global_footer_home">Home
									</a>
									
						
					
									
									<a  target="_self" href="/privacy/overview.go" 
									    name="global_footer_privacy_security">Privacy & Security
									</a>
									
						
					
									
									<a  target="_self" href="http://careers.bankofamerica.com/careershome.aspx" 
									    name="global_footer_careers">Careers
									</a>
									
						
					
									
									<a  target="_self" href="/sitemap/personal.go" 
									    name="global_footer_site_map">Site Map
									</a>
									
						
					
									<a href="javascript:void(0);" class="gf-last-link boa-dialog boa-com-info-layer-link" name="global_footer_ad_practices_lnk" rel="global_footer_ad_practices">Advertising Practices</a>
								<div id="global_footer_ad_practices" class="hide">
									<h3>Advertising Practices</h3>
										<p>We strive to provide you with information about products and services you might find interesting and useful. Relationship-based ads and online behavioral advertising help us do that.</p>
<p>Here's how it works: We gather information about your online activities, such as the searches you conduct on our Sites and the pages you visit. This information may be used to deliver advertising on our Sites and offline (for example, by phone, email and direct mail) that's customized to meet specific interests you may have.</p>
<p>If you prefer that we do not use this information, you may <a onclick="$('.ui-dialog').remove();" name="WebsiteAdPractices_OptOut" href="/privacy/online-privacy-notice.go#advertising-on-our-sites" target="_blank">opt out of online behavioral advertising</a>. If you opt out, though, you may still receive generic advertising. In addition, financial advisors/Client Managers may continue to use information collected online to provide product and service information in accordance with account agreements.</p>
<p>Also, if you opt out of online behavioral advertising, you may still see ads when you sign in to your account, for example through Online Banking or MyMerrill. These ads are based on your specific account relationships with us.</p>
<p>To learn more about relationship-based ads, online behavioral advertising and our privacy practices, please review the <a onclick="$('.ui-dialog').remove();" name="WebsiteAdPractices_PrivacyNotice" href="/privacy/online-privacy-notice.go" target="_blank">Bank of America Online Privacy Notice</a> and our <a onclick="$('.ui-dialog').remove();" name="Online-privacy-faqs" href="/privacy/faq/online-privacy-faq.go" target="_blank">Online Privacy FAQs</a>.</p>
								</div>
						<div class="clearboth"></div>
	    			</div>
	      			<div class="gf-disclaimer"><img alt="Available on the Apple App Store" src="https://www2.bac-assets.com/content/images/ContextualSiteGraphics/Logos/en_US/Apple_logo.jpg" />
<p>Apple, the Apple logo, iPhone, iPad, Mac and MacBookAir are trademarks of Apple Inc., registered in the U.S. and other countries. App Store is a service mark of Apple Inc.</p>
<div class="clearboth">&nbsp;</div>
</div>
<p>Some accounts, services and fees vary from state to state. Please review the <a href="/deposits/bank-account-fees.go" name="footer-personal-schedule-of-fees" target="_blank">Personal Schedule of Fees</a> for your state, also available at your local Banking Center.</p>
<p>Bank of America, N.A. Member FDIC. <a href="/help/equalhousing_popup.go" onclick="function onclick() { function onclick() { window.open('/help/equalhousing_popup.go','newwin','width=640,height=371,scrollbars=yes,resizable=yes,left=35,top=161'); return false; } }" name="Equal_Housing_Lender">Equal Housing Lender<img alt="" src="https://www2.bac-assets.com/content/images/ContextualSiteGraphics/Logos/en_US/icon_equal_housing_lender.gif" width="14" height="9" /></a><br />&copy; 2016 Bank of America Corporation.</p>
         		</div>
         		<div class="footer-social-container" style="float:right;max-width:30%;padding-left:50px;padding-top:19px;">




<div class="boa-social-loader" data-loaded="false" data-platform="borneo"  data-options=''></div>

         		</div>
         		<div class="clearboth"></div>
  			</div>
		</div>

</div>
					</div>
				</div>
			</div>
		</div>
	</body>	
</html>

