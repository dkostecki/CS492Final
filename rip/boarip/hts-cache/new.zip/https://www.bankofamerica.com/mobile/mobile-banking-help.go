<!DOCTYPE html>
<html lang="en-US" class="no-js"> 


	<head>



<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<title>Get help with Mobile Banking from Bank of America</title>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1,user-scalable=no">

<link rel="apple-touch-icon-precomposed" sizes="144x144" href="https://www2.bac-assets.com/pa/global-mobile-web-dotcom/1.0/graphic/favicon/apple-touch-icon-144x144-precomposed.png">
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="https://www2.bac-assets.com/pa/global-mobile-web-dotcom/1.0/graphic/favicon/apple-touch-icon-114x114-precomposed.png">
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="https://www2.bac-assets.com/pa/global-mobile-web-dotcom/1.0/graphic/favicon/apple-touch-icon-72x72-precomposed.png">
<link rel="apple-touch-icon-precomposed" href="https://www2.bac-assets.com/pa/global-mobile-web-dotcom/1.0/graphic/favicon/apple-touch-icon-precomposed.png">


	   
				<meta name="Keywords" CONTENT="Mobile Banking Help" />
				<meta name="Description" CONTENT="Get help with Mobile Banking from Bank of America" />

		
		<!--my change is here-->
<!--
true 1.4.1.modified
-->
<!--my change is here end-->


	    	
	  		<link href="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/PBI-WEB/2017.03.0/style/global-mw-jawr.css" media="all" rel="stylesheet" type="text/css" /> 
		
		<link href="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/PBI-WEB/2017.03.0/style/pbi-web-mw-jawr.css" 
			media="all" rel="stylesheet" type="text/css" /> 
			
		<script src="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/PBI-WEB/2017.03.0/script/global-mw-jawr.js"
			type="text/javascript"></script>
		
	
     	 <link href="https://www2.bac-assets.com/pa/global-mobile-web-dotcom/1.0/style/global-mobile-web-media-queries.css" media="all" rel="stylesheet" type="text/css" />
			
  <!-- tealeaf is on -->
		<script src="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/Global/1.0/script/tealeafbundle.js" type="text/javascript"></script>         


<style>body{display:none;}</style>

	</head>
	<body class="mw-layout mw-standard-layout" data-component="layout" data-layout="mw-standard">

<script type="text/javascript"> 
	if (self == top) {
		var theBody = document.getElementsByTagName('body')[0];
		theBody.style.display = "block";
	} 
	else {top.location = self.location;}
</script>
<noscript>
	<style>body{display:block;}</style>
</noscript>
		
    		<div id="page" data-role="page" data-page="bac_mobile_banking_help" class=" details">
		  



<script language="javascript" src="/pa/components/modules/tag-manager-module/1.1/script/tag-manager-module-borneo-global-skin.js"></script>
<script>

(function() {
  var fireCallback = function( cb ) {
    if ( typeof cb === "function" ) cb();
  };
  
  function ddoPopulateBase( callback ) {
    try {
		  var DDO = window.digitalData,
		  	bactm_mergeDDO = function( newDDO, priorDDO ) {
		  		if( typeof priorDDO === "undefined" ) {
				  	priorDDO = digitalData || {};
				  }

			    for (var l in newDDO) {
			        if (typeof priorDDO[l] === "undefined") {
			            priorDDO[l] = newDDO[l];
			        }
			        if (newDDO[l] !== null) {
			            if (typeof newDDO[l] === "object") {
			                bactm_mergeDDO(newDDO[l], priorDDO[l]);
			            } else {
			                priorDDO[l] = bactm_validateValue( newDDO[l] ) ? newDDO[l] : priorDDO[l];
			            }
			        }
			    }

			    return priorDDO;
				},
				bactm_olb3rdPartyId = "null";

			if (typeof DDO === "undefined") {
				var simpleDDO = { page: { pageInfo:[{ pageID: null }], attributes: {}, category: { primaryCategory: null }}};

				DDO = (typeof digitalData === "object") ? digitalData : simpleDDO; 
			}

				DDO = bactm_mergeDDO( {pageInstanceID:"notprod",load_coremetrics:false,load_opinionlabs:false,load_touchcommerce:true,load_audiencemanager:true,page:{pageInfo:[{pageID:null,destinationURL:null,referringURL:null,issueDate:null,language:null,segmentValue:null,appName:null,appStepNumber:null,appStepName:null,attr:"-_--_--_--_--_--_--_--_--_--_--_--_--_--_-"}],category:{primaryCategory:null,addlCategory:null,pageType:null},attributes:{searchString:null,searchResults:null,olbSessionID:null,subCampaignCode:null,DARTUrl:null,stateCookie:null,SASIEnabled:false,needOLBcookie:false,standardDART:[],standardDARTes:[],clickDART:[],clickDARTes:[],gaId:[],chat:{account_type:null,boa_associate:null,boa_retiree:null,customer_lob:null,customer_segment:null,data:null,email_campaign:null,entitlement_code:null,error_category:null,error_count:null,first_login:null,inqSalesProductTypes:{},invitation_background:null,invitation_template:null,referral_campaign:null,getStateValue:false,cust_fn:null,cust_ln:null,target:null}}},user:{segment:null,online_id:null,preferred_rewards_tier:null,olb3rdpartyid:null},version:"BAC_0.12"}, DDO );

			DDO.page.pageInfo[0].pageID = "Help:Content-M;Help_Mobile";
			DDO.page.category.primaryCategory  = "Help:Content-M";
			DDO.page.pageInfo[0].language = "en-US";
			DDO.page.attributes.olbSessionID = "null";
			DDO.page.attributes.SASIEnabled =  "false";
			if (typeof DDO.user != "undefined" && typeof DDO.user.olb3rdpartyid != "undefined") {
				DDO.user.olb3rdpartyid = bactm_olb3rdPartyId;
			}

			window.utag_data = {};
			window.bactm_envSelector = bactm_setTMLib();
			window.digitalData = DDO;

      return fireCallback( callback );

    } catch(e) { }
  }
	if( window.boa && window.boa.digitalData ) {
    window.boa.digitalData.register( ddoPopulateBase );
	}
	else {
	  // Handle scenario where the header isn't available (and thus the default digitalData object and utag loader are missing).
	  //
		var writeScript = function(a,b,c,d){
			a='//tags.tiqcdn.com/utag/bofa/main/' + bactm_envSelector + '/utag.js';
			b=document;
			c='script';
			d=b.createElement(c);
			d.src=a;
			d.type='text/java'+c;
			d.async=true;
			a=b.getElementsByTagName(c)[0];
			a.parentNode.insertBefore(d,a);
		};

		ddoPopulateBase( writeScript );
	}
})();			
</script>


	
	
<style>
	.mw-sprite > .sprite {
		background-image: url('/content/images/ContextualSiteGraphics/Instructional/en_US/mobile-web/mw-sprite_2x.20151030.png')!important;
		-webkit-background-size: 400px 400px;
		-moz-background-size: 400px 400px;
		-o-background-size: 400px 400px;
		background-size:  400px 400px;
	}
	.mw-sprite-raster > .sprite {
		background-image: url('/content/images/ContextualSiteGraphics/Instructional/en_US/mobile-web-branded/mw-sprite-raster_20140714@1x.jpg')!important;
		background-size:  400px 400px;
	}
	.mw-sprite-homepage > .sprite {
		background-image: url('/content/images/ContextualSiteGraphics/Instructional/en_US/mobile-web/mw-sprite-homepage_1x20150611.jpg')!important;
		background-size:  400px 400px;
	}

	/* Media query targets any display greater than 640px, or any 2x pixel-ratio webkit device, or any device with a generally high-resolution (192dpi)
	*/
	html.hires .mw-sprite > .sprite {  background-image: url('/content/images/ContextualSiteGraphics/Instructional/en_US/mobile-web/mw-sprite_4x.20151030.png') !important; } 
	html.hires .mw-sprite-raster > .sprite {   background-image: url('/content/images/ContextualSiteGraphics/Instructional/en_US/mobile-web-branded/mw-sprite-raster_20140714@2x.jpg') !important; }      
	html.hires .mw-sprite-homepage > .sprite {   background-image: url('/content/images/ContextualSiteGraphics/Instructional/en_US/mobile-web/mw-sprite-homepage_2x20150611.jpg') !important; }      

	.mw-sprite-2x > .sprite { background-image: url('/content/images/ContextualSiteGraphics/Instructional/en_US/mobile-web/mw-sprite_2x.20151030.png')!important; }
	.mw-sprite-4x > .sprite {  background-image: url('/content/images/ContextualSiteGraphics/Instructional/en_US/mobile-web/mw-sprite_4x.20151030.png') !important; } 

	.mw-sprite-raster-1x > .sprite { background-image: url('/content/images/ContextualSiteGraphics/Instructional/en_US/mobile-web-branded/mw-sprite-raster_20140714@1x.jpg')!important; }
	.mw-sprite-raster-2x > .sprite {   background-image: url('/content/images/ContextualSiteGraphics/Instructional/en_US/mobile-web-branded/mw-sprite-raster_20140714@2x.jpg') !important; }      

	.mw-sprite-homepage-1x > .sprite { background-image: url('/content/images/ContextualSiteGraphics/Instructional/en_US/mobile-web/mw-sprite-homepage_1x20150611.jpg')!important; }
	.mw-sprite-homepage-2x > .sprite {   background-image: url('/content/images/ContextualSiteGraphics/Instructional/en_US/mobile-web/mw-sprite-homepage_2x20150611.jpg') !important; }
</style><a class="mw-mod ada-hidden" href="#skip-to-h1" id="mw-skip-link-module-ada-hidden-skin" data-component="module" data-module="mw-skip-link" data-skin="ada-hidden">Skip To Main Content</a>



	
		
		
<header class="mw-mod mw-header-module-sign-in-skin mw-hm-sis" id="header" 
    data-component="module" data-module="mw-header" data-skin="sign-in" data-id="persistent"
    data-role="header" data-position="fixed" data-fullscreen="true" data-tap-toggle="false">

        <a class="mw-sprite mw-sprite-fill mw-sprite-A1 logo" id="mw-bac-logo" href="/mobile/banking.go">
            Bank of America
        </a>
			
				<a class="mw-sprite mw-sprite-fill mw-sprite-K1 menu" id="mw-menu-open" href="#menu">
						<span class="ada-hidden"></span>
						Activate
						<span class="ada-hidden"> Menu</span>
				</a>
			  
				<a id="mw-sign-in" class="mw-sprite mw-sprite-G1 btn-bofa btn-bofa-icon btn-bofa-sign-in sign-in" href="https://staticweb.bankofamerica.com/cavmwebbactouch/common/index.html#home?app=signon">
						<span class="ada-hidden"></span>
						Sign In
						<span class="ada-hidden">to Online Banking</span>
				</a>
			  
	  
        

</header>


<section class="mw-modal-module-dialog-skin mw-modm-ds   leaving" data-animate="left">
    <div class="g pad os-container">



      	<div class="r row-content rel-external  wrap-none-only ">
			<h2>You're leaving bankofamerica.com</h2>
			<p>You&rsquo;re continuing to a site that we don&rsquo;t own or operate. Please refer to that website&rsquo;s posted privacy policy and terms of use.</p><p>Continue?</p>
		</div>





      	<div class="r row-content rel-internal  wrap-mda-only ">
			<h2>You're leaving Mobile Banking</h2>
			<p>In order to open a new account, you'll be leaving Mobile Banking. To view and manage your current accounts, simply return to your Mobile Banking app.</p>
		</div>



	 <div class="r row-buttons">
			<div class="one-half">
			  <a class="btn-bofa btn-bofa-large no close" href="#" id="leaving-bac-no">Cancel</a>
			</div>
			<div class="one-half">
			  <a class="btn-bofa btn-bofa-large btn-bofa-blue yes" href="#" id="leaving-bac-yes">Continue</a>
			</div>
      </div>



    </div>




<script>
      $(document).on( 'pageshow', function() {
        $('a[rel="external"],a[rel="internal"]').on( 'click', function(e) {
          e.preventDefault();

          var boaModalDialogData = {
            target: ".mw-modm-ds.leaving",
            buffer: 16,
            animation: "left",
            callbacks: {}
          };

          var href = $(this).attr('href');
          $('.yes', boaModalDialogData.target).on('click', function(e) {
            window.location.href = href;
          });
          boaModalDialogData.callbacks.contract = mw.modules.modal.removeRel;

          boaModalDialogData.anchor = $(this);
          var modal1 = mw.modules.modal.init(boaModalDialogData);
        });
      });

				var byaModalDialog = function(e) {

          var boaModalDialogDataBYA = {
            target: ".mw-modm-ds.bya",
            buffer: 16,
            animation: "left",
						background: "#FFFFFF",
            callbacks: {}
          };

          boaModalDialogDataBYA.anchor = $(this);
          var modal2 = mw.modules.modal.init(boaModalDialogDataBYA);
        };
    </script>

  </section>

				<section id="content" data-role="content">
										






<section class="mw-module mw-engagement-module-h1-skin mw-em-h1s help mw-sprite mw-sprite-K2  help mw-sprite mw-sprite-K2" data-component="module" data-module="mw-engagement" data-skin="h1">
	<style>
			/* Non Retina Images */
				.mw-em-h1s div.bounce ul li .img { background-image: url(); }

			@media
				only screen and (min-width: 640px),
				only screen and (min-resolution: 192dpi),
				only screen and (min--moz-device-pixel-ratio: 2),
				only screen and (-o-min-device-pixel-ratio: 2/1), 
				only screen and (-webkit-min-device-pixel-ratio: 2), 
				only screen and (min-device-pixel-ratio: 2) {

					/* Retina Images */
					.mw-em-h1s div.bounce ul li .img { background-image: url(); }
			}
		</style>
	<div class="bounce  no-img-bg"> 
		<ul>
			<li>
				<div class="g pad">
					<div class="r">
						<div class="one-whole">
									<h1>Help</h1>
									<p>Let us help you get the information you're looking for.</p>	
									<div class="img"></div>
							
						</div>
					</div>
				</div>
				
			</li>
		</ul>
	</div>
</section>


<section class="mw-mod mw-links-list-module-tabs-skin mw-llm-tbs width-natural" data-component="module" data-module="mw-link-list-module" data-skin="tabs-skin">
		<nav class="g">
			<ul class="r nav-tabs">
						<li class=" one-third active"><a href="#contact" class =" contact" id="help-link-tab-contact">Contact</a></li>           
						<li class=" one-third"><a href="#faqs" class =" faqs" id="help-link-tab-faqs">FAQs</a></li>           
						<li class=" one-third"><a href="#securitytips" class =" securitytips" id="help-link-tab-security-tips">Security Tips</a></li>           
			</ul>
		</nav>
</section>



	<section class="mw-mod mw-content-module-contact-us-skin mw-cm-cus" data-component="module" data-module="mw-content-module" data-skin="contact-us-skin">
		<div id="contact" class="g pad tab-panel">
				<div class="r" style="margin-top:20px;">
					<div class="one-whole">
						<h3 class="textBold">Online & Mobile Help</h3>
						<p><a href="tel:800-933-6262" id="tel-online-help">1.800.933.6262</a></p>
<p>M&ndash;F&nbsp;8 a.m.&ndash;11 p.m. ET</p>
<p>S&ndash;S 8 a.m.&ndash;8 p.m. ET</p>
					 </div>
				 </div>	         
				<div class="r" >
					<div class="one-whole">
						
						<p>Twitter - send us a Tweet: <a href="http://www.twitter.com/BofA_Help" id="twitter-boa-help" rel="external" target="_self">@BofA_Help</a></p>
<p>M&ndash;F 8 a.m. &ndash;9 p.m. ET</p>
<p>Sat. 11 a.m.&ndash;8 p.m. ET</p>
					 </div>
				 </div>	         
				<div class="r" >
					<div class="one-whole mw-sprite mw-box-arrow">
						
						<p>See more contact options on our <a href="/homepage/overview.go?MobileRedirect=false" id="help-fullsite">full site</a></p>
					 </div>
				 </div>	         
				<div class="r" >
					<div class="one-whole mw-sprite mw-box-arrow">
						
						<p>Find a banking center or ATM</p>
<p><a href="http://locators.bankofamerica.com/locator/locator/" id="help-locations">Locations</a></p>
					 </div>
				 </div>	         
				<div class="r" >
					<div class="one-whole mw-sprite mw-box-arrow">
						
						<p><a href="https://secure.opinionlab.com/ccc01/o.asp?id=wwxOVCML&amp;referer=http%3A%2F%2Fmobile.bankofamerica.com%2Fmobileweb" id="help-feedback">Send feedback</a></p>
					 </div>
				 </div>	         
		</div>		
	</section>







	<section class="mw-mod mw-content-module-full-width-skin mw-cm-fws faq-content" data-component="module" data-module="mw-content-module" data-skin="full-width-skin">
		<div id="faqs" class="g tab-panel">

				<div class="r">
							<div class="one-whole">
								<p>Get answers to our top mobile questions.</p>
							</div>

						<div class="one-whole">
							<ul class="faqs os-container">
									<li class="collapse faq os-ios-only" data-collapse-speed="2000" id = "help-faq-what-can-i-do-on-my-mobile-device-ios">
										<h2 class="collapse-toggle">What can I do on my mobile device?</h2>								
										<div class="collapse-hidden">
													<h3>Manage your accounts</h3>
													<p>If you already have an account with us, you can access it from your mobile device to get account information on the go. There are different ways to do this:</p>
<ul>
<li><a id="sign-in-enroll" href="https://staticweb.bankofamerica.com/cavmwebbactouch/common/index.html#home?app=signon" target="_self">Sign in to your account or enroll for online account access</a> from our mobile home page</li>
<li><a id="download-mobile-app" href="http://itunes.apple.com/us/app/bank-america-mobile-banking/id284847138?mt=8" target="_self">Download our free Mobile Banking App</a> to do more with your accounts on a mobile device, such as deposit checks and get Mobile App Alerts</li>
<li>Use <a id="boa-text-banking" href="/online-banking/mobile-banking-applications.go" target="_self">Bank of America Text Banking</a> to get balance and recent account information</li>
</ul>
													<h3>Shop for products</h3>
													<p>You can also research some of our most popular products, such as checking accounts and credit cards, and check rates for home and auto loans. Often, you can open or apply for an account with a quick phone call.</p>
										</div>	
									</li>
									<li class="collapse faq os-and-only"  id = "help-faq-what-can-i-do-on-my-mobile-device-and">
										<h2 class="collapse-toggle">What can I do on my mobile device?</h2>								
										<div class="collapse-hidden">
													<h3>Manage your accounts</h3>
													<p>If you already have an account with us, you can access it from your mobile device to get account information on the go. There are different ways to do this:</p>
<ul>
<li><a id="sign-in-enroll" href="https://staticweb.bankofamerica.com/cavmwebbactouch/common/index.html#home?app=signon" target="_self">Sign in to your account or enroll for online account access</a> from our mobile home page</li>
<li><a id="download-mobile-app" href="market://details?id=com.infonow.bofa" target="_self">Download our free Mobile Banking App</a> to do more with your accounts on a mobile device, such as deposit checks and get Mobile App Alerts</li>
<li>Use <a id="boa-text-banking" href="/online-banking/mobile-banking-applications.go" target="_self">Bank of America Text Banking</a> to get balance and recent account information</li>
</ul>
													<h3>Shop for products</h3>
													<p>You can also research some of our most popular products, such as checking accounts and credit cards, and check rates for home and auto loans. Often, you can open or apply for an account with a quick phone call.</p>
										</div>	
									</li>
									<li class="collapse faq os-bb-only"  id = "help-faq-what-can-i-do-on-my-mobile-device-bb">
										<h2 class="collapse-toggle">What can I do on my mobile device?</h2>								
										<div class="collapse-hidden">
													<h3>Manage your accounts</h3>
													<p>If you already have an account with us, you can access it from your mobile device to get account information on the go. There are different ways to do this:</p>
<ul>
<li><a id="sign-in-enroll" href="https://staticweb.bankofamerica.com/cavmwebbactouch/common/index.html#home?app=signon" target="_self">Sign in to your account or enroll for online account access</a> from our mobile home page</li>
<li><a id="download-mobile-app" href="http://appworld.blackberry.com/webstore/content/1211/?lang=EN" target="_self">Download our free Mobile Banking App</a> to do more with your accounts on a mobile device, such as deposit checks and get Mobile App Alerts</li>
<li>Use <a id="boa-text-banking" href="/online-banking/mobile-banking-applications.go" target="_self">Bank of America Text Banking</a> to get balance and recent account information</li>
</ul>
													<h3>Shop for products</h3>
													<p>You can also research some of our most popular products, such as checking accounts and credit cards, and check rates for home and auto loans. Often, you can open or apply for an account with a quick phone call.</p>
										</div>	
									</li>
									<li class="collapse faq os-none-only"  id = "help-faq-what-can-i-do-on-my-mobile-device-none">
										<h2 class="collapse-toggle">What can I do on my mobile device?</h2>								
										<div class="collapse-hidden">
													<h3>Manage your accounts</h3>
													<p>If you already have an account with us, you can access it from your mobile device to get account information on the go. There are different ways to do this:</p>
<ul>
<li><a id="sign-in-enroll" href="https://staticweb.bankofamerica.com/cavmwebbactouch/common/index.html#home?app=signon" target="_self">Sign in to your account or enroll for online account access</a> from our mobile home page</li>
<li><a id="download-mobile-app" href="/online-banking/mobile.go?request_locale=en_US" target="_self">Download our free Mobile Banking App</a> to do more with your accounts on a mobile device, such as deposit checks and get Mobile App Alerts</li>
<li>Use <a id="boa-text-banking" href="/online-banking/mobile-banking-applications.go" target="_self">Bank of America Text Banking</a> to get balance and recent account information</li>
</ul>
													<h3>Shop for products</h3>
													<p>You can also research some of our most popular products, such as checking accounts and credit cards, and check rates for home and auto loans. Often, you can open or apply for an account with a quick phone call.</p>
										</div>	
									</li>
									<li class="collapse faq "  id = "help-faq-is-online-banking-the-same-here">
										<h2 class="collapse-toggle">Is Online Banking the same here?</h2>								
										<div class="collapse-hidden">
													<p>Here you can check your balances and get your account details. You can also pay bills and make transfers after setting up those services on your personal computer. If you&rsquo;ve already enrolled in Online Banking and have an Online ID and Passcode, there&rsquo;s nothing more you need to do to access your accounts from your mobile device. All you do is sign in. To take advantage of all Online Banking services, however, you need to sign in via your personal computer.</p>
										</div>	
									</li>
									<li class="collapse faq os-none-only"  id = "help-faq-how-is-the-mobile-app-different-none">
										<h2 class="collapse-toggle">How is the Mobile Banking App different?</h2>								
										<div class="collapse-hidden">
													<p>The Mobile Banking App, which you can <a id="mobile-download-none" href="/online-banking/mobile.go?request_locale=en_US" target="_self">download for free</a>, allows you to do more in your Online Banking accounts than you can do here. When you sign in to your account here, you can check your balances, and if you set up Bill Pay and Transfers on a personal computer first, you can also pay bills and make transfers.</p>
<p>With the app, you can do all of that plus use Mobile Check Deposit, get Mobile App Alerts and use BankAmeriDeals<sup>&reg;</sup> while you&rsquo;re on the move.</p>
										</div>	
									</li>
									<li class="collapse faq os-ios-only"  id = "help-faq-how-is-the-mobile-app-different-ios">
										<h2 class="collapse-toggle">How is the Mobile Banking App different?</h2>								
										<div class="collapse-hidden">
													<p>The Mobile Banking App, which you can <a id="mobile-download-ios" href="http://itunes.apple.com/us/app/bank-america-mobile-banking/id284847138?mt=8" target="_self">download for free</a>, allows you to do more in your Online Banking accounts than you can do here. When you sign in to your account here, you can check your balances, and if you set up Bill Pay and Transfers on a personal computer first, you can also pay bills and make transfers.</p>
<p>With the app, you can do all of that plus use Mobile Check Deposit, get Mobile App Alerts and use BankAmeriDeals<sup>&reg;</sup> while you&rsquo;re on the move.</p>
										</div>	
									</li>
									<li class="collapse faq os-and-only"  id = "help-faq-how-is-the-mobile-app-different-and">
										<h2 class="collapse-toggle">How is the Mobile Banking App different?</h2>								
										<div class="collapse-hidden">
													<p>The Mobile Banking App, which you can <a id="mobile-download-and" href="market://details?id=com.infonow.bofa" target="_self">download for free</a>, allows you to do more in your Online Banking accounts than you can do here. When you sign in to your account here, you can check your balances, and if you set up Bill Pay and Transfers on a personal computer first, you can also pay bills and make transfers.</p>
<p>With the app, you can do all of that plus use Mobile Check Deposit, get Mobile App Alerts and use BankAmeriDeals<sup>&reg;</sup> while you&rsquo;re on the move.</p>
										</div>	
									</li>
									<li class="collapse faq os-bb-only"  id = "help-faq-how-is-the-mobile-app-different-bb">
										<h2 class="collapse-toggle">How is the Mobile Banking App different?</h2>								
										<div class="collapse-hidden">
													<p>The Mobile Banking App, which you can <a id="mobile-download-bb" href="http://appworld.blackberry.com/webstore/content/1211/?lang=EN" target="_self">download for free</a>, allows you to do more in your Online Banking accounts than you can do here. When you sign in to your account here, you can check your balances, and if you set up Bill Pay and Transfers on a personal computer first, you can also pay bills and make transfers.</p>
<p>With the app, you can do all of that plus use Mobile Check Deposit, get Mobile App Alerts and use BankAmeriDeals<sup>&reg;</sup> while you&rsquo;re on the move.</p>
										</div>	
									</li>
							</ul>
						</div>

				</div>
		</div>
	</section>







	<section class="mw-mod mw-content-module-full-width-skin mw-cm-fws faq-content" data-component="module" data-module="mw-content-module" data-skin="full-width-skin">
		<div id="securitytips" class="g tab-panel">

				<div class="r">
							<div class="one-whole">
								<p>Let&rsquo;s work together to keep information secure.</p>
							</div>

						<div class="one-whole">
							<ul class="faqs">
									<li class="collapse faq" data-collapse-speed="2000" id = "help-mobile-banking-security">
										<h2 class="collapse-toggle">Mobile banking security</h2>								
										<div class="collapse-hidden">
													<p>Your information is secure when you&rsquo;re using Mobile Banking. You&rsquo;re required to sign in the same way you would through Online Banking. Additionally, we do not allow your Passcode or any account information to be stored on your device.</p>
										</div>	
									</li>
									<li class="collapse faq"  id = "help-smshing">
										<h2 class="collapse-toggle">SMShing</h2>								
										<div class="collapse-hidden">
													<p>SMShing is phishing that happens via SMS text message. A criminal sends a text message tricking you into replying with financial or personal information or clicking on links that will sneak viruses onto your mobile device. To guard against these scams:</p>
<ul>
<li>Don&rsquo;t respond to a text message that requests personal or financial information. Bank of America will never ask you to respond in this way.</li>
<li>Verify the phone numbers that appear in a text message. Store Bank of America phone numbers in your mobile contacts for quick reference. Or, if you have the Mobile Banking App, you can go to Settings in the app and tap Contact Us to confirm legitimate phone numbers.</li>
</ul>
										</div>	
									</li>
									<li class="collapse faq"  id = "help-stolen-devices">
										<h2 class="collapse-toggle">Stolen devices</h2>								
										<div class="collapse-hidden">
													<p>Mobile phones and tablets offer convenience, but they&rsquo;re also easy to lose or steal, which can put your information at risk. Here are some basic safety tips:</p>
<ul>
<li>Password-protect your device so it can&rsquo;t be accessed unless the password is entered</li>
<li>Enable an automatic screen-locking mechanism to lock the device when it&rsquo;s not actively being used</li>
<li>Consider using a remote wipe program, which will give you the ability to send a command to your device that will delete any data</li>
<li>Keep a record of the device&rsquo;s make, model and serial number in case it&rsquo;s stolen. It also helps that before accessing your financial information, you must first enter your Online ID and Passcode.</li>
</ul>
										</div>	
									</li>
									<li class="collapse faq"  id = "help-traditional-online-threats">
										<h2 class="collapse-toggle">Traditional online threats</h2>								
										<div class="collapse-hidden">
													<p>Viruses, malware and other programs that steal your personal information or financial details are also able to infect some mobile devices. There are a couple of preventive measures you can take:</p>
<ul>
<li>Some tablets may support traditional anti-virus products. Consider installing antivirus software if supported on your device.</li>
<li>Back up the device&rsquo;s data. This will allow you to restore the data if you need to wipe the memory to remove a harmful software threat.</li>
</ul>
<p>Stay vigilant about security when taking advantage of the convenience these devices offer.</p>
										</div>	
									</li>
							</ul>
						</div>

				</div>
		</div>
	</section>
								   	</section>







    <nav class="mw-mod mw-navigation-module-flyout-skin mw-nm-fs" id="mw-navigation" data-role="panel" data-position="left" data-display="push" >
			<ul class = "os-container">
			
								
					<li class = ""> <a href="/mobile/banking.go"  id="mw-menu-home"><span class="ada-hidden">Visit our Mobile </span>Home <span class="ada-hidden"> Page</span></a> </li>
			
								
								
					<li class = " "> <a rel="{$link}" href="/mweb/index.html?app=enrollments"  id="mw-menu-sign-in-enroll"><span class="ada-hidden"></span>Enroll <span class="ada-hidden"></span></a> </li>
								
					<li class = ""> <a href="https://staticweb.bankofamerica.com/cavmwebbactouch/common/index.html#home?app=bba"  id="mw-menu-schedule-an-appointment"><span class="ada-hidden"></span>Schedule an appointment <span class="ada-hidden"></span></a> </li>
			
								
					<li class = "os-none-only"> <a href="https://locators.bankofamerica.com"  class = "" id="mw-menu-locations"><span class="ada-hidden">Get a list of Bank </span>Locations <span class="ada-hidden"></span></a> </li>
			
								
					<li class = "os-none-only"> <a href="/online-banking/mobile.go?request_locale=en_US"  class = "" id="mw-menu-getapp-default"><span class="ada-hidden"></span>Get the App <span class="ada-hidden"> for your device</span></a> </li>
			
								
					<li class = "os-and-only"> <a href="market://details?id=com.infonow.bofa"  class = "" id="mw-menu-getapp-and"><span class="ada-hidden"></span>Get the App <span class="ada-hidden"> for your device</span></a> </li>
			
								
					<li class = "os-ios-only"> <a href="http://itunes.apple.com/us/app/bank-america-mobile-banking/id284847138?mt=8"  class = "" id="mw-menu-getapp-ios"><span class="ada-hidden"></span>Get the App <span class="ada-hidden"> for your device</span></a> </li>
			
								
					<li class = "os-bb-only"> <a href="http://appworld.blackberry.com/webstore/content/1211/?lang=EN"  class = "" id="mw-menu-getapp-bb"><span class="ada-hidden"></span>Get the App <span class="ada-hidden"> for your device</span></a> </li>
			
								
					<li class = " "> <a href="/mobile/mobile-banking-help.go"  id="mw-menu-help"><span class="ada-hidden"></span>Help <span class="ada-hidden"> page for mobile users</span></a> </li>
			</ul>
				<h3><span class="ada-hidden"> </span> BROWSE OUR PRODUCTS<span class="ada-hidden">  SECTION</span> </h3>
			<ul>
			
								
					<li class = ""> <a href="/credit-cards/mobile/credit-cards.go"  class = "mw-sprite mw-sprite-A4" id="mw-menu-credit-cards"><span class="ada-hidden">Get more information about </span>Credit Cards <span class="ada-hidden"></span></a> </li>
			
								
					<li class = ""> <a href="/deposits/mobile/checking-accounts.go"  class = "mw-sprite mw-sprite-B4" id="anc-checking-account"><span class="ada-hidden">Get more information about </span>Checking Accounts <span class="ada-hidden"></span></a> </li>
			
								
					<li class = ""> <a href="/deposits/mobile/savings-accounts.go"  class = "mw-sprite mw-sprite-C4" id="mw-menu-savings"><span class="ada-hidden">Get more information about </span>Savings Accounts <span class="ada-hidden"></span></a> </li>
			
								
					<li class = ""> <a href="/auto-loans/"  class = "mw-sprite mw-sprite-D4 mw-width-02" id="mw-menu-auto-loans"><span class="ada-hidden">Get more information about </span>Auto Loans <span class="ada-hidden"></span></a> </li>
			
								
					<li class = ""> <a href="/mortgage/home-mortgage/"  class = "mw-sprite mw-sprite-F4" id="mw-menu-home-loans"><span class="ada-hidden">Get more information about </span>Home Loans <span class="ada-hidden"></span></a> </li>
			
								
					<li class = ""> <a href="https://www.merrilledge.com/m/pages/mobile/home-mobile.aspx?cm_sp=GWM-SelfDirectedBrokerage-_-InvestmentAccounts-_-G216LT009P_MEmobi_HomepageTextLink_Investment_Accounts_Link"  class = "mw-sprite mw-sprite-G4 mw-width-02" id="mw-menu-investment"><span class="ada-hidden">Get more information about </span>Investment Accounts <span class="ada-hidden"></span></a> </li>
			
								
					<li class = ""> <a href="http://promo.bankofamerica.com/sbmpp/index4/?cm_sp=SB-General-_-Small_Biz_MPP-_-KO16LT0008_mobi_Small_Business_mobi&source_id=10011SCK1420002"  class = "mw-sprite mw-sprite-I4" id="mw-menu-small-business"><span class="ada-hidden">Get more information about </span>Small Business <span class="ada-hidden"></span></a> </li>
			</ul>
				<h3><span class="ada-hidden"> </span> SEE MORE SERVICES<span class="ada-hidden">  SECTION</span> </h3>
			<ul>
			
								
					<li class = ""> <a href="https://secure.opinionlab.com/ccc01/o.asp?id=wwxOVCML&referer=http%3A%2F%2Fmobile.bankofamerica.com%2Fmobileweb"  id="mw-menu-feedback"><span class="ada-hidden"></span>Send Feedback <span class="ada-hidden"> on your experience</span></a> </li>
			
								
					<li class = ""> <a href="/privacy/overview.go"  id="mw-menu-privacy"><span class="ada-hidden">Review</span>Privacy &amp; Security <span class="ada-hidden"></span></a> </li>
			
								
					<li class = "Full Site"> <a href="/homepage/overview.go?MobileRedirect=false"  id="mw-menu-full-site"><span class="ada-hidden">View the </span>Full Site <span class="ada-hidden"></span></a> </li>
			</ul>
	</nav>




<footer class="mw-mod mw-footer-module-standard-skin mw-fm-ss" id="footer" data-component="module" data-module="mw-footer" data-skin="standard" data-role="footer">
	<ul class="links">



		     <li class="wrap-none-only">
		     	<a href="https://secure.opinionlab.com/ccc01/o.asp?id=wwxOVCML&referer=http%3A%2F%2Fmobile.bankofamerica.com%2Fmobileweb"  id="anc_mwf_snd_fdbk">Send Feedback</a>
		     </li>



		     <li class="wrap-all">
		     	<a href="/privacy/overview.go"  id="anc_mwf_pvy_scty">Privacy &amp; Security</a>
		     </li>



		     <li class="wrap-none-only">
		     	<a href="/mobile/mobile-banking-help.go"  id="anc_mwf_help">Help</a>
		     </li>



		     <li class="wrap-all">
		     	<a href="/mobile/site-ad-practices.go"  id="anc_mwf_Sie_Ad_Prac">Advertising Practices</a>
		     </li>



		     <li class="wrap-none-only">
		     	<a href="/homepage/overview.go?MobileRedirect=false"  id="anc_mwf_ful_site">Full Site</a>
		     </li>
	</ul>
	<div class="copyright">
      <p>&copy;2017 Bank of America Corporation. <br />Bank of America, N.A. Member FDIC. <a href="https://www.bankofamerica.com/help/equalhousing_popup.go" id="anc_mwf_help_equal_housing_lender" title="Equal Housing Lender information. Link opens in new window." onclick="function onclick() { window.open('/help/equalhousing_popup.go','newwin','width=640,height=371,scrollbars=yes,resizable=yes,left=35,top=161'); return false; }" target="_blank">Equal Housing Lender.</a></p>
   </div>
</footer>
    		</div>
        	
		<div class="js-includes">




		<script src="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/PBI-WEB/2017.03.0/script/pbi-web-mw-jawr.js"
			type="text/javascript"></script>          
	      	
	<script type="text/javascript" src="https://www2.bac-assets.com/pa/global-assets/external/coremetrics/hp/eluminate.js"></script>
    <script type="text/javascript" src="https://www2.bac-assets.com/pa/global-assets/external/coremetrics/hp/cmdatatagutils.js"></script>

	<script>
	function cmSetDD(){var testString=window.location.href;if(testString.toLowerCase().indexOf(".bankofamerica.com")>-1){testString=testString.toLowerCase();var tempArr=testString.split(".bankofamerica.com");var tempStr=tempArr[0];if(tempStr.indexOf("//")>-1){tempArr=tempStr.split("//");tempStr=tempArr[1];if(tempStr.indexOf(".")>-1){tempArr=tempStr.split(".");tempStr=tempArr[0];var tempStrPt2=tempArr[1]}if(tempStr.indexOf("www")>-1){if(tempStr.indexOf("-")>-1){cmSetStaging()}else{if(tempStrPt2!=null){if(tempStrPt2.indexOf("ecnp")>-1){cmSetStaging()}}else{cmSetProduction()}}}else{if(tempStr.indexOf("-")>-1){if(tempStr.indexOf("sitekey")>-1){if(tempStr=="sitekey"){cmSetProduction()}else{cmSetStaging()}}else{cmSetStaging()}}else{if(tempStrPt2!=null){if(tempStrPt2.indexOf("ecnp")>-1){cmSetStaging()}}else{cmSetProduction()}}}}}}if(typeof cmSetStaging=="function"){cmSetDD()};
	</script>

		</div>
		
		<div id="tagging" class="hide">

    <script>
      var boaTagData = {
        "DART": {
          "globals" : {
            "pageName" : ""
          },
          "events" : {
            "click" : {
			},
					
						
            "load" : {
												"page" : "default"
            }
							
        	
            
          }
        },
        "CoreMetrics": {
          "globals" : {
			"pageID" : "Help:Content-M;Help_Mobile",
			"categoryID" : "Help:Content-M",
        },
      },
        "TestAndTarget": {
          	"sourceUrl" : "https://www2.bac-assets.com/pa/global-assets/1.0/script/mbox.js",
            "profile": {
					"param" : { "showOverlay" : "", "device" : "" }
            },
            "events": {
              "load": {
								"bac_mobile_banking_help" : {
												
												
													"Default"	
													 : { "filter" : "os:Default", "value" : "bac_mobile_banking_help" }
												
										 }
										 
			  
              }
            }
        }
      };
    </script>	
		</div>
    </body>

</html>

