
 

				<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
				<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
				<head>


<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta http-equiv="content-type" content="text/html;charset=utf-8">





<title>Business Checking Overdraft Protection</title>

<meta name="Description" CONTENT="Avoid the inconvenience of overdrawing your business checking account with Bank of America's Overdraft Protection service.">
<meta name="Keywords" CONTENT="overdraft protection, bank of america overdraft protection">

		<link rel="canonical" href="https://www.bankofamerica.com/smallbusiness/resources/overdraft-protection.go"/>

<link rel="shortcut icon" href="/pa/global-assets/1.0/graphic/favicon.ico" type="image/ico" />

			<link rel="stylesheet" type="text/css" href="/pa/components/bundles/gzip-compressed/xengine/APS-small-business/2017.03.0/style/bcs-aps-sb-jawr.css" media="all" />
			<script src="/pa/components/bundles/gzip-compressed/xengine/APS-small-business/2017.03.0/script/bcs-aps-sb-jawr.js" type="text/javascript"></script>
				<script type="text/javascript">
					$(window).load(function(){asyncPrintCssInclude('https://www.bankofamerica.com/pa/components/bundles/gzip-compressed/xengine/APS-small-business/2017.03.0/style/bcs-aps-sb-jawr-print.css');});
				</script>
<script type="text/javascript">
(function() {
	if (typeof mboxUpdate == "function") {
		var windowURL = window.location.href
	    windowURL = windowURL.slice( windowURL.indexOf('.')+1);
		windowURL = windowURL.split( '?' )[0];
		windowURL = windowURL.toLowerCase();
		//alert(windowURL);
		if (
		    //If no mboxes on page, mbox count will be < 1
		    (mboxFactoryDefault.getMboxes().length() < 1) &&

			//Also check for high-volume pages that do not need global logging
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go") &&
			(windowURL != "bankofamerica.com/myaccounts/signin/signin.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/entry/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signonscreen.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatechallengeanswer.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatePassword.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/mobile/banking.go")&&
			(windowURL != "bankofamerica.com/content/preload/olb-myaccount-preload-jawr-module.htm")
			)
		{

			var mboxDiv = document.createElement("div");
			mboxDiv.id = "adobe_touch_clarity_replacement";
			mboxDiv.style.display = "none";
			if (document.body && document.body.firstChild) document.body.insertBefore(mboxDiv,document.body.firstChild);
			mboxDefine(mboxDiv.id,'bac_global_bottom');
			mboxUpdate('bac_global_bottom');
		}
	}
})();
</script>

		<script src="/pa/components/bundles/gzip-compressed/xengine/Global/1.0/script/tealeafbundle.js" type="text/javascript"></script>
			<script>
				var boaPageDataJS = {};
					boaPageDataJS.isLLE = "false";
			</script>
				<style>body{display:none;}</style>
	</head>		

	<body class="fsd-layout-body">	

				<script type="text/javascript">if(self == top){var theBody=document.getElementsByTagName("body")[0];theBody.style.display="block";}else{top.location=self.location;}</script>
				<noscript><style>body{display:block;}</style></noscript>
					<a class='ada-hidden ada-visible-focus' href='#skip-to-h1' id='ada-skip-link'>Skip to main content</a>
		<div class="fsd-layout fsd-2c-700lt-layout">
			<div class="fsd-border">
				<div class="center-content">
					<div class="header">
		  



<script language="javascript" src="/pa/components/modules/tag-manager-module/1.1/script/tag-manager-module-borneo-global-skin.js"></script>
<script>

(function() {
  var fireCallback = function( cb ) {
    if ( typeof cb === "function" ) cb();
  };
  
  function ddoPopulateBase( callback ) {
    try {
		  var DDO = window.digitalData,
		  	bactm_mergeDDO = function( newDDO, priorDDO ) {
		  		if( typeof priorDDO === "undefined" ) {
				  	priorDDO = digitalData || {};
				  }

			    for (var l in newDDO) {
			        if (typeof priorDDO[l] === "undefined") {
			            priorDDO[l] = newDDO[l];
			        }
			        if (newDDO[l] !== null) {
			            if (typeof newDDO[l] === "object") {
			                bactm_mergeDDO(newDDO[l], priorDDO[l]);
			            } else {
			                priorDDO[l] = bactm_validateValue( newDDO[l] ) ? newDDO[l] : priorDDO[l];
			            }
			        }
			    }

			    return priorDDO;
				},
				bactm_olb3rdPartyId = "null";

			if (typeof DDO === "undefined") {
				var simpleDDO = { page: { pageInfo:[{ pageID: null }], attributes: {}, category: { primaryCategory: null }}};

				DDO = (typeof digitalData === "object") ? digitalData : simpleDDO; 
			}

				DDO = bactm_mergeDDO( {"pageInstanceID":"notprod","load_coremetrics":false,"load_opinionlabs":false,"load_touchcommerce":true,"load_audiencemanager":true,"page":{"pageInfo":[{"pageID":null,"destinationURL":null,"referringURL":null,"issueDate":null,"language":null,"segmentValue":null,"appName":null,"appStepNumber":null,"appStepName":null,"attr":"-_--_--_--_--_--_--_--_--_--_--_--_--_--_-"}],"category":{"primaryCategory":null,"addlCategory":null,"pageType":null},"attributes":{"searchString":null,"searchResults":null,"olbSessionID":null,"subCampaignCode":null,"DARTUrl":null,"stateCookie":null,"SASIEnabled":false,"needOLBcookie":false,"standardDART":[],"standardDARTes":[],"clickDART":[],"clickDARTes":[],"gaId":[],"chat":{"site_id":36533230,"account_type":"smallbusiness","boa_associate":null,"boa_retiree":null,"customer_lob":"sbob","customer_segment":null,"data":null,"email_campaign":null,"entitlement_code":null,"error_category":null,"error_count":null,"first_login":null,"inqSalesProductTypes":{},"invitation_background":null,"invitation_template":null,"referral_campaign":null,"getStateValue":false,"cust_fn":null,"cust_ln":null,"target":{"lpButtonDiv-Resources":"SB-Fixed15"}}}},"user":{"segment":null,"online_id":null,"preferred_rewards_tier":null,"olb3rdpartyid":null},"version":"BAC_0.12"}, DDO );

			DDO.page.pageInfo[0].pageID = "";
			DDO.page.category.primaryCategory  = "";
			DDO.page.pageInfo[0].language = "en-US";
			DDO.page.attributes.olbSessionID = "null";
			DDO.page.attributes.SASIEnabled =  "false";
			if (typeof DDO.user != "undefined" && typeof DDO.user.olb3rdpartyid != "undefined") {
				DDO.user.olb3rdpartyid = bactm_olb3rdPartyId;
			}

			window.utag_data = {};
			window.bactm_envSelector = bactm_setTMLib();
			window.digitalData = DDO;

      return fireCallback( callback );

    } catch(e) { }
  }
	if( window.boa && window.boa.digitalData ) {
    window.boa.digitalData.register( ddoPopulateBase );
	}
	else {
	  // Handle scenario where the header isn't available (and thus the default digitalData object and utag loader are missing).
	  //
		var writeScript = function(a,b,c,d){
			a='//tags.tiqcdn.com/utag/bofa/main/' + bactm_envSelector + '/utag.js';
			b=document;
			c='script';
			d=b.createElement(c);
			d.src=a;
			d.type='text/java'+c;
			d.async=true;
			a=b.getElementsByTagName(c)[0];
			a.parentNode.insertBefore(d,a);
		};

		ddoPopulateBase( writeScript );
	}
})();			
</script>



	
	
		
			<noscript>
				<div class="fauxdal-overlay"></div>
				<div class="fauxdal-module">
					<div class="js-disabled-skin">
						<div class="fauxdal-top"></div>
						<div class="fauxdal-bottom">
							<div class="fsd-fauxdal-content">
									<div class="fsd-fauxdal-title">
										Please Use JavaScript
									</div>
										<p>You need a web browser that supports JavaScript to use our site. Without it, some pages won&rsquo;t work as designed. To make sure JavaScript is turned on, please adjust your browser settings.</p>
<p><a name="Browser_Help_And_Tips" href="/onlinebanking/online-banking-security-faqs.go" target="_blank">Browser Help and Tips</a></p>
							</div>        
							<div class="fsd-fauxdal-close"> 
								<a class="btn-bofa btn-bofa-small" name="close_button_js_disabled_modal" href=?js=y>Close</a>
							</div>
							<div class="clearboth"></div>
						</div>
					</div>
				</div>
			</noscript>



 


<div class="header-module">
	<div class="text-w-logo-skin">
		<div class="header-left">
	  
			<div itemscope itemtype="http://schema.org/Corporation" class="bofa-logo">
				<a itemprop="url" name="anc-business-advantage" title="Bank of America Small Business" href="/smallbusiness/index.jsp">
					<img itemprop="logo" height="28" width="221" 
					     alt="Bank of America Small Business" src="/content/images/ContextualSiteGraphics/Logos/en_US/boa_logo.gif"/>
				</a>
			</div>
				<div class="product" data-font="cnx-regular">Business Advantage</div>
			
			<div class="clearboth"></div>

		</div>
		
		<div class="header-right">
			<ul class="header-links">
			
				
					
				
							<li class="sign-in">
		<a					href="/sitemap/hub/signin.go" target="_self"
		name="Sign_In">Sign In</a> 
							</li>
					
				
							<li>		<a					href="/smallbusiness/index.jsp" target="_self"
		name="Home_Header">Home</a> 
</li>
					
				
							<li>		<a					href="https://locators.bankofamerica.com " target="_self"
		name="Locations">Locations</a> 
</li>
					
				
							<li>		<a					href="/contactus/contactus.go?topicId=small_business_banking" target="_self"
		name="Contact_Us">Contact Us</a> 
</li>
					
				
							<li class="last-link">	
		<a					href="/help/" target="_self"
		name="Help">Help</a> 
							</li>
			</ul>
			
			<div class="clearboth"></div>

			<!-- include search-dotcom-util -->



<div class="header-search nlh">
  
  <div class="nav-search">
    <form class="search-form" action="https://secure.bankofamerica.com/myaccounts/public/search-results/unAuthenticatedSearch.go" data-js="/pa/components/utilities/search-util/1.0/script/nav-search.min.js" data-css="/pa/components/utilities/search-util/1.0/style/nav-search.css" data-text-unavailable="Search Currently Unavailable">
      <div class="search-input-container cf" data-icon="search">
        <label for="nav-search-query" class="ada-hidden">Search Term</label>
        <input type="text" placeholder="How can we help you?" name="query" class="search-query" id="nav-search-query" 
          maxlength="99" rel="Search" autocomplete="off"><input type="submit" alt="Search" title="Search" value="Submit Search" name="Search Module - Top Result – Search Button" class="submit track-me">
      </div>
    </form>
  </div>

</div>

		</div>

 		<div class="clearboth"></div>
 	</div>
</div>







	<div class="top-nav-module">
		<div class="fsd-skin sup-ie">
			<ul class="nav-list">
					
					
					<li>
						
								<a href="/smallbusiness/deposits/checking-accounts/" class="top-menu-item"
								name="business_checking_topnav" id="business_checking_topnav">Business Checking<span class="ada-hidden"> &nbsp;link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/smallbusiness/deposits/checking-accounts/business-advantage/"  name="business_advantage_topnav" id="business_advantage_topnav">Business Advantage </a>
															<a href="/smallbusiness/deposits/checking-accounts/business-fundamentals/"  name="business_fundamentals_topnav" id="business_fundamentals_topnav">Business Fundamentals<sup>&reg;</sup> </a>
															<a href="/smallbusiness/business-debit-card.go"  name="business_debit_card_topnav" id="business_debit_card_topnav">Business Debit Card </a>
									</div>
								
									<span class="ada-hidden"> End of submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
					
					
					<li>
						
								<a href="/smallbusiness/cd-savings-accounts.go" class="top-menu-item"
								name="business_savings_and_cds_topnav" id="business_savings_and_cds_topnav">Business Savings & CDs<span class="ada-hidden"> &nbsp;link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/smallbusiness/savings-accounts/business-interest-maximizer.go"  name="business_interest_maximizer_topnav" id="business_interest_maximizer_topnav">Business Interest Maximizer&trade; </a>
															<a href="/smallbusiness/savings-accounts/business-investment-account.go"  name="business_investment_account_topnav" id="business_investment_account_topnav">Business Investment Account </a>
															<a href="/smallbusiness/cds/business-featured-cd.go"  name="business_featured_cd_topnav" id="business_featured_cd_topnav">Business Featured CD </a>
															<a href="/smallbusiness/cds/risk-free-cd.go"  name="business_risk_free_cd_topnav" id="business_risk_free_cd_topnav">Business Risk Free CD<sup>&reg;</sup> </a>
															<a href="/smallbusiness/standard-cds.go"  name="cds_topnav" id="cds_topnav">Standard Business CD </a>
									</div>
								
									<span class="ada-hidden"> End of submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
					
					
					<li>
						
								<a href="javascript:void(0);" class="top-menu-item"
								name="manage_accounts_topnav" id="manage_accounts_topnav">Manage Your Account<span class="ada-hidden"> &nbsp;link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/smallbusiness/online-banking.go"  name="online_banking_topnav" id="online_banking_topnav">Online Banking </a>
															<a href="/smallbusiness/online-banking/cash-management.go"  name="business_tools_topnav" id="business_tools_topnav">Business Tools </a>
									</div>
								
									<span class="ada-hidden"> End of submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
					
					
					<li>
						
								<a href="javascript:void(0);" class="top-menu-item selected"
								name="resources_topnav" id="resources_topnav">Resources<span class="ada-hidden"> &nbsp;link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/smallbusiness/resources/faqs.go"  name="faqs_topnav" id="faqs_topnav">FAQs </a>
															<a href="/smallbusiness/resources/glossary.go"  name="glossary_topnav" id="glossary_topnav">Glossary </a>
															<a href="/smallbusiness/resources/fees-at-a-glance.go"  name="fees_at_a_glance_topnav" id="fees_at_a_glance_topnav">Fees at a Glance </a>
															<a href="/deposits/bank-account-interest-rates/?flow=BCS"  name="account_rates_topnav" id="account_rates_topnav">Account Rates </a>
															<a href="/smallbusiness/platinum-privileges.go"  name="business_platinum_privileges_topnav" id="business_platinum_privileges_topnav">Business Platinum Privileges&trade; </a>
															<a href="/smallbusiness/resources/overdraft-protection.go"  name="overdraft_protection_topnav" id="overdraft_protection_topnav">Overdraft Protection </a>
									</div>
								
									<div class="hasSub">
														<a class="with-info" href="/smallbusiness/education.go"  name="managing_a_small_business_topnav" id="managing_a_small_business_topnav">Managing A Small Business 
															
															<span class="sub-nav-item-info">Articles, tips and tools to help you and your business grow</span>
														</a>
														<a class="with-info" href="/smallbusiness/online-banking/business-services.go"  name="popular_service_combinations_topnav" id="popular_service_combinations_topnav">Popular service combinations 
															
															<span class="sub-nav-item-info">See how business checking solutions combined with Online Banking services can help your business</span>
														</a>
									</div>
									<span class="ada-hidden"> End of submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
			</ul>
				<div class="clearboth"></div>
		</div>
	</div>


	
 
<div class="page-title-fsd-module h-100" id="skip-to-h1">
	<div class="prod-indicator-skin sup-ie">
		<div class="full-width-wrapper">
			<h1 data-font="cnx-regular">Overdraft Protection</h1>	

			

			<div class="clearboth"></div>
		</div>
  	</div>
</div>

<div class="banner-bdf-module">
		<div class="red-c2a-skin sup-ie" style="background-color:#c5d4e3;background-image:url('/content/images/ContextualSiteGraphics/Instructional/en_US/sb_banner-blue-grad.png')">
			<div class="red-c2a-content " style="background-image:url('/content/images/ContextualSiteGraphics/Instructional/en_US/bcs_banner-line-graph.png')">

					<h2>Overdraft Protection</h2>
					<p>Help keep overdrafts under control&mdash;enroll your Small Business checking account in Overdraft Protection today</p>
						<p class="small-action"><strong>Call to learn more:</strong>
						 1.888.BUSINESS</p>
		  <div class="clearboth"><!--  --></div>
		 </div>
	 </div>
</div>




	
<div class="live-person-bdf-module">
   <div class="bcs-skin">
    
     	<a href="javascript:window.print();" name="print">PRINT<span class="ada-hidden">  this page</span></a> 
    
	
		<div id="lpButtonDiv-Resources">
		</div>
		
		<div id="lpButtonDivVoice"></div>
   </div>
</div>

</div>
					<div class="columns">
						<div class="flex-col lt-col" >

	
<div class="generic-content-module tabs-main-content">
	<div class="overview-vzd3-skin com-main-well-content" style="">
				<h3 class="top-element">Help avoid the inconvenience associated with returned checks with Bank of America's Overdraft Protection service.</h3>
			
			


				<h4>How it works</h4>
			
			
						<p>When you sign up for Overdraft Protection,&nbsp;available funds are automatically transferred to your Small Business checking account from another Bank of America business account whenever an overdraft occurs. There is no cost to sign up for Overdraft Protection and we only charge you a fee when we transfer funds for you.<a name="fn-1" href="#footnote1"><sup><span class="ada-hidden">Footnote&nbsp;</span>1</sup></a></p>
			


			
			
							<p class="pad-adjust">The following&nbsp;business accounts can be linked to your Small Business checking account and used for Overdraft Protection:</p>
			


			
			
				<ul>
					<li>
					Business Interest Maximizer&trade;
					
					
					</li>
					<li>
					Business Investment Account
					
					
					</li>
					<li>
					Another business checking account
					
					
					</li>
					<li>
					Business credit card accounts
					
					
					</li>
				</ul>


				<h4></h4>
			
			


				<h4>Overdraft Protection from a linked Bank of America business savings or secondary business checking account:</h4>
			
			
						<p>You can link your business checking account to a Bank of America business savings account or secondary Bank of America business checking account for Overdraft Protection. Then, we can transfer available funds from your linked account to cover overdrafts. The Overdraft Protection transfer fee is $12 per transfer. If you chose to link another checking or savings account for Overdraft Protection, please make sure the other account has enough available funds for potential overdraft situations.</p>
			


				<h4>Overdraft Protection from a linked business credit card:<a name="fn-2" href="#footnote2"><sup><span class="ada-hidden">Footnote&nbsp;</span>2</sup></a></h4>
			
			
						<p>The transfer to cover an overdraft linked to your business card is considered a cash advance. There&rsquo;s a cash advance fee of either $10 or 3% of the transaction, whichever is greater, for transfers of $12 or more when we transfer funds to you.</p>
			


	</div>
</div>

</div>
						<div class="flex-col rt-col" ><script type="text/javascript">

</script>










<div class="state-selector-aps-sb-module">
    <div class="modal-skin sw-inner">
		<p class="pbtm-5">Information for Virginia</p>
	  	<a id="change-state-util" class="show-state-select-modal" rel="state-select-modal" href="javascript:void(0);">Change state <span class="ada-hidden">layer</span></a>
        <div class="state-select-aps-sb-modal hide" id="state-select-modal">
         <div class="modal-content">
            <h3>Select Your State</h3>
                <p>Please tell us where you bank so we can give you accurate rate and fee information for your location.</p>
                <form method="post" action="" id="submitState">
                    <fieldset>
                        <legend>State Selection Form</legend>
                        <input type="hidden" id="requestedUrl" value="" />
                        <label for="stateList">Current State</label>
<select name="stateListName" id="stateList" class="select-box" required="true">
    <option value=" ">Select state</option>
    <option value="AL">Alabama</option>
    <option value="AK">Alaska</option>
    <option value="AZ">Arizona</option>
    <option value="AR">Arkansas</option>
    <option value="CA">California</option>
    <option value="CO">Colorado</option>
    <option value="CT">Connecticut</option>
    <option value="DE">Delaware</option>
    <option value="DC">District of Columbia</option>
    <option value="FL">Florida</option>
    <option value="GA">Georgia</option>
    <option value="HI">Hawaii</option>
    <option value="ID">Idaho</option>
    <option value="IL">Illinois</option>
    <option value="IN">Indiana</option>
    <option value="IA">Iowa</option>
    <option value="KS">Kansas</option>
    <option value="KY">Kentucky</option>
    <option value="LA">Louisiana</option>
    <option value="ME">Maine</option>
    <option value="MD">Maryland</option>
    <option value="MA">Massachusetts</option>
    <option value="MI">Michigan</option>
    <option value="MN">Minnesota</option>
    <option value="MS">Mississippi</option>
    <option value="MO">Missouri</option>
    <option value="MT">Montana</option>
    <option value="NE">Nebraska</option>
    <option value="NV">Nevada</option>
    <option value="NH">New Hampshire</option>
    <option value="NJ">New Jersey</option>
    <option value="NM">New Mexico</option>
    <option value="NY">New York</option>
    <option value="NC">North Carolina</option>
    <option value="ND">North Dakota</option>
    <option value="OH">Ohio</option>
    <option value="OK">Oklahoma</option>
    <option value="OR">Oregon</option>
    <option value="PA">Pennsylvania</option>
    <option value="RI">Rhode Island</option>
    <option value="SC">South Carolina</option>
    <option value="SD">South Dakota</option>
    <option value="TN">Tennessee</option>
    <option value="TX">Texas</option>
    <option value="UT">Utah</option>
    <option value="VT">Vermont</option>
    <option value="VA">Virginia</option>
    <option value="WA">Washington</option>
    <option value="WV">West Virginia</option>
    <option value="WI">Wisconsin</option>
    <option value="WY">Wyoming</option>


</select>

                        <div class="button-cont">
	                        <a id="state_select_submit" class="btn-bofa btn-bofa-small state-select-modal-go-button" href="javascript:void(0);" role="button">Go</a>
	                    </div>
                    </fieldset>
                </form>
		 </div>
		</div>
	</div>
</div>


</div>
						<div class="clearboth"></div>
					</div>
					<div class="footer">
						<div class="footer-top">&nbsp;

 

<div class="apply-banner-module">
  <div class="product-skin lt-blue-skin">
    <div class="apply-banner buttonless">
      <div class="buttonless-text">
        <span class="apply-super">To apply call 1.888.BUSINESS (1.888.287.4637)</span>
        or visit your nearest banking center
      </div>
      <div class="clearboth"><!-- --></div>
    </div>
  </div>
</div>
</div>
						<div class="footer-inner">

<div class="disclaimers-module">
	<div class="fsd-skin sup-ie">
			<p id="footnote1">1 The state in which you opened your account determines the type of account you can link for Overdraft Protection. If you link to a savings account please be aware that federal regulations limit certain types of withdrawals. Please refer to the <a rel="nofollow" name="businessScheduleOfFees_footnote_link" href="/smallbusiness/resources/business-schedule-fees.go" target="_blank">Business Schedule of Fees</a> for more information.</p><p id="footnote2">2 If you enroll in Overdraft Protection with your credit card, overdraft transfers will be bank cash advances and will accrue interest at the APR stated in your Business Card Agreement. Please refer to your Business Card Agreement for additional details.</p>
	</div>
</div>





<div class="power-footer-module">

  <div class="four-col-all-links-skin sup-ie">
    <div class="breadcrumbs">
						<a class="bold-bc" href="/" name="bank_of_america_overdraft_protection_breadcrumbs">Bank of America</a>
						<a href="/smallbusiness" name="small_business_overdraft_protection_breadcrumbs" >Small Business</a>
		
					<a href="/smallbusiness/education.go" name="resources_overdraft_protection_breadcrumbs">Resources</a>
		      	 <span>Overdraft Protection</span>
		    
      <div class="clearboth"></div>
    </div>
    <div class="pf-columns">
      
			<div class="pf-col" style="margin-right:50px;">
				<ul>
					<li>	
					<a href="/smallbusiness/deposits/checking-accounts/" class="bold" name="business_checking_overdraft_protection_power_footer" >Business Checking</a> 
					</li>
						<li> <a href="/smallbusiness/deposits/checking-accounts/business-advantage/" name="business_advantage_overdraft_protection_power_footer">Business Advantage</a> </li>
						<li> <a href="/smallbusiness/deposits/checking-accounts/business-fundamentals/" name="business_fundamentals_overdraft_protection_power_footer">Business Fundamentals<sup>&reg;</sup></a> </li>
						<li> <a href="/smallbusiness/checking-accounts/business-interest-checking.go" name="business_interest_checking_overdraft_protection_power_footer">Business Interest Checking</a> </li>
						<li> <a href="/smallbusiness/checking-accounts/full-analysis-business-checking.go" name="full_analysis_business_checking__overdraft_protection_power_footer">Full Analysis Business Checking </a> </li>
						<li> <a href="/smallbusiness/business-debit-card.go" name="business_debit_card_overdraft_protection_power_footer">Business Debit Card</a> </li>
				</ul>
		      </div>
			<div class="pf-col" style="margin-right:50px;">
				<ul>
					<li>	
					<a href="/smallbusiness/cd-savings-accounts.go" class="bold" name="business_savings_and_cd_overdraft_protection_power_footer" >Business Savings & CDs</a> 
					</li>
						<li> <a href="/smallbusiness/savings-accounts/business-interest-maximizer.go" name="business_interest_maximizer_overdraft_protection_power_footer">Business Interest Maximizer&trade;</a> </li>
						<li> <a href="/smallbusiness/savings-accounts/business-investment-account.go" name="business_investment_account_overdraft_protection_power_footer">Business Investment Account</a> </li>
						<li> <a href="/smallbusiness/cds/business-featured-cd.go" name="business_featured_cd_overdraft_protection_power_footer">Business Featured CD</a> </li>
						<li> <a href="/smallbusiness/cds/risk-free-cd.go" name="business_risk_free_cd_overdraft_protection_power_footer">Business Risk Free CD<sup>&reg;</sup></a> </li>
						<li> <a href="/smallbusiness/standard-cds.go" name="standard_business_cd_overdraft_protection_power_footer">Standard Business CD</a> </li>
				</ul>
		      </div>
			<div class="pf-col" style="margin-right:50px;">
				<ul>
					<li>	
					<a href="/smallbusiness/online-banking.go" class="bold" name="manage_your_account_overdraft_protection_power_footer" >Manage Your Account</a> 
					</li>
						<li> <a href="/smallbusiness/online-banking.go" name="online_banking_overdraft_protection_power_footer">Online Banking</a> </li>
						<li> <a href="/smallbusiness/online-banking/cash-management.go" name="business_tools_overdraft_protection_power_footer">Business Tools</a> </li>
						<li> <a href="/smallbusiness/business-debit-card.go" name="request_a_debit_card_overdraft_protection_power_footer">Request a Debit Card</a> </li>
				</ul>
		      </div>
			<div class="pf-col" style="">
				<ul>
					<li>	
					<a href="/smallbusiness/education.go" class="bold" name="resources_overdraft_protection_power_footer" >Resources</a> 
					</li>
						<li> <a href="/smallbusiness/resources/faqs.go" name="faqs_overdraft_protection_power_footer">FAQs</a> </li>
						<li> <a href="/smallbusiness/resources/glossary.go" name="glossary_overdraft_protection_power_footer">Glossary</a> </li>
						<li> <a href="/smallbusiness/resources/fees-at-a-glance.go" name="fees_at_a_glance_overdraft_protection_power_footer">Fees at a Glance</a> </li>
						<li> <a href="/deposits/bank-account-interest-rates/?flow=BCS" name="account_rates_overdraft_protection_power_footer">Account Rates</a> </li>
						<li> <a href="/smallbusiness/platinum-privileges.go" name="business_platinum_privileges_overdraft_protection_power_footer">Business Platinum Privileges&trade;</a> </li>
						<li> <a href="/smallbusiness/resources/overdraft-protection.go" name="overdraft_protection_overdraft_protection_power_footer">Overdraft Protection</a> </li>
				</ul>
		      </div>
      
      <div class="clearboth"></div>
    </div>
  </div>
</div>




 



		<div class="global-footer-module">
			<div class="fsd-skin">

				<div class="footer-bottom-left" style="float:left;max-width:66%;">
	    			<div class="gf-links">	          	
						
					
									
									<a  target="_self" href="/smallbusiness/index.jsp" 
									    name="global-footer-home">Home
									</a>
									
						
					
									
									<a  target="_self" href="/privacy/index.jsp" 
									    name="global-footer-privacy-security">Privacy & Security
									</a>
									
						
					
									
									<a  target="_self" href="http://careers.bankofamerica.com/careershome.aspx" 
									    name="footer_careers">Careers
									</a>
									
						
					
									
									<a  target="_self" href="/sitemap/sitemap/smallbusiness.go" 
									    name="global-footer-site-map">Site Map
									</a>
									
						
					
									<a href="javascript:void(0);" class="gf-last-link boa-dialog boa-com-info-layer-link" name="global_footer_ad_practices_lnk" rel="global_footer_ad_practices">Advertising Practices</a>
								<div id="global_footer_ad_practices" class="hide">
									<h3>Advertising Practices</h3>
										<p>We strive to provide you with information about products and services you might find interesting and useful. Relationship-based ads and online behavioral advertising help us do that.</p>
<p>Here's how it works: We gather information about your online activities, such as the searches you conduct on our Sites and the pages you visit. This information may be used to deliver advertising on our Sites and offline (for example, by phone, email and direct mail) that's customized to meet specific interests you may have.</p>
<p>If you prefer that we do not use this information, you may <a onclick="$('.ui-dialog').remove();" name="WebsiteAdPractices_OptOut" href="/privacy/online-privacy-notice.go#advertising-on-our-sites" target="_blank">opt out of online behavioral advertising</a>. If you opt out, though, you may still receive generic advertising. In addition, financial advisors/Client Managers may continue to use information collected online to provide product and service information in accordance with account agreements.</p>
<p>Also, if you opt out of online behavioral advertising, you may still see ads when you sign in to your account, for example through Online Banking or MyMerrill. These ads are based on your specific account relationships with us.</p>
<p>To learn more about relationship-based ads, online behavioral advertising and our privacy practices, please review the <a onclick="$('.ui-dialog').remove();" name="WebsiteAdPractices_PrivacyNotice" href="/privacy/online-privacy-notice.go" target="_blank">Bank of America Online Privacy Notice</a> and our <a onclick="$('.ui-dialog').remove();" name="Online-privacy-faqs" href="/privacy/faq/online-privacy-faq.go" target="_blank">Online Privacy FAQs</a>.</p>
								</div>
						<div class="clearboth"></div>
	    			</div>
	      			<p>Bank of America, N.A. Member FDIC. <a onclick="function onclick() { window.open('/help/equalhousing_popup.go','newwin','width=640,height=371,scrollbars=yes,resizable=yes,left=35,top=161'); return false;}" name="Equal_Housing_Lender" href="/help/equalhousing_popup.go">Equal Housing Lender<img src="/content/images/ContextualSiteGraphics/Logos/en_US/icon_equal_housing_lender.gif" alt="" width="14" height="9" /></a> <br />&copy;&nbsp;2017 Bank of America Corporation. All rights reserved.</p>
         		</div>
         		<div class="footer-social-container" style="float:right;max-width:30%;padding-left:50px;padding-top:19px;">




<div class="boa-social-loader" data-loaded="false" data-platform="borneo"  data-options=''></div>

         		</div>
         		<div class="clearboth"></div>
  			</div>
		</div>




 
<script type="text/javascript">
var axel = Math.random()+"";var a = axel * 10000000000000;document.write('<iframe title="iFrame used for layout purpose" src="https://fls.doubleclick.net/activityi;src=1359940;type=bacal484;cat=smb_b426;ord=1;num='+ a + '?" width="1" height="1" frameborder="0" style="display:none;"></iframe>');
</script>
<noscript>
	<iframe title="iFrame used for layout purpose" src="https://fls.doubleclick.net/activityi;src=1359940;type=bacal484;cat=smb_b426;ord=1?" width="0" height="0" frameborder="0" style="display:none;"></iframe>
</noscript>
<script language="javascript" src="/pa/global-assets/external/coremetrics/hp/eluminate.js"></script>
<script language="javascript" src="/pa/global-assets/external/coremetrics/hp/cmdatatagutils.js"></script>

<script language="javascript">
var testString = window.location.href;
    if (testString.toLowerCase().indexOf('.bankofamerica.com') > -1){
        testString = testString.toLowerCase();
        var tempArr = testString.split('.bankofamerica.com');var tempStr = tempArr[0];
        if (tempStr.indexOf('\/\/') > -1) {
            tempArr = tempStr.split('\/\/');tempStr = tempArr[1];
            if (tempStr.indexOf('.') > -1) {
                tempArr = tempStr.split('.');tempStr = tempArr[0];
            }
            if (tempStr.indexOf('www') > -1) {
                if (tempStr.indexOf('-') > -1) {cmSetStaging();}
                else {cmSetProduction();}
            }
            else {
                if (tempStr.indexOf('sitekey') > -1){
                    if (tempStr == 'sitekey') {cmSetProduction();}
                    else {cmSetStaging();}
                }
                else if (tempStr.indexOf('pssit') > -1){
                    if (tempStr == 'pssit') {cmSetStaging();}
                }
                if (tempStr.indexOf('-') > -1) {cmSetStaging();}
                else {cmSetProduction();}    
            }
        }
    }
  </script> 
  
		<script type="text/javascript">
		cmCreatePageviewTag('smbus:Content:Resources;overdraft-protection', null, null, 'smbus:Content:Resources', false, false, null, false, false, null, null, null, null, null, null, null, null, null, null, null, null);
		</script>
								
				
				
				
					
			
			
								
		<script type="text/javascript">
			
	// CoreMetrics 
		$('document').ready(function(){
			// Compare Tab click event.
			$('.tabs-bdf-module a[name*=Compare_tabLink]').bind('click.CM', function(){ 
	
				
						
			
		});
		
		});
			</script>
</div>
					</div>
				</div>
			</div>
		</div>
	</body>	
</html>

