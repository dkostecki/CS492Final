
 

				<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
				<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
				<head>


<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta http-equiv="content-type" content="text/html;charset=utf-8">





<title>Small Business Tips and Resources from Bank of America</title>

<meta name="Description" CONTENT="Find articles, tips and general information that can help small business owners start, manage, and grow their businesses.">
<meta name="Keywords" CONTENT="small business resources, small business articles, small business tips, small business information">

					<meta name="twitter:title" CONTENT="Small Business Tips and Resources from Bank of America" />
					<meta name="twitter:card" CONTENT="summary_large_image" />
					<meta name="twitter:description" CONTENT="Find articles, tips and general information that can help small business owners start, manage, and grow their businesses." />
					<meta name="twitter:site" CONTENT="@BofA_Tips" />
					<meta name="twitter:url" CONTENT="https://www.bankofamerica.com/smallbusiness/education.go" />
					<meta name="twitter:image" CONTENT="https://www.bankofamerica.com/content/images/ContextualSiteGraphics/Instructional/en_US/SB/BP_video_bike_shop_418x418.png" />
		   			<meta property="og:url" CONTENT="https://www.bankofamerica.com/smallbusiness/education.go" />
		   			<meta property="og:title" CONTENT="Small Business Tips and Resources from Bank of America" />
		   			<meta property="og:description" CONTENT="Find articles, tips and general information that can help small business owners start, manage, and grow their businesses." />
		   			<meta property="og:type" CONTENT="website" />
		   			<meta property="og:site_name" CONTENT="Bank of America" />
		   			<meta property="og:image" CONTENT="https://www.bankofamerica.com/content/images/ContextualSiteGraphics/Instructional/en_US/SB/BP_video_bike_shop_418x418.png" />
		<link rel="canonical" href="https://www.bankofamerica.com/smallbusiness/education.go"/>

<link rel="shortcut icon" href="/pa/global-assets/1.0/graphic/favicon.ico" type="image/ico" />

			<link rel="stylesheet" type="text/css" href="/pa/components/bundles/gzip-compressed/xengine/APS-small-business/2017.03.0/style/bcs-aps-sb-jawr.css" media="all" />
			<script src="/pa/components/bundles/gzip-compressed/xengine/APS-small-business/2017.03.0/script/bcs-aps-sb-jawr.js" type="text/javascript"></script>
				<script type="text/javascript">
					$(window).load(function(){asyncPrintCssInclude('https://www.bankofamerica.com/pa/components/bundles/gzip-compressed/xengine/APS-small-business/2017.03.0/style/bcs-aps-sb-jawr-print.css');});
				</script>
<script type="text/javascript">
(function() {
	if (typeof mboxUpdate == "function") {
		var windowURL = window.location.href
	    windowURL = windowURL.slice( windowURL.indexOf('.')+1);
		windowURL = windowURL.split( '?' )[0];
		windowURL = windowURL.toLowerCase();
		//alert(windowURL);
		if (
		    //If no mboxes on page, mbox count will be < 1
		    (mboxFactoryDefault.getMboxes().length() < 1) &&

			//Also check for high-volume pages that do not need global logging
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go") &&
			(windowURL != "bankofamerica.com/myaccounts/signin/signin.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/entry/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signonscreen.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatechallengeanswer.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatePassword.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/mobile/banking.go")&&
			(windowURL != "bankofamerica.com/content/preload/olb-myaccount-preload-jawr-module.htm")
			)
		{

			var mboxDiv = document.createElement("div");
			mboxDiv.id = "adobe_touch_clarity_replacement";
			mboxDiv.style.display = "none";
			if (document.body && document.body.firstChild) document.body.insertBefore(mboxDiv,document.body.firstChild);
			mboxDefine(mboxDiv.id,'bac_global_bottom');
			mboxUpdate('bac_global_bottom');
		}
	}
})();
</script>

		<script src="/pa/components/bundles/gzip-compressed/xengine/Global/1.0/script/tealeafbundle.js" type="text/javascript"></script>
			<script>
				var boaPageDataJS = {};
					boaPageDataJS.isLLE = "false";
			</script>
				<style>body{display:none;}</style>
	</head>		

	<body class="fsd-layout-body">	

				<script type="text/javascript">if(self == top){var theBody=document.getElementsByTagName("body")[0];theBody.style.display="block";}else{top.location=self.location;}</script>
				<noscript><style>body{display:block;}</style></noscript>
					<a class='ada-hidden ada-visible-focus' href='#skip-to-h1' id='ada-skip-link'>Skip to main content</a>
		<div class="fsd-layout fsd-2c-700lt-layout">
			<div class="fsd-border">
				<div class="center-content">
					<div class="header">
		  



<script language="javascript" src="/pa/components/modules/tag-manager-module/1.1/script/tag-manager-module-borneo-global-skin.js"></script>
<script>

(function() {
  var fireCallback = function( cb ) {
    if ( typeof cb === "function" ) cb();
  };
  
  function ddoPopulateBase( callback ) {
    try {
		  var DDO = window.digitalData,
		  	bactm_mergeDDO = function( newDDO, priorDDO ) {
		  		if( typeof priorDDO === "undefined" ) {
				  	priorDDO = digitalData || {};
				  }

			    for (var l in newDDO) {
			        if (typeof priorDDO[l] === "undefined") {
			            priorDDO[l] = newDDO[l];
			        }
			        if (newDDO[l] !== null) {
			            if (typeof newDDO[l] === "object") {
			                bactm_mergeDDO(newDDO[l], priorDDO[l]);
			            } else {
			                priorDDO[l] = bactm_validateValue( newDDO[l] ) ? newDDO[l] : priorDDO[l];
			            }
			        }
			    }

			    return priorDDO;
				},
				bactm_olb3rdPartyId = "null";

			if (typeof DDO === "undefined") {
				var simpleDDO = { page: { pageInfo:[{ pageID: null }], attributes: {}, category: { primaryCategory: null }}};

				DDO = (typeof digitalData === "object") ? digitalData : simpleDDO; 
			}

				DDO = bactm_mergeDDO( {   "pageInstanceID": "notprod",   "load_coremetrics": false,   "load_opinionlabs": false,   "load_touchcommerce": true,   "load_audiencemanager": true,   "page": {     "pageInfo": [       {         "pageID": null,         "destinationURL": null,         "referringURL": null,         "issueDate": null,         "language": null,         "segmentValue": null,         "appName": null,         "appStepNumber": null,         "appStepName": null,         "attr": "-_--_--_--_--_--_--_--_--_--_--_--_--_--_-"       }     ],     "category": {       "primaryCategory": null,       "addlCategory": null,       "pageType": null     },     "attributes": {       "searchString": null,       "searchResults": null,       "olbSessionID": null,       "subCampaignCode": null,       "DARTUrl": null,       "stateCookie": null,       "SASIEnabled": false,       "needOLBcookie": false,       "standardDART": [],       "standardDARTes": [],       "clickDART": [],       "clickDARTes": [],       "gaId": [],       "chat": {         "site_id": 36533184,         "target": {           "lpButtonDivChat": "SB-Fixed14"         },         "account_type": "Online Banking",         "customer_lob": "sbob"       }     }   },   "user": {     "segment": null,     "online_id": null,     "preferred_rewards_tier": null,     "olb3rdpartyid": null   },   "version": "BAC_0.12" }, DDO );

			DDO.page.pageInfo[0].pageID = "smbus:Content:OLBs:FAQ;account-access";
			DDO.page.category.primaryCategory  = "smbus:Content:OLBs:FAQ";
			DDO.page.pageInfo[0].language = "en-US";
			DDO.page.attributes.olbSessionID = "null";
			DDO.page.attributes.SASIEnabled =  "false";
			if (typeof DDO.user != "undefined" && typeof DDO.user.olb3rdpartyid != "undefined") {
				DDO.user.olb3rdpartyid = bactm_olb3rdPartyId;
			}

			window.utag_data = {};
			window.bactm_envSelector = bactm_setTMLib();
			window.digitalData = DDO;

      return fireCallback( callback );

    } catch(e) { }
  }
	if( window.boa && window.boa.digitalData ) {
    window.boa.digitalData.register( ddoPopulateBase );
	}
	else {
	  // Handle scenario where the header isn't available (and thus the default digitalData object and utag loader are missing).
	  //
		var writeScript = function(a,b,c,d){
			a='//tags.tiqcdn.com/utag/bofa/main/' + bactm_envSelector + '/utag.js';
			b=document;
			c='script';
			d=b.createElement(c);
			d.src=a;
			d.type='text/java'+c;
			d.async=true;
			a=b.getElementsByTagName(c)[0];
			a.parentNode.insertBefore(d,a);
		};

		ddoPopulateBase( writeScript );
	}
})();			
</script>





	
	
				<noscript>
				
					<div class="fauxdal-overlay"></div>
					<div class="fauxdal-module">
						<div class="js-disabled-skin">
							<div class="fauxdal-top"></div>
							<div class="fauxdal-bottom">
								<div class="fauxdal-content">
										<div class="fauxdal-title">
											Please Use JavaScript
										</div>
											<p>You need a web browser that supports JavaScript to use our site. Without it, some pages won&rsquo;t work as designed. To make sure JavaScript is turned on, please adjust your browser settings and refresh.</p><p><a title="Browser Help and Tips" name="Browser_Help_and_Tips" href="http://www.bankofamerica.com/onlinebanking/index.cfm?template=browser_help_and_tips">Browser Help and Tips</a></p>
										
								</div>        
								<div class="fauxdal-close"> 
									<a class="btn-bofa btn-bofa-small" href=?js=y>Close</a>
								</div>
								
							</div>
						</div>
					</div>
				</noscript>



 


<div class="header-module">
	<div class="text-w-logo-skin">
		<div class="header-left">
	  
			<div itemscope itemtype="http://schema.org/Corporation" class="bofa-logo">
				<a itemprop="url" name="anc-business-advantage" title="Bank of America Small Business" href="/smallbusiness/index.jsp">
					<img itemprop="logo" height="28" width="221" 
					     alt="Bank of America Small Business" src="/content/images/ContextualSiteGraphics/Logos/en_US/boa_logo.gif"/>
				</a>
			</div>
				<div class="product" data-font="cnx-regular">Business Advantage</div>
			
			<div class="clearboth"></div>

		</div>
		
		<div class="header-right">
			<ul class="header-links">
			
				
					
				
							<li class="sign-in">
		<a					href="/sitemap/hub/signin.go" target="_self"
		name="Sign_In">Sign In</a> 
							</li>
					
				
							<li>		<a					href="/smallbusiness/index.jsp" target="_self"
		name="Home_Header">Home</a> 
</li>
					
				
							<li>		<a					href="https://locators.bankofamerica.com " target="_self"
		name="Locations">Locations</a> 
</li>
					
				
							<li>		<a					href="/contactus/contactus.go?topicId=small_business_banking" target="_self"
		name="Contact_Us">Contact Us</a> 
</li>
					
				
							<li class="last-link">	
		<a					href="/help/" target="_self"
		name="Help">Help</a> 
							</li>
			</ul>
			
			<div class="clearboth"></div>

			<!-- include search-dotcom-util -->



<div class="header-search nlh">
  
  <div class="nav-search">
    <form class="search-form" action="https://secure.bankofamerica.com/myaccounts/public/search-results/unAuthenticatedSearch.go" data-js="/pa/components/utilities/search-util/1.0/script/nav-search.min.js" data-css="/pa/components/utilities/search-util/1.0/style/nav-search.css" data-text-unavailable="Search Currently Unavailable">
      <div class="search-input-container cf" data-icon="search">
        <label for="nav-search-query" class="ada-hidden">Search Term</label>
        <input type="text" placeholder="How can we help you?" name="query" class="search-query" id="nav-search-query" 
          maxlength="99" rel="Search" autocomplete="off"><input type="submit" alt="Search" title="Search" value="Submit Search" name="Search Module - Top Result – Search Button" class="submit track-me">
      </div>
    </form>
  </div>

</div>

		</div>

 		<div class="clearboth"></div>
 	</div>
</div>







	<div class="top-nav-module">
		<div class="fsd-skin sup-ie">
			<ul class="nav-list">
					
					
					<li>
						
								<a href="/smallbusiness/deposits/checking-accounts/" class="top-menu-item"
								name="business_checking_topnav" id="business_checking_topnav">Business Checking<span class="ada-hidden"> &nbsp;link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/smallbusiness/deposits/checking-accounts/business-advantage/"  name="business_advantage_topnav" id="business_advantage_topnav">Business Advantage </a>
															<a href="/smallbusiness/deposits/checking-accounts/business-fundamentals/"  name="business_fundamentals_topnav" id="business_fundamentals_topnav">Business Fundamentals<sup>&reg;</sup> </a>
															<a href="/smallbusiness/business-debit-card.go"  name="business_debit_card_topnav" id="business_debit_card_topnav">Business Debit Card </a>
									</div>
								
									<span class="ada-hidden"> End of submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
					
					
					<li>
						
								<a href="/smallbusiness/cd-savings-accounts.go" class="top-menu-item"
								name="business_savings_and_cds_topnav" id="business_savings_and_cds_topnav">Business Savings & CDs<span class="ada-hidden"> &nbsp;link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/smallbusiness/savings-accounts/business-interest-maximizer.go"  name="business_interest_maximizer_topnav" id="business_interest_maximizer_topnav">Business Interest Maximizer&trade; </a>
															<a href="/smallbusiness/savings-accounts/business-investment-account.go"  name="business_investment_account_topnav" id="business_investment_account_topnav">Business Investment Account </a>
															<a href="/smallbusiness/cds/business-featured-cd.go"  name="business_featured_cd_topnav" id="business_featured_cd_topnav">Business Featured CD </a>
															<a href="/smallbusiness/cds/risk-free-cd.go"  name="business_risk_free_cd_topnav" id="business_risk_free_cd_topnav">Business Risk Free CD<sup>&reg;</sup> </a>
															<a href="/smallbusiness/standard-cds.go"  name="cds_topnav" id="cds_topnav">Standard Business CD </a>
									</div>
								
									<span class="ada-hidden"> End of submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
					
					
					<li>
						
								<a href="javascript:void(0);" class="top-menu-item"
								name="manage_accounts_topnav" id="manage_accounts_topnav">Manage Your Account<span class="ada-hidden"> &nbsp;link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/smallbusiness/online-banking.go"  name="online_banking_topnav" id="online_banking_topnav">Online Banking </a>
															<a href="/smallbusiness/online-banking/cash-management.go"  name="business_tools_topnav" id="business_tools_topnav">Business Tools </a>
									</div>
								
									<span class="ada-hidden"> End of submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
					
					
					<li>
						
								<a href="javascript:void(0);" class="top-menu-item selected"
								name="resources_topnav" id="resources_topnav">Resources<span class="ada-hidden"> &nbsp;link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/smallbusiness/resources/faqs.go"  name="faqs_topnav" id="faqs_topnav">FAQs </a>
															<a href="/smallbusiness/resources/glossary.go"  name="glossary_topnav" id="glossary_topnav">Glossary </a>
															<a href="/smallbusiness/resources/fees-at-a-glance.go"  name="fees_at_a_glance_topnav" id="fees_at_a_glance_topnav">Fees at a Glance </a>
															<a href="/deposits/bank-account-interest-rates/?flow=BCS"  name="account_rates_topnav" id="account_rates_topnav">Account Rates </a>
															<a href="/smallbusiness/platinum-privileges.go"  name="business_platinum_privileges_topnav" id="business_platinum_privileges_topnav">Business Platinum Privileges&trade; </a>
															<a href="/smallbusiness/resources/overdraft-protection.go"  name="overdraft_protection_topnav" id="overdraft_protection_topnav">Overdraft Protection </a>
									</div>
								
									<div class="hasSub">
														<a class="with-info" href="/smallbusiness/education.go"  name="managing_a_small_business_topnav" id="managing_a_small_business_topnav">Managing A Small Business 
															
															<span class="sub-nav-item-info">Articles, tips and tools to help you and your business grow</span>
														</a>
														<a class="with-info" href="/smallbusiness/online-banking/business-services.go"  name="popular_service_combinations_topnav" id="popular_service_combinations_topnav">Popular service combinations 
															
															<span class="sub-nav-item-info">See how business checking solutions combined with Online Banking services can help your business</span>
														</a>
									</div>
									<span class="ada-hidden"> End of submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
			</ul>
				<div class="clearboth"></div>
		</div>
	</div>


	
 
<div class="page-title-fsd-module h-100" id="skip-to-h1">
	<div class="article-skin sup-ie">
		<div class="full-width-wrapper">
			<h1 data-font="cnx-regular">Managing a Small Business</h1>	

			

			<div class="clearboth"></div>
		</div>
  	</div>
</div>




<script>
	$(document).ready(function(){
		engagementModuleGradbgH1Skin.init();
	});
</script>

			<div class="engagement-module">
					<div class="gradbg-h1-skin">
					<h1 id="skip-to-h1" data-font="cnx-regular">Small business tips and resources</h1>					
				</div>
			</div>



<script>
	$(document).ready(function(){
		tabStripModuleIconTxtSkin.init();
	});
</script>


	<div class="tabstrip-module">
	  <div class="icon-text-skin">


	  		  		<div class="tab selected-tab">

						<h2 class="start-business"><a role="tab" aria-selected="false" href="javascript:void(0);" data-target=".starting" name="starting_your_business - Tab">Starting your business</a></h2>
	   				</div>

	  		  		<div class="tab">

						<h2 class="understand-finances"><a role="tab" aria-selected="false" href="javascript:void(0);" data-target=".managing" name="managing_your_business-Tab">Managing your business</a></h2>
	   				</div>

	  		  		<div class="tab">

						<h2 class="grow-business"><a role="tab" aria-selected="false" href="javascript:void(0);" data-target=".growing" name="growing_your_business-Tab">Growing your business</a></h2>
	   				</div>

	   					 <div class="clearboth"></div>
	  </div>
	</div>
</div>
					<div class="columns">
						<div class="flex-col lt-col" >






<div class="main-text-img-module">
   	<div class="multi-section-skin">
	  		<div class="starting" tabindex="0">


			   				<div class="primary-section">
							<div class="section">
										<a 			href="/smallbusiness/education/how-to-start-a-business.go"
 name="anc-starting-a-new-business-image"><img data-src="/content/images/ContextualSiteGraphics/Instructional/en_US/SB/BP_video_bike_shop_418x418.png"  alt="Read Article: Smart planning can set you up for a faster launch - and long-term success." /></a>

									<div class="content-box">
													<h3><a 			href="/smallbusiness/education/how-to-start-a-business.go" class="head-link"
 name="starting_your_business_Tab-planning_for_faster">Starting a new business?</a></h3>
													<a  name="starting_your_business_Tab-planning_for_faster" 			href="/smallbusiness/education/how-to-start-a-business.go" class="content-link"
 >Smart planning can set you up for a faster launch &mdash; and long-term success.			<span class="ada-hidden">Read article: Starting a new business?</span>
<span class="icon article-icon"></span></a>
													<a  name="starting_your_business_Tab-planning_for_faster" 			href="/smallbusiness/education/how-to-start-a-business.go" class="btn-bofa btn-bofa-blue btn-bofa-large"
 >Read article			<span class="ada-hidden">: Smart planning can set you up for a faster launch - and long-term success.</span>
</a>
									</div>

							</div>			   				</div>

			   				<div class="secondary-section three-section">
							<div class="section">
										<a 			href="/smallbusiness/education/business-checking-and-credit-card-benefits.go"
 name="anc-business-checking-and-credit-image"><img data-src="/content/images/ContextualSiteGraphics/Instructional/en_US/SB/BP_video_shop_owner_272x210.png"  alt="Read article: Put business checking and credit card accounts to work for your company" /></a>

									<div class="content-box">
													<h3><a 			href="/smallbusiness/education/business-checking-and-credit-card-benefits.go" class="head-link"
 name="anc-business-checking-and-credit-header">Put business checking and credit card accounts to work for your company.</a></h3>
													<a  name="starting_your_business-put_business_checking" 			href="/smallbusiness/education/business-checking-and-credit-card-benefits.go" class="content-link"
 >Read article			<span class="ada-hidden">: Put business checking and credit card accounts to work for your company.</span>
<span class="icon article-icon"></span></a>
									</div>

							</div>
							<div class="section">
										<a 			href="/smallbusiness/education/how-to-write-a-business-plan.go"
 name="anc-business-plan-image"><img data-src="/content/images/ContextualSiteGraphics/Instructional/en_US/SB/BP_video_business_woman_272x210.png"  alt="A business plan - the key to growth and success." /></a>

									<div class="content-box">
													<h3><a 			href="/smallbusiness/education/how-to-write-a-business-plan.go" class="head-link"
 name="anc-business-plan-header">A business plan - the key to growth and success.</a></h3>
													<a  name="starting_your_business-business_plan_read_article" 			href="/smallbusiness/education/how-to-write-a-business-plan.go" class="content-link"
 >Read article			<span class="ada-hidden">: A business plan - the key to growth and success.</span>
<span class="icon article-icon"></span></a>
									</div>

							</div>
							<div class="section">
										<a 			href="/smallbusiness/education/managing-payables.go"
 name="anc-managing-payables-image"><img data-src="/content/images/ContextualSiteGraphics/Instructional/en_US/SB/BP_video_ipad_272x210.png"  alt="Read article: Avoid cash flow pitfalls - steer your business to financial health." /></a>

									<div class="content-box">
													<h3><a 			href="/smallbusiness/education/managing-payables.go" class="head-link"
 name="anc-managing-payables-header">Avoid cash flow pitfalls - steer your business to financial health.</a></h3>
													<a  name="starting_your_business-managing_payable_article" 			href="/smallbusiness/education/managing-payables.go" class="content-link"
 >Read article			<span class="ada-hidden">: Avoid cash flow pitfalls - steer your business to financial health.</span>
<span class="icon article-icon"></span></a>
									</div>

							</div>			   				</div>		   					<div class="clearboth"></div>
	   		</div>
	</div>
</div>







<div class="main-text-img-module">
   	<div class="multi-section-skin">
	  		<div class="managing hide" tabindex="0">


			   				<div class="primary-section">
							<div class="section">
										<a 			href="/smallbusiness/education/cash-management-for-small-businesses.go"
 name="anc-control-your-cash-flow-image"><img data-src="/content/images/ContextualSiteGraphics/Instructional/en_US/SB/BP_video_bike_shop2_418x418.png"  alt="Read article: Control your cash flow" /></a>

									<div class="content-box">
													<h3><a 			href="/smallbusiness/education/cash-management-for-small-businesses.go" class="head-link"
 name="anc-control-your-cash-flow-header">Control your cash flow</a></h3>
													<a  name="anc-control-your-cash-flow" 			href="/smallbusiness/education/cash-management-for-small-businesses.go" class="content-link"
 >Make sure your business is financially secure by properly managing your cash flow.			<span class="ada-hidden">Read article: Control your cash flow</span>
<span class="icon article-icon"></span></a>
													<a  name="Managing_Business_Tab-control-your-cash-flow_artic" 			href="/smallbusiness/education/cash-management-for-small-businesses.go" class="btn-bofa btn-bofa-blue btn-bofa-large"
 >Read article			<span class="ada-hidden">: Control your cash flow</span>
</a>
									</div>

							</div>			   				</div>

			   				<div class="secondary-section two-section">
							<div class="section">
										<a 			href="/smallbusiness/education/10-ways-avoid-business-bank-account-fees.go"
 name="anc-lower-banking-credit-card-fees-image"><img data-src="/content/images/ContextualSiteGraphics/Instructional/en_US/SB/BP_video_man_woman_272x320.png"  alt="Read article: Lower or avoid business banking and credit card fees" /></a>

									<div class="content-box">
													<h3><a 			href="/smallbusiness/education/10-ways-avoid-business-bank-account-fees.go" class="head-link"
 name="anc-lower-banking-credit-card-fees-header">Lower or avoid business banking and credit card fees.</a></h3>
													<a  name="Managing_business_Tab-banking-credit-card-fees_art" 			href="/smallbusiness/education/10-ways-avoid-business-bank-account-fees.go" class="content-link"
 >Read article			<span class="ada-hidden">: Lower or avoid business banking and credit card fees</span>
<span class="icon article-icon"></span></a>
									</div>

							</div>
							<div class="section">
										<a 			href="/smallbusiness/education/small-business-tax-preparation-tips.go"
 name="anc-mobile-banking-image"><img data-src="/content/images/ContextualSiteGraphics/Instructional/en_US/SmallBusiness/tax-tips-time-spent-on-taxes1.jpg"  alt="Read article: Mobile Banking - the easy way to get business done faster on-the-go." /></a>

									<div class="content-box">
													<h3><a 			href="/smallbusiness/education/small-business-tax-preparation-tips.go" class="head-link"
 name="anc-mobile-banking-header">5 helpful tips for tax season</a></h3>
													<a  name="managing_business_tab-mobile_banking_article" 			href="/smallbusiness/education/small-business-tax-preparation-tips.go" class="content-link"
 >View infographic			<span class="ada-hidden">: 5 helpful tips for tax season</span>
<span class="icon article-icon"></span></a>
									</div>

							</div>			   				</div>		   					<div class="clearboth"></div>
	   		</div>
	</div>
</div>





<script>
				mainWellContentModuleLinksListToggleSkin.init({showMoreText:'Show more <span class="ada-hidden">Show more articles</span>',showLessText:'Show less <span class="ada-hidden">Show less articles</span>'});	
</script>
		
	<div class="main-well-content-module">
		<div class="links-list-toggle-skin com-main-well-content managing">  		
			<h4 class="h2-styling">More on managing your small business</h4>
			<div class="toggle-list-wrapper">
				<ul>	
						
						
					
							<li class="note-icon ">
								<a 			href="/smallbusiness/education/how-mobile-can-help-you-run-your-business.go"
 name="anc-multiple-cards"><span>Mobile Banking - the easy way to get business done faster on the go.</span></a>
							</li>
				</ul>
			</div> 					
		</div> 			
	</div>	






<div class="main-text-img-module">
   	<div class="multi-section-skin">
	  		<div class="growing hide" tabindex="0">


			   				<div class="primary-section">
							<div class="section">
										<a 			href="/smallbusiness/education/small-business-lending-options.go"
 name="anc-give-business-financial-boost"><img data-src="/content/images/ContextualSiteGraphics/Instructional/en_US/SB/BP_video_business_man_418x418.png"  alt="Read article: Give your business a financial boost" /></a>

									<div class="content-box">
													<h3><a 			href="/smallbusiness/education/small-business-lending-options.go" class="head-link"
 name="anc-give-business-financial-boost-header">Give your business a financial boost</a></h3>
													<a  name="anc-give-business-financial-boost" 			href="/smallbusiness/education/small-business-lending-options.go" class="content-link"
 >Choose the loan or credit option that's right for you.			<span class="ada-hidden">Read article: Give your business a financial boost</span>
<span class="icon article-icon"></span></a>
													<a  name="Growing_business_Tab-give_financial-boost_article" 			href="/smallbusiness/education/small-business-lending-options.go" class="btn-bofa btn-bofa-blue btn-bofa-large"
 >Read article			<span class="ada-hidden">: Give your business a financial boost</span>
</a>
									</div>

							</div>			   				</div>

			   				<div class="secondary-section two-section">
							<div class="section">
										<a 			href="/smallbusiness/education/payroll-best-practices.go"
 name="anc-health-payroll-best-practices-image"><img data-src="/content/images/ContextualSiteGraphics/Instructional/en_US/SB/BP_video_calculator_272x320.png"  alt="Read article: Best practices for processing payroll in your small business" /></a>

									<div class="content-box">
													<h3><a 			href="/smallbusiness/education/payroll-best-practices.go" class="head-link"
 name="anc-health-payroll-best-practices-header">Best practices for processing payroll in your small business.</a></h3>
													<a  name="Growing_business_Tab-health-payroll-best-practices" 			href="/smallbusiness/education/payroll-best-practices.go" class="content-link"
 >Read article			<span class="ada-hidden">: Best practices for processing payroll in your small business.</span>
<span class="icon article-icon"></span></a>
									</div>

							</div>
							<div class="section">
										<a 			href="/smallbusiness/education/liquidity-as-a-business-lever.go"
 name="anc-liquidity-as-a-business-lever"><img data-src="/content/images/ContextualSiteGraphics/Instructional/en_US/SB/BP_video_nursery_272X320.jpg"  alt="Read article: Liquidity as a Business Lever" /></a>

									<div class="content-box">
													<h3><a 			href="/smallbusiness/education/liquidity-as-a-business-lever.go" class="head-link"
 name="anc-liquidity-as-a-business-lever">Liquidity as a Business Lever</a></h3>
													<a  name="Growing_business_Tab-liquidity-business-lever" 			href="/smallbusiness/education/liquidity-as-a-business-lever.go" class="content-link"
 >Read article			<span class="ada-hidden">: Liquidity as a Business Lever</span>
<span class="icon article-icon"></span></a>
									</div>

							</div>			   				</div>		   					<div class="clearboth"></div>
	   		</div>
	</div>
</div>

</div>
						<div class="flex-col rt-col" >


<div class="side-well-module">
	<div class="heading-links-skin sup-ie" style="margin:25px 0;">
    		<div class="sm-body">            
				<div class="sm-title">
				    <h2 class="sm-header">More business resources</h2>
				</div>			    
					<h3><a href="/smallbusiness/deposits/checking-accounts/" name="more_business_resources-Small_business_checking">Small business checking</a></h3>
					<p>Get the most out of your small Business checking account for your business.</p>		                
					<h3><a href="/smallbusiness/online-banking/mobile.go" name="more_business_resources-mobile_banking">Mobile Banking</a></h3>
					<p>Enjoy fast, convenient connections and transactions with Mobile Banking.</p>		                
					<h3><a href="http://promo.bankofamerica.com/small-business-videos/" name="more_business_resources-Small_business_videos">Small business videos</a></h3>
					<p>Discover tools and services to help your business.</p>		                
        	</div>              
    	</div>
 </div>

</div>
						<div class="clearboth"></div>
					</div>
					<div class="footer">
						<div class="footer-top">&nbsp;
<div class="disclaimers-module">
	<div class="fsd-skin sup-ie">
			<p>Some accounts and services, and the fees that apply to them, vary from state to state. Please review the information for your state in the <a name="businessScheduleOfFees_disclaimer_link" href="/smallbusiness/resources/business-schedule-fees.go" target="_blank">Business Schedule of Fees</a> and in the Online Banking Service Agreement at <a rel="nofollow" name="serviceAgreement_disclaimer_link" href="http://www.bankofamerica.com/serviceagreement" target="_blank">www.bankofamerica.com/serviceagreement</a>.</p>
	</div>
</div>

</div>
						<div class="footer-inner">
	<script type="text/javascript" src="https://www.bankofamerica.com/pa/components/modules/social-widget-module/1.2.5/script/socialplugin.js"></script>
	





<div class="social-widget-module">
	<div class="social-widget-inner" style="margin:0px;;">
		
			<div id="sharebar">
				 <script type="text/javascript">
				new com.bofa.socialplugin.core.ShareBarPlugin().display({
						"socialplugin_apppath" : "https://www.bankofamerica.com/pa/components/modules/social-widget-module/1.2.5",
						"socialconfig_apppath" : "https://www.bankofamerica.com/content/social",
						"gigyaApiKey" : "3_tIhxOOqZ3o4KC8r_VvalOR-b72A08kp4a1vdf6uyaSH4VTdeKCqMmAwh7n7AX4gz",
						"elementId" : "sharebar",
						"type" : "bottom980",
						"showCounters" : true,
						"enablePrint" : false,
						"contentOverride"	: {
							"facebook" : { "showCounter": false , "tinyUrlCode": false },
							"twitter"  : { "showCounter": false , "tinyUrlCode": false },
							"linkedin"  : { "showCounter": false , "tinyUrlCode": false },
							"digg"  : { "showCounter": false },
							"delicious"  : { "showCounter": false },
							"reddit"  : { "showCounter": false },
							"stumbleupon"  : { "showCounter": false },
							"pinterest"  : { "showCounter": false }
						}
					});
				 </script>
			</div>

	</div>
</div>



<div class="power-footer-module">

  <div class="four-col-all-links-skin sup-ie">
    <div class="breadcrumbs">
						<a class="bold-bc" href="/" name="bank_of_america_education_breadcrumbs">Bank of America</a>
						<a href="/smallbusiness" name="small_business_education_breadcrumbs" >Small Business</a>
		
					<a href="/smallbusiness/education.go" name="resources_education_breadcrumbs">Resources</a>
		      	 <span>Managing a Small Business</span>
		    
      <div class="clearboth"></div>
    </div>
    <div class="pf-columns">
      
			<div class="pf-col" style="margin-right:50px;">
				<ul>
					<li>	
					<a href="/smallbusiness/deposits/checking-accounts/" class="bold" name="business_checking_education_power_footer" >Business Checking</a> 
					</li>
						<li> <a href="/smallbusiness/deposits/checking-accounts/business-advantage/" name="business_advantage_education_power_footer">Business Advantage</a> </li>
						<li> <a href="/smallbusiness/deposits/checking-accounts/business-fundamentals/" name="business_fundamentals_education_power_footer">Business Fundamentals<sup>&reg;</sup></a> </li>
						<li> <a href="/smallbusiness/checking-accounts/business-interest-checking.go" name="business_interest_checking_education_power_footer">Business Interest Checking</a> </li>
						<li> <a href="/smallbusiness/checking-accounts/full-analysis-business-checking.go" name="full_analysis_business_checking__education_power_footer">Full Analysis Business Checking </a> </li>
						<li> <a href="/smallbusiness/business-debit-card.go" name="business_debit_card_education_power_footer">Business Debit Card</a> </li>
				</ul>
		      </div>
			<div class="pf-col" style="margin-right:50px;">
				<ul>
					<li>	
					<a href="/smallbusiness/cd-savings-accounts.go" class="bold" name="business_savings_and_cd_education_power_footer" >Business Savings & CDs</a> 
					</li>
						<li> <a href="/smallbusiness/savings-accounts/business-interest-maximizer.go" name="business_interest_maximizer_education_power_footer">Business Interest Maximizer&trade;</a> </li>
						<li> <a href="/smallbusiness/savings-accounts/business-investment-account.go" name="business_investment_account_education_power_footer">Business Investment Account</a> </li>
						<li> <a href="/smallbusiness/cds/business-featured-cd.go" name="business_featured_cd_education_power_footer">Business Featured CD</a> </li>
						<li> <a href="/smallbusiness/cds/risk-free-cd.go" name="business_risk_free_cd_education_power_footer">Business Risk Free CD<sup>&reg;</sup></a> </li>
						<li> <a href="/smallbusiness/standard-cds.go" name="standard_business_cd_education_power_footer">Standard Business CD</a> </li>
				</ul>
		      </div>
			<div class="pf-col" style="margin-right:50px;">
				<ul>
					<li>	
					<a href="/smallbusiness/online-banking.go" class="bold" name="manage_your_account_education_power_footer" >Manage Your Account</a> 
					</li>
						<li> <a href="/smallbusiness/online-banking.go" name="online_banking_education_power_footer">Online Banking</a> </li>
						<li> <a href="/smallbusiness/online-banking/cash-management.go" name="business_tools_education_power_footer">Business Tools</a> </li>
						<li> <a href="/smallbusiness/business-debit-card.go" name="request_a_debit_card_education_power_footer">Request a Debit Card</a> </li>
				</ul>
		      </div>
			<div class="pf-col" style="">
				<ul>
					<li>	
					<a href="/smallbusiness/education.go" class="bold" name="resources_education_power_footer" >Resources</a> 
					</li>
						<li> <a href="/smallbusiness/resources/faqs.go" name="faqs_education_power_footer">FAQs</a> </li>
						<li> <a href="/smallbusiness/resources/glossary.go" name="glossary_education_power_footer">Glossary</a> </li>
						<li> <a href="/smallbusiness/resources/fees-at-a-glance.go" name="fees_at_a_glance_education_power_footer">Fees at a Glance</a> </li>
						<li> <a href="/deposits/bank-account-interest-rates/?flow=BCS" name="account_rates_education_power_footer">Account Rates</a> </li>
						<li> <a href="/smallbusiness/platinum-privileges.go" name="business_platinum_privileges_education_power_footer">Business Platinum Privileges&trade;</a> </li>
						<li> <a href="/smallbusiness/resources/overdraft-protection.go" name="overdraft_protection_education_power_footer">Overdraft Protection</a> </li>
				</ul>
		      </div>
      
      <div class="clearboth"></div>
    </div>
  </div>
</div>

<script language="javascript" src="/pa/global-assets/external/coremetrics/hp/eluminate.js"></script>
<script language="javascript" src="/pa/global-assets/external/coremetrics/hp/cmdatatagutils.js"></script>

	<script type="text/javascript">		
		function cmSetDD() {
		      var testString = window.location.href;
		      if (testString.toLowerCase().indexOf('.bankofamerica.com') > -1){
			    testString = testString.toLowerCase(); 
			    var tempArr = testString.split('.bankofamerica.com');
			    var tempStr = tempArr[0];
				  if (tempStr.indexOf('\/\/') > -1) {
					tempArr = tempStr.split('\/\/');tempStr = tempArr[1];
					if (tempStr.indexOf('.') > -1) {
					      tempArr = tempStr.split('.');tempStr = tempArr[0];var tempStrPt2 = tempArr[1];}
					      if (tempStr.indexOf('www') > -1) {
						    if (tempStr.indexOf('-') > -1) {cmSetStaging()}
						    else if (tempStrPt2 != null) {
							  if (tempStrPt2.indexOf('ecnp') > -1) {cmSetStaging()} 
						    }
						    else {cmSetProduction()} 
					      }
					      else if (tempStr.indexOf('-') > -1) {
						    if (tempStr.indexOf('sitekey') > -1){
							  if (tempStr == 'sitekey') {cmSetProduction()}
							  else {cmSetStaging()}  
						    } 
						    else if (testString.toLowerCase().indexOf('safe-dev') > -1 || testString.toLowerCase().indexOf('safe-cit') > -1 || testString.toLowerCase().indexOf('safe-sit') > -1) {cmSetStaging()}
						    else if (tempStrPt2 != null) {
							  if (tempStrPt2.indexOf('ecnp') > -1) {cmSetStaging()} 
						    }
						    else {cmSetStaging()}
					      }     
					      else if (tempStrPt2 != null) {
							  if (tempStrPt2.indexOf('ecnp') > -1) {cmSetStaging()} 
						    }
					      else {cmSetProduction()} 
				  }       
		      }  

		}

		if (typeof cmSetStaging == 'function') {cmSetDD()}

		cmCreatePageviewTag('smbus:Content:Education;Education', null, null, 'smbus:Content:Education', false, false, null, false, false, null, null, null, null, null, null, null, null, null, null, null, null);

		
		var coremetrics = new Object();
		coremetrics.CMPageId 		= "smbus:Content:Education;Education";		
		coremetrics.CMAppName		= null;
		coremetrics.CMAppStepNumber	= null;	
		coremetrics.CMAppStepName	= null;
		coremetrics.CMErrorCodes	= "MNGECARDMODERR001";
		coremetrics.CMCategoryId 	= "smbus:Content:Education";		
	</script>



 



		<div class="global-footer-module">
			<div class="fsd-skin">

				<div class="footer-bottom-left" style="float:left;max-width:66%;">
	    			<div class="gf-links">	          	
						
					
									
									<a  target="_self" href="/smallbusiness/index.jsp" 
									    name="global-footer-home">Home
									</a>
									
						
					
									
									<a  target="_self" href="/privacy/index.jsp" 
									    name="global-footer-privacy-security">Privacy & Security
									</a>
									
						
					
									
									<a  target="_self" href="http://careers.bankofamerica.com/careershome.aspx" 
									    name="footer_careers">Careers
									</a>
									
						
					
									
									<a  target="_self" href="/sitemap/sitemap/smallbusiness.go" 
									    name="global-footer-site-map">Site Map
									</a>
									
						
					
									<a href="javascript:void(0);" class="gf-last-link boa-dialog boa-com-info-layer-link" name="global_footer_ad_practices_lnk" rel="global_footer_ad_practices">Advertising Practices</a>
								<div id="global_footer_ad_practices" class="hide">
									<h3>Advertising Practices</h3>
										<p>We strive to provide you with information about products and services you might find interesting and useful. Relationship-based ads and online behavioral advertising help us do that.</p>
<p>Here's how it works: We gather information about your online activities, such as the searches you conduct on our Sites and the pages you visit. This information may be used to deliver advertising on our Sites and offline (for example, by phone, email and direct mail) that's customized to meet specific interests you may have.</p>
<p>If you prefer that we do not use this information, you may <a onclick="$('.ui-dialog').remove();" name="WebsiteAdPractices_OptOut" href="/privacy/online-privacy-notice.go#advertising-on-our-sites" target="_blank">opt out of online behavioral advertising</a>. If you opt out, though, you may still receive generic advertising. In addition, financial advisors/Client Managers may continue to use information collected online to provide product and service information in accordance with account agreements.</p>
<p>Also, if you opt out of online behavioral advertising, you may still see ads when you sign in to your account, for example through Online Banking or MyMerrill. These ads are based on your specific account relationships with us.</p>
<p>To learn more about relationship-based ads, online behavioral advertising and our privacy practices, please review the <a onclick="$('.ui-dialog').remove();" name="WebsiteAdPractices_PrivacyNotice" href="/privacy/online-privacy-notice.go" target="_blank">Bank of America Online Privacy Notice</a> and our <a onclick="$('.ui-dialog').remove();" name="Online-privacy-faqs" href="/privacy/faq/online-privacy-faq.go" target="_blank">Online Privacy FAQs</a>.</p>
								</div>
						<div class="clearboth"></div>
	    			</div>
	      			<p>Bank of America, N.A. Member FDIC. <a href="/help/equalhousing_popup.go" title=" Equal Housing Lender information. Link opens new window." onclick="window.open('/help/equalhousing_popup.go','newwin','width=640,height=371,scrollbars=yes,resizable=yes,left=35,top=161'); return false;" name="Equal_Housing_Lender">Equal Housing Lender<img src="/content/images/ContextualSiteGraphics/Logos/en_US/icon_equal_housing_lender.gif" alt="" width="14" height="9" /></a> <br />&copy;&nbsp;2017 Bank of America Corporation.</p>
         		</div>
         		<div class="footer-social-container" style="float:right;max-width:30%;padding-left:50px;padding-top:19px;">




<div class="boa-social-loader" data-loaded="false" data-platform="borneo"  data-options=''></div>

         		</div>
         		<div class="clearboth"></div>
  			</div>
		</div>

</div>
					</div>
				</div>
			</div>
		</div>
	</body>	
</html>

