
 

				<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
				<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
				<head>


<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta http-equiv="content-type" content="text/html;charset=utf-8">





<title>Account Management for Small Business Banking Accounts</title>

<meta name="Description" CONTENT="Bank of America Small Business Account Management tool offers seamless accounting software integration with your small business banking account.">
<meta name="Keywords" CONTENT="Bank of America Account Management">

					<meta name="twitter:title" CONTENT="Account Management for Small Business Banking Accounts" />
					<meta name="twitter:card" CONTENT="summary" />
					<meta name="twitter:url" CONTENT="https://www.bankofamerica.com/smallbusiness/online-banking/account-management.go" />
					<meta name="twitter:image" CONTENT="https://www.bankofamerica.com/content/images/ContextualSiteGraphics/Logos/en_US/Bank_of_America_Flagscape_71x71.gif" />
					<meta name="twitter:description" CONTENT="Bank of America Small Business Account Management tool offers seamless accounting software integration with your small business banking account." />
					<meta name="twitter:site" CONTENT="@BofA_Tips" />
		   			<meta property="og:title" CONTENT="Account Management for Small Business Banking Accounts" />
		   			<meta property="og:type" CONTENT="website" />
		   			<meta property="og:url" CONTENT="https://www.bankofamerica.com/smallbusiness/online-banking/account-management.go" />
		   			<meta property="og:image" CONTENT="https://www.bankofamerica.com/content/images/ContextualSiteGraphics/Logos/en_US/Bank_of_America_Flagscape_71x71.gif" />
		   			<meta property="og:description" CONTENT="Bank of America Small Business Account Management tool offers seamless accounting software integration with your small business banking account." />
		   			<meta property="og:site_name" CONTENT="Bank of America" />
		<link rel="canonical" href="https://www.bankofamerica.com/smallbusiness/online-banking/account-management.go"/>

<link rel="shortcut icon" href="/pa/global-assets/1.0/graphic/favicon.ico" type="image/ico" />

			<link rel="stylesheet" type="text/css" href="/pa/components/bundles/gzip-compressed/xengine/APS-small-business/2017.03.0/style/olbs-aps-sb-jawr.css" media="all" />
			<script src="/pa/components/bundles/gzip-compressed/xengine/APS-small-business/2017.03.0/script/olbs-aps-sb-jawr.js" type="text/javascript"></script>
				<script type="text/javascript">
					$(window).load(function(){asyncPrintCssInclude('https://www.bankofamerica.com/pa/components/bundles/gzip-compressed/xengine/APS-small-business/2017.03.0/style/olbs-aps-sb-jawr-print.css');});
				</script>
<script type="text/javascript">
(function() {
	if (typeof mboxUpdate == "function") {
		var windowURL = window.location.href
	    windowURL = windowURL.slice( windowURL.indexOf('.')+1);
		windowURL = windowURL.split( '?' )[0];
		windowURL = windowURL.toLowerCase();
		//alert(windowURL);
		if (
		    //If no mboxes on page, mbox count will be < 1
		    (mboxFactoryDefault.getMboxes().length() < 1) &&

			//Also check for high-volume pages that do not need global logging
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go") &&
			(windowURL != "bankofamerica.com/myaccounts/signin/signin.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/entry/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signonscreen.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatechallengeanswer.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatePassword.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/mobile/banking.go")&&
			(windowURL != "bankofamerica.com/content/preload/olb-myaccount-preload-jawr-module.htm")
			)
		{

			var mboxDiv = document.createElement("div");
			mboxDiv.id = "adobe_touch_clarity_replacement";
			mboxDiv.style.display = "none";
			if (document.body && document.body.firstChild) document.body.insertBefore(mboxDiv,document.body.firstChild);
			mboxDefine(mboxDiv.id,'bac_global_bottom');
			mboxUpdate('bac_global_bottom');
		}
	}
})();
</script>

		<script src="/pa/components/bundles/gzip-compressed/xengine/Global/1.0/script/tealeafbundle.js" type="text/javascript"></script>
			<script>
				var boaPageDataJS = {};
					boaPageDataJS.isLLE = "false";
			</script>
				<style>body{display:none;}</style>
	</head>		

	<body class="fsd-layout-body">	

				<script type="text/javascript">if(self == top){var theBody=document.getElementsByTagName("body")[0];theBody.style.display="block";}else{top.location=self.location;}</script>
				<noscript><style>body{display:block;}</style></noscript>
					<a class='ada-hidden ada-visible-focus' href='#skip-to-h1' id='ada-skip-link'>Skip to main content</a>
		<div class="fsd-layout fsd-2c-700lt-layout">
			<div class="fsd-border">
				<div class="center-content">
					<div class="header">
		  



<script language="javascript" src="/pa/components/modules/tag-manager-module/1.1/script/tag-manager-module-borneo-global-skin.js"></script>
<script>

(function() {
  var fireCallback = function( cb ) {
    if ( typeof cb === "function" ) cb();
  };
  
  function ddoPopulateBase( callback ) {
    try {
		  var DDO = window.digitalData,
		  	bactm_mergeDDO = function( newDDO, priorDDO ) {
		  		if( typeof priorDDO === "undefined" ) {
				  	priorDDO = digitalData || {};
				  }

			    for (var l in newDDO) {
			        if (typeof priorDDO[l] === "undefined") {
			            priorDDO[l] = newDDO[l];
			        }
			        if (newDDO[l] !== null) {
			            if (typeof newDDO[l] === "object") {
			                bactm_mergeDDO(newDDO[l], priorDDO[l]);
			            } else {
			                priorDDO[l] = bactm_validateValue( newDDO[l] ) ? newDDO[l] : priorDDO[l];
			            }
			        }
			    }

			    return priorDDO;
				},
				bactm_olb3rdPartyId = "null";

			if (typeof DDO === "undefined") {
				var simpleDDO = { page: { pageInfo:[{ pageID: null }], attributes: {}, category: { primaryCategory: null }}};

				DDO = (typeof digitalData === "object") ? digitalData : simpleDDO; 
			}

				DDO = bactm_mergeDDO( { "pageInstanceID": "notprod", "load_coremetrics": false, "load_opinionlabs": false, "load_touchcommerce": true, "load_audiencemanager": true, "page": { "pageInfo": [ { "pageID": null, "destinationURL": null, "referringURL": null, "issueDate": null, "language": null, "segmentValue": null, "appName": null, "appStepNumber": null, "appStepName": null, "attr": "-_--_--_--_--_--_--_--_--_--_--_--_--_--_-" } ], "category": { "primaryCategory": null, "addlCategory": null, "pageType": null }, "attributes": { "searchString": null, "searchResults": null, "olbSessionID": null, "subCampaignCode": null, "DARTUrl": null, "stateCookie": null, "SASIEnabled": false, "needOLBcookie": false, "standardDART": [], "standardDARTes": [], "clickDART": [], "clickDARTes": [], "gaId": [], "chat": { "site_id": 36533169, "target": { "lpButtonDiv-OnlineBanking": "SB-Fixed15" }, "account_type": "Online Banking", "customer_lob": "sbob" } } }, "user": { "segment": null, "online_id": null, "preferred_rewards_tier": null, "olb3rdpartyid": null }, "version": "BAC_0.12" }, DDO );

			DDO.page.pageInfo[0].pageID = "smbus:Content:OLBs:Online_Banking;account-management";
			DDO.page.category.primaryCategory  = "smbus:Content:OLBs:Online_Banking";
			DDO.page.pageInfo[0].language = "en-US";
			DDO.page.attributes.olbSessionID = "null";
			DDO.page.attributes.SASIEnabled =  "false";
			if (typeof DDO.user != "undefined" && typeof DDO.user.olb3rdpartyid != "undefined") {
				DDO.user.olb3rdpartyid = bactm_olb3rdPartyId;
			}

			window.utag_data = {};
			window.bactm_envSelector = bactm_setTMLib();
			window.digitalData = DDO;

      return fireCallback( callback );

    } catch(e) { }
  }
	if( window.boa && window.boa.digitalData ) {
    window.boa.digitalData.register( ddoPopulateBase );
	}
	else {
	  // Handle scenario where the header isn't available (and thus the default digitalData object and utag loader are missing).
	  //
		var writeScript = function(a,b,c,d){
			a='//tags.tiqcdn.com/utag/bofa/main/' + bactm_envSelector + '/utag.js';
			b=document;
			c='script';
			d=b.createElement(c);
			d.src=a;
			d.type='text/java'+c;
			d.async=true;
			a=b.getElementsByTagName(c)[0];
			a.parentNode.insertBefore(d,a);
		};

		ddoPopulateBase( writeScript );
	}
})();			
</script>



	
	
		
			<noscript>
				<div class="fauxdal-overlay"></div>
				<div class="fauxdal-module">
					<div class="js-disabled-skin">
						<div class="fauxdal-top"></div>
						<div class="fauxdal-bottom">
							<div class="fsd-fauxdal-content">
									<div class="fsd-fauxdal-title">
										Please Use JavaScript
									</div>
										<p>You need a web browser that supports JavaScript to use our site. Without it, some pages won&rsquo;t work as designed. To make sure JavaScript is turned on, please adjust your browser settings.</p>
<p><a name="Browser_Help_And_Tips" href="/onlinebanking/online-banking-security-faqs.go" target="_blank">Browser Help and Tips</a></p>
							</div>        
							<div class="fsd-fauxdal-close"> 
								<a class="btn-bofa btn-bofa-small" name="close_button_js_disabled_modal" href=?js=y>Close</a>
							</div>
							<div class="clearboth"></div>
						</div>
					</div>
				</div>
			</noscript>



 


<div class="header-module">
	<div class="text-w-logo-skin">
		<div class="header-left">
	  
			<div itemscope itemtype="http://schema.org/Corporation" class="bofa-logo">
				<a itemprop="url" name="anc-business-advantage" title="Bank of America Logo" href="/smallbusiness/index.jsp">
					<img itemprop="logo" height="25" width="201" 
					     alt="Bank of America Logo" src="/content/images/ContextualSiteGraphics/Logos/en_US/bofa-logo.gif"/>
				</a>
			</div>
				<div class="product" data-font="cnx-regular">Business Advantage</div>
			
			<div class="clearboth"></div>

		</div>
		
		<div class="header-right">
			<ul class="header-links">
			
				
					
				
							<li class="sign-in">
		<a					href="/sitemap/hub/signin.go" target="_self"
		name="sign-in-header">Sign In</a> 
							</li>
					
				
							<li>		<a					href="/smallbusiness/index.jsp" target="_self"
		name="home-header">Home</a> 
</li>
					
				
							<li>		<a					href="https://locators.bankofamerica.com" target="_self"
		name="locations-header">Locations</a> 
</li>
					
				
							<li>		<a					href="/contactus/contactus.go?topicId=small_business_banking" target="_self"
		name="contact-us-header">Contact Us</a> 
</li>
					
				
							<li class="last-link">	
		<a					href="/smallbusiness/online-banking/faqs/global-account-access.go" target="_self"
		name="help-header">Help</a> 
							</li>
			</ul>
			
			<div class="clearboth"></div>

			<!-- include search-dotcom-util -->



<div class="header-search nlh">
  
  <div class="nav-search">
    <form class="search-form" action="https://secure.bankofamerica.com/myaccounts/public/search-results/unAuthenticatedSearch.go" data-js="/pa/components/utilities/search-util/1.0/script/nav-search.min.js" data-css="/pa/components/utilities/search-util/1.0/style/nav-search.css" data-text-unavailable="Search Currently Unavailable">
      <div class="search-input-container cf" data-icon="search">
        <label for="nav-search-query" class="ada-hidden">Search Term</label>
        <input type="text" placeholder="How can we help you?" name="query" class="search-query" id="nav-search-query" 
          maxlength="99" rel="Search" autocomplete="off"><input type="submit" alt="Search" title="Search" value="Submit Search" name="Search Module - Top Result – Search Button" class="submit track-me">
      </div>
    </form>
  </div>

</div>

		</div>

 		<div class="clearboth"></div>
 	</div>
</div>







	<div class="top-nav-module">
		<div class="fsd-skin sup-ie">
			<ul class="nav-list">
					
					
					<li>
						
								<a href="/smallbusiness/online-banking.go" class="top-menu-item selected"
								name="online_banking_topnav" id="online_banking_topnav">Online Banking<span class="ada-hidden"> &nbsp;link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/smallbusiness/online-banking.go"  name="business_online_banking_topnav" id="business_online_banking_topnav">Business Online Banking </a>
															<a href="/smallbusiness/online-banking/account-management.go"  name="account_permissions_topnav" id="account_permissions_topnav">Account Permissions </a>
															<a href="/smallbusiness/online-banking/quickbooks.go"  name="quicken_or_quickbooks_topnav" id="quicken_or_quickbooks_topnav">QuickBooks<sup>&reg;</sup> </a>
									</div>
								
									<div class="hasSub">
														<a class="with-info" href="/smallbusiness/online-banking/features.go"  name="business_empower_topnav" id="business_empower_topnav">Empower Your Business 
															
															<span class="sub-nav-item-info">See a full list of Online Banking and optional add-on services</span>
														</a>
									</div>
									<span class="ada-hidden"> End of Submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
					
					
					<li>
						
								<a href="/smallbusiness/online-banking/cash-management.go" class="top-menu-item"
								name="cash_management_topnav" id="cash_management_topnav">Cash Management<span class="ada-hidden"> &nbsp;link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/smallbusiness/online-banking/cash-management.go"  name="cash_management_overview_topnav" id="cash_management_overview_topnav">Cash Management Tools </a>
															<a href="/smallbusiness/online-banking/cash-management/remote-deposit.go"  name="remote_deposit_topnav" id="remote_deposit_topnav">Remote Deposit </a>
															<a href="http://promo.bankofamerica.com/olbs/olbs_directpayment.html"  name="invoicing_and_payments_topnav" id="invoicing_and_payments_topnav">Invoicing and payments </a>
															<a href="/smallbusiness/online-banking/cash-management/tax-services.go"  name="tax_services_topnav" id="tax_services_topnav">Tax Services </a>
															<a href="/smallbusiness/online-banking/cash-management/merchant-services.go"  name="merchant_services_topnav" id="merchant_services_topnav">Merchant Services 
																
															</a>
									</div>
								
									<div class="hasSub">
									</div>
									<span class="ada-hidden"> End of Submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
					
					
					<li>
						
								<a href="/smallbusiness/online-banking/payroll.go" class="top-menu-item"
								name="payroll_topnav" id="payroll_topnav">Payroll<span class="ada-hidden"> &nbsp;link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/smallbusiness/online-banking/payroll.go"  name="online_payroll_overview_topnav" id="online_payroll_overview_topnav">Payroll overview </a>
															<a href="/smallbusiness/online-banking/payroll/adp.go"  name="adpreg_payroll_topnav" id="adpreg_payroll_topnav">ADP<sup>&reg;</sup> Payroll </a>
															<a href="/smallbusiness/online-banking/payroll/intuit.go"  name="intuitreg_payroll_topnav" id="intuitreg_payroll_topnav">Intuit<sup>&reg;</sup> Payroll </a>
									</div>
								
									<div class="hasSub">
									</div>
									<span class="ada-hidden"> End of Submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
					
					
					<li>
						
								<a href="/smallbusiness/online-banking/mobile.go" class="top-menu-item"
								name="mobile_banking_topnav" id="mobile_banking_topnav">Mobile Banking<span class="ada-hidden"> &nbsp;link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href=" /smallbusiness/online-banking/mobile.go"  name="mobile_banking_overview_topnav" id="mobile_banking_overview_topnav">Mobile Banking Overview   </a>
															<a href="/smallbusiness/online-banking/mobile/features.go"  name="mobile_banking_features_topnav" id="mobile_banking_features_topnav">Mobile Banking Features </a>
															<a href="/smallbusiness/online-banking/mobile/app/overview.go"  name="mobile_banking_basics_topnav" id="mobile_banking_basics_topnav">Understanding the basics </a>
									</div>
								
									<div class="hasSub">
														<a class="with-info" href="http://merch.bankofamerica.com/web/pages/CloverGo-overview"  name="mobile_pay_topnav" id="mobile_pay_topnav">Mobile Pay 
															<img class="externalLinkArrow" src="/content/images/ContextualSiteGraphics/Instructional/en_US/arrow-external-link.gif" alt="" />
															<span class="sub-nav-item-info">Bank of America Merchant Services mobile payment solutions provide fast, secure payment processing using your smartphone</span>
														</a>
									</div>
									<span class="ada-hidden"> End of Submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
			</ul>
				<div class="clearboth"></div>
		</div>
	</div>


	
 
<div class="page-title-fsd-module h-100" id="skip-to-h1">
	<div class="prod-indicator-skin sup-ie">
		<div class="full-width-wrapper">
			<h1 data-font="cnx-regular">Account Management</h1>	

			

			<div class="clearboth"></div>
		</div>
  	</div>
</div>





	
<div class="live-person-bdf-module">
   <div class="bcs-skin">
    
     	<a href="javascript:window.print();" name="print">PRINT<span class="ada-hidden">  this page</span></a> 
    
	
		<div id="lpButtonDiv-OnlineBanking">
		</div>
		
		<div id="lpButtonDivVoice"></div>
   </div>
</div>

</div>
					<div class="columns">
						<div class="flex-col lt-col" >

	
<div class="generic-content-module tabs-main-content">
	<div class="overview-vzd3-skin com-main-well-content" style="margin: 8px 0px 60px 0px;">
				<h2 class="h2-fsd-red">Account Management gives you power, control and flexibility</h2>
			
			


			
			
						<p>Upgrade your Online Banking experience with Account Management from Bank of America. You'll get more control over your accounts plus the increased functionality and flexibility that comes with seamless QuickBooks<span style="font-size: xx-small; color: #333333; font-family: Verdana;"><span style="font-size: xx-small; color: #333333; font-family: Verdana;"><span style="font-size: xx-small; color: #333333; font-family: Verdana;"><sup>&reg;</sup></span></span></span> integration.</p>
			


				<h3>The power to grant customized access to your accounts</h3>
			
			


			
			
				<ul>
					<li>
					Establish individual account access levels, including Bill Pay
					
					
					</li>
					<li>
					Enjoy increased flexibility: For example, you can allow an employee to view details of one account for specific business needs and allow your accountant to view details of all accounts and make payments from a selected account
					
					
					</li>
					<li>
					Easily manage users on our newly redesigned User Management page.
					
					
					</li>
				</ul>


				<h3>The control to manage multiple accounts</h3>
			
			


			
			
				<ul>
					<li>
					Manage accounts for multiple businesses with one Online ID
					
					
					</li>
					<li>
					Transfer funds between different business entity accounts linked to your profile
					
					
					</li>
				</ul>


				<h3>The flexibility of seamless QuickBooks<sup>&reg;</sup> integration</h3>
			
			


			
			
				<ul>
					<li>
					Easy synchronization of your banking transactions with your accounting software
					
					
					</li>
					<li>
					Perform all your online banking directly within <a name="quickbooks" href="/smallbusiness/online-banking/quickbooks.go" target="_self">QuickBooks<sup>&reg;</sup></a>
					
					
					</li>
				</ul>


	</div>
</div>






<div class="featured-content-module">
   <div class="c2a-feature-skin featured-box-vzd3-common sup-ie">
      <div class="fc-drop-shadow-outer">
         <div class="fc-drop-shadow-inner">
            <div class="fc-content-border">
               <div class="fc-content">					
					<div class="top-section">
								<div class="img-container fcm-c2a-container"> 
									<img height="120" width="158" src="/content/images/ContextualSiteGraphics/Instructional/en_US/Feature_account_managment.png" alt="" style="margin-right:10px"/>
								</div>
						<!-- inline style on above img tag should be sourced from CMS. This will allow flexible space/placement around the image for different images. -->
						<!-- End logical img container include -->
						
						<div class="content-container fcm-c2a-container">
									<h2 class="cnx-medium">Try Account Management for 3 months&mdash;at no charge</h2>
										<p>That's a $45 value.<a name="1" href="#footnote1"><span class="ada-hidden">Footnote </span><sup>1</sup></a> After 3 months, Account Management is just $15 per month&mdash;and the fee is waived when you have <a name="business-advantage-checking" href="/smallbusiness/checking-accounts/business-advantage.go" target="_self">Business Advantage Checking</a>. Enroll today so you can get back to what matters most: your business.</p>
									       <a class="button-common button-blue display-skw-2col-modal-link"  href="javascript:void(0);" name="Sign-up-now"><span>Sign up now</span><span class="ada-hidden"> for Account Management</span></a>
										<div class="clearboth"></div>
						</div>
					</div>				
					
				</div>
            </div>
         </div>
      </div>
   </div>
</div>







	<div class="hide" id="display-skw-2col-modal">	
		<div class="flex-modal-main-content">
		  <div class="skw-col" id="modal-inject-SKW"></div>
		  <div class="supp-content-col">
			 <h4>Sign in to Small Business Online Banking to enroll in <span id="dynamicTxt"></span>.</h4>
			 <ul class="gray-sq-bullet">
					<li>Not using Small Business Online Banking yet? <a name="enroll_now_to_sb_online_banking" href="https://secure.bankofamerica.com/login/enroll/entry/olbEnroll.go?reason=model_enroll">Enroll now</a></li>
					<li>Don't have a Small Business checking account? <a name="open_a_business_checking_account_now" href="/smallbusiness/checking-accounts.go">Open an account now</a></li>
			 </ul>
		  </div>
		  <div class="clearboth"></div>
		</div>
	</div>



	<div class="sitekey-widget-display-module-hidden-skin hide">

<div class="sitekey-widget-util">
	<div id="skwContainer">
		<div id="skwContent"></div>
		
		<script language="JavaScript" type="text/javascript">

			var skwURL = "https://secure.bankofamerica.com/login/sign-in/";
			var sitekey_ui_script;
			
				sitekey_ui_script = '<script language="JavaScript" type="text\/javascript" src="'+skwURL+'entry/sitekeyWidgetScript.go?inScript=true&gcsl_token=CB142EB1CE50383E3A575EA5085AB731564CC823365055008B1A559CC5B37E306E30AA435B02A37FADA9E207AC8E9D88996ABAFC2A1ADA1C318B077706455D976C171BE77496934338BFEB9305D3F2E0CB4ED1338FE0EA5DA149DE40B0211A2EF3A3B11965F260DFCF13305AC9AD54CA0293E109CB0425FE3A3817D91054FCB9A096C8FD9CCDD4546CC3BBB5ECBAAAA4C4FE5940B9C2D901988B255F83FC2D639CDCCC141211096640BE8A028ADCD2AAE9467EB832233A09EFA53F37BCD081FC1715486BD86693790B78021EFD35D3B292710454F5AAB07910542CD6BD85BFCF2F50D3E4CD21C05251B8F212FF4DC3692FB80437FFD03B1F1BDC4659C0A2AC93E21523CAC5500A6EB9D63047F573FBAE2BAAE3DEF737B787FBB953D06F440EADCA5528ADFBF4125712C863441FD0AC1273483EAD8AC07CC7A0D3F7EF6E26FE19D75A5C19DB7F4AEF5286A7AE294B795AE3076563BDF830756A425CBA3230EED02B374192911B1CC435AA105AC4A4C2911A38F40BC744595CDB3329903CAB8B32B8E3530F2DB3ABD17188A3AACECBB66FC0CBE9B8B1C676BFA1B3187FF74010FDB4BBB89483664016CA77C12BC55CC60BBF9331C72788EA74CB0F8AE114A5B9FEAF4DB125B0FF5F6CC6D50AE19E6D7644A51C35EE5D38200270AD04C67AE4BD11617A95DF2C2A282F4D08A619043B8A0335A8442FEB1565D9EBA21B332358C2F61486ACAAF3CD8AF392AE8B25C74A43995820598B90611D8B7878A7894543F542AD3FCC53B050FE05CECDCD2F855B12B6E34A249E7CEEA466BB34943C3B7F3B7E8501B871501DC73C1FAEE2940408391960F81E9BEF4C998D60324E2ED25E4BD5A37361479738875A63DC4821679B783B0B5EBB8BE4118AA917A5A822E14A5458356EC1B15F7F0403B8F86855C71B59BE516ED3EC54E7117C54EB81A7655DFD0F07BDDD7C7722B6885E15F523E896EC513580FC3D0D733B78555BC8FA2901AB9C16A916BB727651E16BCEABF559E59472&source=BOFA-OLBS&gcsl_iv=18DB9B31132A8D9C"><\/script>';
			

			document.writeln(sitekey_ui_script);


		</script>

		<script language="JavaScript" type="text/javascript">


				if( typeof($skwjq)==="undefined" || typeof(skwInitSettings)==="undefined" ) {
					document.write('<div class="skw-client-error" style="color:#333;font:62.5%/1.5 Verdana,Arial,Helvetica,sans-serif;width:205px;font-size:11px;line-height:14px;"><h2>Online Banking temporarily unavailable</h2><p>We\'re sorry, but we\'re working to restore it as quickly as possible.<\/p><p>Please try <a style="color:#36C;" name="anc-refresh-en-US" href="javascript:window.location.reload(true);">refreshing your browser<\/a> or try again later.<\/p></div>');
				}

		</script>
		<noscript>
			<link rel="stylesheet" type="text/css" href="https://secure.bankofamerica.com/pa/components/modules/sitekey-widget-module/1.0/style/sitekey-widget-layout-nojs.css" />

				<div class="skw-js-disabled-container">
					<span class="skw-nojs-ada-hidden">text_secure_sign_in</span>
					<div class="skw-js-disabled-content">
						<div class="skw-js-disabled-heading">text_use_javascript</div>
						<div>text_browser_support_javascript</div>
						<div>text_adjust_browser_setting</div>
						<a target="_self" href="/onlinebanking/online-banking-security-faqs.go" name="label_browser_help_tips">text_browser_help_tips</a>
					</div>
				</div>

		</noscript>
	</div>
	<br clear="all"/>
</div>

	</div>

</div>
						<div class="flex-col rt-col" >



<div class="side-well-module">
   <div class="c2a-img-skin">
    <div class="sw-outer">
      <div class="sw-inner">
        <div class="sw-corner sw-tleft"></div>
        <div class="sw-corner sw-tright"></div>
        <div class="sw-main sw-std-pad">
	      <h2 class="h2-fsd-sw-red">Account Management</h2>
    	<div class="sw-main-content no-top-brd">   
					<p class="pbtm-10">Manage your business finances with confidence and control.</p>
						<img class="sidewell-image" src="/content/images/ContextualSiteGraphics/Instructional/en_US/acc_management.gif" alt=""/>
						<div class="clearboth"><!--  --></div>
							<!--c2aResponse ONACTIVECART  selectedProductDetails NFS_AM_ACCM_OLBSPRODUCT numberOfItemsInCart 0-->
									<a href="javascript:void(0);" class="button-common button-red display-skw-2col-modal-link" name="Sign-up-now"><span>Sign up now</span><span class="ada-hidden"> for Account Management</span></a>
							
					
	      <div class="clearboth"><!--  --></div>
    	</div>
    	      <div class="clearboth"><!--  --></div>
        </div>
       <div class="sw-bottom"></div>
      </div>
      <div class="sw-corner sw-bleft"></div>
      <div class="sw-corner sw-bright"></div>
    </div>
 </div>
</div>

</div>
						<div class="clearboth"></div>
					</div>
					<div class="footer">
						<div class="footer-top">&nbsp;</div>
						<div class="footer-inner">

<div class="footnote-com-module">
   <div class="fsd-layout-skin sup-ie">
   
   <script>
		$(function() {
			if ($('.footnote-com-module .fsd-layout-skin').text().length > 10) {
				$('.footnote-com-module .fsd-layout-skin').addClass('wfootnote');
			}
		});
	</script>
   
					<div class="h-100">
						<div class="footnote" id="footnote1">
							<div class="fn-num">1.</div>
							<div class="fn-text">There is a monthly fee of $15 for the Account Management service. This fee will be waived for the first 3 calendar months you are enrolled in the service. </div>
							<div class="clearboth"></div>
						</div>
					</div>
   </div>
</div>





<div class="power-footer-module">

  <div class="four-col-all-links-skin sup-ie">
    <div class="breadcrumbs">
						<a class="bold-bc" href="/" name="bank_of_america_account_management_breadcrumbs">Bank of America</a>
						<a href="/smallbusiness/" name="small_business_online_banking_and_services_account_management_breadcrumbs" >Small Business</a>
		
					<a href="/smallbusiness/online-banking.go" name="business_online_banking_account_management_breadcrumbs">Business Online Banking</a>
		      	 <span>Account Management</span>
		    
      <div class="clearboth"></div>
    </div>
    <div class="pf-columns">
      
			<div class="pf-col" style="margin-right:50px;">
				<ul>
					<li>	
					<a href="/smallbusiness/online-banking.go" class="bold" name="business_online_banking_account_management_power_footer" >Business Online Banking</a> 
					</li>
						<li> <a href="/smallbusiness/online-banking/account-management.go" name="account_permissions_account_management_power_footer">Account Permissions</a> </li>
						<li> <a href="/smallbusiness/online-banking/quickbooks.go" name="quickbooks_account_management_power_footer">QuickBooks<sup>&reg;</sup></a> </li>
				</ul>
		      </div>
			<div class="pf-col" style="margin-right:50px;">
				<ul>
					<li>	
					<a href="/smallbusiness/online-banking/cash-management.go" class="bold" name="cash_management_account_management_power_footer" >Cash Management</a> 
					</li>
						<li> <a href="/smallbusiness/online-banking/cash-management/remote-deposit.go" name="remote_deposit_account_management_power_footer">Remote Deposit</a> </li>
						<li> <a href="http://promo.bankofamerica.com/olbs/olbs_directpayment.html" name="invoicing_and_payments_account_management_power_footer">Invoicing and payments</a> </li>
						<li> <a href="/smallbusiness/online-banking/cash-management/tax-services.go" name="tax_services_account_management_power_footer">Tax Services</a> </li>
						<li> <a href="/smallbusiness/online-banking/cash-management/merchant-services.go" name="merchant_services_account_management_power_footer">Merchant Services</a> </li>
				</ul>
		      </div>
			<div class="pf-col" style="margin-right:50px;">
				<ul>
					<li>	
					<a href="/smallbusiness/online-banking/payroll.go" class="bold" name="payroll_account_management_power_footer" >Payroll</a> 
					</li>
						<li> <a href="/smallbusiness/online-banking/payroll.go" name="payroll_overview_account_management_power_footer">Payroll overview</a> </li>
						<li> <a href="/smallbusiness/online-banking/payroll/adp.go" name="adp_payroll_account_management_power_footer">ADP Payroll&reg;</a> </li>
						<li> <a href="/smallbusiness/online-banking/payroll/intuit.go" name="intuit_payroll_account_management_power_footer">Intuit Payroll&reg;</a> </li>
				</ul>
		      </div>
			<div class="pf-col" style="margin-right:50px;">
				<ul>
					<li>	
					<a href="/smallbusiness/online-banking/mobile.go" class="bold" name="mobile_banking_account_management_power_footer" >Mobile Banking</a> 
					</li>
						<li> <a href="/smallbusiness/online-banking/mobile/features.go" name="mobile_banking_features_account_management_power_footer">Mobile Banking Features</a> </li>
						<li> <a href="/smallbusiness/online-banking/mobile/app/overview.go" name="understanding__the_basics_account_management_power_footer">Understanding the basics</a> </li>
				</ul>
		      </div>
      
      <div class="clearboth"></div>
    </div>
  </div>
</div>




 



		<div class="global-footer-module">
			<div class="fsd-skin">

				<div class="footer-bottom-left" style="float:left;max-width:66%;">
	    			<div class="gf-links">	          	
						
					
									
									<a  target="_self" href="/smallbusiness/index.jsp" 
									    name="global-footer-home">Home
									</a>
									
						
					
									
									<a  target="_self" href="/privacy/index.jsp" 
									    name="global-footer-privacy-security">Privacy & Security
									</a>
									
						
					
									
									<a  target="_self" href="http://www.bankofamerica.com/careers/" 
									    name="global-footer-careers">Careers
									</a>
									
						
					
									
									<a  target="_self" href="/sitemap/sitemap/smallbusiness.go" 
									    name="global-footer-site-map">Site Map
									</a>
									
						
					
									<a href="javascript:void(0);" class="gf-last-link boa-dialog boa-com-info-layer-link" name="global_footer_ad_practices_lnk" rel="global_footer_ad_practices">Advertising Practices</a>
								<div id="global_footer_ad_practices" class="hide">
									<h3>Advertising Practices</h3>
										<p>We strive to provide you with information about products and services you might find interesting and useful. Relationship-based ads and online behavioral advertising help us do that.</p>
<p>Here's how it works: We gather information about your online activities, such as the searches you conduct on our Sites and the pages you visit. This information may be used to deliver advertising on our Sites and offline (for example, by phone, email and direct mail) that's customized to meet specific interests you may have.</p>
<p>If you prefer that we do not use this information, you may <a onclick="$('.ui-dialog').remove();" name="WebsiteAdPractices_OptOut" href="/privacy/online-privacy-notice.go#advertising-on-our-sites" target="_blank">opt out of online behavioral advertising</a>. If you opt out, though, you may still receive generic advertising. In addition, financial advisors/Client Managers may continue to use information collected online to provide product and service information in accordance with account agreements.</p>
<p>Also, if you opt out of online behavioral advertising, you may still see ads when you sign in to your account, for example through Online Banking or MyMerrill. These ads are based on your specific account relationships with us.</p>
<p>To learn more about relationship-based ads, online behavioral advertising and our privacy practices, please review the <a onclick="$('.ui-dialog').remove();" name="WebsiteAdPractices_PrivacyNotice" href="/privacy/online-privacy-notice.go" target="_blank">Bank of America Online Privacy Notice</a> and our <a onclick="$('.ui-dialog').remove();" name="Online-privacy-faqs" href="/privacy/faq/online-privacy-faq.go" target="_blank">Online Privacy FAQs</a>.</p>
								</div>
						<div class="clearboth"></div>
	    			</div>
	      			<p>Bank of America, N.A. Member FDIC. <a onclick="function onclick() { window.open('/help/equalhousing_popup.go','newwin','width=640,height=371,scrollbars=yes,resizable=yes,left=35,top=161'); return false; }" name="Equal_Housing_Lender" href="/help/equalhousing_popup.go">Equal Housing Lender<img src="/content/images/ContextualSiteGraphics/Logos/en_US/icon_equal_housing_lender.gif" alt="" width="14" height="9" /></a> <br />&copy;&nbsp;2017 Bank of America Corporation. All rights reserved.</p>
         		</div>
         		<div class="footer-social-container" style="float:right;max-width:30%;padding-left:50px;padding-top:19px;">




<div class="boa-social-loader" data-loaded="false" data-platform="borneo"  data-options=''></div>

         		</div>
         		<div class="clearboth"></div>
  			</div>
		</div>




 
<script type="text/javascript" src="/pa/global-assets/external/coremetrics/hp/eluminate.js"></script>
<script type="text/javascript" src="/pa/global-assets/external/coremetrics/hp/cmdatatagutils.js"></script>

<script type="text/javascript">
/*Minified version CM Data Direction Code - updated 8-21-2013 */
function cmSetDD(){var testString=window.location.href;if(testString.toLowerCase().indexOf(".bankofamerica.com")>-1){testString=testString.toLowerCase();var tempArr=testString.split(".bankofamerica.com");var tempStr=tempArr[0];if(tempStr.indexOf("//")>-1){tempArr=tempStr.split("//");tempStr=tempArr[1];if(tempStr.indexOf(".")>-1){tempArr=tempStr.split(".");tempStr=tempArr[0];var tempStrPt2=tempArr[1]}if(tempStr.indexOf("www")>-1){if(tempStr.indexOf("-")>-1){cmSetStaging()}else{if(tempStrPt2!=null){if(tempStrPt2.indexOf("ecnp")>-1){cmSetStaging()}}else{cmSetProduction()}}}else{if(tempStr.indexOf("-")>-1){if(tempStr.indexOf("sitekey")>-1){if(tempStr=="sitekey"){cmSetProduction()}else{cmSetStaging()}}else{cmSetStaging()}}else{if(tempStrPt2!=null){if(tempStrPt2.indexOf("ecnp")>-1){cmSetStaging()}}else{cmSetProduction()}}}}}}if(typeof cmSetStaging=="function"){cmSetDD()};
</script>




    <script type="text/javascript">
        var href = window.location.href;
        $('html')
        .on('error', function(e, err) {
            cmCreateCustomError('smbus:Content:OLBs:Online_Banking;account-management', null, null, null, err.code, 'smbus:Content:OLBs:Online_Banking', err.message);
        })
        .on('click', '[data-cm]', function() {
            cmCreateManualLinkClickTag(href, $(this).data('cm').click, cG7.cM0[cm_ClientID]);
        });
    </script>
			<script type="text/javascript">
				cmCreatePageviewTag('smbus:Content:OLBs:Online_Banking;account-management', null, null, 'smbus:Content:OLBs:Online_Banking', false, false, null, false, false, null, null, null, null, null, null, null, null, null, null, null, null);
			</script>
			<div itemscope="itemscope" itemtype="http://schema.org/WebPage">
					<span style="display:none" itemprop="name">Account Management for Small Business Banking Accounts</span>
					<a style="display:none" itemprop="url" href="https://www.bankofamerica.com/smallbusiness/online-banking/account-management.go"></a>
					<span style="display:none" itemprop="description">Bank of America Small Business Account Management tool offers seamless accounting software integration with your small business banking account.</span>
					<img style="display:none" class="no-stretch" itemprop="image" alt="Account Management for Small Business Banking Accounts" src="https://www.bankofamerica.com/content/images/ContextualSiteGraphics/Logos/en_US/Bank_of_America_Flagscape_71x71.gif">
			</div>
</div>
					</div>
				</div>
			</div>
		</div>
	</body>	
</html>

