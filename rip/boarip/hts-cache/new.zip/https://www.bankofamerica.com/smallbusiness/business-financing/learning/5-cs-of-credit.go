
 

				<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
				<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
				<head>


<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta http-equiv="content-type" content="text/html;charset=utf-8">





<title>What Are Banks Looking For? - Information from Bank of America</title>

<meta name="Description" CONTENT="Banks look at these 5 C's to help determine the creditworthiness of the business that's asking for financing. How does your business stack up?">
<meta name="Keywords" CONTENT="business financing articles, 5 C's of credit">

		<link rel="canonical" href="https://www.bankofamerica.com/smallbusiness/business-financing/learning/5-cs-of-credit.go"/>

<link rel="shortcut icon" href="/pa/global-assets/1.0/graphic/favicon.ico" type="image/ico" />

			<link rel="stylesheet" type="text/css" href="/pa/components/bundles/gzip-compressed/xengine/APS-small-business/2017.03.0/style/bcs-aps-sb-jawr.css" media="all" />
			<script src="/pa/components/bundles/gzip-compressed/xengine/APS-small-business/2017.03.0/script/bcs-aps-sb-jawr.js" type="text/javascript"></script>
				<script type="text/javascript">
					$(window).load(function(){asyncPrintCssInclude('https://www.bankofamerica.com/pa/components/bundles/gzip-compressed/xengine/APS-small-business/2017.03.0/style/bcs-aps-sb-jawr-print.css');});
				</script>
<script type="text/javascript">
(function() {
	if (typeof mboxUpdate == "function") {
		var windowURL = window.location.href
	    windowURL = windowURL.slice( windowURL.indexOf('.')+1);
		windowURL = windowURL.split( '?' )[0];
		windowURL = windowURL.toLowerCase();
		//alert(windowURL);
		if (
		    //If no mboxes on page, mbox count will be < 1
		    (mboxFactoryDefault.getMboxes().length() < 1) &&

			//Also check for high-volume pages that do not need global logging
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go") &&
			(windowURL != "bankofamerica.com/myaccounts/signin/signin.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/entry/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signonscreen.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatechallengeanswer.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatePassword.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/mobile/banking.go")&&
			(windowURL != "bankofamerica.com/content/preload/olb-myaccount-preload-jawr-module.htm")
			)
		{

			var mboxDiv = document.createElement("div");
			mboxDiv.id = "adobe_touch_clarity_replacement";
			mboxDiv.style.display = "none";
			if (document.body && document.body.firstChild) document.body.insertBefore(mboxDiv,document.body.firstChild);
			mboxDefine(mboxDiv.id,'bac_global_bottom');
			mboxUpdate('bac_global_bottom');
		}
	}
})();
</script>

		<script src="/pa/components/bundles/gzip-compressed/xengine/Global/1.0/script/tealeafbundle.js" type="text/javascript"></script>
			<script>
				var boaPageDataJS = {};
					boaPageDataJS.isLLE = "false";
			</script>
				<style>body{display:none;}</style>
	</head>		

	<body class="fsd-layout-body">	

				<script type="text/javascript">if(self == top){var theBody=document.getElementsByTagName("body")[0];theBody.style.display="block";}else{top.location=self.location;}</script>
				<noscript><style>body{display:block;}</style></noscript>
					<a class='ada-hidden ada-visible-focus' href='#skip-to-h1' id='ada-skip-link'>Skip to main content</a>
		<div class="fsd-layout fsd-2c-600lt-layout">
			<div class="fsd-border">
				<div class="center-content">
					<div class="header">
		  



<script language="javascript" src="/pa/components/modules/tag-manager-module/1.1/script/tag-manager-module-borneo-global-skin.js"></script>
<script>

(function() {
  var fireCallback = function( cb ) {
    if ( typeof cb === "function" ) cb();
  };
  
  function ddoPopulateBase( callback ) {
    try {
		  var DDO = window.digitalData,
		  	bactm_mergeDDO = function( newDDO, priorDDO ) {
		  		if( typeof priorDDO === "undefined" ) {
				  	priorDDO = digitalData || {};
				  }

			    for (var l in newDDO) {
			        if (typeof priorDDO[l] === "undefined") {
			            priorDDO[l] = newDDO[l];
			        }
			        if (newDDO[l] !== null) {
			            if (typeof newDDO[l] === "object") {
			                bactm_mergeDDO(newDDO[l], priorDDO[l]);
			            } else {
			                priorDDO[l] = bactm_validateValue( newDDO[l] ) ? newDDO[l] : priorDDO[l];
			            }
			        }
			    }

			    return priorDDO;
				},
				bactm_olb3rdPartyId = "null";

			if (typeof DDO === "undefined") {
				var simpleDDO = { page: { pageInfo:[{ pageID: null }], attributes: {}, category: { primaryCategory: null }}};

				DDO = (typeof digitalData === "object") ? digitalData : simpleDDO; 
			}

				DDO = bactm_mergeDDO( {pageInstanceID:"notprod",load_coremetrics:false,load_opinionlabs:false,load_touchcommerce:true,load_audiencemanager:true,page:{pageInfo:[{pageID:null,destinationURL:null,referringURL:null,issueDate:null,language:null,segmentValue:null,appName:null,appStepNumber:null,appStepName:null,attr:"-_--_--_--_--_--_--_--_--_--_--_--_--_--_-"}],category:{primaryCategory:null,addlCategory:null,pageType:null},attributes:{searchString:null,searchResults:null,olbSessionID:null,subCampaignCode:null,DARTUrl:null,stateCookie:null,SASIEnabled:false,needOLBcookie:false,standardDART:[],standardDARTes:[],clickDART:[],clickDARTes:[],gaId:[],chat:{account_type:null,boa_associate:null,boa_retiree:null,customer_lob:null,customer_segment:null,data:null,email_campaign:null,entitlement_code:null,error_category:null,error_count:null,first_login:null,inqSalesProductTypes:{},invitation_background:null,invitation_template:null,referral_campaign:null,getStateValue:false,cust_fn:null,cust_ln:null,target:null}}},user:{segment:null,online_id:null,preferred_rewards_tier:null,olb3rdpartyid:null},version:"BAC_0.12"}, DDO );

			DDO.page.pageInfo[0].pageID = "smbus:Content:SB_Financing:Learning;5-cs-of-credit";
			DDO.page.category.primaryCategory  = "smbus:Content:SB_Financing:Learning";
			DDO.page.pageInfo[0].language = "en-US";
			DDO.page.attributes.olbSessionID = "null";
			DDO.page.attributes.SASIEnabled =  "false";
			if (typeof DDO.user != "undefined" && typeof DDO.user.olb3rdpartyid != "undefined") {
				DDO.user.olb3rdpartyid = bactm_olb3rdPartyId;
			}

			window.utag_data = {};
			window.bactm_envSelector = bactm_setTMLib();
			window.digitalData = DDO;

      return fireCallback( callback );

    } catch(e) { }
  }
	if( window.boa && window.boa.digitalData ) {
    window.boa.digitalData.register( ddoPopulateBase );
	}
	else {
	  // Handle scenario where the header isn't available (and thus the default digitalData object and utag loader are missing).
	  //
		var writeScript = function(a,b,c,d){
			a='//tags.tiqcdn.com/utag/bofa/main/' + bactm_envSelector + '/utag.js';
			b=document;
			c='script';
			d=b.createElement(c);
			d.src=a;
			d.type='text/java'+c;
			d.async=true;
			a=b.getElementsByTagName(c)[0];
			a.parentNode.insertBefore(d,a);
		};

		ddoPopulateBase( writeScript );
	}
})();			
</script>





	
	
				<noscript>
				
					<div class="fauxdal-overlay"></div>
					<div class="fauxdal-module">
						<div class="js-disabled-skin">
							<div class="fauxdal-top"></div>
							<div class="fauxdal-bottom">
								<div class="fauxdal-content">
										<div class="fauxdal-title">
											Please Use JavaScript
										</div>
											<p>You need a web browser that supports JavaScript to use our site. Without it, some pages won't work as designed. To make sure JavaScript is turned on, please adjust your browser settings.</p><p><a name="Browser_Help_And_Tips" href="http://www.bankofamerica.com/onlinebanking/index.cfm?template=browser_help_and_tips" target="_blank">Browser Help and Tips</a></p>
										
								</div>        
								<div class="fauxdal-close"> 
									<a class="btn-bofa btn-bofa-small" href=?js=y>Close</a>
								</div>
								
							</div>
						</div>
					</div>
				</noscript>



 


<div class="header-module">
	<div class="text-w-logo-skin">
		<div class="header-left">
	  
			<div itemscope itemtype="http://schema.org/Corporation" class="bofa-logo">
				<a itemprop="url" name="anc-business-advantage" title="Bank of America logo" href="/smallbusiness/">
					<img itemprop="logo" height="28" width="221" 
					     alt="Bank of America logo" src="/content/images/ContextualSiteGraphics/Logos/en_US/boa_logo.gif"/>
				</a>
			</div>
				<div class="product" data-font="cnx-regular">Business Advantage</div>
			
			<div class="clearboth"></div>

		</div>
		
		<div class="header-right">
			<ul class="header-links">
			
				
					
				
							<li class="sign-in">
		<a					href="/sitemap/hub/signin.go" target="_self"
		name="Sign_In">Sign In</a> 
							</li>
					
				
							<li>		<a					href="/smallbusiness/" target="_self"
		name="Home_Header">Home</a> 
</li>
					
				
							<li>		<a					href="https://locators.bankofamerica.com" target="_self"
		name="Locations">Locations</a> 
</li>
					
				
							<li>		<a					href="/contactus/contactus.go?topicId=small_business_banking " target="_self"
		name="Contact_Us">Contact Us</a> 
</li>
					
				
							<li class="last-link">	
		<a					href="/smallbusiness/business-financing/learning/faqs-applying-for-financing.go" target="_self"
		name="Help">Help</a> 
							</li>
			</ul>
			
			<div class="clearboth"></div>

			<!-- include search-dotcom-util -->



<div class="header-search nlh">
  
  <div class="nav-search">
    <form class="search-form" action="https://secure.bankofamerica.com/myaccounts/public/search-results/unAuthenticatedSearch.go" data-js="/pa/components/utilities/search-util/1.0/script/nav-search.min.js" data-css="/pa/components/utilities/search-util/1.0/style/nav-search.css" data-text-unavailable="Search Currently Unavailable">
      <div class="search-input-container cf" data-icon="search">
        <label for="nav-search-query" class="ada-hidden">Search Term</label>
        <input type="text" placeholder="How can we help you?" name="query" class="search-query" id="nav-search-query" 
          maxlength="99" rel="Search" autocomplete="off"><input type="submit" alt="Search" title="Search" value="Submit Search" name="Search Module - Top Result – Search Button" class="submit track-me">
      </div>
    </form>
  </div>

</div>

		</div>

 		<div class="clearboth"></div>
 	</div>
</div>







	<div class="top-nav-module">
		<div class="fsd-skin sup-ie">
			<ul class="nav-list">
					
					
					<li>
						
									<a href="/smallbusiness/business-financing.go" class="top-menu-item"
									name="overview_topnav" id="overview_topnav">Overview</a>
					</li>
					
					
					<li>
						
								<a href="/smallbusiness/business-financing/working-capital.go" class="top-menu-item"
								name="business_credit_lines_and_loans_topnav" id="business_credit_lines_and_loans_topnav">Business Credit Lines & Loans<span class="ada-hidden"> link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/smallbusiness/business-financing/working-capital.go"  name="overview_topnav" id="overview_topnav"><span class="ada-hidden">Business credit lines and loans </span>Overview </a>
															<a href="/smallbusiness/business-financing/working-capital/business-line-of-credit.go"  name="business_line_of_credit_topnav" id="business_line_of_credit_topnav">Business Line of Credit </a>
															<a href="/smallbusiness/business-financing/working-capital/business-loans.go"  name="secured_business_loans_topnav" id="secured_business_loans_topnav">Secured Business Loans </a>
															<a href="/smallbusiness/business-financing/working-capital/unsecured-business-line-of-credit.go"  name="unsecured_line_of_credit_topnav" id="unsecured_line_of_credit_topnav">Unsecured Line of Credit </a>
									</div>
								
									<div class="hasSub">
														<a class="with-info" href="/smallbusiness/credit-cards/"  name="business_credit_cards_topnav" id="business_credit_cards_topnav">Business Credit Cards 
															
															<span class="sub-nav-item-info">Pay for everyday expenses and get online management tools</span>
														</a>
									</div>
									<span class="ada-hidden"> End of submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
					
					
					<li>
						
									<a href="/smallbusiness/business-financing/commercial-real-estate-loans.go" class="top-menu-item"
									name="commercial_real_estate_topnav" id="commercial_real_estate_topnav">Commercial Real Estate</a>
					</li>
					
					
					<li>
						
								<a href="/smallbusiness/business-financing/equipment-vehicle-loans/overview.go" class="top-menu-item"
								name="equipment_and_vehicles_topnav" id="equipment_and_vehicles_topnav">Equipment & Vehicles<span class="ada-hidden"> link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/smallbusiness/business-financing/equipment-vehicle-loans/overview.go"  name="overview_topnav" id="overview_topnav"><span class="ada-hidden">Equipment and vehicles </span>Overview </a>
															<a href="/smallbusiness/business-financing/equipment-financing/equipment-loans.go"  name="equipment__topnav" id="equipment__topnav">Equipment  </a>
															<a href="/smallbusiness/business-financing/commercial-vehicle-financing/commercial-vehicle-loans.go"  name="vehicles_topnav" id="vehicles_topnav">Vehicles </a>
									</div>
								
									<div class="hasSub">
														<a class="with-info" href="/smallbusiness/business-financing/equipment-financing/loans-leasing-compare.go"  name="should_i_buy_or_lease_topnav" id="should_i_buy_or_lease_topnav">Should I Buy or Lease? 
															
															<span class="sub-nav-item-info">Compare the advantages to see what's right for your business</span>
														</a>
									</div>
									<span class="ada-hidden"> End of submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
					
					
					<li>
						
								<a href="/smallbusiness/business-financing/learning.go" class="top-menu-item selected"
								name="resources_topnav" id="resources_topnav">Resources<span class="ada-hidden"> link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/smallbusiness/business-financing/learning.go"  name="learn_about_financing_topnav" id="learn_about_financing_topnav"><span class="ada-hidden">Resources </span>Learn about Financing </a>
															<a href="/smallbusiness/business-financing/recommendation.go"  name="get_a_recommendation_topnav" id="get_a_recommendation_topnav">Get a Recommendation </a>
															<a href="/smallbusiness/business-financing/learning/faqs-applying-for-financing.go"  name="faqs_topnav" id="faqs_topnav">FAQs </a>
									</div>
								
									<div class="hasSub">
														<a class="with-info" href="/smallbusiness/business-financing/learning/sba-financing.go#url-things-to-know-tab-content"  name="is_sba_financing_right_for_me_topnav" id="is_sba_financing_right_for_me_topnav">Is SBA Financing Right For Me? 
															
															<span class="sub-nav-item-info">5 things you should know about SBA loans</span>
														</a>
									</div>
									<span class="ada-hidden"> End of submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
			</ul>
				<div class="clearboth"></div>
		</div>
	</div>



<div class="page-title-fsd-module h-100" id="skip-to-h1">
	<div class="standard-gray-skin sup-ie">
		<h1 data-font="cnx-regular">What Are Banks Looking For?</h1>
  </div>
</div>

</div>
					<div class="columns">
						<div class="flex-col lt-col" >




<div class="article-module">
  <div class="fsd-skin com-main-well-content table-vzd3-common sup-ie">
  
	
			 <h2 class="h2-fsd-gray article-sbf">Banks want to know how you fit into the 5 C's of credit</h2>
		
	
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		     
		
		
		
		
	
		
	
		
		
		
		
		
		
		
		
		
		
		
		<p class="intro-text sbf-summary">Banks look at these 5 C's to help determine the creditworthiness of the business that's asking for financing. How does your business stack up?</p>		
		
		
		
		
		
		     
		
		
		
		
	
		
	
		
		
		
		
		
		
		
		
		
				<h3 class="p-subheading">Capacity</h3>		
		
		
		
		
		
		
		
		     
		
		
		
		
	
		
	
		
		
		
		
		
		
		
				<p>Does your business have the financial capacity to support debt and expenses? Typically a business needs to have $1.25 of income to support every $1 of debt service. The extra $0.25 provides a cushion for your business to absorb unexpected expenses or a downturn in the economy.</p>		
		
		
		
		
		
		
		
		
		
		     
		
		
		
		
	
		
	
		
		
		
		
		
		
		
		
		
				<h3 class="p-subheading">Capital</h3>		
		
		
		
		
		
		
		
		     
		
		
		
		
	
		
	
		
		
		
		
		
		
		
				<p>Your business owns capital assets such as cash and equipment; is there enough to help support the financing you want? You and others may have invested capital in your business; how much? The answers say a lot about whether the business is one in which the bank wants to invest.</p>		
		
		
		
		
		
		
		
		
		
		     
		
		
		
		
	
		
	
		
		
		
		
		
		
		
		
		
				<h3 class="p-subheading">Collateral</h3>		
		
		
		
		
		
		
		
		     
		
		
		
		
	
		
	
		
		
		
		
		
		
		
				<p>Accounts receivable, inventory, cash, equipment and commercial real estate are all forms of<br />collateral that banks leverage to secure loans. In addition to looking at the value of your collateral, the bank will consider any existing debt you may still owe on that collateral.</p>		
		
		
		
		
		
		
		
		
		
		     
		
		
		
		
	
		
	
		
		
		
		
		
		
		
		
		
				<h3 class="p-subheading">Conditions</h3>		
		
		
		
		
		
		
		
		     
		
		
		
		
	
		
	
		
		
		
		
		
		
		
				<p>The state of the economy, trends in your industry and pending legislation relative to your business are all conditions that are considered by banks. These types of factors&mdash;often out of your control&mdash;may affect your ability to make payments.</p>		
		
		
		
		
		
		
		
		
		
		     
		
		
		
		
	
		
	
		
		
		
		
		
		
		
		
		
				<h3 class="p-subheading">Character</h3>		
		
		
		
		
		
		
		
		     
		
		
		
		
	
		
	
		
		
		
		
		
		
		
				<p>Work experience, experience in your industry and personal credit history are all character traits banks will consider. Your personal integrity and good standing&mdash;and the integrity and standing of those closely tied to the success of the business&mdash;are critically important.</p>		
		
		
		
		
		
		
		
		
		
		     
		
		
		
		
	
		
	
		
		
		
		
		
		
		
		
		
				<h3 class="p-subheading">Plus one more</h3>		
		
		
		
		
		
		
		
		     
		
		
		
		
	
		
	
		
		
		
		
		
		
		
				<p>In addition to these 5 C's, there&rsquo;s one more C that can make a world of difference: communication. Your willingness to communicate openly with your banker and your other advisors about the opportunities and challenges your business faces is key to a productive financial partnership.</p>		
		
		
		
		
		
		
		
		
		
		     
		
		
		
		
			<div class="dotted-btm-return">
			 	<a href="/smallbusiness/business-financing/learning.go" name="Return_to_Learning_Center_overview">Return to Learning Center Overview</a>
			</div>	
   </div>
</div>
		
</div>
						<div class="flex-col rt-col" >

<div class="print-module-browser-dialog-skin" style=""> 
	<a href="javascript:window.print();" name="print">PRINT<span class="ada-hidden"> this page</span></a>
</div>



	
<div class="cta-module target-sidewell-sbf-wide location-top ">
	<div class="cta focus-call "> <!-- focus-call|focus-find|focus-chat|focus-email|focus-qualify|focus-mlo|focus-all|focus-one -->
		<div class="intro">
			<h2>Contact us</h2>
		</div>
			<ul class="options ">
					<li class="call">
						<h3><a href="javascript:void(0);" name="call-small-business-speacialist"> <span class="ada-hidden ada-closed">Get details on how to</span> <span class="ada-hidden ada-open" >Hide details on how to</span> Call <span class="ada-hidden">a smallbusiness specialist</span> </a></h3>
						<div class="details ">
									<p class="large">866.543.2808</p>
								<p class="small"></p>
							<p class="small">You can apply by calling or<br /> making an appointment<br /> Mon-Fri 8 a.m. - 10 p.m. ET</p>	
						</div>
					</li>
				<li class="hide"></li>
						<li class="chat first hide">
							<h3>
								<a href="#" name="chat-small-business-speacialist"> 
									<span class="ada-hidden ada-closed">Show information for </span>
									<span class="ada-hidden ada-open">Hide information for </span>
									Chat online
								</a>
							</h3>
							<div class="details ">
								<p>You can apply by calling or making an appointment</p>
									<div id="lpButtonDivChat">								
									</div>
							</div>
						</li>
						<li class="qualify after ">
							<h3>
								<a href="#" name="schedule-callback-small-business-specialist">
									<span class="ada-hidden ada-closed">Show information for </span> 
									<span class="ada-hidden ada-open">Hide information for </span> 
									Let's get started
								</a>
							</h3>
							<div class="details ">
								<strong><a href="https://secure.bankofamerica.com/mycommunications/public/appointments/getTopics.go?marketingCode=SBFINLEARN_ECBBA_A2000_A2400&amp;comment=Please%20share%20the%20following:%20Months%20in%20Business,%20Gross%20revenue,%20Use%20of%20financing%20proceeds">Schedule an appointment</a></strong><br /> to meet with a small<br />business specialist who can<br /> answer your questions and <br />start your application by<br /> phone or in-person
							</div>
						</li>
			</ul>
	</div>
</div>

<div class="side-well-module"> </div>


<div class="side-well-module">
   <div class="content-list-skin sup-ie" style="">
      <div class="sw-outer">
         <div class="sw-inner">
            <div class="sw-corner sw-tleft"></div>
            <div class="sw-corner sw-tright"></div>
            <div class="sw-main sw-std-pad">
            
            	<h2>Join the online community
            	</h2>
			            	<ul>
			            		<li>
									The Bank of America Small Business Online Community allows you to exchange ideas and information and benefit from the experience of others.
			               		</li>
			            		<li>
									<a name="small_business_online_community" href="https://smallbusinessonlinecommunity.bankofamerica.com/welcome" target="_self">Explore the Small Business Online Community</a>
			               		</li>
			               	</ul>
             
            </div>
            <div class="sw-bottom"></div>
         </div>
         <div class="sw-corner sw-bleft"></div>
         <div class="sw-corner sw-bright"></div>
      </div>
   </div>
</div>

<script type="text/javascript">

</script>







<div class="state-selector-aps-sb-module">
<div class="modal-skin">
		<div class="state-select-aps-sb-modal hide" id="state-select-modal">
         <div class="modal-content">
            <h3>Select Your State</h3>
                <p>Please tell us where you bank so we can give you accurate rate and fee information for your location.</p>
                <form method="post" action="" id="submitState">
                    <fieldset>
                        <legend>State Selection Form</legend>
                        <input type="hidden" id="requestedUrl" value="" />
                        <label for="stateList">Current State</label>
<select name="stateListName" id="stateList" class="select-box" required="true">
    <option value=" ">Select state</option>
    <option value="AL">Alabama</option>
    <option value="AK">Alaska</option>
    <option value="AZ">Arizona</option>
    <option value="AR">Arkansas</option>
    <option value="CA">California</option>
    <option value="CO">Colorado</option>
    <option value="CT">Connecticut</option>
    <option value="DE">Delaware</option>
    <option value="DC">District of Columbia</option>
    <option value="FL">Florida</option>
    <option value="GA">Georgia</option>
    <option value="HI">Hawaii</option>
    <option value="ID">Idaho</option>
    <option value="IL">Illinois</option>
    <option value="IN">Indiana</option>
    <option value="IA">Iowa</option>
    <option value="KS">Kansas</option>
    <option value="KY">Kentucky</option>
    <option value="LA">Louisiana</option>
    <option value="ME">Maine</option>
    <option value="MD">Maryland</option>
    <option value="MA">Massachusetts</option>
    <option value="MI">Michigan</option>
    <option value="MN">Minnesota</option>
    <option value="MS">Mississippi</option>
    <option value="MO">Missouri</option>
    <option value="MT">Montana</option>
    <option value="NE">Nebraska</option>
    <option value="NV">Nevada</option>
    <option value="NH">New Hampshire</option>
    <option value="NJ">New Jersey</option>
    <option value="NM">New Mexico</option>
    <option value="NY">New York</option>
    <option value="NC">North Carolina</option>
    <option value="ND">North Dakota</option>
    <option value="OH">Ohio</option>
    <option value="OK">Oklahoma</option>
    <option value="OR">Oregon</option>
    <option value="PA">Pennsylvania</option>
    <option value="RI">Rhode Island</option>
    <option value="SC">South Carolina</option>
    <option value="SD">South Dakota</option>
    <option value="TN">Tennessee</option>
    <option value="TX">Texas</option>
    <option value="UT">Utah</option>
    <option value="VT">Vermont</option>
    <option value="VA">Virginia</option>
    <option value="WA">Washington</option>
    <option value="WV">West Virginia</option>
    <option value="WI">Wisconsin</option>
    <option value="WY">Wyoming</option>


</select>

                        <div class="button-cont">
	                        <a id="state_select_submit" class="btn-bofa btn-bofa-small state-select-modal-go-button" href="javascript:void(0);" role="button">Go</a>
	                    </div>
                    </fieldset>
                </form>
		 </div>
		</div>
</div>
</div>

</div>
						<div class="clearboth"></div>
					</div>
					<div class="footer">
						<div class="footer-top">&nbsp;</div>
						<div class="footer-inner">
<div class="disclaimers-module">
	<div class="fsd-skin sup-ie">
			<p><br />Some applications may require further consideration and additional information may be requested.<br /> Credit is subject to approval. Normal credit standards apply.<br /> Visa is a registered trademark of Visa International Service Association, and is used by the issuer pursuant to license from VISA USA, Inc.<br /> Bank of America and the Bank of America logo are registered trademarks of Bank of America corporation.</p>
	</div>
</div>





<div class="power-footer-module">

  <div class="four-col-all-links-skin sup-ie">
    <div class="breadcrumbs">
						<a class="bold-bc" href="/" name="bank_of_america_5_cs_of_credit_breadcrumbs">Bank of America</a>
						<a href="/smallbusiness/" name="small_business_5_cs_of_credit_breadcrumbs" >Small Business</a>
		
					<a href="/smallbusiness/business-financing/learning.go" name="resources_5_cs_of_credit_breadcrumbs">Resources</a>
		      	 <span>What Are Banks Looking For?</span>
		    
      <div class="clearboth"></div>
    </div>
    <div class="pf-columns">
      
			<div class="pf-col" style="margin-right:50px;">
				<ul>
					<li>	
					<a href="/smallbusiness/business-financing/working-capital.go" class="bold" name="operating_cash_5_cs_of_credit_power_footer" >Operating Cash</a> 
					</li>
						<li> <a href="/smallbusiness/business-financing/working-capital/business-line-of-credit.go" name="business_line_of_credit_5_cs_of_credit_power_footer">Business Line of Credit</a> </li>
						<li> <a href="/smallbusiness/business-financing/working-capital/business-loans.go" name="business_loan_5_cs_of_credit_power_footer">Business Loans</a> </li>
						<li> <a href="/smallbusiness/credit-cards/" name="business_credit_cards_5_cs_of_credit_power_footer">Business Credit Cards</a> </li>
				</ul>
		      </div>
			<div class="pf-col" style="margin-right:50px;">
				<ul>
					<li>	
					<a href="/smallbusiness/business-financing/commercial-real-estate-loans.go" class="bold" name="commercial_real_estate_5_cs_of_credit_power_footer" >Commercial Real Estate</a> 
					</li>
						<li> <a href="/smallbusiness/business-financing/commercial-real-estate-loans.go#tabs-3" name="buy_or_rent_5_cs_of_credit_power_footer">Buy or rent?</a> </li>
				</ul>
		      </div>
			<div class="pf-col" style="margin-right:50px;">
				<ul>
					<li>	
					<a href="/smallbusiness/business-financing/equipment-vehicle-loans/overview.go" class="bold" name="equipment__vehicles_5_cs_of_credit_power_footer" >Equipment & Vehicles</a> 
					</li>
						<li> <a href="/smallbusiness/business-financing/equipment-financing/equipment-loans.go" name="equipment_financing_5_cs_of_credit_power_footer">Equipment</a> </li>
						<li> <a href="/smallbusiness/business-financing/commercial-vehicle-financing/commercial-vehicle-loans.go" name="vehicles_5_cs_of_credit_power_footer">Vehicles</a> </li>
						<li> <a href="/smallbusiness/business-financing/equipment-financing/loans-leasing-compare.go" name="should_i_buy_or_lease_5_cs_of_credit_power_footer">Should I Buy or Lease?</a> </li>
				</ul>
		      </div>
			<div class="pf-col" style="margin-right:50px;">
				<ul>
					<li>	
					<a href="/smallbusiness/business-financing/learning.go" class="bold" name="resources_5_cs_of_credit_power_footer" >Resources</a> 
					</li>
						<li> <a href="/smallbusiness/business-financing/recommendation.go" name="get_recommendation_5_cs_of_credit_power_footer">Get a Recommendation</a> </li>
						<li> <a href="/smallbusiness/business-financing/learning/faqs-applying-for-financing.go" name="faqs_5_cs_of_credit_power_footer">FAQs</a> </li>
						<li> <a href="/smallbusiness/business-financing/learning/sba-financing.go" name="is_sba_financing_right_for_me_5_cs_of_credit_power_footer">Is SBA Financing Right For Me?</a> </li>
				</ul>
		      </div>
      
      <div class="clearboth"></div>
    </div>
  </div>
</div>




 



		<div class="global-footer-module">
			<div class="fsd-skin">

				<div class="footer-bottom-left" style="float:left;max-width:66%;">
	    			<div class="gf-links">	          	
						
					
									
									<a  target="_self" href="/smallbusiness" 
									    name="global_footer_home">Home
									</a>
									
						
					
									
									<a  target="_self" href="/privacy/overview.go" 
									    name="global_footer_privacy_security">Privacy & Security
									</a>
									
						
					
									
									<a  target="_self" href="http://careers.bankofamerica.com/careershome.aspx" 
									    name="global_footer_careers">Careers
									</a>
									
						
					
									
									<a  target="_self" href="/sitemap/sitemap/smallbusiness.go" 
									    name="global_footer_site_map">Site Map
									</a>
									
						
					
									<a href="javascript:void(0);" class="gf-last-link boa-dialog boa-com-info-layer-link" name="global_footer_ad_practices_lnk" rel="global_footer_ad_practices">Advertising Practices</a>
								<div id="global_footer_ad_practices" class="hide">
									<h3>Advertising Practices</h3>
										<p>We strive to provide you with information about products and services you might find interesting and useful. Relationship-based ads and online behavioral advertising help us do that.</p>
<p>Here's how it works: We gather information about your online activities, such as the searches you conduct on our Sites and the pages you visit. This information may be used to deliver advertising on our Sites and offline (for example, by phone, email and direct mail) that's customized to meet specific interests you may have.</p>
<p>If you prefer that we do not use this information, you may <a onclick="$('.ui-dialog').remove();" name="WebsiteAdPractices_OptOut" href="/privacy/online-privacy-notice.go#advertising-on-our-sites" target="_blank">opt out of online behavioral advertising</a>. If you opt out, though, you may still receive generic advertising. In addition, financial advisors/Client Managers may continue to use information collected online to provide product and service information in accordance with account agreements.</p>
<p>Also, if you opt out of online behavioral advertising, you may still see ads when you sign in to your account, for example through Online Banking or MyMerrill. These ads are based on your specific account relationships with us.</p>
<p>To learn more about relationship-based ads, online behavioral advertising and our privacy practices, please review the <a onclick="$('.ui-dialog').remove();" name="WebsiteAdPractices_PrivacyNotice" href="/privacy/online-privacy-notice.go" target="_blank">Bank of America Online Privacy Notice</a> and our <a onclick="$('.ui-dialog').remove();" name="Online-privacy-faqs" href="/privacy/faq/online-privacy-faq.go" target="_blank">Online Privacy FAQs</a>.</p>
								</div>
						<div class="clearboth"></div>
	    			</div>
	      			<p>Bank of America, N.A. Member FDIC. <a title="Equal Housing Lender information." onclick="window.open('/help/equalhousing_popup.go','newwin','width=640,height=371,scrollbars=yes,resizable=yes,left=35,top=161'); return false;" name="Equal_Housing_Lender" href="/help/equalhousing_popup.go" target="_blank">Equal Housing Lender<img src="/content/images/ContextualSiteGraphics/Logos/en_US/gfoot-home-icon.png" alt="" width="14" height="9" /></a> <br />&copy;&nbsp;2017 Bank of America Corporation. All rights reserved.</p>
         		</div>
         		<div class="footer-social-container" style="float:right;max-width:30%;padding-left:50px;padding-top:19px;">




<div class="boa-social-loader" data-loaded="false" data-platform="borneo"  data-options=''></div>

         		</div>
         		<div class="clearboth"></div>
  			</div>
		</div>




 
<script language="javascript" src="/pa/global-assets/external/coremetrics/hp/eluminate.js"></script>
<script language="javascript" src="/pa/global-assets/external/coremetrics/hp/cmdatatagutils.js"></script>

	<script type="text/javascript">		
		function cmSetDD() {
		      var testString = window.location.href;
		      if (testString.toLowerCase().indexOf('.bankofamerica.com') > -1){
			    testString = testString.toLowerCase(); 
			    var tempArr = testString.split('.bankofamerica.com');
			    var tempStr = tempArr[0];
				  if (tempStr.indexOf('\/\/') > -1) {
					tempArr = tempStr.split('\/\/');tempStr = tempArr[1];
					if (tempStr.indexOf('.') > -1) {
					      tempArr = tempStr.split('.');tempStr = tempArr[0];var tempStrPt2 = tempArr[1];}
					      if (tempStr.indexOf('www') > -1) {
						    if (tempStr.indexOf('-') > -1) {cmSetStaging()}
						    else if (tempStrPt2 != null) {
							  if (tempStrPt2.indexOf('ecnp') > -1) {cmSetStaging()} 
						    }
						    else {cmSetProduction()} 
					      }
					      else if (tempStr.indexOf('-') > -1) {
						    if (tempStr.indexOf('sitekey') > -1){
							  if (tempStr == 'sitekey') {cmSetProduction()}
							  else {cmSetStaging()}  
						    } 
						    else if (testString.toLowerCase().indexOf('safe-dev') > -1 || testString.toLowerCase().indexOf('safe-cit') > -1 || testString.toLowerCase().indexOf('safe-sit') > -1) {cmSetStaging()}
						    else if (tempStrPt2 != null) {
							  if (tempStrPt2.indexOf('ecnp') > -1) {cmSetStaging()} 
						    }
						    else {cmSetStaging()}
					      }     
					      else if (tempStrPt2 != null) {
							  if (tempStrPt2.indexOf('ecnp') > -1) {cmSetStaging()} 
						    }
					      else {cmSetProduction()} 
				  }       
		      }  

		}

		if (typeof cmSetStaging == 'function') {cmSetDD()}

		cmCreatePageviewTag('smbus:Content:SB_Financing:Learning;5-cs-of-credit', null, null, 'smbus:Content:SB_Financing:Learning', false, false, null, false, false, null, null, null, null, null, null, null, null, null, null, null, null);

		
		var coremetrics = new Object();
		coremetrics.CMPageId 		= "smbus:Content:SB_Financing:Learning;5-cs-of-credit";		
		coremetrics.CMAppName		= null;
		coremetrics.CMAppStepNumber	= null;	
		coremetrics.CMAppStepName	= null;
		coremetrics.CMErrorCodes	= "MNGECARDMODERR001";
		coremetrics.CMCategoryId 	= "smbus:Content:SB_Financing:Learning";		
	</script>
</div>
					</div>
				</div>
			</div>
		</div>
	</body>	
</html>

