
 

				<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
				<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
				<head>


<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta http-equiv="content-type" content="text/html;charset=utf-8">





<title>Health Care Practice Loans Physicians</title>

<meta name="Description" CONTENT="When you need new equipment for your practice, Bank of America can help you find the financing that's right for you">
<meta name="Keywords" CONTENT="practice, Bank of America">

		<link rel="canonical" href="https://www.bankofamerica.com/smallbusiness/practice-loans/health-care-loans/medical-loans.go"/>

<link rel="shortcut icon" href="/pa/global-assets/1.0/graphic/favicon.ico" type="image/ico" />

			<link rel="stylesheet" type="text/css" href="/pa/components/bundles/gzip-compressed/xengine/APS-small-business/2017.03.0/style/olbs-aps-sb-jawr.css" media="all" />
			<script src="/pa/components/bundles/gzip-compressed/xengine/APS-small-business/2017.03.0/script/olbs-aps-sb-jawr.js" type="text/javascript"></script>
				<script type="text/javascript">
					$(window).load(function(){asyncPrintCssInclude('https://www.bankofamerica.com/pa/components/bundles/gzip-compressed/xengine/APS-small-business/2017.03.0/style/olbs-aps-sb-jawr-print.css');});
				</script>
<script type="text/javascript">
(function() {
	if (typeof mboxUpdate == "function") {
		var windowURL = window.location.href
	    windowURL = windowURL.slice( windowURL.indexOf('.')+1);
		windowURL = windowURL.split( '?' )[0];
		windowURL = windowURL.toLowerCase();
		//alert(windowURL);
		if (
		    //If no mboxes on page, mbox count will be < 1
		    (mboxFactoryDefault.getMboxes().length() < 1) &&

			//Also check for high-volume pages that do not need global logging
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go") &&
			(windowURL != "bankofamerica.com/myaccounts/signin/signin.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/entry/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signonscreen.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatechallengeanswer.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatePassword.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/mobile/banking.go")&&
			(windowURL != "bankofamerica.com/content/preload/olb-myaccount-preload-jawr-module.htm")
			)
		{

			var mboxDiv = document.createElement("div");
			mboxDiv.id = "adobe_touch_clarity_replacement";
			mboxDiv.style.display = "none";
			if (document.body && document.body.firstChild) document.body.insertBefore(mboxDiv,document.body.firstChild);
			mboxDefine(mboxDiv.id,'bac_global_bottom');
			mboxUpdate('bac_global_bottom');
		}
	}
})();
</script>

		<script src="/pa/components/bundles/gzip-compressed/xengine/Global/1.0/script/tealeafbundle.js" type="text/javascript"></script>
			<script>
				var boaPageDataJS = {};
					boaPageDataJS.isLLE = "false";
			</script>
				<style>body{display:none;}</style>
	</head>		

	<body class="fsd-layout-body">	

				<script type="text/javascript">if(self == top){var theBody=document.getElementsByTagName("body")[0];theBody.style.display="block";}else{top.location=self.location;}</script>
				<noscript><style>body{display:block;}</style></noscript>
					<a class='ada-hidden ada-visible-focus' href='#skip-to-h1' id='ada-skip-link'>Skip to main content</a>
		<div class="fsd-layout fsd-2c-700lt-layout">
			<div class="fsd-border">
				<div class="center-content">
					<div class="header">
		  



<script language="javascript" src="/pa/components/modules/tag-manager-module/1.1/script/tag-manager-module-borneo-global-skin.js"></script>
<script>

(function() {
  var fireCallback = function( cb ) {
    if ( typeof cb === "function" ) cb();
  };
  
  function ddoPopulateBase( callback ) {
    try {
		  var DDO = window.digitalData,
		  	bactm_mergeDDO = function( newDDO, priorDDO ) {
		  		if( typeof priorDDO === "undefined" ) {
				  	priorDDO = digitalData || {};
				  }

			    for (var l in newDDO) {
			        if (typeof priorDDO[l] === "undefined") {
			            priorDDO[l] = newDDO[l];
			        }
			        if (newDDO[l] !== null) {
			            if (typeof newDDO[l] === "object") {
			                bactm_mergeDDO(newDDO[l], priorDDO[l]);
			            } else {
			                priorDDO[l] = bactm_validateValue( newDDO[l] ) ? newDDO[l] : priorDDO[l];
			            }
			        }
			    }

			    return priorDDO;
				},
				bactm_olb3rdPartyId = "null";

			if (typeof DDO === "undefined") {
				var simpleDDO = { page: { pageInfo:[{ pageID: null }], attributes: {}, category: { primaryCategory: null }}};

				DDO = (typeof digitalData === "object") ? digitalData : simpleDDO; 
			}

				DDO = bactm_mergeDDO( {   "pageInstanceID": "notprod",   "load_coremetrics": false,   "load_opinionlabs": false,   "load_touchcommerce": true,   "load_audiencemanager": true,   "page": {     "pageInfo": [       {         "pageID": null,         "destinationURL": null,         "referringURL": null,         "issueDate": null,         "language": null,         "segmentValue": null,         "appName": null,         "appStepNumber": null,         "appStepName": null,         "attr": "-_--_--_--_--_--_--_--_--_--_--_--_--_--_-"       }     ],     "category": {       "primaryCategory": null,       "addlCategory": null,       "pageType": null     },     "attributes": {       "searchString": null,       "searchResults": null,       "olbSessionID": null,       "subCampaignCode": null,       "DARTUrl": null,       "stateCookie": null,       "SASIEnabled": false,       "needOLBcookie": false,       "standardDART": [],       "standardDARTes": [],       "clickDART": [],       "clickDARTes": [],       "gaId": [],       "chat": {         "site_id": 36533212,         "target": {           "lpButtonDiv-Practice-Solutions": "SB-Fixed13"         },         "account_type": "smallbusiness",         "customer_lob": "sbob"       }     }   },   "user": {     "segment": null,     "online_id": null,     "preferred_rewards_tier": null,     "olb3rdpartyid": null   },   "version": "BAC_0.12" }, DDO );

			DDO.page.pageInfo[0].pageID = "smbus:Content:practice_loans:health_care;medical-loans";
			DDO.page.category.primaryCategory  = "smbus:Content:practice_loans:health_care";
			DDO.page.pageInfo[0].language = "en-US";
			DDO.page.attributes.olbSessionID = "null";
			DDO.page.attributes.SASIEnabled =  "false";
			if (typeof DDO.user != "undefined" && typeof DDO.user.olb3rdpartyid != "undefined") {
				DDO.user.olb3rdpartyid = bactm_olb3rdPartyId;
			}

			window.utag_data = {};
			window.bactm_envSelector = bactm_setTMLib();
			window.digitalData = DDO;

      return fireCallback( callback );

    } catch(e) { }
  }
	if( window.boa && window.boa.digitalData ) {
    window.boa.digitalData.register( ddoPopulateBase );
	}
	else {
	  // Handle scenario where the header isn't available (and thus the default digitalData object and utag loader are missing).
	  //
		var writeScript = function(a,b,c,d){
			a='//tags.tiqcdn.com/utag/bofa/main/' + bactm_envSelector + '/utag.js';
			b=document;
			c='script';
			d=b.createElement(c);
			d.src=a;
			d.type='text/java'+c;
			d.async=true;
			a=b.getElementsByTagName(c)[0];
			a.parentNode.insertBefore(d,a);
		};

		ddoPopulateBase( writeScript );
	}
})();			
</script>



	
	
		
			<noscript>
				<div class="fauxdal-overlay"></div>
				<div class="fauxdal-module">
					<div class="js-disabled-skin">
						<div class="fauxdal-top"></div>
						<div class="fauxdal-bottom">
							<div class="fsd-fauxdal-content">
									<div class="fsd-fauxdal-title">
										Please Use JavaScript
									</div>
										<p>You need a web browser that supports JavaScript to use our site. Without it, some pages won&rsquo;t work as designed. To make sure JavaScript is turned on, please adjust your browser settings.</p>
<p><a name="Browser_Help_And_Tips" href="/onlinebanking/online-banking-security-faqs.go" target="_blank">Browser Help and Tips</a></p>
							</div>        
							<div class="fsd-fauxdal-close"> 
								<a class="btn-bofa btn-bofa-small" name="close_button_js_disabled_modal" href=?js=y>Close</a>
							</div>
							<div class="clearboth"></div>
						</div>
					</div>
				</div>
			</noscript>



 


<div class="header-module">
	<div class="text-w-logo-skin">
		<div class="header-left">
	  
			<div itemscope itemtype="http://schema.org/Corporation" class="bofa-logo">
				<a itemprop="url" name="anc-practice-loans" title="Bank of America logo" href="/smallbusiness/index.jsp">
					<img itemprop="logo" height="25" width="201" 
					     alt="Bank of America logo" src="/content/images/ContextualSiteGraphics/Logos/en_US/bofa-logo.gif"/>
				</a>
			</div>
				<div class="product" data-font="cnx-regular">Practice Loans</div>
			
			<div class="clearboth"></div>

		</div>
		
		<div class="header-right">
			<ul class="header-links">
			
				
					
				
							<li class="sign-in">
								<a href="/sitemap/hub/signin.go" name="sign-in-header" 
								   onClick="return dartFireOnClickSpecial('1359940','gcibl189','pracs463',this.href);" target="_self">Sign In</a> 
							</li>					
					
				
							<li>		<a					href="/smallbusiness/" target="_self"
		name="home-header">Home</a> 
</li>
					
				
							<li>		<a					href="https://locators.bankofamerica.com" target="_self"
		name="locations-header">Locations</a> 
</li>
					
				
							<li>		<a					href="/contactus/contactus.go?topicId=small_business_banking" target="_self"
		name="contact-us-header">Contact Us</a> 
</li>
					
				
							<li class="last-link">	
		<a					href="/smallbusiness/practice-loans/resources/FAQs.go" target="_self"
		name="help-header">Help</a> 
							</li>
			</ul>
			
			<div class="clearboth"></div>

			<!-- include search-dotcom-util -->



<div class="header-search nlh">
  
  <div class="nav-search">
    <form class="search-form" action="https://secure.bankofamerica.com/myaccounts/public/search-results/unAuthenticatedSearch.go" data-js="/pa/components/utilities/search-util/1.0/script/nav-search.min.js" data-css="/pa/components/utilities/search-util/1.0/style/nav-search.css" data-text-unavailable="Search Currently Unavailable">
      <div class="search-input-container cf" data-icon="search">
        <label for="nav-search-query" class="ada-hidden">Search Term</label>
        <input type="text" placeholder="How can we help you?" name="query" class="search-query" id="nav-search-query" 
          maxlength="99" rel="Search" autocomplete="off"><input type="submit" alt="Search" title="Search" value="Submit Search" name="Search Module - Top Result – Search Button" class="submit track-me">
      </div>
    </form>
  </div>

</div>

		</div>

 		<div class="clearboth"></div>
 	</div>
</div>







	<div class="top-nav-module">
		<div class="fsd-skin sup-ie">
			<ul class="nav-list">
					
					
					<li>
						
									<a href="/smallbusiness/practice-loans/health-care-loans/overview.go" class="top-menu-item"
									name="health_care_practice_loans_topnav" id="health_care_practice_loans_topnav">Health Care Practice Loans</a>
					</li>
					
					
					<li>
						
									<a href="/smallbusiness/practice-loans/health-care-loans/dentist-loans.go" class="top-menu-item"
									name="dentists_topnav" id="dentists_topnav">Dentists</a>
					</li>
					
					
					<li>
						
									<a href="/smallbusiness/practice-loans/health-care-loans/veterinary-loans.go" class="top-menu-item"
									name="veterinarians_topnav" id="veterinarians_topnav">Veterinarians</a>
					</li>
					
					
					<li>
						
									<a href="/smallbusiness/practice-loans/health-care-loans/medical-loans.go" class="top-menu-item selected"
									name="physicians__optometrists_topnav" id="physicians__optometrists_topnav">Physicians & Optometrists</a>
					</li>
					
					
					<li>
						
								<a href="/smallbusiness/practice-loans/resources/overview.go" class="top-menu-item"
								name="resources_topnav" id="resources_topnav">Resources<span class="ada-hidden"> &nbsp;link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/smallbusiness/practice-loans/resources/overview.go"  name="resources_overview_topnav" id="resources_overview_topnav">Resources Overview </a>
															<a href="/smallbusiness/practice-loans/resources/FAQs.go"  name="faqs_topnav" id="faqs_topnav">FAQs </a>
															<a href="/smallbusiness/practice-loans/resources/events-dentists.go"  name="events_topnav" id="events_topnav">Events </a>
															<a href="/smallbusiness/practice-loans/resources/endorsements.go"  name="endorsements_topnav" id="endorsements_topnav">Endorsements </a>
									</div>
								
									<div class="hasSub">
														<a class="with-info" href="https://host.visualcalc.com/practicesolutions/ "  name="equipment_loan_calculator_topnav" id="equipment_loan_calculator_topnav">Equipment Loan Calculator 
															
															<span class="sub-nav-item-info">Estimate monthly payments, ROI and tax benefits</span>
														</a>
														<a class="with-info" href="https://smallbusinessonlinecommunity.bankofamerica.com/"  name="online_community_topnav" id="online_community_topnav">Online Community 
															
															<span class="sub-nav-item-info">Access small business news, articles & more</span>
														</a>
									</div>
									<span class="ada-hidden"> End of Submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
			</ul>
				<div class="clearboth"></div>
		</div>
	</div>



<div class="page-title-fsd-module h-100" id="skip-to-h1">
	<div class="standard-gray-skin sup-ie">
		<h1 data-font="cnx-regular">Physician Practice Financing</h1>
  </div>
</div>


	<div class="banner-aps-sb-module">
		<div class="left-content-skin sup-ie" style="background-color:#d3ebfc;background-image:url('/content/images/ContextualSiteGraphics/Instructional/en_US/SmallBusiness/physicians_PracticeSolutions.jpg')">
			<div class="banner-content blue-style" style="background-image:url('/content/images/ContextualSiteGraphics/Instructional/en_US/SmallBusiness/physicians_PracticeSolutions.jpg')">
				<h2><span style="color:#d4001a">Practice loans for medical professionals</span></h2>				
				<p>Flexible financing and business expertise to realize your dreams</p>
					<div class="call-to-action">
						<span class="cta-html-dest"></span>
					</div>
				<p>Call to speak with a medical practice specialist</p>
				<div class="clearboth"><!--  --></div>
			</div>
		</div>	 
	</div>

<div class="print-module-browser-dialog-skin" style=""> 
	<a href="javascript:window.print();" name="print">PRINT<span class="ada-hidden"> this page</span></a>
</div></div>
					<div class="columns">
						<div class="flex-col lt-col" >

	
<div class="generic-content-module tabs-main-content">
	<div class="overview-vzd3-skin com-main-well-content" style="">
				<h3>Medical practice financing designed to help you succeed</h3>
			
			


			
			
						<p>In addition to a full range of medical practice financing options, for a wide variety of medical specialties, Bank of America offers the critical knowledge you need to establish and develop your practice, from <a class="boa-dialog boa-com-info-layer-link dotted force-visited" rel="glossary-popup-1" name="demographic_site_analysis" href="javaScript:void;">demographic site analysis</a> of your practice location to the <a name="practice_heartbeat" href="/smallbusiness/practice-loans/resources/practice-heartbeat.go" target="_self">Practice Heartbeat<sup>&reg;</sup></a> program, which helps you develop vital practice management skills.</p>
			


			
			
						<p>Bank of America has earned more <a name="see_endorsements" href="/smallbusiness/practice-loans/resources/endorsements.go" target="_self">endorsements</a> from national and state medical and dental associations than any other financial institution.</p>
			


			
			
						<p>If you're unsure whether your specific practice qualifies you for financing, <a class="boa-dialog boa-com-info-layer-link dotted force-visited" rel="glossary-popup-2" name="medical_specialties" href="javaScript:void;">view our list of qualified medical specialties</a>.</p>
			


	</div>
</div>



	
<div class="generic-content-module tabs-main-content">
	<div class="overview-vzd3-skin com-main-well-content" style="">
			
			
						<p><strong><br />Limited time offers:</strong></p>
<ul>
<li><span>3% interest rate for the first 3 years on a debt consolidation loan</span><span><a href="#Footnote 1" name="DentistFootnote"><span class="ada-hidden">Footnote</span><sup>1</sup></a></span></li>
<li>1.89% for the first year on an acquisition loan. Plus, enjoy a fixed payment and a low rate at the same time<a href="#Footnote 2" name="fn2"><span class="ada-hidden">Footnote</span><sup>2</sup></a></li>
</ul>
			


	</div>
</div>

						
<div style="				margin:38px 0 38px;
" class="spacer-module-gray-dotted-skin boa-brd-top"></div>








	<div class="main-well-content-module">
	   <div class="show-hide-alt-skin com-main-well-content table-vzd3-common table-vzd3-com table-vzd-alt-row sup-ie">	   	
	      		<div class="show-hide-all">
	      			<a href="javascript:void(0);" class="sh-show-all" name="show-all">Show all<span class="ada-hidden"> hidden sections</span></a>
	      			&nbsp;|&nbsp;
		 		<a href="javascript:void(0);" class="sh-hide-all" name="hide-all">Hide all<span class="ada-hidden"> expanded sections</span></a>
	      		</div>
		
			<ul class="sh-main">
				<li>
				<span class="sh-link closed"><a href="javascript:void(0);" name="New_practice_start-up"><span class="ada-hidden ada-action">Show</span> <span class="sh-link-text">New practice start-up</span></a></span>
				<div class="sh-content-area hide">
					<p><strong>Get your new practice started off right</strong></p>
<p>When you're starting out, you may need more than just financing&mdash;you might also appreciate guidance on how to build a successful practice. We can help you locate reliable, reasonably priced sources for everything from equipment to cabinetry to software.</p>
<p>We'll help you with our unique&mdash;and complimentary&mdash;<a href="/smallbusiness/practice-loans/resources/practice-heartbeat.go" name="new_practice_startup_practice_hearbeat" target="_self">Practice Heartbeat<sup>&reg;</sup></a> program,<a href="#footnote3" name="new_practice_startup_footnote_1"><span class="ada-hidden">Footnote </span><sup>3</sup></a> a customized plan that can help you develop the management skills so crucial to the growth of your business. You'll work with one of our personal Practice Specialists who will prepare you for the ups and downs that lie ahead&mdash;and when it comes to financing, we'll work with you to make it as easy as possible.<a href="#footnote4" name="new_practice_startup_footnote_2"><span class="ada-hidden">Footnote </span><sup>4</sup></a></p>
<ul>
<li>Up to 100% financing for everything from architectural and design fees to renovations and construction, equipment, cabinetry and other project expenses&mdash;including tenant improvements</li>
<li>Working capital to help you get started</li>
<li>Competitive terms to keep payments low and affordable</li>
<li>Rate lock program that will protect you against potential interest rate changes through project build-out phase</li>
<li>A dedicated project manager resource to help get things done on time and within budget</li>
<li>Low administration fees&mdash;which save hundreds of dollars over more time-consuming loans through the Small Business Administration</li>
<li><a href="javascript:void(0);" class="boa-dialog boa-com-info-layer-link dotted force-visited" rel="glossary-popup-1" name="new_practice_startup_demographic_site_analysis">Demographic Site Analysis</a> to help you select the ideal location and attract the patient base you want<a href="#footnote5" name="new_practice_startup_footnote_3"><span class="ada-hidden">Footnote </span><sup>5</sup></a></li>
</ul>                         
					</div>
				</li>
		
		
				<li>
				<span class="sh-link closed"><a href="javascript:void(0);" name="Practice_sales_and_purchases"><span class="ada-hidden ada-action">Show</span> <span class="sh-link-text">Practice sales and purchases</span></a></span>
				<div class="sh-content-area hide">
					<p><strong>Purchase your own practice&mdash;with financing up to $5 million</strong></p>
<p>Purchasing your own practice is something you may do just once in your lifetime. That's why you need to work with someone who can make it as easy as possible from start to finish.</p>
<p>We offer resources you can use to analyze your planned purchase&mdash;including location, patient base, fee structure and more. You can also take advantage of our complimentary <a name="practice_sales_and_purchases_practice_hearbeat" href="/smallbusiness/practice-loans/resources/practice-heartbeat.go" target="_self">Practice Heartbeat<sup>&reg;</sup></a> program<a name="practice_sales_and_purchases_footnote_1" href="#footnote3"><span class="ada-hidden">Footnote </span><sup>3</sup></a>&mdash;a customized plan designed to help you develop the management skills so crucial to the growth of your business. Together we'll review a variety of financial options for helping you meet your goals.<a name="practice_sales_and_purchases_footnote_2" href="#footnote4"><span class="ada-hidden">Footnote </span><sup>4</sup></a> Our resources include:</p>
<ul>
<li>Customized loan amounts that provide up to 100% financing plus additional working capital</li>
<li>Interest-only payments available while you adjust to ownership</li>
<li>Competitive terms to keep payments low and affordable</li>
<li>Fixed-rate terms to meet your specific needs</li>
<li>The ultimate in flexibility and control with principal reduction and early payoff options</li>
<li>The funds you need up to $5 million</li>
<li><a class="boa-dialog boa-com-info-layer-link dotted force-visited" rel="glossary-popup-1" name="practice_sales_and_purchases_demographic_site_analysis" href="javaScript:void;">Demographic Site Analysis</a> to help you select the ideal location and attract the patient base you want<a name="practice_sales_and_purchases_footnote_3" href="#footnote6"><span class="ada-hidden">Footnote </span><sup>6</sup></a> </li>
<li>Purchase and real estate combination loans that simplify your financial life</li>
<li>Rate lock program that will protect you against potential interest rate changes through project build-out phase</li>
</ul>
<div id="_mcePaste" class="mcePaste" style="position: absolute; left: -40px; top: -25px; width: 1px; height: 1px; overflow: hidden;"></div>
				</div>
				</li>

		
				<li>
				<span class="sh-link closed"><a href="javascript:void(0);" name="Owner-occupied_commercial_real_estate"><span class="ada-hidden ada-action">Show</span> <span class="sh-link-text">Owner-occupied commercial real estate</span></a></span>
				<div class="sh-content-area hide">
					<p><strong>Purchase or refinance the building that's right for you</strong></p>
<p>When leasing space isn't the best option, it may be time to consider buying or relocating to your own building.</p>
<p>We offer a complete suite of real estate loan products including first mortgages, down payment loans, refinancing and more&mdash;including practice purchase and commercial real estate combinations. We'll customize a financing solution that meets the specific needs of your practice. Our financing programs<a name="commercial_real_estate_footnote_2" href="#footnote4"><span class="ada-hidden">Footnote </span><sup>4</sup></a> include:</p>
<ul>
<li>Conventional loans with simple applications and short approval times</li>
<li>Low or $0 down payments to help you realize your dream with minimal cash outlays</li>
<li>Interest-only payments available while you adjust to ownership</li>
<li>Competitive terms to keep payments low and affordable</li>
<li><a class="boa-dialog boa-com-info-layer-link dotted force-visited" rel="glossary-popup-1" name="commercial_real_estate_demographic_site_analysis" href="javaScript:void;">Demographic Site Analysis</a> to help you select the ideal location and attract the patient base you want<a name="commercial_real_estate_footnote_3" href="#footnote6"><span class="ada-hidden">Footnote </span><sup>6</sup></a></li>
<li>The ultimate in flexibility and control with principal reduction and early payoff options</li>
</ul>
<div id="_mcePaste" class="mcePaste" style="position: absolute; left: -40px; top: -25px; width: 1px; height: 1px; overflow: hidden;"></div>
				</div>
				</li>

		
				<li>
				<span class="sh-link closed"><a href="javascript:void(0);" name="Improvement_expansion_and_relocation"><span class="ada-hidden ada-action">Show</span> <span class="sh-link-text">Improvement, expansion and relocation</span></a></span>
				<div class="sh-content-area hide">
					<p><strong>It's a big decision&mdash;relax, we're here to help you every step of the way</strong></p>
<p>The professional and financial rewards of expanding or remodeling your practice can be well worth the effort&mdash;especially when you have our health care financing experts on your team.</p>
<p>We can help you locate reliable, reasonably priced sources for everything from equipment to cabinetry to software. We offer resources that may enable you to determine cost-effective methods for remodeling and expanding, and can discuss financing alternatives to help you achieve your dream of a more profitable practice&mdash;now and in the future.<a name="improvement_expansion_footnote_2" href="#footnote4"><span class="ada-hidden">Footnote </span><sup>4</sup></a></p>
<ul>
<li>Up to 100% financing for everything from architectural and design fees to renovations and construction to equipment and cabinetry and other project expenses&mdash;including tenant improvements</li>
<li>Interest-only payments available after completing your remodel or expansion</li>
<li>No payments during the draw period</li>
<li>Competitive terms to keep payments low and affordable</li>
<li>Fixed rates to suit your practice needs</li>
<li>Rate lock program that will protect you against potential interest rate changes through project build-out phase</li>
<li><a class="boa-dialog boa-com-info-layer-link dotted force-visited" rel="glossary-popup-1" name="improvement_expansion_demographic_site_analysis" href="javaScript:void;">Demographic Site Analysis</a> to help you select the ideal location and attract the patient base you want<a name="improvement_expansion_footnote_3" href="#footnote6"><span class="ada-hidden">Footnote </span><sup>6</sup></a></li>
<li>The ultimate in flexibility and control with principal reduction and early payoff options</li>
<li>A dedicated project manager resource to help get things done on time and within budget</li>
</ul>
				</div>
				</li>

		
				<li>
				<span class="sh-link closed"><a href="javascript:void(0);" name="Equipment_purchases"><span class="ada-hidden ada-action">Show</span> <span class="sh-link-text">Equipment purchases</span></a></span>
				<div class="sh-content-area hide">
					<p><strong>We make the process quick and easy</strong></p>
<p>When your equipment breaks down or becomes obsolete, you may need to replace it quickly. We understand. That's why in most equipment purchase situations no tax returns or financial statements are required. Even if you're not in a hurry, you'll appreciate the financial advice and assistance we can offer.</p>
<p>We'll explain the tax benefits you can receive from depreciation and first-year write-offs&mdash;as well as the Section 179 tax implications<a href="#footnote7" name="equipment_purchase_footnote_4"><span class="ada-hidden">Footnote </span><sup>7</sup></a>&mdash;of qualifying equipment and software purchases. We'll even help you decide between leasing and buying. We offer a wide variety of financial options and flexible terms that will make upgrading your equipment easier than you ever imagined.</p>
<ul>
<li>Quick and easy phone application process</li>
<li>Comprehensive financing for everything from installation to training and equipment costs</li>
<li>Simple interest payoffs and principal reductions that put you back in control</li>
<li>Flexible payment structures to meet your needs</li>
</ul>
<p>&nbsp;</p>
<p class="last">Use our <a href="https://host.visualcalc.com/practicesolutions/" name="equipment_loan_calculator" target="_self">Equipment Loan Calculator</a> to estimate monthly payments, return on investment and Section 179 tax benefits.</p>
				</div>
				</li>

		
				<li>
				<span class="sh-link closed"><a href="javascript:void(0);" name="Practice_debt_consolidation"><span class="ada-hidden ada-action">Show</span> <span class="sh-link-text">Practice debt consolidation</span></a></span>
				<div class="sh-content-area hide">
					<p><strong>Simplify your financial life</strong></p>
<p>Now you can leverage your professional equity to upgrade or expand, fund future growth, consolidate bills into one low monthly payment or improve your cash flow by lowering your overhead. We'll work with you to customize a plan that suits your income, debt level and plans for the future.<a name="practice_debt_consolidation_footnote_2" href="#footnote4"><span class="ada-hidden">Footnote </span><sup>4</sup></a></p>
<ul>
<li>Sensible solutions at competitive fixed rates</li>
<li>Customized loan amounts to meet your financing needs</li>
<li>Competitive terms to keep payments low and affordable</li>
<li>The ultimate in flexibility and control with principal reduction and early payoff options</li>
</ul>
<div id="_mcePaste" class="mcePaste" style="position: absolute; left: -40px; top: -25px; width: 1px; height: 1px; overflow: hidden;"></div>
				</div>
				</li>
			</ul>
	   </div>
	</div>
</div>
						<div class="flex-col rt-col" >

<!-- touchCommerceEnabled -->

 


<div class="cta-module target-sidewell">	
	<div class="cta focus-call">
		<div class="intro">
			<h3>We're here to help</h3>
		</div>		
		<ul class="options">
				<li class="call first">							
					<div class="details">							
						<p>Our Practice Specialists are standing by to assist you.</p>
									<p class="large"><span class="cta-html-src">800.497.6076</span></p>
							<p class="small">Mon.-Thu. 8 a.m.-8 p.m. ET<br />Fri. 8 a.m.-7 p.m. ET</p>
						<p><br />Existing account support</p>
							<p class="large">888.852.5000</p>
							<p class="small">Mon.-Fri.&nbsp;7 a.m.-9 p.m. ET</p>
					</div>						
				</li>

			<!-- New condition for S83320 -->
			<!-- updated to merge all conditions related to practice loans for story S130354 -->
				
					<li class="qualify">
						<h4><a href="#" name="Request_information"><span class="ada-hidden ada-closed">Show details on how to </span><span class="ada-hidden ada-open" style="display:none;">Hide details on how to </span>Request information<span class="ada-hidden"> about practice specialist</span></a></h4>
						<div class="details">
							<p>Complete a brief and secure email form and one of our Practice Specialists will get back to you as soon as possible.</p>
								<p><a name="Request_information_now" onclick="location.reload();location.href=/contact-us/practice-loans-email.go;dartFireOnClick('1359940','gcibl189','pracs994'); return false;" href="/contact-us/practice-loans-email.go">Request information now
								<span class="ada-hidden"> about practice specialist</span></a></p>
						</div>
					</li>
					 
					 
					 
					
					<li class="chat">
							<h4><a href="#" name="Chat_online"onClick="return dartFireOnClick('1359940','gcibl189','pracs947');">
							<span class="ada-hidden ada-closed">Show details on how to </span><span class="ada-hidden ada-open" style="display:none;">Hide details on how to </span>Chat online<span class="ada-hidden"> about practice financing</span></a></h4>
						<div class="details">						
							<div id="lpButtonDiv-Practice-Solutions">
							</div>							
						</div>					
					</li>				


				
		</ul>
	</div>
</div>

<div class="side-well-module"> </div>
		
<script type="text/javascript">
	$('.cta-html-dest').html($('.cta-html-src').html());
	cta_module.skins = {
	"Side Well" : {
	"id" : "sidewell",
	"container" :  ".side-well-module:first",
	"bind" : ".side-well-module:first",
	"location" : "first"
	}
	};
</script>

<div class="c2a-aps-sb-module">
	<div class="sw-link-skin">
		<div class="sw-outer">
			<div class="sw-inner">
				<div class="sw-corner sw-tleft"></div>
				<div class="sw-corner sw-tright"></div>
				<div class="sw-main sw-std-pad">
					<h2 class="h2-fsd-sw-gray">Endorsements</h2>
					<div class="sw-main-content">
								<p>Bank of America is proud to be a financial partner of the American Academy of Family Physicians</p>
									<img src="/content/images/ContextualSiteGraphics/Instructional/en_US/SBPS-am-acad-of-fam-phys.png" alt=""/>
								<div class="c2a-link"><a href="/smallbusiness/practice-loans/resources/endorsements.go" name="Endorsements">See endorsements <span class="raquo-link"> </span></a></div>
					</div>
				</div>
				<div class="sw-bottom"></div>
			</div>
			<div class="sw-corner sw-bleft"></div>
			<div class="sw-corner sw-bright"></div>
		</div>
	</div>
</div>
</div>
						<div class="clearboth"></div>
					</div>
					<div class="footer">
						<div class="footer-top">&nbsp;</div>
						<div class="footer-inner">

<div class="footnote-com-module">
   <div class="fsd-layout-skin sup-ie">
   
   <script>
		$(function() {
			if ($('.footnote-com-module .fsd-layout-skin').text().length > 10) {
				$('.footnote-com-module .fsd-layout-skin').addClass('wfootnote');
			}
		});
	</script>
   
					<div class="h-100">
						<div class="footnote" id="footnote1">
							<div class="fn-num">1.</div>
							<div class="fn-text">All programs subject to credit approval and loan amounts are subject to creditworthiness. Some restrictions may apply. The term, amount, interest rate and repayment schedule for your loan, and any product features, including interest rate locks, may vary depending on your creditworthiness and on the type, amount and collateral for your loan. Promotional rate available only with a prepayment fee. One of three prepayment fees will be required, depending on the option you choose. Applications must be submitted by April 30, 2017 and close by July 31, 2017. </div>
							<div class="clearboth"></div>
						</div>
					</div>
					<div class="h-100">
						<div class="footnote" id="footnote2">
							<div class="fn-num">2.</div>
							<div class="fn-text"><span>All programs subject to credit approval and loan amounts are subject to creditworthiness. Some restrictions may apply. The term, amount, interest rate and repayment schedule for your loan, and any product features, including interest rate locks, may vary depending on your creditworthiness and on the type, amount and collateral for your loan. Bank of America may prohibit use of an account to pay off or pay down another Bank of America account. Promotional rate available only with a prepayment fee. One of three prepayment fees will be required, depending on the option you choose. Applications must be submitted by July 31, 2017 and close by November 30, 2017. Loans with interest only periods are not eligible for the promotional offer.</span> </div>
							<div class="clearboth"></div>
						</div>
					</div>
					<div class="h-100">
						<div class="footnote" id="footnote3">
							<div class="fn-num">3.</div>
							<div class="fn-text">Bank of America Practice Solutions makes no express or implied warranties with respect to any aspect of the Practice Heartbeat<sup>&reg;</sup> program, nor does it guaranty any success or promise any results, and hereby disclaims the same to the extent allowed by law. The opinions of Bank of America Practice Solutions are based upon prior experience, and it makes no promise or guaranty that you will achieve any particular measure of success or results by participating in the program. You are not bound by any recommendations provided under this program and retain full responsibility for the results achieved by your professional practice. </div>
							<div class="clearboth"></div>
						</div>
					</div>
					<div class="h-100">
						<div class="footnote" id="footnote4">
							<div class="fn-num">4.</div>
							<div class="fn-text">All programs subject to credit approval and loan amounts are subject to creditworthiness. Some restrictions may apply. The term, amount, interest rate and repayment schedule for your loan, and any product features, including interest rate locks, may vary depending on your creditworthiness and on the type, amount and collateral for your loan. Bank of America may prohibit use of an account to pay off or pay down another Bank of America account. Bank of America Practice Solutions is a division of Bank of America Corporation. Bank of America is a registered trademark of Bank of America Corporation. </div>
							<div class="clearboth"></div>
						</div>
					</div>
					<div class="h-100">
						<div class="footnote" id="footnote5">
							<div class="fn-num">5.</div>
							<div class="fn-text">Bank of America Practice Solutions engages Scott McDonald &amp; Associates and RealScore, both national marketing firms specializing in demographic research, site analysis and profile reports for health care professionals to produce a demographic report to assist health care professionals in evaluating where to locate their professional practices. Scott McDonald &amp; Associates and RealScore charge a fee for this service, which is passed on to the customer. </div>
							<div class="clearboth"></div>
						</div>
					</div>
					<div class="h-100">
						<div class="footnote" id="footnote6">
							<div class="fn-num">6.</div>
							<div class="fn-text">Bank of America Practice Solutions engages Scott McDonald &amp; Associates, a national marketing firm specializing in demographic research, site analysis and profile reports for health care professionals to produce a demographic report to assist health care professionals in evaluating where to locate their professional practices. Scott McDonald &amp; Associates charges a fee for this service, which is passed on to the customer. </div>
							<div class="clearboth"></div>
						</div>
					</div>
					<div class="h-100">
						<div class="footnote" id="footnote7">
							<div class="fn-num">7.</div>
							<div class="fn-text">For details regarding the IRS section 179 tax allowance, consult your tax advisor. </div>
							<div class="clearboth"></div>
						</div>
					</div>
   </div>
</div>




 



		<div class="global-footer-module">
			<div class="fsd-skin">

				<div class="footer-bottom-left" style="float:left;max-width:66%;">
	    			<div class="gf-links">	          	
						
					
									
									<a  target="_self" href="/smallbusiness/index.jsp" 
									    name="global-footer-home">Home
									</a>
									
						
					
									
									<a  target="_self" href="/privacy/overview.go" 
									    name="global-footer-privacy-security">Privacy & Security
									</a>
									
						
					
									
									<a  target="_self" href="http://careers.bankofamerica.com/careershome.aspx" 
									    name="global-footer-careers">Careers
									</a>
									
						
					
									
									<a  target="_self" href="/sitemap/sitemap/smallbusiness.go" 
									    name="global-footer-site-map">Site Map
									</a>
									
						
					
									<a href="javascript:void(0);" class="gf-last-link boa-dialog boa-com-info-layer-link" name="global_footer_ad_practices_lnk" rel="global_footer_ad_practices">Advertising Practices</a>
								<div id="global_footer_ad_practices" class="hide">
									<h3>Advertising Practices</h3>
										<p>We strive to provide you with information about products and services you might find interesting and useful. Relationship-based ads and online behavioral advertising help us do that.</p>
<p>Here's how it works: We gather information about your online activities, such as the searches you conduct on our Sites and the pages you visit. This information may be used to deliver advertising on our Sites and offline (for example, by phone, email and direct mail) that's customized to meet specific interests you may have.</p>
<p>If you prefer that we do not use this information, you may <a onclick="$('.ui-dialog').remove();" name="WebsiteAdPractices_OptOut" href="/privacy/online-privacy-notice.go#advertising-on-our-sites" target="_blank">opt out of online behavioral advertising</a>. If you opt out, though, you may still receive generic advertising. In addition, financial advisors/Client Managers may continue to use information collected online to provide product and service information in accordance with account agreements.</p>
<p>Also, if you opt out of online behavioral advertising, you may still see ads when you sign in to your account, for example through Online Banking or MyMerrill. These ads are based on your specific account relationships with us.</p>
<p>To learn more about relationship-based ads, online behavioral advertising and our privacy practices, please review the <a onclick="$('.ui-dialog').remove();" name="WebsiteAdPractices_PrivacyNotice" href="/privacy/online-privacy-notice.go" target="_blank">Bank of America Online Privacy Notice</a> and our <a onclick="$('.ui-dialog').remove();" name="Online-privacy-faqs" href="/privacy/faq/online-privacy-faq.go" target="_blank">Online Privacy FAQs</a>.</p>
								</div>
						<div class="clearboth"></div>
	    			</div>
	      			<p>Bank of America, N.A. Member FDIC. <a onclick="function onclick() { window.open('/help/equalhousing_popup.go','newwin','width=640,height=371,scrollbars=yes,resizable=yes,left=35,top=161'); return false; }" name="Equal_Housing_Lender" href="/help/equalhousing_popup.go">Equal Housing Lender<img src="/content/images/ContextualSiteGraphics/Logos/en_US/icon_equal_housing_lender.gif" alt="" width="14" height="9" /></a> <br />&copy; 2017 Bank of America Corporation. All rights reserved.</p>
         		</div>
         		<div class="footer-social-container" style="float:right;max-width:30%;padding-left:50px;padding-top:19px;">




<div class="boa-social-loader" data-loaded="false" data-platform="borneo"  data-options=''></div>

         		</div>
         		<div class="clearboth"></div>
  			</div>
		</div>


				<div id="glossary-popup-1" class="hide tabs-main-content">
					<h3>Demographic Site Analysis</h3>
					<p>Your practice is a business, and understanding your market is critical to business success. Our Demographic Site Analysis provides detailed fact-based insight through an analysis of geographic, social, economic and growth potential factors. Whether you&rsquo;re deciding on a location or already have one, this is an excellent tool for helping you understand your target market. With Demographic Site Analysis you can:</p><ul><li>Anticipate the growth potential of your specific area</li><li>Receive in-depth information on area residents including age, income, size of household and more</li><li>Identify lifestyle preferences such as leisure activities, reading habits and purchase patterns</li><li>Discover how to market your services to achieve a higher return on investment</li></ul>
				</div>
				<div id="glossary-popup-2" class="hide tabs-main-content">
					<h3>Medical specialties</h3>
					<p>The medical specialties we finance vary depending on whether you are seeking financing for an established practice or starting up a practice from scratch.</p> <p><strong>Established practices:</strong> We offer financing for a wide range of specialties. Call 800.497.6076 to speak with a Practice Specialist and discuss your particular specialty and financing needs.</p> <p><strong>Start-up practices:</strong> We offer financing for anesthesiology: pain management, cardiology, colon &amp; rectal surgery, dermatology, family practice, gastroenterology, general surgery, internal medicine, neurology, OB/GYN, oncology, ophthalmology, optometry, orthopedic surgery, otolaryngology, pathology, pediatrics, plastic surgery, podiatric surgery, pulmonary, radiology, thoracic surgery, urology and vascular surgery.</p>
				</div>
				<div id="glossary-popup-3" class="hide tabs-main-content">
					<h3>Account Management</h3>
					<p>The Account Management service allows you to perform all your Online Banking tasks&mdash;including payments and transfers&mdash;directly in QuickBooks.<sup>&reg;</sup><a name="fn-1" href="#footnote1"><sup><span class="ada-hidden">Footnote&nbsp;</span>1</sup></a></p>
				</div>
			
<!-- start number replacer -->
<script type="text/javascript">
<!--
vs_account_id = "CtjSZVLv_rNmIgEJ";
//-->
</script>


<script type="text/javascript" src="https://www.voicestar.com/euinc/number-changer.js">
</script>

<script>
function getUrlVars() {
var vars = {};
var parts = window.location.href.replace(/[?&]+([^=&]+)=([^&]*)/gi, function(m,key,value) {
vars[key] = value;
});
return vars;
}
var myDynamicID = getUrlVars()["vsaccountid"];
</script>
</div>
					</div>
				</div>
			</div>
		</div>
	</body>	
</html>

