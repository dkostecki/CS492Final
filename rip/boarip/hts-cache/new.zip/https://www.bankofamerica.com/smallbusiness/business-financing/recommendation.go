
 

				<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
				<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
				<head>


<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta http-equiv="content-type" content="text/html;charset=utf-8">





<title>Get a Business Financing Recommendation from Bank of America</title>

<meta name="Description" CONTENT="Use this recommendatino tool to help find the right financing for your specific business need.">
<meta name="Keywords" CONTENT="business financing recommendations, find the right financing, comparing loans and leases, Bank of America loans, Bank of America leases">

		<link rel="canonical" href="https://www.bankofamerica.com/smallbusiness/business-financing/recommendation.go"/>

<link rel="shortcut icon" href="/pa/global-assets/1.0/graphic/favicon.ico" type="image/ico" />

			<link rel="stylesheet" type="text/css" href="/pa/components/bundles/gzip-compressed/xengine/APS-small-business/2017.03.0/style/bcs-aps-sb-jawr.css" media="all" />
			<script src="/pa/components/bundles/gzip-compressed/xengine/APS-small-business/2017.03.0/script/bcs-aps-sb-jawr.js" type="text/javascript"></script>
				<script type="text/javascript">
					$(window).load(function(){asyncPrintCssInclude('https://www.bankofamerica.com/pa/components/bundles/gzip-compressed/xengine/APS-small-business/2017.03.0/style/bcs-aps-sb-jawr-print.css');});
				</script>
<script type="text/javascript">
(function() {
	if (typeof mboxUpdate == "function") {
		var windowURL = window.location.href
	    windowURL = windowURL.slice( windowURL.indexOf('.')+1);
		windowURL = windowURL.split( '?' )[0];
		windowURL = windowURL.toLowerCase();
		//alert(windowURL);
		if (
		    //If no mboxes on page, mbox count will be < 1
		    (mboxFactoryDefault.getMboxes().length() < 1) &&

			//Also check for high-volume pages that do not need global logging
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go") &&
			(windowURL != "bankofamerica.com/myaccounts/signin/signin.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/entry/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signonscreen.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatechallengeanswer.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatePassword.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/mobile/banking.go")&&
			(windowURL != "bankofamerica.com/content/preload/olb-myaccount-preload-jawr-module.htm")
			)
		{

			var mboxDiv = document.createElement("div");
			mboxDiv.id = "adobe_touch_clarity_replacement";
			mboxDiv.style.display = "none";
			if (document.body && document.body.firstChild) document.body.insertBefore(mboxDiv,document.body.firstChild);
			mboxDefine(mboxDiv.id,'bac_global_bottom');
			mboxUpdate('bac_global_bottom');
		}
	}
})();
</script>

		<script src="/pa/components/bundles/gzip-compressed/xengine/Global/1.0/script/tealeafbundle.js" type="text/javascript"></script>
			<script>
				var boaPageDataJS = {};
					boaPageDataJS.isLLE = "false";
			</script>
				<style>body{display:none;}</style>
	</head>	

	<body class="fsd-layout-body">	

				<script type="text/javascript">if(self == top){var theBody=document.getElementsByTagName("body")[0];theBody.style.display="block";}else{top.location=self.location;}</script>
				<noscript><style>body{display:block;}</style></noscript>
					<a class='ada-hidden ada-visible-focus' href='#skip-to-h1' id='ada-skip-link'>Skip to main content</a>
		<div class="fsd-layout fsd-1c-layout">
			<div class="center-content">
				<div class="header">
		  



<script language="javascript" src="/pa/components/modules/tag-manager-module/1.1/script/tag-manager-module-borneo-global-skin.js"></script>
<script>

(function() {
  var fireCallback = function( cb ) {
    if ( typeof cb === "function" ) cb();
  };
  
  function ddoPopulateBase( callback ) {
    try {
		  var DDO = window.digitalData,
		  	bactm_mergeDDO = function( newDDO, priorDDO ) {
		  		if( typeof priorDDO === "undefined" ) {
				  	priorDDO = digitalData || {};
				  }

			    for (var l in newDDO) {
			        if (typeof priorDDO[l] === "undefined") {
			            priorDDO[l] = newDDO[l];
			        }
			        if (newDDO[l] !== null) {
			            if (typeof newDDO[l] === "object") {
			                bactm_mergeDDO(newDDO[l], priorDDO[l]);
			            } else {
			                priorDDO[l] = bactm_validateValue( newDDO[l] ) ? newDDO[l] : priorDDO[l];
			            }
			        }
			    }

			    return priorDDO;
				},
				bactm_olb3rdPartyId = "null";

			if (typeof DDO === "undefined") {
				var simpleDDO = { page: { pageInfo:[{ pageID: null }], attributes: {}, category: { primaryCategory: null }}};

				DDO = (typeof digitalData === "object") ? digitalData : simpleDDO; 
			}

				DDO = bactm_mergeDDO( {pageInstanceID:"notprod",load_coremetrics:false,load_opinionlabs:false,load_touchcommerce:true,load_audiencemanager:true,page:{pageInfo:[{pageID:null,destinationURL:null,referringURL:null,issueDate:null,language:null,segmentValue:null,appName:null,appStepNumber:null,appStepName:null,attr:"-_--_--_--_--_--_--_--_--_--_--_--_--_--_-"}],category:{primaryCategory:null,addlCategory:null,pageType:null},attributes:{searchString:null,searchResults:null,olbSessionID:null,subCampaignCode:null,DARTUrl:null,stateCookie:null,SASIEnabled:false,needOLBcookie:false,standardDART:[],standardDARTes:[],clickDART:[],clickDARTes:[],gaId:[],chat:{account_type:null,boa_associate:null,boa_retiree:null,customer_lob:null,customer_segment:null,data:null,email_campaign:null,entitlement_code:null,error_category:null,error_count:null,first_login:null,inqSalesProductTypes:{},invitation_background:null,invitation_template:null,referral_campaign:null,getStateValue:false,cust_fn:null,cust_ln:null,target:null}}},user:{segment:null,online_id:null,preferred_rewards_tier:null,olb3rdpartyid:null},version:"BAC_0.12"}, DDO );

			DDO.page.pageInfo[0].pageID = "smbus:Content:SB_Financing:Learning;recommendation";
			DDO.page.category.primaryCategory  = "smbus:Content:SB_Financing:Learning";
			DDO.page.pageInfo[0].language = "en-US";
			DDO.page.attributes.olbSessionID = "null";
			DDO.page.attributes.SASIEnabled =  "false";
			if (typeof DDO.user != "undefined" && typeof DDO.user.olb3rdpartyid != "undefined") {
				DDO.user.olb3rdpartyid = bactm_olb3rdPartyId;
			}

			window.utag_data = {};
			window.bactm_envSelector = bactm_setTMLib();
			window.digitalData = DDO;

      return fireCallback( callback );

    } catch(e) { }
  }
	if( window.boa && window.boa.digitalData ) {
    window.boa.digitalData.register( ddoPopulateBase );
	}
	else {
	  // Handle scenario where the header isn't available (and thus the default digitalData object and utag loader are missing).
	  //
		var writeScript = function(a,b,c,d){
			a='//tags.tiqcdn.com/utag/bofa/main/' + bactm_envSelector + '/utag.js';
			b=document;
			c='script';
			d=b.createElement(c);
			d.src=a;
			d.type='text/java'+c;
			d.async=true;
			a=b.getElementsByTagName(c)[0];
			a.parentNode.insertBefore(d,a);
		};

		ddoPopulateBase( writeScript );
	}
})();			
</script>





	
	
				<noscript>
				
					<div class="fauxdal-overlay"></div>
					<div class="fauxdal-module">
						<div class="js-disabled-skin">
							<div class="fauxdal-top"></div>
							<div class="fauxdal-bottom">
								<div class="fauxdal-content">
										<div class="fauxdal-title">
											Please Use JavaScript
										</div>
											<p>You need a web browser that supports JavaScript to use our site. Without it, some pages won't work as designed. To make sure JavaScript is turned on, please adjust your browser settings.</p><p><a name="Browser_Help_And_Tips" href="http://www.bankofamerica.com/onlinebanking/index.cfm?template=browser_help_and_tips" target="_blank">Browser Help and Tips</a></p>
										
								</div>        
								<div class="fauxdal-close"> 
									<a class="btn-bofa btn-bofa-small" href=?js=y>Close</a>
								</div>
								
							</div>
						</div>
					</div>
				</noscript>



 


<div class="header-module">
	<div class="text-w-logo-skin">
		<div class="header-left">
	  
			<div itemscope itemtype="http://schema.org/Corporation" class="bofa-logo">
				<a itemprop="url" name="anc-business-advantage" title="Bank of America logo" href="/smallbusiness/">
					<img itemprop="logo" height="28" width="221" 
					     alt="Bank of America logo" src="/content/images/ContextualSiteGraphics/Logos/en_US/boa_logo.gif"/>
				</a>
			</div>
				<div class="product" data-font="cnx-regular">Business Advantage</div>
			
			<div class="clearboth"></div>

		</div>
		
		<div class="header-right">
			<ul class="header-links">
			
				
					
				
							<li class="sign-in">
		<a					href="/sitemap/hub/signin.go" target="_self"
		name="Sign_In">Sign In</a> 
							</li>
					
				
							<li>		<a					href="/smallbusiness/" target="_self"
		name="Home_Header">Home</a> 
</li>
					
				
							<li>		<a					href="https://locators.bankofamerica.com" target="_self"
		name="Locations">Locations</a> 
</li>
					
				
							<li>		<a					href="/contactus/contactus.go?topicId=small_business_banking " target="_self"
		name="Contact_Us">Contact Us</a> 
</li>
					
				
							<li class="last-link">	
		<a					href="/smallbusiness/business-financing/learning/faqs-applying-for-financing.go" target="_self"
		name="Help">Help</a> 
							</li>
			</ul>
			
			<div class="clearboth"></div>

			<!-- include search-dotcom-util -->



<div class="header-search nlh">
  
  <div class="nav-search">
    <form class="search-form" action="https://secure.bankofamerica.com/myaccounts/public/search-results/unAuthenticatedSearch.go" data-js="/pa/components/utilities/search-util/1.0/script/nav-search.min.js" data-css="/pa/components/utilities/search-util/1.0/style/nav-search.css" data-text-unavailable="Search Currently Unavailable">
      <div class="search-input-container cf" data-icon="search">
        <label for="nav-search-query" class="ada-hidden">Search Term</label>
        <input type="text" placeholder="How can we help you?" name="query" class="search-query" id="nav-search-query" 
          maxlength="99" rel="Search" autocomplete="off"><input type="submit" alt="Search" title="Search" value="Submit Search" name="Search Module - Top Result – Search Button" class="submit track-me">
      </div>
    </form>
  </div>

</div>

		</div>

 		<div class="clearboth"></div>
 	</div>
</div>







	<div class="top-nav-module">
		<div class="fsd-skin sup-ie">
			<ul class="nav-list">
					
					
					<li>
						
									<a href="/smallbusiness/business-financing.go" class="top-menu-item"
									name="overview_topnav" id="overview_topnav">Overview</a>
					</li>
					
					
					<li>
						
								<a href="/smallbusiness/business-financing/working-capital.go" class="top-menu-item"
								name="business_credit_lines_and_loans_topnav" id="business_credit_lines_and_loans_topnav">Business Credit Lines & Loans<span class="ada-hidden"> link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/smallbusiness/business-financing/working-capital.go"  name="overview_topnav" id="overview_topnav"><span class="ada-hidden">Business credit lines and loans </span>Overview </a>
															<a href="/smallbusiness/business-financing/working-capital/business-line-of-credit.go"  name="business_line_of_credit_topnav" id="business_line_of_credit_topnav">Business Line of Credit </a>
															<a href="/smallbusiness/business-financing/working-capital/business-loans.go"  name="secured_business_loans_topnav" id="secured_business_loans_topnav">Secured Business Loans </a>
															<a href="/smallbusiness/business-financing/working-capital/unsecured-business-line-of-credit.go"  name="unsecured_line_of_credit_topnav" id="unsecured_line_of_credit_topnav">Unsecured Line of Credit </a>
									</div>
								
									<div class="hasSub">
														<a class="with-info" href="/smallbusiness/credit-cards/"  name="business_credit_cards_topnav" id="business_credit_cards_topnav">Business Credit Cards 
															
															<span class="sub-nav-item-info">Pay for everyday expenses and get online management tools</span>
														</a>
									</div>
									<span class="ada-hidden"> End of submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
					
					
					<li>
						
									<a href="/smallbusiness/business-financing/commercial-real-estate-loans.go" class="top-menu-item"
									name="commercial_real_estate_topnav" id="commercial_real_estate_topnav">Commercial Real Estate</a>
					</li>
					
					
					<li>
						
								<a href="/smallbusiness/business-financing/equipment-vehicle-loans/overview.go" class="top-menu-item"
								name="equipment_and_vehicles_topnav" id="equipment_and_vehicles_topnav">Equipment & Vehicles<span class="ada-hidden"> link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/smallbusiness/business-financing/equipment-vehicle-loans/overview.go"  name="overview_topnav" id="overview_topnav"><span class="ada-hidden">Equipment and vehicles </span>Overview </a>
															<a href="/smallbusiness/business-financing/equipment-financing/equipment-loans.go"  name="equipment__topnav" id="equipment__topnav">Equipment  </a>
															<a href="/smallbusiness/business-financing/commercial-vehicle-financing/commercial-vehicle-loans.go"  name="vehicles_topnav" id="vehicles_topnav">Vehicles </a>
									</div>
								
									<div class="hasSub">
														<a class="with-info" href="/smallbusiness/business-financing/equipment-financing/loans-leasing-compare.go"  name="should_i_buy_or_lease_topnav" id="should_i_buy_or_lease_topnav">Should I Buy or Lease? 
															
															<span class="sub-nav-item-info">Compare the advantages to see what's right for your business</span>
														</a>
									</div>
									<span class="ada-hidden"> End of submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
					
					
					<li>
						
								<a href="/smallbusiness/business-financing/learning.go" class="top-menu-item selected"
								name="resources_topnav" id="resources_topnav">Resources<span class="ada-hidden"> link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/smallbusiness/business-financing/learning.go"  name="learn_about_financing_topnav" id="learn_about_financing_topnav"><span class="ada-hidden">Resources </span>Learn about Financing </a>
															<a href="/smallbusiness/business-financing/recommendation.go"  name="get_a_recommendation_topnav" id="get_a_recommendation_topnav">Get a Recommendation </a>
															<a href="/smallbusiness/business-financing/learning/faqs-applying-for-financing.go"  name="faqs_topnav" id="faqs_topnav">FAQs </a>
									</div>
								
									<div class="hasSub">
														<a class="with-info" href="/smallbusiness/business-financing/learning/sba-financing.go#url-things-to-know-tab-content"  name="is_sba_financing_right_for_me_topnav" id="is_sba_financing_right_for_me_topnav">Is SBA Financing Right For Me? 
															
															<span class="sub-nav-item-info">5 things you should know about SBA loans</span>
														</a>
									</div>
									<span class="ada-hidden"> End of submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
			</ul>
				<div class="clearboth"></div>
		</div>
	</div>



<div class="page-title-fsd-module h-100" id="skip-to-h1">
	<div class="standard-gray-skin sup-ie">
		<h1 data-font="cnx-regular">Get a Recommendation</h1>
  </div>
</div>





	<div id="working-capital-rec-tool" class="selection-filter-module">
		<div class="recommendation-tool-skin">	
				<div id="selection">		
					<h2 data-font="cnx-regular"><p>Narrow your choices to find the right financing</p></h2>
					<form id="rec-tool">			
							<div class="selectBox how first">												
								<fieldset>
									<legend class="show-legend">I want my money:</legend>
										<div>
											<label for="at-once">All at once</label>
											<input type="checkbox" name="at-once" id="at-once">
										</div>							
										<div>
											<label for="as-need">As I need it</label>
											<input type="checkbox" name="as-need" id="as-need">
										</div>
								</fieldset>
							</div>
						
						
							<div class="selectBox plan">								
								<div>
								<fieldset>
									<legend class="show-legend">I plan to use it for:</legend>
									<label for="plan" class="ada-hidden">dropdown list for plan, please select Combox</label>
									<select id="plan" name="plan">
											<option value="default">Select purpose</option>													
											<option value="comm-real-estate">Commercial real estate</option>													
											<option value="expansion-renovation">Expansion or renovation</option>													
											<option value="on-going">Ongoing operations</option>													
											<option value="vehicle-equipment">Vehicle or equipment financing</option>													
									</select>
								</fieldset>
								</div>
							</div>
						
							<div class="selectBox secured">								
								<fieldset>
								<legend class="show-legend">I can offer as collateral:</legend>
									<div>
										<label for="real-estate">Real estate</label>
										<input type="checkbox" name="real-estate" id="real-estate">
									</div>
									<div>
										<label for="business-assets">General <a class="boa-dialog boa-com-info-layer-link" rel="businesAssets" href="javascript:void(0);">business assets</a></label>
										<input type="checkbox" name="business-assets" id="business-assets">
									</div>
									<div>
										<label for="item-purchasing">The item I'm purchasing</label>
										<input type="checkbox" name="item-purchasing" id="item-purchasing">
									</div>
								
								</fieldset>
							</div>
					</form>
				</div>	
			
					<h3 id="match-productions"><span id="number">All</span> product<span id="plural">s</span> shown </h3>
					<a class="view-all hide" name="anc-view-all" href="javascript:void(0)">view all</a>
					<a class="print no-print" name="anc-print" href="javascript:window.print();">PRINT</a>
					<div class="clearboth"></div>
						<table id="products" border="0" summary="The table below shows the matching products based on your selection">
<thead> 
<tr>
<th class="col-1" scope="col"><span class="ada-hidden">Products</span></th><th class="col-2" scope="col"><a class="boa-dialog boa-com-info-layer-link" rel="creditAmount" name="anc-credit-amount" href="javascript:void(0);">Credit amount</a></th><th class="col-3" scope="col">What&rsquo;s it for</th><th class="col-4" scope="col">Features</th>
</tr>
</thead> 
<tbody>
<tr class="row expansion-renovation business-assets item-purchasing real-estate on-going as-need vehicle-equipment">
<td class="col-1" scope="row"><a name="business-line-of-credit" href="/smallbusiness/business-financing/working-capital/business-line-of-credit.go">Business line of <br />credit</a><br />
<div class="icon secured">&nbsp;</div>
</td>
<td class="col-2 large">$10,000-<br />$1 million</td>
<td class="col-3">On-demand working capital, payroll funds, improved cash flow, inventory, materials and financing of accounts receivable</td>
<td class="col-4">
<ul class="gray-sq-bullet">
<li>Get money as you need it</li>
<li>Variable monthly payments with revolving terms</li>
<li>Fast, easy access to money via phone or bank transfer</li>
</ul>
</td>
</tr>
<tr class="row expansion-renovation item-purchasing real-estate at-once comm-real-estate">
<td class="col-1" scope="row"><a name="commercial-real-estate-loans" href="/smallbusiness/business-financing/commercial-real-estate-loans.go">Real estate loan</a><br />
<div class="icon rl-estate">&nbsp;</div>
</td>
<td class="col-2 large">$25,000-<br />$2 million</td>
<td class="col-3">Commercial real estate</td>
<td class="col-4">
<ul class="gray-sq-bullet">
<li>Secured by the real estate you purchase or own </li>
<li>Fixed monthly payments with terms up to 15 years (fully amortized) or 10-year balloon (up to 25-year amortization) </li>
<li>Finance up to 80% of appraised value</li>
</ul>
</td>
</tr>
<tr class="row item-purchasing on-going at-once vehicle-equipment">
<td class="col-1" scope="row"><a name="light-vehicle-loans" href="/smallbusiness/business-financing/commercial-vehicle-financing/commercial-vehicle-loans.go">Light vehicle loan</a><br />
<div class="icon light-vehicle">&nbsp;</div>
</td>
<td class="col-2 large">$25,000-<br />$2 million</td>
<td class="col-3">Automobiles, vans or light trucks</td>
<td class="col-4">
<ul class="gray-sq-bullet">
<li>Secured by the vehicle you purchase</li>
<li>Fixed monthly payments for new vehicles</li>
<li>Finance up to 80% of the purchase price</li>
</ul>
</td>
</tr>
<tr class="row item-purchasing on-going at-once vehicle-equipment">
<td class="col-1" scope="row"><a name="commercial-vehicle-loans" href="/smallbusiness/business-financing/commercial-vehicle-financing/commercial-vehicle-loans.go">Commercial vehicle loan</a><br />
<div class="icon commercial-vehicle">&nbsp;</div>
</td>
<td class="col-2 large">$25,000-<br />$2 million</td>
<td class="col-3">Commercial-purpose vehicles</td>
<td class="col-4">
<ul class="gray-sq-bullet">
<li>Secured by the&nbsp;vehicle you purchase</li>
<li>Fixed monthly payments with terms up to 60 months for new vehicles</li>
<li>Finance up to 80% of the purchase price</li>
</ul>
</td>
</tr>
<tr class="row item-purchasing on-going at-once vehicle-equipment">
<td class="col-1" scope="row"><a name="Equipment_loan" href="/smallbusiness/business-financing/equipment-financing/equipment-loans.go">Equipment loan</a><br />
<div class="icon equipment">&nbsp;</div>
</td>
<td class="col-2 large">$25,000-<br />$2 million</td>
<td class="col-3"><a class="boa-dialog boa-com-info-layer-link" rel="generalPurpose" name="anc-general-purpose" href="javascript:void(0);">General-purpose equipment</a></td>
<td class="col-4">
<ul class="gray-sq-bullet">
<li>Secured by the equipment you purchase</li>
<li>Fixed monthly payments with terms up to 60 <br />months for new equipment</li>
<li>Finance up to 80% of the purchase price</li>
</ul>
</td>
</tr>
<tr class="row at-once comm-real-estate expansion-renovation vehicle-equipment on-going real-estate item-purchasing business-assets">
<td class="col-1" scope="row"><a name="business_loan" href="/smallbusiness/business-financing/working-capital/business-loans.go">Business term loan</a><br />
<div class="icon secured">&nbsp;</div>
</td>
<td class="col-2 large">$25,000-<br />$2 million</td>
<td class="col-3">Lump-sum working capital, improved cash flow,<br />debt refinancing, inventory and materials</td>
<td class="col-4">
<ul class="gray-sq-bullet">
<li>Secured by general business assets</li>
<li>Fixed monthly payments with terms up to 5 years</li>
<li>Finance up to 80% of the purchase price; up to 100% when secured by certificate of deposit (CD)</li>
</ul>
</td>
</tr>
<tr class="row item-purchasing at-once vehicle-equipment">
<td class="col-1" scope="row"><a name="equipment-leasing" href="/smallbusiness/business-financing/equipment-financing/equipment-leasing.go">Equipment lease purchase</a><br />
<div class="icon equipment">&nbsp;</div>
</td>
<td class="col-2 large">$25,000-<br />$2 million</td>
<td class="col-3"><a class="boa-dialog boa-com-info-layer-link" rel="generalPurpose" name="anc-general-purpose1" href="javascript:void(0);">General-purpose equipment</a></td>
<td class="col-4">
<ul class="gray-sq-bullet">
<li>At the end of the lease, you will own the equipment for $1</li>
<li>Fixed monthly payments with terms up to 5 years</li>
<li>Finance up to 100% of the purchase price plus some <a class="boa-dialog boa-com-info-layer-link" rel="softCosts" name="anc-soft-costs2" href="javascript:void(0);">soft costs</a></li>
</ul>
</td>
</tr>
<tr class="row item-purchasing at-once vehicle-equipment">
<td class="col-1" scope="row"><a name="commercial-vehicle-leasing" href="/smallbusiness/business-financing/commercial-vehicle-financing/commercial-vehicle-leasing.go">Vehicle lease purchase</a><br />
<div class="icon commercial-vehicle">&nbsp;</div>
</td>
<td class="col-2 large">$25,000-<br />$2 million</td>
<td class="col-3">Commercial-purpose vehicles</td>
<td class="col-4">
<ul class="gray-sq-bullet">
<li>At the end of the lease, you will own the equipment for $1</li>
<li>Fixed monthly payments with terms up to 5 years</li>
<li>Finance up to 100% of the purchase price plus some <a class="boa-dialog boa-com-info-layer-link" rel="softCosts" name="anc-soft-costs3" href="javascript:void(0);">soft costs</a></li>
</ul>
</td>
</tr>
<tr class="row item-purchasing as-need vehicle-equipment">
<td class="col-1" scope="row"><a name="equipment-lines-of-credit" href="/smallbusiness/business-financing/equipment-financing/equipment-lines-of-credit.go">Equipment line of credit</a><br />
<div class="icon equipment">&nbsp;</div>
</td>
<td class="col-2 large">$50,000-<br />$1 million</td>
<td class="col-3">Equipment or commercial-purpose vehicles</td>
<td class="col-4">
<ul class="gray-sq-bullet">
<li>Allows for multiple acquisitions for up to 12 months&mdash;each acquisition is handled as a separate lease</li>
<li>Lease type can vary for each acquisition</li>
<li>Up to 100% financing of the purchase price plus some <a class="boa-dialog boa-com-info-layer-link" rel="softCosts" name="anc-soft-costs4" href="javascript:void(0);">soft costs</a></li>
</ul>
</td>
</tr>
<tr class="row item-purchasing at-once vehicle-equipment">
<td class="col-1" scope="row"><a name="true_tax_lease" href="/smallbusiness/business-financing/equipment-financing/equipment-leasing.go">True tax lease</a><br />
<div class="icon secured">&nbsp;</div>
</td>
<td class="col-2 large">$25,000-<br />$2 million</td>
<td class="col-3"><a class="boa-dialog boa-com-info-layer-link" rel="generalPurpose" name="anc-general-purpose3" href="javascript:void(0);">General-purpose equipment</a></td>
<td class="col-4">
<ul class="gray-sq-bullet">
<li>At the end of the lease, you can rent, return or purchase the equipment, or renew the lease</li>
<li>Fixed monthly payments with terms up to 5 years</li>
<li>Finance up to 100% of the purchase price plus some <a class="boa-dialog boa-com-info-layer-link" rel="softCosts" name="anc-soft-costs1" href="javascript:void(0);">soft costs</a></li>
</ul>
</td>
</tr>
<tr class="row item-purchasing at-once vehicle-equipment">
<td class="col-1" scope="row"><a name="trac_lease" href="/smallbusiness/business-financing/commercial-vehicle-financing/commercial-vehicle-leasing.go">TRAC lease</a><br />
<div class="icon commercial-vehicle">&nbsp;</div>
</td>
<td class="col-2 large">$25,000-<br />$2 million</td>
<td class="col-3">Commercial-purpose vehicles</td>
<td class="col-4">
<ul class="gray-sq-bullet">
<li>At the end of the lease, vehicle may be purchased for predetermined amount</li>
<li>Fixed monthly payments with terms up to 5 years</li>
<li>Finance up to 100% of the purchase price plus some <a class="boa-dialog boa-com-info-layer-link" rel="softCosts" name="anc-soft-costs1" href="javascript:void(0);">soft costs</a></li>
</ul>
</td>
</tr>
<tr class="row expansion-renovation on-going as-need">
<td class="col-1" scope="row"><a name="business-credit-credit" href="/smallbusiness/credit-cards/">Business credit card</a><br />
<div class="icon credit-card">&nbsp;</div>
</td>
<td class="col-2 large">flexible</td>
<td class="col-3">Day-to-day business expenses, inventory and materials, financing of accounts receivables.</td>
<td class="col-4">
<ul class="gray-sq-bullet">
<li>Get money as you need it</li>
<li>Variable monthly payments with revolving terms</li>
<li>Flexible account management resources</li>
</ul>
</td>
</tr>
</tbody>
</table>
					<div class="cant">
						<h3>Can't find what you need?</h3>
							<p>If you're a health care professional, an attorney, a CPA or an insurance agent, you'll want to visit the <a href="/smallbusiness/practice-loans/overview.go" name="practice-loans">small business practice loans</a> section of our website. Farmers and agribusiness professionals should visit our <a href="/smallbusiness/business-financing/learning/agricultural-loans.go" name="agricultural-loans">agricultural loans</a> page. If you're a large institution or corporation seeking financing greater than $2 million or custom payment options, we want to help: Please call one of our small business financing specialists to discuss your credit needs.</p>
					</div>
						 <div id="creditAmount" class="hide">
							<h3>Credit amount</h3>							
							<p>Minimum and maximum amounts for each type of financing may vary based on your specific business situation and applicable state laws.</p>				
						</div>				
						 <div id="softCosts" class="hide">
							<h3>Soft costs</h3>							
							<p>Soft costs are costs associated with the purchase of an item that are not part of the item price. For example, taxes, freight charges and delivery fees are soft costs.</p>				
						</div>				
						 <div id="businesAssets" class="hide">
							<h3>Business assets</h3>							
							<p>General business assets can be used to secure some loans. These include inventory, accounts receivable, furniture, fixtures or cash (via a certificate of deposit with Bank of America).</p>				
						</div>				
						 <div id="generalPurpose" class="hide">
							<h3>Equipment types</h3>							
							<p>We finance a wide variety of equipment, for example:</p>
<ul class="gray-sq-bullet">
<li>Light-industrial equipment such as packing machines and office equipment</li>
<li>Heavy-industrial equipment such as conveyor belts, printing presses and stationary machinery</li>
<li>Commercial vehicles (typically greater than 2.5 tons) such as heavy trucks and trailers</li>
</ul>
<p>This is by no means a comprehensive list. <a href="/contact-us/small-business-financing-email.go" target="_self">Request a callback</a> to talk to us about the specific needs of your business.</p>				
						</div>				
		</div>
	</div>
</div>
				<div class="columns">
					<div class="one-col"><script type="text/javascript">

</script>







<div class="state-selector-aps-sb-module">
<div class="modal-skin">
		<div class="state-select-aps-sb-modal hide" id="state-select-modal">
         <div class="modal-content">
            <h3>Select Your State</h3>
                <p>Please tell us where you bank so we can give you accurate rate and fee information for your location.</p>
                <form method="post" action="" id="submitState">
                    <fieldset>
                        <legend>State Selection Form</legend>
                        <input type="hidden" id="requestedUrl" value="" />
                        <label for="stateList">Current State</label>
<select name="stateListName" id="stateList" class="select-box" required="true">
    <option value=" ">Select state</option>
    <option value="AL">Alabama</option>
    <option value="AK">Alaska</option>
    <option value="AZ">Arizona</option>
    <option value="AR">Arkansas</option>
    <option value="CA">California</option>
    <option value="CO">Colorado</option>
    <option value="CT">Connecticut</option>
    <option value="DE">Delaware</option>
    <option value="DC">District of Columbia</option>
    <option value="FL">Florida</option>
    <option value="GA">Georgia</option>
    <option value="HI">Hawaii</option>
    <option value="ID">Idaho</option>
    <option value="IL">Illinois</option>
    <option value="IN">Indiana</option>
    <option value="IA">Iowa</option>
    <option value="KS">Kansas</option>
    <option value="KY">Kentucky</option>
    <option value="LA">Louisiana</option>
    <option value="ME">Maine</option>
    <option value="MD">Maryland</option>
    <option value="MA">Massachusetts</option>
    <option value="MI">Michigan</option>
    <option value="MN">Minnesota</option>
    <option value="MS">Mississippi</option>
    <option value="MO">Missouri</option>
    <option value="MT">Montana</option>
    <option value="NE">Nebraska</option>
    <option value="NV">Nevada</option>
    <option value="NH">New Hampshire</option>
    <option value="NJ">New Jersey</option>
    <option value="NM">New Mexico</option>
    <option value="NY">New York</option>
    <option value="NC">North Carolina</option>
    <option value="ND">North Dakota</option>
    <option value="OH">Ohio</option>
    <option value="OK">Oklahoma</option>
    <option value="OR">Oregon</option>
    <option value="PA">Pennsylvania</option>
    <option value="RI">Rhode Island</option>
    <option value="SC">South Carolina</option>
    <option value="SD">South Dakota</option>
    <option value="TN">Tennessee</option>
    <option value="TX">Texas</option>
    <option value="UT">Utah</option>
    <option value="VT">Vermont</option>
    <option value="VA">Virginia</option>
    <option value="WA">Washington</option>
    <option value="WV">West Virginia</option>
    <option value="WI">Wisconsin</option>
    <option value="WY">Wyoming</option>


</select>

                        <div class="button-cont">
	                        <a id="state_select_submit" class="btn-bofa btn-bofa-small state-select-modal-go-button" href="javascript:void(0);" role="button">Go</a>
	                    </div>
                    </fieldset>
                </form>
		 </div>
		</div>
</div>
</div>

</div>
				</div>
				<div class="footer">
					<div class="footer-top">&nbsp;

 


	<div class="apply-banner-module">
		<div class="product-skin lt-blue-skin small-text-no-btn">
			<div class="apply-banner">
				<div class="no-button">
					<p style="padding: 10px 0 7px 0;">Talk to a small business specialist by phone or in person to get a recommendation and start your application.&nbsp;<a href="https://secure.bankofamerica.com/mycommunications/public/appointments/getTopics.go?marketingCode=SBFINBLUE_ECBBA_A2000_A2400&amp;
comment=Please%20share%20the%20following:%20Months%20in%20Business,%20Gross%20revenue,%20Use%20of%20financing%20proce
eds" target="_self">Let's get started</a> &raquo;</p>
				</div>
			</div>
		</div>
	</div>
</div>
					<div class="footer-inner">

	<div class="footnote-module">    
		<div class="fsd-layout-skin sup-ie">	
		
			

			
		</div>
	</div>




<div class="power-footer-module">

  <div class="four-col-all-links-skin sup-ie">
    <div class="breadcrumbs">
						<a class="bold-bc" href="/" name="bank_of_america_recommendation_breadcrumbs">Bank of America</a>
						<a href="/smallbusiness/" name="small_business_recommendation_breadcrumbs" >Small Business</a>
		
					<a href="/smallbusiness/business-financing/learning.go" name="resources_recommendation_breadcrumbs">Resources</a>
		      	 <span>Get a Recommendation</span>
		    
      <div class="clearboth"></div>
    </div>
    <div class="pf-columns">
      
			<div class="pf-col" style="margin-right:50px;">
				<ul>
					<li>	
					<a href="/smallbusiness/business-financing/working-capital.go" class="bold" name="operating_cash_recommendation_power_footer" >Operating Cash</a> 
					</li>
						<li> <a href="/smallbusiness/business-financing/working-capital/business-line-of-credit.go" name="business_line_of_credit_recommendation_power_footer">Business Line of Credit</a> </li>
						<li> <a href="/smallbusiness/business-financing/working-capital/business-loans.go" name="business_loan_recommendation_power_footer">Business Loans</a> </li>
						<li> <a href="/smallbusiness/credit-cards/" name="business_credit_cards_recommendation_power_footer">Business Credit Cards</a> </li>
				</ul>
		      </div>
			<div class="pf-col" style="margin-right:50px;">
				<ul>
					<li>	
					<a href="/smallbusiness/business-financing/commercial-real-estate-loans.go" class="bold" name="commercial_real_estate_recommendation_power_footer" >Commercial Real Estate</a> 
					</li>
						<li> <a href="/smallbusiness/business-financing/commercial-real-estate-loans.go#tabs-3" name="buy_or_rent_recommendation_power_footer">Buy or rent?</a> </li>
				</ul>
		      </div>
			<div class="pf-col" style="margin-right:50px;">
				<ul>
					<li>	
					<a href="/smallbusiness/business-financing/equipment-vehicle-loans/overview.go" class="bold" name="equipment__vehicles_recommendation_power_footer" >Equipment & Vehicles</a> 
					</li>
						<li> <a href="/smallbusiness/business-financing/equipment-financing/equipment-loans.go" name="equipment_financing_recommendation_power_footer">Equipment</a> </li>
						<li> <a href="/smallbusiness/business-financing/commercial-vehicle-financing/commercial-vehicle-loans.go" name="vehicles_recommendation_power_footer">Vehicles</a> </li>
						<li> <a href="/smallbusiness/business-financing/equipment-financing/loans-leasing-compare.go" name="should_i_buy_or_lease_recommendation_power_footer">Should I Buy or Lease?</a> </li>
				</ul>
		      </div>
			<div class="pf-col" style="margin-right:50px;">
				<ul>
					<li>	
					<a href="/smallbusiness/business-financing/learning.go" class="bold" name="resources_recommendation_power_footer" >Resources</a> 
					</li>
						<li> <a href="/smallbusiness/business-financing/recommendation.go" name="get_recommendation_recommendation_power_footer">Get a Recommendation</a> </li>
						<li> <a href="/smallbusiness/business-financing/learning/faqs-applying-for-financing.go" name="faqs_recommendation_power_footer">FAQs</a> </li>
						<li> <a href="/smallbusiness/business-financing/learning/sba-financing.go" name="is_sba_financing_right_for_me_recommendation_power_footer">Is SBA Financing Right For Me?</a> </li>
				</ul>
		      </div>
      
      <div class="clearboth"></div>
    </div>
  </div>
</div>




 



		<div class="global-footer-module">
			<div class="fsd-skin">

				<div class="footer-bottom-left" style="float:left;max-width:66%;">
	    			<div class="gf-links">	          	
						
					
									
									<a  target="_self" href="/smallbusiness" 
									    name="global_footer_home">Home
									</a>
									
						
					
									
									<a  target="_self" href="/privacy/overview.go" 
									    name="global_footer_privacy_security">Privacy & Security
									</a>
									
						
					
									
									<a  target="_self" href="http://careers.bankofamerica.com/careershome.aspx" 
									    name="global_footer_careers">Careers
									</a>
									
						
					
									
									<a  target="_self" href="/sitemap/sitemap/smallbusiness.go" 
									    name="global_footer_site_map">Site Map
									</a>
									
						
					
									<a href="javascript:void(0);" class="gf-last-link boa-dialog boa-com-info-layer-link" name="global_footer_ad_practices_lnk" rel="global_footer_ad_practices">Advertising Practices</a>
								<div id="global_footer_ad_practices" class="hide">
									<h3>Advertising Practices</h3>
										<p>We strive to provide you with information about products and services you might find interesting and useful. Relationship-based ads and online behavioral advertising help us do that.</p>
<p>Here's how it works: We gather information about your online activities, such as the searches you conduct on our Sites and the pages you visit. This information may be used to deliver advertising on our Sites and offline (for example, by phone, email and direct mail) that's customized to meet specific interests you may have.</p>
<p>If you prefer that we do not use this information, you may <a onclick="$('.ui-dialog').remove();" name="WebsiteAdPractices_OptOut" href="/privacy/online-privacy-notice.go#advertising-on-our-sites" target="_blank">opt out of online behavioral advertising</a>. If you opt out, though, you may still receive generic advertising. In addition, financial advisors/Client Managers may continue to use information collected online to provide product and service information in accordance with account agreements.</p>
<p>Also, if you opt out of online behavioral advertising, you may still see ads when you sign in to your account, for example through Online Banking or MyMerrill. These ads are based on your specific account relationships with us.</p>
<p>To learn more about relationship-based ads, online behavioral advertising and our privacy practices, please review the <a onclick="$('.ui-dialog').remove();" name="WebsiteAdPractices_PrivacyNotice" href="/privacy/online-privacy-notice.go" target="_blank">Bank of America Online Privacy Notice</a> and our <a onclick="$('.ui-dialog').remove();" name="Online-privacy-faqs" href="/privacy/faq/online-privacy-faq.go" target="_blank">Online Privacy FAQs</a>.</p>
								</div>
						<div class="clearboth"></div>
	    			</div>
	      			<p>Bank of America, N.A. Member FDIC. <a title="Equal Housing Lender information." onclick="window.open('/help/equalhousing_popup.go','newwin','width=640,height=371,scrollbars=yes,resizable=yes,left=35,top=161'); return false;" name="Equal_Housing_Lender" href="/help/equalhousing_popup.go" target="_blank">Equal Housing Lender<img src="/content/images/ContextualSiteGraphics/Logos/en_US/gfoot-home-icon.png" alt="" width="14" height="9" /></a> <br />&copy;&nbsp;2017 Bank of America Corporation. All rights reserved.</p>
         		</div>
         		<div class="footer-social-container" style="float:right;max-width:30%;padding-left:50px;padding-top:19px;">




<div class="boa-social-loader" data-loaded="false" data-platform="borneo"  data-options=''></div>

         		</div>
         		<div class="clearboth"></div>
  			</div>
		</div>




 
<script language="javascript" src="/pa/global-assets/external/coremetrics/hp/eluminate.js"></script>
<script language="javascript" src="/pa/global-assets/external/coremetrics/hp/cmdatatagutils.js"></script>

	<script type="text/javascript">		
		function cmSetDD() {
		      var testString = window.location.href;
		      if (testString.toLowerCase().indexOf('.bankofamerica.com') > -1){
			    testString = testString.toLowerCase(); 
			    var tempArr = testString.split('.bankofamerica.com');
			    var tempStr = tempArr[0];
				  if (tempStr.indexOf('\/\/') > -1) {
					tempArr = tempStr.split('\/\/');tempStr = tempArr[1];
					if (tempStr.indexOf('.') > -1) {
					      tempArr = tempStr.split('.');tempStr = tempArr[0];var tempStrPt2 = tempArr[1];}
					      if (tempStr.indexOf('www') > -1) {
						    if (tempStr.indexOf('-') > -1) {cmSetStaging()}
						    else if (tempStrPt2 != null) {
							  if (tempStrPt2.indexOf('ecnp') > -1) {cmSetStaging()} 
						    }
						    else {cmSetProduction()} 
					      }
					      else if (tempStr.indexOf('-') > -1) {
						    if (tempStr.indexOf('sitekey') > -1){
							  if (tempStr == 'sitekey') {cmSetProduction()}
							  else {cmSetStaging()}  
						    } 
						    else if (testString.toLowerCase().indexOf('safe-dev') > -1 || testString.toLowerCase().indexOf('safe-cit') > -1 || testString.toLowerCase().indexOf('safe-sit') > -1) {cmSetStaging()}
						    else if (tempStrPt2 != null) {
							  if (tempStrPt2.indexOf('ecnp') > -1) {cmSetStaging()} 
						    }
						    else {cmSetStaging()}
					      }     
					      else if (tempStrPt2 != null) {
							  if (tempStrPt2.indexOf('ecnp') > -1) {cmSetStaging()} 
						    }
					      else {cmSetProduction()} 
				  }       
		      }  

		}

		if (typeof cmSetStaging == 'function') {cmSetDD()}

		cmCreatePageviewTag('smbus:Content:SB_Financing:Learning;recommendation', null, null, 'smbus:Content:SB_Financing:Learning', false, false, null, false, false, null, null, null, null, null, null, null, null, null, null, null, null);

		
		var coremetrics = new Object();
		coremetrics.CMPageId 		= "smbus:Content:SB_Financing:Learning;recommendation";		
		coremetrics.CMAppName		= null;
		coremetrics.CMAppStepNumber	= null;	
		coremetrics.CMAppStepName	= null;
		coremetrics.CMErrorCodes	= "MNGECARDMODERR001";
		coremetrics.CMCategoryId 	= "smbus:Content:SB_Financing:Learning";		
	</script>
</div>
				</div>
			</div>
		</div>	
	</body>	
</html>

