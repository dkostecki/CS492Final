
 

				<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
				<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
				<head>


<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta http-equiv="content-type" content="text/html;charset=utf-8">





<title>Business Banking Online with Bank of America Small Business</title>

<meta name="Description" CONTENT="With Bank of America Small Business Online Banking, you can access detailed account information, send online payments and more. Learn how.">
<meta name="Keywords" CONTENT="business online banking, business banking online, online business banking, business banking, business online banking">

					<meta name="twitter:title" CONTENT="Business Banking Online with Bank of America Small Business" />
					<meta name="twitter:card" CONTENT="summary" />
					<meta name="twitter:url" CONTENT="https://www.bankofamerica.com/smallbusiness/online-banking.go" />
					<meta name="twitter:image" CONTENT="https://www.bankofamerica.com/content/images/ContextualSiteGraphics/Logos/en_US/Bank_of_America_Flagscape_71x71.gif" />
					<meta name="twitter:description" CONTENT="With Bank of America Small Business Online Banking, you can access detailed account information, send online payments and more. Learn how." />
					<meta name="twitter:site" CONTENT="@BofA_Tips" />
		   			<meta property="og:title" CONTENT="Business Banking Online with Bank of America Small Business" />
		   			<meta property="og:type" CONTENT="website" />
		   			<meta property="og:url" CONTENT="https://www.bankofamerica.com/smallbusiness/online-banking.go" />
		   			<meta property="og:image" CONTENT="https://www.bankofamerica.com/content/images/ContextualSiteGraphics/Logos/en_US/Bank_of_America_Flagscape_71x71.gif" />
		   			<meta property="og:description" CONTENT="With Bank of America Small Business Online Banking, you can access detailed account information, send online payments and more. Learn how." />
		   			<meta property="og:site_name" CONTENT="Bank of America" />
		<link rel="canonical" href="https://www.bankofamerica.com/smallbusiness/online-banking.go"/>

<link rel="shortcut icon" href="/pa/global-assets/1.0/graphic/favicon.ico" type="image/ico" />

			<link rel="stylesheet" type="text/css" href="/pa/components/bundles/gzip-compressed/xengine/APS-small-business/2017.03.0/style/olbs-aps-sb-jawr.css" media="all" />
			<script src="/pa/components/bundles/gzip-compressed/xengine/APS-small-business/2017.03.0/script/olbs-aps-sb-jawr.js" type="text/javascript"></script>
				<script type="text/javascript">
					$(window).load(function(){asyncPrintCssInclude('https://www.bankofamerica.com/pa/components/bundles/gzip-compressed/xengine/APS-small-business/2017.03.0/style/olbs-aps-sb-jawr-print.css');});
				</script>
<script type="text/javascript">
(function() {
	if (typeof mboxUpdate == "function") {
		var windowURL = window.location.href
	    windowURL = windowURL.slice( windowURL.indexOf('.')+1);
		windowURL = windowURL.split( '?' )[0];
		windowURL = windowURL.toLowerCase();
		//alert(windowURL);
		if (
		    //If no mboxes on page, mbox count will be < 1
		    (mboxFactoryDefault.getMboxes().length() < 1) &&

			//Also check for high-volume pages that do not need global logging
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go") &&
			(windowURL != "bankofamerica.com/myaccounts/signin/signin.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/entry/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signonscreen.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatechallengeanswer.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatePassword.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/mobile/banking.go")&&
			(windowURL != "bankofamerica.com/content/preload/olb-myaccount-preload-jawr-module.htm")
			)
		{

			var mboxDiv = document.createElement("div");
			mboxDiv.id = "adobe_touch_clarity_replacement";
			mboxDiv.style.display = "none";
			if (document.body && document.body.firstChild) document.body.insertBefore(mboxDiv,document.body.firstChild);
			mboxDefine(mboxDiv.id,'bac_global_bottom');
			mboxUpdate('bac_global_bottom');
		}
	}
})();
</script>

		<script src="/pa/components/bundles/gzip-compressed/xengine/Global/1.0/script/tealeafbundle.js" type="text/javascript"></script>
			<script>
				var boaPageDataJS = {};
					boaPageDataJS.isLLE = "false";
			</script>
				<style>body{display:none;}</style>
	</head>		

	<body class="fsd-layout-body">	

				<script type="text/javascript">if(self == top){var theBody=document.getElementsByTagName("body")[0];theBody.style.display="block";}else{top.location=self.location;}</script>
				<noscript><style>body{display:block;}</style></noscript>
					<a class='ada-hidden ada-visible-focus' href='#skip-to-h1' id='ada-skip-link'>Skip to main content</a>
		<div class="fsd-layout fsd-2c-700lt-layout">
			<div class="fsd-border">
				<div class="center-content">
					<div class="header">
		  



<script language="javascript" src="/pa/components/modules/tag-manager-module/1.1/script/tag-manager-module-borneo-global-skin.js"></script>
<script>

(function() {
  var fireCallback = function( cb ) {
    if ( typeof cb === "function" ) cb();
  };
  
  function ddoPopulateBase( callback ) {
    try {
		  var DDO = window.digitalData,
		  	bactm_mergeDDO = function( newDDO, priorDDO ) {
		  		if( typeof priorDDO === "undefined" ) {
				  	priorDDO = digitalData || {};
				  }

			    for (var l in newDDO) {
			        if (typeof priorDDO[l] === "undefined") {
			            priorDDO[l] = newDDO[l];
			        }
			        if (newDDO[l] !== null) {
			            if (typeof newDDO[l] === "object") {
			                bactm_mergeDDO(newDDO[l], priorDDO[l]);
			            } else {
			                priorDDO[l] = bactm_validateValue( newDDO[l] ) ? newDDO[l] : priorDDO[l];
			            }
			        }
			    }

			    return priorDDO;
				},
				bactm_olb3rdPartyId = "null";

			if (typeof DDO === "undefined") {
				var simpleDDO = { page: { pageInfo:[{ pageID: null }], attributes: {}, category: { primaryCategory: null }}};

				DDO = (typeof digitalData === "object") ? digitalData : simpleDDO; 
			}

				DDO = bactm_mergeDDO( {   "pageInstanceID": "notprod",   "load_coremetrics": false,   "load_opinionlabs": false,   "load_touchcommerce": true,   "load_audiencemanager": true,   "page": {     "pageInfo": [       {         "pageID": null,         "destinationURL": null,         "referringURL": null,         "issueDate": null,         "language": null,         "segmentValue": null,         "appName": null,         "appStepNumber": null,         "appStepName": null,         "attr": "-_--_--_--_--_--_--_--_--_--_--_--_--_--_-"       }     ],     "category": {       "primaryCategory": null,       "addlCategory": null,       "pageType": null     },     "attributes": {       "searchString": null,       "searchResults": null,       "olbSessionID": null,       "subCampaignCode": null,       "DARTUrl": null,       "stateCookie": null,       "SASIEnabled": false,       "needOLBcookie": false,       "standardDART": [],       "standardDARTes": [],       "clickDART": [],       "clickDARTes": [],       "gaId": [],       "chat": {         "site_id": 36533168,         "target": {           "lpButtonDiv-OnlineBanking": "SB-Fixed15"         },         "account_type": "Online Banking",         "customer_lob": "sbob"       }     }   },   "user": {     "segment": null,     "online_id": null,     "preferred_rewards_tier": null,     "olb3rdpartyid": null   },   "version": "BAC_0.12" }, DDO );

			DDO.page.pageInfo[0].pageID = "smbus:Content:OLBs:Online_Banking;online-banking";
			DDO.page.category.primaryCategory  = "smbus:Content:OLBs:Online_Banking";
			DDO.page.pageInfo[0].language = "en-US";
			DDO.page.attributes.olbSessionID = "null";
			DDO.page.attributes.SASIEnabled =  "false";
			if (typeof DDO.user != "undefined" && typeof DDO.user.olb3rdpartyid != "undefined") {
				DDO.user.olb3rdpartyid = bactm_olb3rdPartyId;
			}

			window.utag_data = {};
			window.bactm_envSelector = bactm_setTMLib();
			window.digitalData = DDO;

      return fireCallback( callback );

    } catch(e) { }
  }
	if( window.boa && window.boa.digitalData ) {
    window.boa.digitalData.register( ddoPopulateBase );
	}
	else {
	  // Handle scenario where the header isn't available (and thus the default digitalData object and utag loader are missing).
	  //
		var writeScript = function(a,b,c,d){
			a='//tags.tiqcdn.com/utag/bofa/main/' + bactm_envSelector + '/utag.js';
			b=document;
			c='script';
			d=b.createElement(c);
			d.src=a;
			d.type='text/java'+c;
			d.async=true;
			a=b.getElementsByTagName(c)[0];
			a.parentNode.insertBefore(d,a);
		};

		ddoPopulateBase( writeScript );
	}
})();			
</script>



	
	
		
			<noscript>
				<div class="fauxdal-overlay"></div>
				<div class="fauxdal-module">
					<div class="js-disabled-skin">
						<div class="fauxdal-top"></div>
						<div class="fauxdal-bottom">
							<div class="fsd-fauxdal-content">
									<div class="fsd-fauxdal-title">
										Please Use JavaScript
									</div>
										<p>You need a web browser that supports JavaScript to use our site. Without it, some pages won&rsquo;t work as designed. To make sure JavaScript is turned on, please adjust your browser settings.</p>
<p><a name="Browser_Help_And_Tips" href="/onlinebanking/online-banking-security-faqs.go" target="_blank">Browser Help and Tips</a></p>
							</div>        
							<div class="fsd-fauxdal-close"> 
								<a class="btn-bofa btn-bofa-small" name="close_button_js_disabled_modal" href=?js=y>Close</a>
							</div>
							<div class="clearboth"></div>
						</div>
					</div>
				</div>
			</noscript>



 


<div class="header-module">
	<div class="text-w-logo-skin">
		<div class="header-left">
	  
			<div itemscope itemtype="http://schema.org/Corporation" class="bofa-logo">
				<a itemprop="url" name="anc-business-advantage" title="Bank of America Logo" href="/smallbusiness/index.jsp">
					<img itemprop="logo" height="25" width="201" 
					     alt="Bank of America Logo" src="/content/images/ContextualSiteGraphics/Logos/en_US/bofa-logo.gif"/>
				</a>
			</div>
				<div class="product" data-font="cnx-regular">Business Advantage</div>
			
			<div class="clearboth"></div>

		</div>
		
		<div class="header-right">
			<ul class="header-links">
			
				
					
				
							<li class="sign-in">
		<a					href="/sitemap/hub/signin.go" target="_self"
		name="sign-in-header">Sign In</a> 
							</li>
					
				
							<li>		<a					href="/smallbusiness/index.jsp" target="_self"
		name="home-header">Home</a> 
</li>
					
				
							<li>		<a					href="https://locators.bankofamerica.com" target="_self"
		name="locations-header">Locations</a> 
</li>
					
				
							<li>		<a					href="/contactus/contactus.go?topicId=small_business_banking" target="_self"
		name="contact-us-header">Contact Us</a> 
</li>
					
				
							<li class="last-link">	
		<a					href="/smallbusiness/online-banking/faqs/global-account-access.go" target="_self"
		name="help-header">Help</a> 
							</li>
			</ul>
			
			<div class="clearboth"></div>

			<!-- include search-dotcom-util -->



<div class="header-search nlh">
  
  <div class="nav-search">
    <form class="search-form" action="https://secure.bankofamerica.com/myaccounts/public/search-results/unAuthenticatedSearch.go" data-js="/pa/components/utilities/search-util/1.0/script/nav-search.min.js" data-css="/pa/components/utilities/search-util/1.0/style/nav-search.css" data-text-unavailable="Search Currently Unavailable">
      <div class="search-input-container cf" data-icon="search">
        <label for="nav-search-query" class="ada-hidden">Search Term</label>
        <input type="text" placeholder="How can we help you?" name="query" class="search-query" id="nav-search-query" 
          maxlength="99" rel="Search" autocomplete="off"><input type="submit" alt="Search" title="Search" value="Submit Search" name="Search Module - Top Result – Search Button" class="submit track-me">
      </div>
    </form>
  </div>

</div>

		</div>

 		<div class="clearboth"></div>
 	</div>
</div>







	<div class="top-nav-module">
		<div class="fsd-skin sup-ie">
			<ul class="nav-list">
					
					
					<li>
						
								<a href="/smallbusiness/online-banking.go" class="top-menu-item selected"
								name="online_banking_topnav" id="online_banking_topnav">Online Banking<span class="ada-hidden"> &nbsp;link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/smallbusiness/online-banking.go"  name="business_online_banking_topnav" id="business_online_banking_topnav">Business Online Banking </a>
															<a href="/smallbusiness/online-banking/account-management.go"  name="account_permissions_topnav" id="account_permissions_topnav">Account Permissions </a>
															<a href="/smallbusiness/online-banking/quickbooks.go"  name="quicken_or_quickbooks_topnav" id="quicken_or_quickbooks_topnav">QuickBooks<sup>&reg;</sup> </a>
									</div>
								
									<div class="hasSub">
														<a class="with-info" href="/smallbusiness/online-banking/features.go"  name="business_empower_topnav" id="business_empower_topnav">Empower Your Business 
															
															<span class="sub-nav-item-info">See a full list of Online Banking and optional add-on services</span>
														</a>
									</div>
									<span class="ada-hidden"> End of Submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
					
					
					<li>
						
								<a href="/smallbusiness/online-banking/cash-management.go" class="top-menu-item"
								name="cash_management_topnav" id="cash_management_topnav">Cash Management<span class="ada-hidden"> &nbsp;link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/smallbusiness/online-banking/cash-management.go"  name="cash_management_overview_topnav" id="cash_management_overview_topnav">Cash Management Tools </a>
															<a href="/smallbusiness/online-banking/cash-management/remote-deposit.go"  name="remote_deposit_topnav" id="remote_deposit_topnav">Remote Deposit </a>
															<a href="http://promo.bankofamerica.com/olbs/olbs_directpayment.html"  name="invoicing_and_payments_topnav" id="invoicing_and_payments_topnav">Invoicing and payments </a>
															<a href="/smallbusiness/online-banking/cash-management/tax-services.go"  name="tax_services_topnav" id="tax_services_topnav">Tax Services </a>
															<a href="/smallbusiness/online-banking/cash-management/merchant-services.go"  name="merchant_services_topnav" id="merchant_services_topnav">Merchant Services 
																
															</a>
									</div>
								
									<div class="hasSub">
									</div>
									<span class="ada-hidden"> End of Submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
					
					
					<li>
						
								<a href="/smallbusiness/online-banking/payroll.go" class="top-menu-item"
								name="payroll_topnav" id="payroll_topnav">Payroll<span class="ada-hidden"> &nbsp;link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/smallbusiness/online-banking/payroll.go"  name="online_payroll_overview_topnav" id="online_payroll_overview_topnav">Payroll overview </a>
															<a href="/smallbusiness/online-banking/payroll/adp.go"  name="adpreg_payroll_topnav" id="adpreg_payroll_topnav">ADP<sup>&reg;</sup> Payroll </a>
															<a href="/smallbusiness/online-banking/payroll/intuit.go"  name="intuitreg_payroll_topnav" id="intuitreg_payroll_topnav">Intuit<sup>&reg;</sup> Payroll </a>
									</div>
								
									<div class="hasSub">
									</div>
									<span class="ada-hidden"> End of Submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
					
					
					<li>
						
								<a href="/smallbusiness/online-banking/mobile.go" class="top-menu-item"
								name="mobile_banking_topnav" id="mobile_banking_topnav">Mobile Banking<span class="ada-hidden"> &nbsp;link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href=" /smallbusiness/online-banking/mobile.go"  name="mobile_banking_overview_topnav" id="mobile_banking_overview_topnav">Mobile Banking Overview   </a>
															<a href="/smallbusiness/online-banking/mobile/features.go"  name="mobile_banking_features_topnav" id="mobile_banking_features_topnav">Mobile Banking Features </a>
															<a href="/smallbusiness/online-banking/mobile/app/overview.go"  name="mobile_banking_basics_topnav" id="mobile_banking_basics_topnav">Understanding the basics </a>
									</div>
								
									<div class="hasSub">
														<a class="with-info" href="http://merch.bankofamerica.com/web/pages/CloverGo-overview"  name="mobile_pay_topnav" id="mobile_pay_topnav">Mobile Pay 
															<img class="externalLinkArrow" src="/content/images/ContextualSiteGraphics/Instructional/en_US/arrow-external-link.gif" alt="" />
															<span class="sub-nav-item-info">Bank of America Merchant Services mobile payment solutions provide fast, secure payment processing using your smartphone</span>
														</a>
									</div>
									<span class="ada-hidden"> End of Submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
			</ul>
				<div class="clearboth"></div>
		</div>
	</div>


	
 
<div class="page-title-fsd-module h-100" id="skip-to-h1">
	<div class="prod-indicator-skin sup-ie">
		<div class="full-width-wrapper">
			<h1 data-font="cnx-regular">Small Business Online Banking</h1>	

			

			<div class="clearboth"></div>
		</div>
  	</div>
</div>


<!--Banner for savings details pages-->



	<div class="banner-bdf-module">
	   <!-- inline style for banner background should be sourced from CMS.  This includes height, width and URL of background stored in media bin. -->
	   <div class="red-headline-skin sup-ie" style="height:301px;width:980px;background:url('/content/images/ContextualSiteGraphics/Instructional/en_US/SB/CAST-47313-EA-ASSET.jpg');">
		  <div class="banner-content" style="left:50px;top:42px;">  <!-- for flexibilility, the values of the inline style should be sourced from CMS.  These values position the text in the banner. -->
			 <h2 class="headline">Safe. Simple. Streamlined.</h2>
			 <div class="subtitle"><p style="font-size: 20px;">Get convenient, secure account access with<br />Small Business Online Banking.</p></div>
			<!--selectedProductName Online-Banking c2aResponse ONACTIVECART  selectedProductDetails Online_Banking numberOfItemsInCart 0-->
					<a class="button-common-large button-blue-large" href="https://secure.bankofamerica.com/login/enroll/entry/olbEnroll.go" name="enroll-in-OLB"><span>Enroll in Online Banking</span></a>
			 <div class="clearboth"></div>
		  </div>
	   </div>	
    </div>


<div class="tabstrip-module tabstrip-full-width">
	<div class="fsd-skin">
			<div class="tab first-tab selected-tab">
			 <div class="tab-cap"></div>
				   <a href="/smallbusiness/online-banking.go" name="online_banking_features">Features</a>
				 <div class="tab-cap rt-cap"></div>
				 <div class="clearboth"></div>
			</div>
		      <div class="tab ">
			 <div class="tab-cap"></div>
				   <a href="/smallbusiness/online-banking/additional-services.go" name="additional_services">Additional Services</a>
				 <div class="tab-cap rt-cap"></div>
				 <div class="clearboth"></div>
			</div>
		      <div class="tab ">
			 <div class="tab-cap"></div>
				   <a href="/smallbusiness/online-banking/faqs/account-access.go" name="faqs">FAQs</a>
				 <div class="tab-cap rt-cap"></div>
				 <div class="clearboth"></div>
			</div>
	<div class="clearboth"></div>
	</div>
	
 </div>




	
<div class="live-person-bdf-module">
   <div class="bcs-skin">
    
     	<a href="javascript:window.print();" name="print">PRINT<span class="ada-hidden">  this page</span></a> 
    
	
		<div id="lpButtonDiv-OnlineBanking">
		</div>
		
		<div id="lpButtonDivVoice"></div>
   </div>
</div>

</div>
					<div class="columns">
						<div class="flex-col lt-col" >

	
<div class="generic-content-module tabs-main-content">
	<div class="overview-vzd3-skin com-main-well-content" style="margin:0 0 40px 0;">
			
			
						<p>Run your business more efficiently and effectively while keeping your finances simple and secure. Experience the confidence and control of Small Business Online Banking.</p>
			


				<h3>Secure, easy access to your account</h3>
			
			


			
			
				<ul>
					<li>
					Real-time balance information and pending transactions
					
					
					</li>
					<li>
					12 months of sortable online transactions&mdash;view check and deposit slips online
					
					
					</li>
					<li>
					18 months of online checking and savings statements, plus an option to <a class="boa-dialog boa-com-info-layer-link dotted force-visited" rel="glossary-popup-2" name="go-paperless" href="javaScript:void(0);">go paperless</a>
					
					
					</li>
					<li>
					Transaction downloads to <a name="quickbooks" href="/smallbusiness/online-banking/quickbooks.go" target="_self">QuickBooks<sup>&reg;</sup></a>
					
					
					</li>
					<li>
					<a class="boa-dialog boa-com-info-layer-link dotted force-visited" rel="glossary-popup-1" name="automatic-alerts" href="javaScript:void(0);">Automatic alerts</a><a name="fnote2" href="#footnote1"><span class="ada-hidden">Footnote </span><sup>2</sup></a> informing you of changes and updates to your account
					
					
					</li>
					<li>
					Self-service account requests, including check and deposit slip reorder and check stop payment
					
					
					</li>
					<li>
					Manage checking, savings, CDs, loans, lines of credit and credit cards
					
					
					</li>
					<li>
					Industry-standard online security
					
					
					</li>
				</ul>


				<h3>Online bill payment and transfers</h3>
			
			


			
			
				<ul>
					<li>
					Send one-time&nbsp;or recurring electronic&nbsp;payments and checks to companies and individuals
					
					
					</li>
					<li>
					Receive bills from some companies electronically and get email notifications when a bill is paid
					
					
					</li>
					<li>
					Wire money same day or transfer money next day or third business day inside or outside the&nbsp;U.S.&mdash;you control the speed
					
					
					</li>
					<li>
					Transfer funds to your Bank of America consumer checking account from your checking or brokerage accounts at other financial institutions<a name="fnote3" href="#footnote2"><span class="ada-hidden">Footnote </span><sup>3</sup></a>
					
					
					</li>
				</ul>


	</div>
</div>




<div class="buttons-module" style="margin:0 0 40px 0;">
  <div class="standalone-skin sup-ie">
							
								<a href="https://secure.bankofamerica.com/login/enroll/entry/olbEnroll.go" class="button-common button-blue" name="enroll-in-OLB"><span>Enroll in Online Banking</span></a>    	
							
    <div class="clearboth"></div>
  </div>
</div>
  
  







<div class="featured-content-module" >
   <div class="two-feature-borderless-skin">
      <div class="fc-col-content">
	      <div class="fc-details plt-10">
          	 <h2>Features and services chart 	</h2>
             <p class= "pbtm-5">
			    Learn more about payroll services and the full suite of features that can benefit your business.
		     </p>
             <a class="no-print" name="features-and-services-chart" href="/smallbusiness/online-banking/features.go" >View the chart <span class="raquo-link">&#8250;&#8250;</span> <span class="ada-hidden">for Features and services</span></a>			 
		  </div>
		  <div class="clearboth"></div>			  
      </div>    
       <div class="fc-col-content">
	      <div class="fc-details plt-10">
	          	 <h2>Online Banking means business </h2>
             <p class="pbtm-5">
                With Small Business Online Banking, you enjoy confidence and control.
		     </p>
               <a class="no-print" name="sign-up-now" target="_self" href="https://secure.bankofamerica.com/login/enroll/entry/olbEnroll.go">Sign up now <span class="ada-hidden">for Online Banking</span></a>&nbsp;<span class="no-print">|</span>&nbsp; 			 
               <a class="no-print" name="take-a-test-drive" target="_blank" onclick="window.open('http://infocenter.bankofamerica.com/smallbusiness/ic2/online-banking/getting-started/', '','width=1000, height=660,left=80,scrollbars=yes,resizable=yes,top=45'); return false;" href="http://infocenter.bankofamerica.com/smallbusiness/ic2/online-banking/getting-started/">Take a test drive <span class="ada-hidden">for Online Banking. Link opens in a new window.</span></a> 			 
		  </div>
		  <div class="clearboth"></div>			  
      </div> 	  
      <div class="clearboth"></div>
   </div>
</div>

				<div id="glossary-popup-1" class="hide tabs-main-content">
					<h3>Automatic alerts</h3>
					<p>Automatic alerts allow you to receive notices via email or text message based on conditions you specify, for example: insufficient funds in your checking or saving account, irregular card or account activity and balances approaching your credit limit or dropping beneath a specified amount.<a href="#footnote3"><span class="ada-hidden">Footnote</span><sup>3</sup></a></p>
				</div>
				<div id="glossary-popup-2" class="hide tabs-main-content">
					<h3>Go Paperless</h3>
					<p>You can save paper and avoid messy filing by requesting that we stop mailing your paper statement.</p><p class="mtop-5">After you sign in to Online Banking, look for the leaf icon (<img src="/content/images/ContextualSiteGraphics/Logos/en_US/icon_library/Green_leaf.bmp" alt="green leaf icon" /> ) or simply go to&nbsp;<strong>Profile &amp; Settings</strong> and click on the <strong>Paperless settings</strong> link.</p><p class="mtop-5">We will send you an email every month when your statement is available for viewing online. If there are changes to account terms and conditions or other legal notifications, they will also be presented online, along with your account statements. You can always resume delivery of your paper statements at a later date.</p>
				</div>




<div class="carousel-bdf-module" style="width:700px;">
	<div class="img-w-text-skin sup-ie">
		
		<script type="text/javascript">					
			$(document).ready(function(){				
				if($(".carousel-bdf-module .img-w-text-skin").length > 0){					
					$('#slides').slides({
						container: 'slides-container',
						play: 15000,
						pause: 2500,
						hoverPause: true,
						fadeSpeed: 0,
						prependPagination: true,
						rotation:false,
						paginationAdaTitle: 'Featured ',
						paginationAdaPrep: 'of',
						animationComplete: function(current){
							var currentSlide = $('.carousel-slide:eq(0)');
							var $list = $('ul.pagination li a','#slides');
							if(current != undefined)
								currentSlide = $('.carousel-slide:eq('+eval(current-1)+')');
							$('.slide-count','.carousel-content').find('span.ada-hidden').hide();
							$('.slide-count', currentSlide).find('span.ada-hidden').show();
							$list.find('span').addClass('hide');
							$list.eq(current-1).find('span').removeClass('hide');
							
						}
					})
					.find("ul.pagination li a")
					.each(function(){
						var name = $(this).text();
						$(this).attr("name","marketing_carousel_top_radio_button_" + name.replace(/\s+/g,"_"));
					});
					normalizeHeight();
					var $navigationList = $('ul.pagination li a','#slides');
					$navigationList.each(function(){
						$(this).append('<span class="hide"> Active article</span>');
					});
					$navigationList.eq(0).find('span').removeClass('hide');
					$navigationList.click(function(){
						$navigationList.find('span').addClass('hide');
						$(this).find('span').removeClass('hide');
					});
				};
			});
			
			function normalizeHeight() {
				var normalizedHeight = 1;
				$(".carousel-bdf-module .img-w-text-skin #slides .carousel-slide").each(function() {
				    if ($(this).is(":hidden")) $(this).addClass("normalization-hide").show();
				    var candidateHeight = $(this).find(".carousel-content").height();
				    normalizedHeight = (candidateHeight > normalizedHeight ? candidateHeight : normalizedHeight);
				    if ($(this).hasClass("normalization-hide")) $(this).hide();
				});
				$(".carousel-bdf-module .img-w-text-skin #slides .slides-container").height(normalizedHeight).css("min-height","110px");
			}
		</script>
	   
	   <span class="ada-hidden">Press alt+ctrl+shift+s to stop, alt+ctrl+shift+n to move next slide, alt+ctrl+shift+p to move previous slide.</span> 
	 	<div id="slides">
			<div class="slides-container">
						<div class="carousel-slide image" tabindex="-1">
							<div class="carousel-image"><img src="/content/images/ContextualSiteGraphics/Instructional/en_US/carousel_payroll_services.png" alt=""/></div>
							<div class="carousel-content">
								<div class="slide-count"><span class="ada-hidden">Slide </span>1 of 4<span class="ada-hidden"> about Payroll Services</span></div>
								<h2>Easy, accurate payroll</h2>
									<p>Self-service or full-service payroll, the choice is yours</p>
									<a href="/smallbusiness/online-banking/payroll.go" name="learn-about-payroll-services" id="learn-about-payroll-services">Learn about payroll services </a>
							</div>
						</div>					
						<div class="carousel-slide image" tabindex="-1">
							<div class="carousel-image"><img src="/content/images/ContextualSiteGraphics/Instructional/en_US/SB/cta-Overview.png" alt=""/></div>
							<div class="carousel-content">
								<div class="slide-count"><span class="ada-hidden">Slide </span>2 of 4<span class="ada-hidden"> about Account Management</span></div>
								<h2>Manage your finances with confidence</h2>
									<p>Account Management tools give you more flexibility and control over your accounts so you can get back to what matters most&mdash;your business.</p>
<p><a onclick="MyWindow=window.open('https://promo.bankofamerica.com/sb/account-management/','MyWindow','toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,resizable=no,width=800,height=700'); return false;" href="#">Learn about our Account Management service&gt;&gt;</a></p>
									<a href="/smallbusiness/online-banking/account-management.go" name="learn-about-account-management" id="learn-about-account-management"></a>
							</div>
						</div>					
						<div class="carousel-slide image" tabindex="-1">
							<div class="carousel-image"><img src="/content/images/ContextualSiteGraphics/Instructional/en_US/carousel_rdo.png" alt=""/></div>
							<div class="carousel-content">
								<div class="slide-count"><span class="ada-hidden">Slide </span>3 of 4<span class="ada-hidden"> about Remote Deposits Online</span></div>
								<h2>Online check deposits</h2>
									<p>Remote Deposit Online lets you manage your business on your schedule.</p>
									<a href="/smallbusiness/online-banking/cash-management/remote-deposit.go" name="learn-about-remote-deposit-online" id="learn-about-remote-deposit-online">Learn about Remote Deposit Online </a>
							</div>
						</div>					
						<div class="carousel-slide image" tabindex="-1">
							<div class="carousel-image"><img src="/content/images/ContextualSiteGraphics/Instructional/en_US/SmallBusiness/Merchant_Services_Carousel.png" alt=""/></div>
							<div class="carousel-content">
								<div class="slide-count"><span class="ada-hidden">Slide </span>4 of 4<span class="ada-hidden"> about Merchant Services</span></div>
								<h2>Accept any kind of payment</h2>
									<p>Fast and easy electronic payments from one of the top merchant services processors<a href="#Footnote 4" name="carousel"><span class="ada-hidden">Footnote</span><sup>4</sup></a></p>
									<a href="https://www.bankofamerica.com/smallbusiness/online-banking/cash-management/merchant-services.go" name="learn-about-merchant-services" id="learn-about-merchant-services">Learn about Merchant Services</a>
							</div>
						</div>					
			</div>
		</div>
	 </div>
</div>

	<div class="footnote-module">    
		<div class="fsd-layout-skin sup-ie">	
		
					<!--inside footnoteContext list-->
							<div class="footnote">	
									<!--inside else list-->		
									<!--Note Index :::1-->
								<div class="fn-num" id="footnote1"><sup>1</sup></div>
								<div class="fn-text">Alerts recieved as text messages on your mobile access device may incur a charge from your mobile access provided. Mobile App alerts are not available on select devices.</div>
								<div class="clearboth"></div>
							</div>	
							
					<!--inside footnoteContext list-->
							<div class="footnote">	
									<!--inside else list-->		
									<!--Note Index :::1-->
								<div class="fn-num" id="footnote2"><sup>2</sup></div>
								<div class="fn-text">Fees apply to wire and certain transfers. See the <a href="https://www.bankofamerica.com/online-banking/service-agreement.go" target="_self">Online Banking Service Agreement</a> for details.</div>
								<div class="clearboth"></div>
							</div>	
							
					<!--inside footnoteContext list-->
							<div class="footnote">	
									<!--inside else list-->		
									<!--Note Index :::1-->
								<div class="fn-num" id="footnote3"><sup>3</sup></div>
								<div class="fn-text">Alerts received as text messages on your mobile access device may incur a charge from your mobile access service provider. The Mobile Banking app and Mobile Banking app alerts are not available on select devices. Mobile Banking app alerts are not available on the Mobile Website.</div>
								<div class="clearboth"></div>
							</div>	
							
					<!--inside footnoteContext list-->
							<div class="footnote">	
									<!--inside else list-->		
									<!--Note Index :::1-->
								<div class="fn-num" id="footnote4"><sup>4</sup></div>
								<div class="fn-text">Based on bankcard, other credit, and PIN debit sales volume and transactions. Per the Nilson Report, March 2015, Issue 1059.</div>
								<div class="clearboth"></div>
							</div>	
							
			

			
		</div>
	</div>
</div>
						<div class="flex-col rt-col" >




		<div class="sitekey-widget-display-module" style="">
				<div class="stand-alone-skin">

<div class="sitekey-widget-util">
	<div id="skwContainer">
		<div id="skwContent"></div>
		
		<script language="JavaScript" type="text/javascript">

			var skwURL = "https://secure.bankofamerica.com/login/sign-in/";
			var sitekey_ui_script;
			
				sitekey_ui_script = '<script language="JavaScript" type="text\/javascript" src="'+skwURL+'entry/sitekeyWidgetScript.go?inScript=true&gcsl_token=7F4693F858F90A79ADA40C905709087DAFE443213E2C2CEFC37035A4295DF7F97EA729F176E710863A5C0E8BDD6060779A40A70E3F4F2F4E0804837A850BFD84E3A126A46D73BD8E74A249B27E5D91EDF5884940001E6A7E3F0C0DAD50611A782044C400ABBFC7DBA1ACA33CA4735E2F35DDCA803F74B1E3E52DACD7F8A83BA5EB491CADAB512EF95D576EF3D7820737A6936BD1BE3FFFF35F7AB13BA2E6AAE88685316E4DB26254266263EC203B40F826C18933AE6E2A8576A4B9DA0E7A40E2A5C2972585B69A88B7B707B3CAEF94BBC04D7C9196BD3200436BB2EE6AB1A8D65E2169B56064B8F5205D6D0B61DEEB03DF975E68D09B3F75B473FC980A4224B9504F7FB6E47D8ABD740A7B560737747FA1963B388898803DED3DB05FAE61F34608BB7E2AD23C8C274184106943FC59632301D8DED03ED93242D5E2FD7EBD634968D629BE80E7CA9B657851FA0BB976A657FC63324CD6F24EC52364EB0F0052019A4911A5AB6D739AED8214082F5BF8D7694533B11BEDF084F8C812FC59B9182CA25455E8E14A065DCA901BCE65D06EACA084EA6849326E6221B245F8E0AFBCA43DE8B2A92009D1E9949EC3B66FE8388238900BAA530EFB234123DE864E6F7B9F93678883322D3E16F1D1B7B6CC25B063E840D8550B5E2F9A4D68D3E986D4B7C81C4C695B66FBFBE4F6D6AAA8267633CB7B37F6DA6929CAED5C6C4D2D16A65C2F8B3CFB728468F7B881F4B32F3C7D267FA0B638D05500B7C96C66650346D32CD9EA39358F268A3FC01FF52556718CC3487FA71594C9C26522DEF74D0856C33CA24369EBD8BE468D5473BE568707E54BDEC0781CE9FC3CAF68&source=BOFA-OLBS&gcsl_iv=D9EF980CB2E6BF31"><\/script>';


			document.writeln(sitekey_ui_script);


		</script>

		<script language="JavaScript" type="text/javascript">


				if( typeof($skwjq)==="undefined" || typeof(skwInitSettings)==="undefined" ) {
					document.write('<div class="skw-client-error" style="color:#333;font:62.5%/1.5 Verdana,Arial,Helvetica,sans-serif;width:205px;font-size:11px;line-height:14px;"><h2>Online Banking temporarily unavailable</h2><p>We\'re sorry, but we\'re working to restore it as quickly as possible.<\/p><p>Please try <a style="color:#36C;" name="anc-refresh-en-US" href="javascript:window.location.reload(true);">refreshing your browser<\/a> or try again later.<\/p></div>');
				}

		</script>
		<noscript>
			<link rel="stylesheet" type="text/css" href="https://secure.bankofamerica.com/pa/components/modules/sitekey-widget-module/1.0/style/sitekey-widget-layout-nojs.css" />

				<div class="skw-js-disabled-container">
					<span class="skw-nojs-ada-hidden">text_secure_sign_in</span>
					<div class="skw-js-disabled-content">
						<div class="skw-js-disabled-heading">text_use_javascript</div>
						<div>text_browser_support_javascript</div>
						<div>text_adjust_browser_setting</div>
						<a target="_self" href="/onlinebanking/online-banking-security-faqs.go" name="label_browser_help_tips">text_browser_help_tips</a>
					</div>
				</div>

		</noscript>
	</div>
	<br clear="all"/>
</div>

				
			</div>
			<div class="clearboth"></div>
		</div>


		<div class="side-well-module">
		  <div class="links-list-skin">
		    <div class="sw-outer">
		      <div class="sw-inner">
		        <div class="sw-corner sw-tleft"></div>
		        <div class="sw-corner sw-tright"></div>
		        <div class="sw-main sw-std-pad">
		          <div class="h2-fsd-sw-gray"><h2>Sign in to other services</h2></div>
		          <div class="sw-main-content">
		            <ul class="li-pbtm-10">
							<li><a href="http://corp.bankofamerica.com/business/smb/landing/cashpro-smallbusiness/index" target="_self" name="cashpro_online">CashPro Online<span class="ada-hidden"> CashPro Online</span></a></li>					    
							<li><a href="https://www.bamsaccess.net/bamsaccess/NpcaccessServ" target="_self" name="merchant_reporting">Merchant Reporting</a></li>
							<li class="last-li"><a href="https://olui2.fs.ml.com/login/login.aspx?sgt=3&_ tps=251F6751-8578-4ECC-9EFC-39AEA81CFD3E" target="_self" name="business_investing">Business Investing</a></li>
		            </ul>
		          </div>
		        </div>
		        <div class="sw-bottom"></div>
		      </div>
		      <div class="sw-corner sw-bleft"></div>
		      <div class="sw-corner sw-bright"></div>
		    </div>
		  </div>
		</div>	
</div>
						<div class="clearboth"></div>
					</div>
					<div class="footer">
						<div class="footer-top">&nbsp;</div>
						<div class="footer-inner">
<div class="disclaimers-module">
	<div class="fsd-skin sup-ie">
			<p>Bank of America does not deliver the services associated with ADP products. Internet access may be required. Internet service provider fees may apply. Other bank fees may apply. See <a href="https://www-dev3.ecnp.bankofamerica.com/smallbusiness/resources/business-schedule-fees.go" name="business_schedule_fees" title="business_schedule_fees" target="_blank">Business Schedule of Fees</a> for details.</p>
<p>ADP, the ADP logo, and RUN Powered by ADP are registered trademarks of ADP, LLC, and ADP A more human resource is a service mark of ADP, LLC.</p>
<p>24/7/365 service is offered for RUN Powered by ADP</p>
	</div>
</div>





<div class="power-footer-module">

  <div class="four-col-all-links-skin sup-ie">
    <div class="breadcrumbs">
						<a class="bold-bc" href="/" name="bank_of_america_online_banking_breadcrumbs">Bank of America</a>
						<a href="/smallbusiness/" name="small_business_online_banking_and_services_online_banking_breadcrumbs" >Small Business</a>
		
					<a href="/smallbusiness/online-banking.go" name="business_online_banking_online_banking_breadcrumbs">Business Online Banking</a>
		      	 <span>Small Business Online Banking</span>
		    
      <div class="clearboth"></div>
    </div>
    <div class="pf-columns">
      
			<div class="pf-col" style="margin-right:50px;">
				<ul>
					<li>	
					<a href="/smallbusiness/online-banking.go" class="bold" name="business_online_banking_online_banking_power_footer" >Business Online Banking</a> 
					</li>
						<li> <a href="/smallbusiness/online-banking/account-management.go" name="account_permissions_online_banking_power_footer">Account Permissions</a> </li>
						<li> <a href="/smallbusiness/online-banking/quickbooks.go" name="quickbooks_online_banking_power_footer">QuickBooks<sup>&reg;</sup></a> </li>
				</ul>
		      </div>
			<div class="pf-col" style="margin-right:50px;">
				<ul>
					<li>	
					<a href="/smallbusiness/online-banking/cash-management.go" class="bold" name="cash_management_online_banking_power_footer" >Cash Management</a> 
					</li>
						<li> <a href="/smallbusiness/online-banking/cash-management/remote-deposit.go" name="remote_deposit_online_banking_power_footer">Remote Deposit</a> </li>
						<li> <a href="http://promo.bankofamerica.com/olbs/olbs_directpayment.html" name="invoicing_and_payments_online_banking_power_footer">Invoicing and payments</a> </li>
						<li> <a href="/smallbusiness/online-banking/cash-management/tax-services.go" name="tax_services_online_banking_power_footer">Tax Services</a> </li>
						<li> <a href="/smallbusiness/online-banking/cash-management/merchant-services.go" name="merchant_services_online_banking_power_footer">Merchant Services</a> </li>
				</ul>
		      </div>
			<div class="pf-col" style="margin-right:50px;">
				<ul>
					<li>	
					<a href="/smallbusiness/online-banking/payroll.go" class="bold" name="payroll_online_banking_power_footer" >Payroll</a> 
					</li>
						<li> <a href="/smallbusiness/online-banking/payroll.go" name="payroll_overview_online_banking_power_footer">Payroll overview</a> </li>
						<li> <a href="/smallbusiness/online-banking/payroll/adp.go" name="adp_payroll_online_banking_power_footer">ADP Payroll&reg;</a> </li>
						<li> <a href="/smallbusiness/online-banking/payroll/intuit.go" name="intuit_payroll_online_banking_power_footer">Intuit Payroll&reg;</a> </li>
				</ul>
		      </div>
			<div class="pf-col" style="margin-right:50px;">
				<ul>
					<li>	
					<a href="/smallbusiness/online-banking/mobile.go" class="bold" name="mobile_banking_online_banking_power_footer" >Mobile Banking</a> 
					</li>
						<li> <a href="/smallbusiness/online-banking/mobile/features.go" name="mobile_banking_features_online_banking_power_footer">Mobile Banking Features</a> </li>
						<li> <a href="/smallbusiness/online-banking/mobile/app/overview.go" name="understanding__the_basics_online_banking_power_footer">Understanding the basics</a> </li>
				</ul>
		      </div>
      
      <div class="clearboth"></div>
    </div>
  </div>
</div>




 



		<div class="global-footer-module">
			<div class="fsd-skin">

				<div class="footer-bottom-left" style="float:left;max-width:66%;">
	    			<div class="gf-links">	          	
						
					
									
									<a  target="_self" href="/smallbusiness/index.jsp" 
									    name="global-footer-home">Home
									</a>
									
						
					
									
									<a  target="_self" href="/privacy/index.jsp" 
									    name="global-footer-privacy-security">Privacy & Security
									</a>
									
						
					
									
									<a  target="_self" href="http://www.bankofamerica.com/careers/" 
									    name="global-footer-careers">Careers
									</a>
									
						
					
									
									<a  target="_self" href="/sitemap/sitemap/smallbusiness.go" 
									    name="global-footer-site-map">Site Map
									</a>
									
						
					
									<a href="javascript:void(0);" class="gf-last-link boa-dialog boa-com-info-layer-link" name="global_footer_ad_practices_lnk" rel="global_footer_ad_practices">Advertising Practices</a>
								<div id="global_footer_ad_practices" class="hide">
									<h3>Advertising Practices</h3>
										<p>We strive to provide you with information about products and services you might find interesting and useful. Relationship-based ads and online behavioral advertising help us do that.</p>
<p>Here's how it works: We gather information about your online activities, such as the searches you conduct on our Sites and the pages you visit. This information may be used to deliver advertising on our Sites and offline (for example, by phone, email and direct mail) that's customized to meet specific interests you may have.</p>
<p>If you prefer that we do not use this information, you may <a onclick="$('.ui-dialog').remove();" name="WebsiteAdPractices_OptOut" href="/privacy/online-privacy-notice.go#advertising-on-our-sites" target="_blank">opt out of online behavioral advertising</a>. If you opt out, though, you may still receive generic advertising. In addition, financial advisors/Client Managers may continue to use information collected online to provide product and service information in accordance with account agreements.</p>
<p>Also, if you opt out of online behavioral advertising, you may still see ads when you sign in to your account, for example through Online Banking or MyMerrill. These ads are based on your specific account relationships with us.</p>
<p>To learn more about relationship-based ads, online behavioral advertising and our privacy practices, please review the <a onclick="$('.ui-dialog').remove();" name="WebsiteAdPractices_PrivacyNotice" href="/privacy/online-privacy-notice.go" target="_blank">Bank of America Online Privacy Notice</a> and our <a onclick="$('.ui-dialog').remove();" name="Online-privacy-faqs" href="/privacy/faq/online-privacy-faq.go" target="_blank">Online Privacy FAQs</a>.</p>
								</div>
						<div class="clearboth"></div>
	    			</div>
	      			<p>Bank of America, N.A. Member FDIC. <a onclick="function onclick() { window.open('/help/equalhousing_popup.go','newwin','width=640,height=371,scrollbars=yes,resizable=yes,left=35,top=161'); return false; }" name="Equal_Housing_Lender" href="/help/equalhousing_popup.go">Equal Housing Lender<img src="/content/images/ContextualSiteGraphics/Logos/en_US/icon_equal_housing_lender.gif" alt="" width="14" height="9" /></a> <br />&copy;&nbsp;2017 Bank of America Corporation. All rights reserved.</p>
         		</div>
         		<div class="footer-social-container" style="float:right;max-width:30%;padding-left:50px;padding-top:19px;">




<div class="boa-social-loader" data-loaded="false" data-platform="borneo"  data-options=''></div>

         		</div>
         		<div class="clearboth"></div>
  			</div>
		</div>




 
<script type="text/javascript" src="/pa/global-assets/external/coremetrics/hp/eluminate.js"></script>
<script type="text/javascript" src="/pa/global-assets/external/coremetrics/hp/cmdatatagutils.js"></script>

<script type="text/javascript">
/*Minified version CM Data Direction Code - updated 8-21-2013 */
function cmSetDD(){var testString=window.location.href;if(testString.toLowerCase().indexOf(".bankofamerica.com")>-1){testString=testString.toLowerCase();var tempArr=testString.split(".bankofamerica.com");var tempStr=tempArr[0];if(tempStr.indexOf("//")>-1){tempArr=tempStr.split("//");tempStr=tempArr[1];if(tempStr.indexOf(".")>-1){tempArr=tempStr.split(".");tempStr=tempArr[0];var tempStrPt2=tempArr[1]}if(tempStr.indexOf("www")>-1){if(tempStr.indexOf("-")>-1){cmSetStaging()}else{if(tempStrPt2!=null){if(tempStrPt2.indexOf("ecnp")>-1){cmSetStaging()}}else{cmSetProduction()}}}else{if(tempStr.indexOf("-")>-1){if(tempStr.indexOf("sitekey")>-1){if(tempStr=="sitekey"){cmSetProduction()}else{cmSetStaging()}}else{cmSetStaging()}}else{if(tempStrPt2!=null){if(tempStrPt2.indexOf("ecnp")>-1){cmSetStaging()}}else{cmSetProduction()}}}}}}if(typeof cmSetStaging=="function"){cmSetDD()};
</script>




    <script type="text/javascript">
        var href = window.location.href;
        $('html')
        .on('error', function(e, err) {
            cmCreateCustomError('smbus:Content:OLBs:Online_Banking;online-banking', null, null, null, err.code, 'smbus:Content:OLBs:Online_Banking', err.message);
        })
        .on('click', '[data-cm]', function() {
            cmCreateManualLinkClickTag(href, $(this).data('cm').click, cG7.cM0[cm_ClientID]);
        });
    </script>
			<script type="text/javascript">
				cmCreatePageviewTag('smbus:Content:OLBs:Online_Banking;online-banking', null, null, 'smbus:Content:OLBs:Online_Banking', false, false, null, false, false, null, null, null, null, null, null, null, null, null, null, null, null);
			</script>
			<div itemscope="itemscope" itemtype="http://schema.org/WebPage">
					<span style="display:none" itemprop="name">Business Banking Online with Bank of America Small Business</span>
					<a style="display:none" itemprop="url" href="https://www.bankofamerica.com/smallbusiness/online-banking.go"></a>
					<span style="display:none" itemprop="description">With Bank of America Small Business Online Banking, you can access detailed account information, send online payments and more. Learn how.</span>
					<img style="display:none" class="no-stretch" itemprop="image" alt="Business Banking Online with Bank of America Small Business" src="https://www.bankofamerica.com/content/images/ContextualSiteGraphics/Logos/en_US/Bank_of_America_Flagscape_71x71.gif">
			</div>
</div>
					</div>
				</div>
			</div>
		</div>
	</body>	
</html>

