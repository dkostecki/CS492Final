
 

				<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
				<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
				<head>


<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta http-equiv="content-type" content="text/html;charset=utf-8">





<title>Payroll services for small businesses</title>

<meta name="Description" CONTENT="Looking for Online Payroll Services for your business? Compare the options we offer to help make processing payroll easier.">
<meta name="Keywords" CONTENT="payroll service, business online payroll, online payroll, online payroll services, payroll services for small business, small business payroll">

					<meta name="twitter:title" CONTENT="Online Payroll Services for Small Business" />
					<meta name="twitter:card" CONTENT="summary" />
					<meta name="twitter:url" CONTENT="https://www.bankofamerica.com/smallbusiness/online-banking/payroll.go" />
					<meta name="twitter:image" CONTENT="https://www.bankofamerica.com/content/images/ContextualSiteGraphics/Logos/en_US/Bank_of_America_Flagscape_71x71.gif" />
					<meta name="twitter:description" CONTENT="Looking for Online Payroll Services for your business? Compare the options we offer to help make processing payroll easier." />
					<meta name="twitter:site" CONTENT="@BofA_Tips" />
		   			<meta property="og:title" CONTENT="Online Payroll Services for Small Business" />
		   			<meta property="og:type" CONTENT="website" />
		   			<meta property="og:url" CONTENT="https://www.bankofamerica.com/smallbusiness/online-banking/payroll.go" />
		   			<meta property="og:image" CONTENT="https://www.bankofamerica.com/content/images/ContextualSiteGraphics/Logos/en_US/Bank_of_America_Flagscape_71x71.gif" />
		   			<meta property="og:description" CONTENT="Looking for Online Payroll Services for your business? Compare the options we offer to help make processing payroll easier." />
		   			<meta property="og:site_name" CONTENT="Bank of America" />
		<link rel="canonical" href="https://www.bankofamerica.com/smallbusiness/online-banking/payroll.go"/>

<link rel="shortcut icon" href="/pa/global-assets/1.0/graphic/favicon.ico" type="image/ico" />

			<link rel="stylesheet" type="text/css" href="/pa/components/bundles/gzip-compressed/xengine/APS-small-business/2017.03.0/style/olbs-aps-sb-jawr.css" media="all" />
			<script src="/pa/components/bundles/gzip-compressed/xengine/APS-small-business/2017.03.0/script/olbs-aps-sb-jawr.js" type="text/javascript"></script>
				<script type="text/javascript">
					$(window).load(function(){asyncPrintCssInclude('https://www.bankofamerica.com/pa/components/bundles/gzip-compressed/xengine/APS-small-business/2017.03.0/style/olbs-aps-sb-jawr-print.css');});
				</script>
<script type="text/javascript">
(function() {
	if (typeof mboxUpdate == "function") {
		var windowURL = window.location.href
	    windowURL = windowURL.slice( windowURL.indexOf('.')+1);
		windowURL = windowURL.split( '?' )[0];
		windowURL = windowURL.toLowerCase();
		//alert(windowURL);
		if (
		    //If no mboxes on page, mbox count will be < 1
		    (mboxFactoryDefault.getMboxes().length() < 1) &&

			//Also check for high-volume pages that do not need global logging
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go") &&
			(windowURL != "bankofamerica.com/myaccounts/signin/signin.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/entry/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signonscreen.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatechallengeanswer.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatePassword.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/mobile/banking.go")&&
			(windowURL != "bankofamerica.com/content/preload/olb-myaccount-preload-jawr-module.htm")
			)
		{

			var mboxDiv = document.createElement("div");
			mboxDiv.id = "adobe_touch_clarity_replacement";
			mboxDiv.style.display = "none";
			if (document.body && document.body.firstChild) document.body.insertBefore(mboxDiv,document.body.firstChild);
			mboxDefine(mboxDiv.id,'bac_global_bottom');
			mboxUpdate('bac_global_bottom');
		}
	}
})();
</script>

		<script src="/pa/components/bundles/gzip-compressed/xengine/Global/1.0/script/tealeafbundle.js" type="text/javascript"></script>
			<script>
				var boaPageDataJS = {};
					boaPageDataJS.isLLE = "false";
			</script>
				<style>body{display:none;}</style>
	</head>		

	<body class="fsd-layout-body">	

				<script type="text/javascript">if(self == top){var theBody=document.getElementsByTagName("body")[0];theBody.style.display="block";}else{top.location=self.location;}</script>
				<noscript><style>body{display:block;}</style></noscript>
					<a class='ada-hidden ada-visible-focus' href='#skip-to-h1' id='ada-skip-link'>Skip to main content</a>
		<div class="fsd-layout fsd-2c-700lt-layout">
			<div class="fsd-border">
				<div class="center-content">
					<div class="header">
		  



<script language="javascript" src="/pa/components/modules/tag-manager-module/1.1/script/tag-manager-module-borneo-global-skin.js"></script>
<script>

(function() {
  var fireCallback = function( cb ) {
    if ( typeof cb === "function" ) cb();
  };
  
  function ddoPopulateBase( callback ) {
    try {
		  var DDO = window.digitalData,
		  	bactm_mergeDDO = function( newDDO, priorDDO ) {
		  		if( typeof priorDDO === "undefined" ) {
				  	priorDDO = digitalData || {};
				  }

			    for (var l in newDDO) {
			        if (typeof priorDDO[l] === "undefined") {
			            priorDDO[l] = newDDO[l];
			        }
			        if (newDDO[l] !== null) {
			            if (typeof newDDO[l] === "object") {
			                bactm_mergeDDO(newDDO[l], priorDDO[l]);
			            } else {
			                priorDDO[l] = bactm_validateValue( newDDO[l] ) ? newDDO[l] : priorDDO[l];
			            }
			        }
			    }

			    return priorDDO;
				},
				bactm_olb3rdPartyId = "null";

			if (typeof DDO === "undefined") {
				var simpleDDO = { page: { pageInfo:[{ pageID: null }], attributes: {}, category: { primaryCategory: null }}};

				DDO = (typeof digitalData === "object") ? digitalData : simpleDDO; 
			}

				DDO = bactm_mergeDDO( {pageInstanceID:"notprod",load_coremetrics:false,load_opinionlabs:false,load_touchcommerce:true,load_audiencemanager:true,page:{pageInfo:[{pageID:null,destinationURL:null,referringURL:null,issueDate:null,language:null,segmentValue:null,appName:null,appStepNumber:null,appStepName:null,attr:"-_--_--_--_--_--_--_--_--_--_--_--_--_--_-"}],category:{primaryCategory:null,addlCategory:null,pageType:null},attributes:{searchString:null,searchResults:null,olbSessionID:null,subCampaignCode:null,DARTUrl:null,stateCookie:null,SASIEnabled:false,needOLBcookie:false,standardDART:[],standardDARTes:[],clickDART:[],clickDARTes:[],gaId:[],chat:{account_type:null,boa_associate:null,boa_retiree:null,customer_lob:null,customer_segment:null,data:null,email_campaign:null,entitlement_code:null,error_category:null,error_count:null,first_login:null,inqSalesProductTypes:{},invitation_background:null,invitation_template:null,referral_campaign:null,getStateValue:false,cust_fn:null,cust_ln:null,target:null}}},user:{segment:null,online_id:null,preferred_rewards_tier:null,olb3rdpartyid:null},version:"BAC_0.12"}, DDO );

			DDO.page.pageInfo[0].pageID = "smbus:Content:OLBs:Payroll;payroll";
			DDO.page.category.primaryCategory  = "smbus:Content:OLBs:Payroll";
			DDO.page.pageInfo[0].language = "en-US";
			DDO.page.attributes.olbSessionID = "null";
			DDO.page.attributes.SASIEnabled =  "false";
			if (typeof DDO.user != "undefined" && typeof DDO.user.olb3rdpartyid != "undefined") {
				DDO.user.olb3rdpartyid = bactm_olb3rdPartyId;
			}

			window.utag_data = {};
			window.bactm_envSelector = bactm_setTMLib();
			window.digitalData = DDO;

      return fireCallback( callback );

    } catch(e) { }
  }
	if( window.boa && window.boa.digitalData ) {
    window.boa.digitalData.register( ddoPopulateBase );
	}
	else {
	  // Handle scenario where the header isn't available (and thus the default digitalData object and utag loader are missing).
	  //
		var writeScript = function(a,b,c,d){
			a='//tags.tiqcdn.com/utag/bofa/main/' + bactm_envSelector + '/utag.js';
			b=document;
			c='script';
			d=b.createElement(c);
			d.src=a;
			d.type='text/java'+c;
			d.async=true;
			a=b.getElementsByTagName(c)[0];
			a.parentNode.insertBefore(d,a);
		};

		ddoPopulateBase( writeScript );
	}
})();			
</script>




 


<div class="header-module">
	<div class="text-w-logo-skin">
		<div class="header-left">
	  
			<div itemscope itemtype="http://schema.org/Corporation" class="bofa-logo">
				<a itemprop="url" name="anc-business-advantage" title="Bank of America Logo" href="/smallbusiness/index.jsp">
					<img itemprop="logo" height="25" width="201" 
					     alt="Bank of America Logo" src="/content/images/ContextualSiteGraphics/Logos/en_US/bofa-logo.gif"/>
				</a>
			</div>
				<div class="product" data-font="cnx-regular">Business Advantage</div>
			
			<div class="clearboth"></div>

		</div>
		
		<div class="header-right">
			<ul class="header-links">
			
				
					
				
							<li class="sign-in">
		<a					href="/sitemap/hub/signin.go" target="_self"
		name="sign-in-header">Sign In</a> 
							</li>
					
				
							<li>		<a					href="/smallbusiness/index.jsp" target="_self"
		name="home-header">Home</a> 
</li>
					
				
							<li>		<a					href="https://locators.bankofamerica.com" target="_self"
		name="locations-header">Locations</a> 
</li>
					
				
							<li>		<a					href="/contactus/contactus.go?topicId=small_business_banking" target="_self"
		name="contact-us-header">Contact Us</a> 
</li>
					
				
							<li class="last-link">	
		<a					href="/smallbusiness/online-banking/faqs/global-account-access.go" target="_self"
		name="help-header">Help</a> 
							</li>
			</ul>
			
			<div class="clearboth"></div>

			<!-- include search-dotcom-util -->



<div class="header-search nlh">
  
  <div class="nav-search">
    <form class="search-form" action="https://secure.bankofamerica.com/myaccounts/public/search-results/unAuthenticatedSearch.go" data-js="/pa/components/utilities/search-util/1.0/script/nav-search.min.js" data-css="/pa/components/utilities/search-util/1.0/style/nav-search.css" data-text-unavailable="Search Currently Unavailable">
      <div class="search-input-container cf" data-icon="search">
        <label for="nav-search-query" class="ada-hidden">Search Term</label>
        <input type="text" placeholder="How can we help you?" name="query" class="search-query" id="nav-search-query" 
          maxlength="99" rel="Search" autocomplete="off"><input type="submit" alt="Search" title="Search" value="Submit Search" name="Search Module - Top Result – Search Button" class="submit track-me">
      </div>
    </form>
  </div>

</div>

		</div>

 		<div class="clearboth"></div>
 	</div>
</div>







	<div class="top-nav-module">
		<div class="fsd-skin sup-ie">
			<ul class="nav-list">
					
					
					<li>
						
								<a href="/smallbusiness/online-banking.go" class="top-menu-item"
								name="online_banking_topnav" id="online_banking_topnav">Online Banking<span class="ada-hidden"> &nbsp;link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/smallbusiness/online-banking.go"  name="business_online_banking_topnav" id="business_online_banking_topnav">Business Online Banking </a>
															<a href="/smallbusiness/online-banking/account-management.go"  name="account_permissions_topnav" id="account_permissions_topnav">Account Permissions </a>
															<a href="/smallbusiness/online-banking/quickbooks.go"  name="quicken_or_quickbooks_topnav" id="quicken_or_quickbooks_topnav">QuickBooks<sup>&reg;</sup> </a>
									</div>
								
									<div class="hasSub">
														<a class="with-info" href="/smallbusiness/online-banking/features.go"  name="business_empower_topnav" id="business_empower_topnav">Empower Your Business 
															
															<span class="sub-nav-item-info">See a full list of Online Banking and optional add-on services</span>
														</a>
									</div>
									<span class="ada-hidden"> End of Submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
					
					
					<li>
						
								<a href="/smallbusiness/online-banking/cash-management.go" class="top-menu-item"
								name="cash_management_topnav" id="cash_management_topnav">Cash Management<span class="ada-hidden"> &nbsp;link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/smallbusiness/online-banking/cash-management.go"  name="cash_management_overview_topnav" id="cash_management_overview_topnav">Cash Management Tools </a>
															<a href="/smallbusiness/online-banking/cash-management/remote-deposit.go"  name="remote_deposit_topnav" id="remote_deposit_topnav">Remote Deposit </a>
															<a href="http://promo.bankofamerica.com/olbs/olbs_directpayment.html"  name="invoicing_and_payments_topnav" id="invoicing_and_payments_topnav">Invoicing and payments </a>
															<a href="/smallbusiness/online-banking/cash-management/tax-services.go"  name="tax_services_topnav" id="tax_services_topnav">Tax Services </a>
															<a href="/smallbusiness/online-banking/cash-management/merchant-services.go"  name="merchant_services_topnav" id="merchant_services_topnav">Merchant Services 
																
															</a>
									</div>
								
									<div class="hasSub">
									</div>
									<span class="ada-hidden"> End of Submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
					
					
					<li>
						
								<a href="/smallbusiness/online-banking/payroll.go" class="top-menu-item selected"
								name="payroll_topnav" id="payroll_topnav">Payroll<span class="ada-hidden"> &nbsp;link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/smallbusiness/online-banking/payroll.go"  name="online_payroll_overview_topnav" id="online_payroll_overview_topnav">Payroll overview </a>
															<a href="/smallbusiness/online-banking/payroll/adp.go"  name="adpreg_payroll_topnav" id="adpreg_payroll_topnav">ADP<sup>&reg;</sup> Payroll </a>
															<a href="/smallbusiness/online-banking/payroll/intuit.go"  name="intuitreg_payroll_topnav" id="intuitreg_payroll_topnav">Intuit<sup>&reg;</sup> Payroll </a>
									</div>
								
									<div class="hasSub">
									</div>
									<span class="ada-hidden"> End of Submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
					
					
					<li>
						
								<a href="/smallbusiness/online-banking/mobile.go" class="top-menu-item"
								name="mobile_banking_topnav" id="mobile_banking_topnav">Mobile Banking<span class="ada-hidden"> &nbsp;link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href=" /smallbusiness/online-banking/mobile.go"  name="mobile_banking_overview_topnav" id="mobile_banking_overview_topnav">Mobile Banking Overview   </a>
															<a href="/smallbusiness/online-banking/mobile/features.go"  name="mobile_banking_features_topnav" id="mobile_banking_features_topnav">Mobile Banking Features </a>
															<a href="/smallbusiness/online-banking/mobile/app/overview.go"  name="mobile_banking_basics_topnav" id="mobile_banking_basics_topnav">Understanding the basics </a>
									</div>
								
									<div class="hasSub">
														<a class="with-info" href="http://merch.bankofamerica.com/web/pages/CloverGo-overview"  name="mobile_pay_topnav" id="mobile_pay_topnav">Mobile Pay 
															<img class="externalLinkArrow" src="/content/images/ContextualSiteGraphics/Instructional/en_US/arrow-external-link.gif" alt="" />
															<span class="sub-nav-item-info">Bank of America Merchant Services mobile payment solutions provide fast, secure payment processing using your smartphone</span>
														</a>
									</div>
									<span class="ada-hidden"> End of Submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
			</ul>
				<div class="clearboth"></div>
		</div>
	</div>


	
 
<div class="page-title-fsd-module h-100" id="skip-to-h1">
	<div class="prod-indicator-skin sup-ie">
		<div class="full-width-wrapper">
			<h1 data-font="cnx-regular">Payroll services for small businesses</h1>	

			

			<div class="clearboth"></div>
		</div>
  	</div>
</div>

	
	<div class="banner-bdf-module" style="background-color:;">
			<div class="btn-text-skin">
			<img alt="" src="/content/images/ContextualSiteGraphics/Instructional/en_US/SB/payroll_overview_new2_980x285.jpg"/>
				<div class="text-btn-overlay"> 
							<h2 class="h2-middle"><b>Small business, made easier</b></h2>
								<p>Self-service options and expert help - products&nbsp;designed <br />with your business in mind</p>	
				</div>
				
			</div>
		</div>


	
	
		
			<noscript>
				<div class="fauxdal-overlay"></div>
				<div class="fauxdal-module">
					<div class="js-disabled-skin">
						<div class="fauxdal-top"></div>
						<div class="fauxdal-bottom">
							<div class="fsd-fauxdal-content">
									<div class="fsd-fauxdal-title">
										Please Use JavaScript
									</div>
										<p>You need a web browser that supports JavaScript to use our site. Without it, some pages won&rsquo;t work as designed. To make sure JavaScript is turned on, please adjust your browser settings.</p>
<p><a name="Browser_Help_And_Tips" href="/onlinebanking/online-banking-security-faqs.go" target="_blank">Browser Help and Tips</a></p>
							</div>        
							<div class="fsd-fauxdal-close"> 
								<a class="btn-bofa btn-bofa-small" name="close_button_js_disabled_modal" href=?js=y>Close</a>
							</div>
							<div class="clearboth"></div>
						</div>
					</div>
				</div>
			</noscript>

<div class="print-module-browser-dialog-skin" style=""> 
	<a href="javascript:window.print();" name="print">PRINT<span class="ada-hidden"> this page</span></a>
</div></div>
					<div class="columns">
						<div class="flex-col lt-col" >





	<div class="generic-content-module">
		<div class="two-col-skin fsd-font sup-ie">
			<p>Bank of America, with the help of our partners, offers options for your small business to help simplify payroll administration and other human resource tasks. These options help save you time and effort so you can focus on what&rsquo;s important &mdash; your business.</p>
				<div class="gcm-col gcm-col-one">
					<p></p>
					<h2><a name="full-service-payroll" href="/smallbusiness/online-banking/payroll/adp.go">ADP<sup>&reg;</sup></a></h2>
					<div class="inner">
							<p>Hire-to-retire small business payroll and HR solutions.<br />Backed by 24/7 payroll customer support, ADP frees up your back office allowing you to focus on what matters most to you.<br /><br /></p>
							<p><a href="/smallbusiness/online-banking/payroll/adp.go" target="_self">See how ADP works</a></p>
					</div>
				
				</div>
				<div class="gcm-col">
					<p></p>
					<h2><a name="easy-online-payroll" href="/smallbusiness/online-banking/payroll/intuit.go">Intuit<sup>&reg;</sup></a></h2>
					<div class="inner">
							<p>Intuit, the makers of QuickBooks<sup>&reg;</sup>, provide both DIY and full service payroll solutions to meet your small business needs. Intuit makes payroll simple so you can get back to doing what you love &ndash; running your business.</p>
							<p><a href="/smallbusiness/online-banking/payroll/intuit.go" target="_self">See how Intuit works</a></p>
					</div>
				
				</div>
			<div class="clearboth"></div>
		</div>
	</div>




<div class="feature-content-module">
   <div class="tabled-dynamic-availability-skin sup-ie">
  
     
      
			<table class="last-table" summary="">
				<thead>
					
						<tr>
									<th scope="col"><span class="ada-hidden"></span></th>
									<th scope="col">ADP<sup>&reg;</sup><span class="ada-hidden">ADP<sup>&reg;</sup></span></th>
									<th scope="col">Intuit<sup>&reg;</sup><span class="ada-hidden">Intuit<sup>&reg;</sup></span></th>
						</tr>
				</thead> 
				<tbody>
							 <tr>
											<td>I would like to manage my own payroll, using software with guaranteed accuracy.<span class="ada-hidden">I would like to manage my own payroll, using software with guaranteed accuracy.</span></td>  
											<td><span class="ada-hidden"></span></td>  
											<td><img height="50px" width="50px" src="/content/images/ContextualSiteGraphics/Instructional/en_US/SB/checkmark_red_50x50.png" alt="Yes"/><span class="ada-hidden">Intuit - Yes</span></td> 
							 </tr>
							 <tr>
											<td>I would like a professional to take my payroll information and set up my account for me<span class="ada-hidden">I would like a professional to take my payroll information and set up my account for me</span></td>  
											<td><img height="50px" width="50px" src="/content/images/ContextualSiteGraphics/Instructional/en_US/SB/checkmark_red_50x50.png" alt="Yes"/><span class="ada-hidden">ADP - Yes</span></td>
											<td><img height="50px" width="50px" src="/content/images/ContextualSiteGraphics/Instructional/en_US/SB/checkmark_red_50x50.png" alt="Yes"/><span class="ada-hidden"> - Yes</span></td> 
							 </tr>
							 <tr>
											<td>I would like to have my employee hours automatically calculated<span class="ada-hidden">I would like to have my employee hours automatically calculated</span></td>  
											<td><img height="50px" width="50px" src="/content/images/ContextualSiteGraphics/Instructional/en_US/SB/checkmark_red_50x50.png" alt="Yes"/><span class="ada-hidden">ADP - Yes</span></td>
											<td><img height="50px" width="50px" src="/content/images/ContextualSiteGraphics/Instructional/en_US/SB/checkmark_red_50x50.png" alt="Yes"/><span class="ada-hidden">Intuit - Yes</span></td> 
							 </tr>
							 <tr>
											<td>I would like to call an HR professional regarding labor laws and HR policies<span class="ada-hidden">I would like to call an HR professional regarding labor laws and HR policies</span></td>  
											<td><img height="50px" width="50px" src="/content/images/ContextualSiteGraphics/Instructional/en_US/SB/checkmark_red_50x50.png" alt="Yes"/><span class="ada-hidden">ADP - Yes</span></td>
											<td><span class="ada-hidden"></span></td>  
							 </tr>
				</tbody>
			</table>
      
   </div>
</div>

</div>
						<div class="flex-col rt-col" >



<!-- FTL :Module code starts here . All anchor names should begin with prefix 'anc' -->
<div class="side-well-module">  
   <div class="generic-content-skin">
      <div class="sm-top-cap"></div>
      <div class="sm-body">	  
         <h3 class="sm-title-bar">
			Small Business 401(k)
		 </h3>
         <div class="sm-main">
		
					
									<p>Offer your employees a simplified, low-cost 401(k) plan through Merrill Edge.</p>
<p><a href="http://www.merrilledge.com/small-business/401k? name=" learn_more_about_sb401k="" id="learn_more_about_SB401K" src_cd="bac_sb_payroll_services&quot;" title="Merrill Edge SB 401k">Learn more <span class="ada-hidden">&nbsp;about Small Business 401 (k) plans </span></a></p>							
         </div>
      </div>
      <div class="sm-btm-cap"></div>
   </div>   
</div>
</div>
						<div class="clearboth"></div>
					</div>
					<div class="footer">
						<div class="footer-top">&nbsp;</div>
						<div class="footer-inner">
<div class="disclaimers-module">
	<div class="fsd-skin sup-ie">
			<p>Intuit&reg; Online Payroll is a product of Intuit Inc. You must go to the Intuit website to enroll in and use the product. Bank of America is not responsible for the product or the performance of Intuit Inc. Intuit and the Intuit logo are registered trademarks of Intuit Inc., used under license.</p>
<p>Bank of America does not deliver the services associated with ADP products. Internet access may be required. Internet service provider fees may apply. Other bank fees may apply. See <a href="/smallbusiness/resources/business-schedule-fees.go" name="business_schedule_fees" title="business_schedule_fees" target="_blank">Business Schedule of Fees</a>&nbsp;for details. ADP, the ADP logo, and RUN Powered by ADP are registered trademarks of ADP, LLC, and ADP A more human resource is a service mark of ADP, LLC.</p>
<p>24/7/365 service is offered for RUN Powered by ADP</p>
<p>Bank of America and the Bank of America logo are registered trademarks of Bank of America Corporation.</p>
	</div>
</div>





<div class="power-footer-module">

  <div class="four-col-all-links-skin sup-ie">
    <div class="breadcrumbs">
						<a class="bold-bc" href="/" name="bank_of_america_payroll_breadcrumbs">Bank of America</a>
						<a href="/smallbusiness/" name="small_business_online_banking_and_services_payroll_breadcrumbs" >Small Business</a>
		
					<a href="/smallbusiness/online-banking/payroll.go" name="payroll_payroll_breadcrumbs">Payroll</a>
		      	 <span>Payroll services for small businesses</span>
		    
      <div class="clearboth"></div>
    </div>
    <div class="pf-columns">
      
			<div class="pf-col" style="margin-right:50px;">
				<ul>
					<li>	
					<a href="/smallbusiness/online-banking.go" class="bold" name="business_online_banking_payroll_power_footer" >Business Online Banking</a> 
					</li>
						<li> <a href="/smallbusiness/online-banking/account-management.go" name="account_permissions_payroll_power_footer">Account Permissions</a> </li>
						<li> <a href="/smallbusiness/online-banking/quickbooks.go" name="quickbooks_payroll_power_footer">QuickBooks<sup>&reg;</sup></a> </li>
				</ul>
		      </div>
			<div class="pf-col" style="margin-right:50px;">
				<ul>
					<li>	
					<a href="/smallbusiness/online-banking/cash-management.go" class="bold" name="cash_management_payroll_power_footer" >Cash Management</a> 
					</li>
						<li> <a href="/smallbusiness/online-banking/cash-management/remote-deposit.go" name="remote_deposit_payroll_power_footer">Remote Deposit</a> </li>
						<li> <a href="http://promo.bankofamerica.com/olbs/olbs_directpayment.html" name="invoicing_and_payments_payroll_power_footer">Invoicing and payments</a> </li>
						<li> <a href="/smallbusiness/online-banking/cash-management/tax-services.go" name="tax_services_payroll_power_footer">Tax Services</a> </li>
						<li> <a href="/smallbusiness/online-banking/cash-management/merchant-services.go" name="merchant_services_payroll_power_footer">Merchant Services</a> </li>
				</ul>
		      </div>
			<div class="pf-col" style="margin-right:50px;">
				<ul>
					<li>	
					<a href="/smallbusiness/online-banking/payroll.go" class="bold" name="payroll_payroll_power_footer" >Payroll</a> 
					</li>
						<li> <a href="/smallbusiness/online-banking/payroll.go" name="payroll_overview_payroll_power_footer">Payroll overview</a> </li>
						<li> <a href="/smallbusiness/online-banking/payroll/adp.go" name="adp_payroll_payroll_power_footer">ADP Payroll&reg;</a> </li>
						<li> <a href="/smallbusiness/online-banking/payroll/intuit.go" name="intuit_payroll_payroll_power_footer">Intuit Payroll&reg;</a> </li>
				</ul>
		      </div>
			<div class="pf-col" style="margin-right:50px;">
				<ul>
					<li>	
					<a href="/smallbusiness/online-banking/mobile.go" class="bold" name="mobile_banking_payroll_power_footer" >Mobile Banking</a> 
					</li>
						<li> <a href="/smallbusiness/online-banking/mobile/features.go" name="mobile_banking_features_payroll_power_footer">Mobile Banking Features</a> </li>
						<li> <a href="/smallbusiness/online-banking/mobile/app/overview.go" name="understanding__the_basics_payroll_power_footer">Understanding the basics</a> </li>
				</ul>
		      </div>
      
      <div class="clearboth"></div>
    </div>
  </div>
</div>




 



		<div class="global-footer-module">
			<div class="fsd-skin">

				<div class="footer-bottom-left" style="float:left;max-width:66%;">
	    			<div class="gf-links">	          	
						
					
									
									<a  target="_self" href="/smallbusiness/index.jsp" 
									    name="global-footer-home">Home
									</a>
									
						
					
									
									<a  target="_self" href="/privacy/index.jsp" 
									    name="global-footer-privacy-security">Privacy & Security
									</a>
									
						
					
									
									<a  target="_self" href="http://www.bankofamerica.com/careers/" 
									    name="global-footer-careers">Careers
									</a>
									
						
					
									
									<a  target="_self" href="/sitemap/sitemap/smallbusiness.go" 
									    name="global-footer-site-map">Site Map
									</a>
									
						
					
									<a href="javascript:void(0);" class="gf-last-link boa-dialog boa-com-info-layer-link" name="global_footer_ad_practices_lnk" rel="global_footer_ad_practices">Advertising Practices</a>
								<div id="global_footer_ad_practices" class="hide">
									<h3>Advertising Practices</h3>
										<p>We strive to provide you with information about products and services you might find interesting and useful. Relationship-based ads and online behavioral advertising help us do that.</p>
<p>Here's how it works: We gather information about your online activities, such as the searches you conduct on our Sites and the pages you visit. This information may be used to deliver advertising on our Sites and offline (for example, by phone, email and direct mail) that's customized to meet specific interests you may have.</p>
<p>If you prefer that we do not use this information, you may <a onclick="$('.ui-dialog').remove();" name="WebsiteAdPractices_OptOut" href="/privacy/online-privacy-notice.go#advertising-on-our-sites" target="_blank">opt out of online behavioral advertising</a>. If you opt out, though, you may still receive generic advertising. In addition, financial advisors/Client Managers may continue to use information collected online to provide product and service information in accordance with account agreements.</p>
<p>Also, if you opt out of online behavioral advertising, you may still see ads when you sign in to your account, for example through Online Banking or MyMerrill. These ads are based on your specific account relationships with us.</p>
<p>To learn more about relationship-based ads, online behavioral advertising and our privacy practices, please review the <a onclick="$('.ui-dialog').remove();" name="WebsiteAdPractices_PrivacyNotice" href="/privacy/online-privacy-notice.go" target="_blank">Bank of America Online Privacy Notice</a> and our <a onclick="$('.ui-dialog').remove();" name="Online-privacy-faqs" href="/privacy/faq/online-privacy-faq.go" target="_blank">Online Privacy FAQs</a>.</p>
								</div>
						<div class="clearboth"></div>
	    			</div>
	      			<p>Bank of America, N.A. Member FDIC. <a onclick="function onclick() { window.open('/help/equalhousing_popup.go','newwin','width=640,height=371,scrollbars=yes,resizable=yes,left=35,top=161'); return false; }" name="Equal_Housing_Lender" href="/help/equalhousing_popup.go">Equal Housing Lender<img src="/content/images/ContextualSiteGraphics/Logos/en_US/icon_equal_housing_lender.gif" alt="" width="14" height="9" /></a> <br />&copy;&nbsp;2017 Bank of America Corporation. All rights reserved.</p>
         		</div>
         		<div class="footer-social-container" style="float:right;max-width:30%;padding-left:50px;padding-top:19px;">




<div class="boa-social-loader" data-loaded="false" data-platform="borneo"  data-options=''></div>

         		</div>
         		<div class="clearboth"></div>
  			</div>
		</div>

<script type="text/javascript" src="/pa/global-assets/external/coremetrics/hp/eluminate.js"></script>
<script type="text/javascript" src="/pa/global-assets/external/coremetrics/hp/cmdatatagutils.js"></script>

<script type="text/javascript">
/*Minified version CM Data Direction Code - updated 8-21-2013 */
function cmSetDD(){var testString=window.location.href;if(testString.toLowerCase().indexOf(".bankofamerica.com")>-1){testString=testString.toLowerCase();var tempArr=testString.split(".bankofamerica.com");var tempStr=tempArr[0];if(tempStr.indexOf("//")>-1){tempArr=tempStr.split("//");tempStr=tempArr[1];if(tempStr.indexOf(".")>-1){tempArr=tempStr.split(".");tempStr=tempArr[0];var tempStrPt2=tempArr[1]}if(tempStr.indexOf("www")>-1){if(tempStr.indexOf("-")>-1){cmSetStaging()}else{if(tempStrPt2!=null){if(tempStrPt2.indexOf("ecnp")>-1){cmSetStaging()}}else{cmSetProduction()}}}else{if(tempStr.indexOf("-")>-1){if(tempStr.indexOf("sitekey")>-1){if(tempStr=="sitekey"){cmSetProduction()}else{cmSetStaging()}}else{cmSetStaging()}}else{if(tempStrPt2!=null){if(tempStrPt2.indexOf("ecnp")>-1){cmSetStaging()}}else{cmSetProduction()}}}}}}if(typeof cmSetStaging=="function"){cmSetDD()};
</script>




    <script type="text/javascript">
        var href = window.location.href;
        $('html')
        .on('error', function(e, err) {
            cmCreateCustomError('smbus:Content:OLBs:Payroll;payroll', null, null, null, err.code, 'smbus:Content:OLBs:Payroll', err.message);
        })
        .on('click', '[data-cm]', function() {
            cmCreateManualLinkClickTag(href, $(this).data('cm').click, cG7.cM0[cm_ClientID]);
        });
    </script>
			<script type="text/javascript">
				cmCreatePageviewTag('smbus:Content:OLBs:Payroll;payroll', null, null, 'smbus:Content:OLBs:Payroll', false, false, null, false, false, null, null, null, null, null, null, null, null, null, null, null, null);
			</script>



 
			<div itemscope="itemscope" itemtype="http://schema.org/WebPage">
					<span style="display:none" itemprop="name">Intuit� Online Payroll Services available through Bank of America Small Business</span>
					<a style="display:none" itemprop="url" href="https://www.bankofamerica.com/smallbusiness/online-banking/payroll.go"></a>
					<span style="display:none" itemprop="description">Intuit� Payroll Services available through Bank of America makes it easy for you to process your own payroll or get help from an expert.</span>
					<img style="display:none" class="no-stretch" itemprop="image" alt="Intuit� Online Payroll Services available through Bank of America Small Business" src="https://www.bankofamerica.com/content/images/ContextualSiteGraphics/Logos/en_US/Bank_of_America_Flagscape_71x71.gif">
			</div>
</div>
					</div>
				</div>
			</div>
		</div>
	</body>	
</html>

