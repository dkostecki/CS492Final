
 

				<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
				<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
				<head>


<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta http-equiv="content-type" content="text/html;charset=utf-8">





<title>Fees Associated with Bank of America Business Checking & Savings Accounts</title>

<meta name="Description" CONTENT="An overview of fees associated with checking and savings accounts from Bank of America Small Business.">
<meta name="Keywords" CONTENT="business checking fees, bank of america business checking fees, savings account fees, bank of america small business fees">

		<link rel="canonical" href="https://www.bankofamerica.com/smallbusiness/resources/fees-at-a-glance.go"/>

<link rel="shortcut icon" href="/pa/global-assets/1.0/graphic/favicon.ico" type="image/ico" />

			<link rel="stylesheet" type="text/css" href="/pa/components/bundles/gzip-compressed/xengine/APS-small-business/2017.03.0/style/bcs-aps-sb-jawr.css" media="all" />
			<script src="/pa/components/bundles/gzip-compressed/xengine/APS-small-business/2017.03.0/script/bcs-aps-sb-jawr.js" type="text/javascript"></script>
				<script type="text/javascript">
					$(window).load(function(){asyncPrintCssInclude('https://www.bankofamerica.com/pa/components/bundles/gzip-compressed/xengine/APS-small-business/2017.03.0/style/bcs-aps-sb-jawr-print.css');});
				</script>
<script type="text/javascript">
(function() {
	if (typeof mboxUpdate == "function") {
		var windowURL = window.location.href
	    windowURL = windowURL.slice( windowURL.indexOf('.')+1);
		windowURL = windowURL.split( '?' )[0];
		windowURL = windowURL.toLowerCase();
		//alert(windowURL);
		if (
		    //If no mboxes on page, mbox count will be < 1
		    (mboxFactoryDefault.getMboxes().length() < 1) &&

			//Also check for high-volume pages that do not need global logging
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go") &&
			(windowURL != "bankofamerica.com/myaccounts/signin/signin.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/entry/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signonscreen.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatechallengeanswer.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatePassword.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/mobile/banking.go")&&
			(windowURL != "bankofamerica.com/content/preload/olb-myaccount-preload-jawr-module.htm")
			)
		{

			var mboxDiv = document.createElement("div");
			mboxDiv.id = "adobe_touch_clarity_replacement";
			mboxDiv.style.display = "none";
			if (document.body && document.body.firstChild) document.body.insertBefore(mboxDiv,document.body.firstChild);
			mboxDefine(mboxDiv.id,'bac_global_bottom');
			mboxUpdate('bac_global_bottom');
		}
	}
})();
</script>

		<script src="/pa/components/bundles/gzip-compressed/xengine/Global/1.0/script/tealeafbundle.js" type="text/javascript"></script>
			<script>
				var boaPageDataJS = {};
					boaPageDataJS.isLLE = "false";
			</script>
				<style>body{display:none;}</style>
	</head>		

	<body class="fsd-layout-body">	

				<script type="text/javascript">if(self == top){var theBody=document.getElementsByTagName("body")[0];theBody.style.display="block";}else{top.location=self.location;}</script>
				<noscript><style>body{display:block;}</style></noscript>
					<a class='ada-hidden ada-visible-focus' href='#skip-to-h1' id='ada-skip-link'>Skip to main content</a>
		<div class="fsd-layout fsd-2c-700lt-layout">
			<div class="fsd-border">
				<div class="center-content">
					<div class="header">
		  



<script language="javascript" src="/pa/components/modules/tag-manager-module/1.1/script/tag-manager-module-borneo-global-skin.js"></script>
<script>

(function() {
  var fireCallback = function( cb ) {
    if ( typeof cb === "function" ) cb();
  };
  
  function ddoPopulateBase( callback ) {
    try {
		  var DDO = window.digitalData,
		  	bactm_mergeDDO = function( newDDO, priorDDO ) {
		  		if( typeof priorDDO === "undefined" ) {
				  	priorDDO = digitalData || {};
				  }

			    for (var l in newDDO) {
			        if (typeof priorDDO[l] === "undefined") {
			            priorDDO[l] = newDDO[l];
			        }
			        if (newDDO[l] !== null) {
			            if (typeof newDDO[l] === "object") {
			                bactm_mergeDDO(newDDO[l], priorDDO[l]);
			            } else {
			                priorDDO[l] = bactm_validateValue( newDDO[l] ) ? newDDO[l] : priorDDO[l];
			            }
			        }
			    }

			    return priorDDO;
				},
				bactm_olb3rdPartyId = "null";

			if (typeof DDO === "undefined") {
				var simpleDDO = { page: { pageInfo:[{ pageID: null }], attributes: {}, category: { primaryCategory: null }}};

				DDO = (typeof digitalData === "object") ? digitalData : simpleDDO; 
			}

				DDO = bactm_mergeDDO( {"pageInstanceID":"notprod","load_coremetrics":false,"load_opinionlabs":false,"load_touchcommerce":true,"load_audiencemanager":true,"page":{"pageInfo":[{"pageID":null,"destinationURL":null,"referringURL":null,"issueDate":null,"language":null,"segmentValue":null,"appName":null,"appStepNumber":null,"appStepName":null,"attr":"-_--_--_--_--_--_--_--_--_--_--_--_--_--_-"}],"category":{"primaryCategory":null,"addlCategory":null,"pageType":null},"attributes":{"searchString":null,"searchResults":null,"olbSessionID":null,"subCampaignCode":null,"DARTUrl":null,"stateCookie":null,"SASIEnabled":false,"needOLBcookie":false,"standardDART":[],"standardDARTes":[],"clickDART":[],"clickDARTes":[],"gaId":[],"chat":{"site_id":36533228,"account_type":"smallbusiness","boa_associate":null,"boa_retiree":null,"customer_lob":"sbob","customer_segment":null,"data":null,"email_campaign":null,"entitlement_code":null,"error_category":null,"error_count":null,"first_login":null,"inqSalesProductTypes":{},"invitation_background":null,"invitation_template":null,"referral_campaign":null,"getStateValue":false,"cust_fn":null,"cust_ln":null,"target":{"lpButtonDiv-Resources":"SB-Fixed15"}}}},"user":{"segment":null,"online_id":null,"preferred_rewards_tier":null,"olb3rdpartyid":null},"version":"BAC_0.12"}, DDO );

			DDO.page.pageInfo[0].pageID = "";
			DDO.page.category.primaryCategory  = "";
			DDO.page.pageInfo[0].language = "en-US";
			DDO.page.attributes.olbSessionID = "null";
			DDO.page.attributes.SASIEnabled =  "false";
			if (typeof DDO.user != "undefined" && typeof DDO.user.olb3rdpartyid != "undefined") {
				DDO.user.olb3rdpartyid = bactm_olb3rdPartyId;
			}

			window.utag_data = {};
			window.bactm_envSelector = bactm_setTMLib();
			window.digitalData = DDO;

      return fireCallback( callback );

    } catch(e) { }
  }
	if( window.boa && window.boa.digitalData ) {
    window.boa.digitalData.register( ddoPopulateBase );
	}
	else {
	  // Handle scenario where the header isn't available (and thus the default digitalData object and utag loader are missing).
	  //
		var writeScript = function(a,b,c,d){
			a='//tags.tiqcdn.com/utag/bofa/main/' + bactm_envSelector + '/utag.js';
			b=document;
			c='script';
			d=b.createElement(c);
			d.src=a;
			d.type='text/java'+c;
			d.async=true;
			a=b.getElementsByTagName(c)[0];
			a.parentNode.insertBefore(d,a);
		};

		ddoPopulateBase( writeScript );
	}
})();			
</script>



	
	
		
			<noscript>
				<div class="fauxdal-overlay"></div>
				<div class="fauxdal-module">
					<div class="js-disabled-skin">
						<div class="fauxdal-top"></div>
						<div class="fauxdal-bottom">
							<div class="fsd-fauxdal-content">
									<div class="fsd-fauxdal-title">
										Please Use JavaScript
									</div>
										<p>You need a web browser that supports JavaScript to use our site. Without it, some pages won&rsquo;t work as designed. To make sure JavaScript is turned on, please adjust your browser settings.</p>
<p><a name="Browser_Help_And_Tips" href="/onlinebanking/online-banking-security-faqs.go" target="_blank">Browser Help and Tips</a></p>
							</div>        
							<div class="fsd-fauxdal-close"> 
								<a class="btn-bofa btn-bofa-small" name="close_button_js_disabled_modal" href=?js=y>Close</a>
							</div>
							<div class="clearboth"></div>
						</div>
					</div>
				</div>
			</noscript>



 


<div class="header-module">
	<div class="text-w-logo-skin">
		<div class="header-left">
	  
			<div itemscope itemtype="http://schema.org/Corporation" class="bofa-logo">
				<a itemprop="url" name="anc-business-advantage" title="Bank of America Small Business" href="/smallbusiness/index.jsp">
					<img itemprop="logo" height="28" width="221" 
					     alt="Bank of America Small Business" src="/content/images/ContextualSiteGraphics/Logos/en_US/boa_logo.gif"/>
				</a>
			</div>
				<div class="product" data-font="cnx-regular">Business Advantage</div>
			
			<div class="clearboth"></div>

		</div>
		
		<div class="header-right">
			<ul class="header-links">
			
				
					
				
							<li class="sign-in">
		<a					href="/sitemap/hub/signin.go" target="_self"
		name="Sign_In">Sign In</a> 
							</li>
					
				
							<li>		<a					href="/smallbusiness/index.jsp" target="_self"
		name="Home_Header">Home</a> 
</li>
					
				
							<li>		<a					href="https://locators.bankofamerica.com " target="_self"
		name="Locations">Locations</a> 
</li>
					
				
							<li>		<a					href="/contactus/contactus.go?topicId=small_business_banking" target="_self"
		name="Contact_Us">Contact Us</a> 
</li>
					
				
							<li class="last-link">	
		<a					href="/help/" target="_self"
		name="Help">Help</a> 
							</li>
			</ul>
			
			<div class="clearboth"></div>

			<!-- include search-dotcom-util -->



<div class="header-search nlh">
  
  <div class="nav-search">
    <form class="search-form" action="https://secure.bankofamerica.com/myaccounts/public/search-results/unAuthenticatedSearch.go" data-js="/pa/components/utilities/search-util/1.0/script/nav-search.min.js" data-css="/pa/components/utilities/search-util/1.0/style/nav-search.css" data-text-unavailable="Search Currently Unavailable">
      <div class="search-input-container cf" data-icon="search">
        <label for="nav-search-query" class="ada-hidden">Search Term</label>
        <input type="text" placeholder="How can we help you?" name="query" class="search-query" id="nav-search-query" 
          maxlength="99" rel="Search" autocomplete="off"><input type="submit" alt="Search" title="Search" value="Submit Search" name="Search Module - Top Result – Search Button" class="submit track-me">
      </div>
    </form>
  </div>

</div>

		</div>

 		<div class="clearboth"></div>
 	</div>
</div>







	<div class="top-nav-module">
		<div class="fsd-skin sup-ie">
			<ul class="nav-list">
					
					
					<li>
						
								<a href="/smallbusiness/deposits/checking-accounts/" class="top-menu-item"
								name="business_checking_topnav" id="business_checking_topnav">Business Checking<span class="ada-hidden"> &nbsp;link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/smallbusiness/deposits/checking-accounts/business-advantage/"  name="business_advantage_topnav" id="business_advantage_topnav">Business Advantage </a>
															<a href="/smallbusiness/deposits/checking-accounts/business-fundamentals/"  name="business_fundamentals_topnav" id="business_fundamentals_topnav">Business Fundamentals<sup>&reg;</sup> </a>
															<a href="/smallbusiness/business-debit-card.go"  name="business_debit_card_topnav" id="business_debit_card_topnav">Business Debit Card </a>
									</div>
								
									<span class="ada-hidden"> End of submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
					
					
					<li>
						
								<a href="/smallbusiness/cd-savings-accounts.go" class="top-menu-item"
								name="business_savings_and_cds_topnav" id="business_savings_and_cds_topnav">Business Savings & CDs<span class="ada-hidden"> &nbsp;link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/smallbusiness/savings-accounts/business-interest-maximizer.go"  name="business_interest_maximizer_topnav" id="business_interest_maximizer_topnav">Business Interest Maximizer&trade; </a>
															<a href="/smallbusiness/savings-accounts/business-investment-account.go"  name="business_investment_account_topnav" id="business_investment_account_topnav">Business Investment Account </a>
															<a href="/smallbusiness/cds/business-featured-cd.go"  name="business_featured_cd_topnav" id="business_featured_cd_topnav">Business Featured CD </a>
															<a href="/smallbusiness/cds/risk-free-cd.go"  name="business_risk_free_cd_topnav" id="business_risk_free_cd_topnav">Business Risk Free CD<sup>&reg;</sup> </a>
															<a href="/smallbusiness/standard-cds.go"  name="cds_topnav" id="cds_topnav">Standard Business CD </a>
									</div>
								
									<span class="ada-hidden"> End of submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
					
					
					<li>
						
								<a href="javascript:void(0);" class="top-menu-item"
								name="manage_accounts_topnav" id="manage_accounts_topnav">Manage Your Account<span class="ada-hidden"> &nbsp;link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/smallbusiness/online-banking.go"  name="online_banking_topnav" id="online_banking_topnav">Online Banking </a>
															<a href="/smallbusiness/online-banking/cash-management.go"  name="business_tools_topnav" id="business_tools_topnav">Business Tools </a>
									</div>
								
									<span class="ada-hidden"> End of submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
					
					
					<li>
						
								<a href="javascript:void(0);" class="top-menu-item selected"
								name="resources_topnav" id="resources_topnav">Resources<span class="ada-hidden"> &nbsp;link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/smallbusiness/resources/faqs.go"  name="faqs_topnav" id="faqs_topnav">FAQs </a>
															<a href="/smallbusiness/resources/glossary.go"  name="glossary_topnav" id="glossary_topnav">Glossary </a>
															<a href="/smallbusiness/resources/fees-at-a-glance.go"  name="fees_at_a_glance_topnav" id="fees_at_a_glance_topnav">Fees at a Glance </a>
															<a href="/deposits/bank-account-interest-rates/?flow=BCS"  name="account_rates_topnav" id="account_rates_topnav">Account Rates </a>
															<a href="/smallbusiness/platinum-privileges.go"  name="business_platinum_privileges_topnav" id="business_platinum_privileges_topnav">Business Platinum Privileges&trade; </a>
															<a href="/smallbusiness/resources/overdraft-protection.go"  name="overdraft_protection_topnav" id="overdraft_protection_topnav">Overdraft Protection </a>
									</div>
								
									<div class="hasSub">
														<a class="with-info" href="/smallbusiness/education.go"  name="managing_a_small_business_topnav" id="managing_a_small_business_topnav">Managing A Small Business 
															
															<span class="sub-nav-item-info">Articles, tips and tools to help you and your business grow</span>
														</a>
														<a class="with-info" href="/smallbusiness/online-banking/business-services.go"  name="popular_service_combinations_topnav" id="popular_service_combinations_topnav">Popular service combinations 
															
															<span class="sub-nav-item-info">See how business checking solutions combined with Online Banking services can help your business</span>
														</a>
									</div>
									<span class="ada-hidden"> End of submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
			</ul>
				<div class="clearboth"></div>
		</div>
	</div>


	
 
<div class="page-title-fsd-module h-100" id="skip-to-h1">
	<div class="prod-indicator-skin sup-ie">
		<div class="full-width-wrapper">
			<h1 data-font="cnx-regular">Fees at a Glance</h1>	

			

			<div class="clearboth"></div>
		</div>
  	</div>
</div>





	
<div class="live-person-bdf-module">
   <div class="bcs-skin">
    
     	<a href="javascript:window.print();" name="print">PRINT<span class="ada-hidden">  this page</span></a> 
    
	
		<div id="lpButtonDiv-Resources">
		</div>
		
	
   </div>
</div>

</div>
					<div class="columns">
						<div class="flex-col lt-col" >






<div class="tab-group-content-module">
    <div class="hide-show-skin sup-ie table-vzd3-common">	
		<p class="plt-15 pbtm-15">Effective: April 14,2017</p>
	
     <div id="group-tabs" class="ui-tabs">
        <ul id="section-tabs" class="tab-holder ui-helper-clearfix">
				<li class="css3-pie"><a href="#tabs-1" name="accountFees_tab_link">Account Fees</a></li>
				<li class="css3-pie"><a href="#tabs-2" name="serviceFeesOtherInfo_tab_link">Service Fees & Other Information</a></li>
        </ul>
	<div class="clearboth"><!--  --></div>	
	<!-- feeWaivedIndiactor added for all the fields from eprod/cdm -->	
			
					<div id="tabs-1" class="accordion-group">
		  <h3><a href="javascript:void(0);" name="Checking_Accounts">Checking Accounts</a></h3>
          
		  <div class="accordion-section">
		  	<div class="accordion-inner">
				<a href="javascript:void(0);" class="show-all" name="checkingAccounts_showAll_link">Show All<span class="ada-hidden">&nbsp;content</span></a>
				<span>&nbsp;|&nbsp;</span>
				<a href="javascript:void(0);" class="hide-all" name="checkingAccounts_hideAll_link">Hide All<span class="ada-hidden">&nbsp;content</span></a>
				<ul class="question-group">					
						
						
						
							
					    <li><a href="javascript:void(0);" class="tab-content-link" name="Business_Fundamentals<sup>reg;</sup>"><span class="ada-hidden ada-action">Hide </span>Business Fundamentals<sup>&reg;</sup></a>
							<div class="content-area">
								<p class="bold">Fee Type:&nbsp;Monthly fee</p>
							  
								<p class="bold">Fee:&nbsp;
									<span class="urgent-info">$15</span>
								</p>
											<p>Pay no monthly maintenance fee for Business Fundamentals when you meet one of the following requirements each statement cycle:</p>
<ul>
<li>Spending $250 per month in new purchases using a linked Bank of America business debit or credit card</li>
<li>Maintaining a minimum daily balance of $3,000</li>
<li>Maintaining an average monthly balance of $5,000</li>
<li>Maintaining a combined average monthly balance of $15,000&nbsp; in linked accounts</li>
</ul>
							 </div>
						  </li>
						
						
						
							
					    <li><a href="javascript:void(0);" class="tab-content-link" name="Business_Advantage"><span class="ada-hidden ada-action">Hide </span>Business Advantage</a>
							<div class="content-area">
								<p class="bold">Fee Type:&nbsp;Monthly fee</p>
							  
								<p class="bold">Fee:&nbsp;
									<span class="urgent-info">$29.95</span>
								</p>
											<p>Pay no monthly maintenance fee for Business Advantage when you meet one of the following requirements each statement cycle:</p>
<ul>
<li>Spending $2,500 per month in new purchases using a linked Bank of America business credit card</li>
<li>Qualifying active use of Bank of America Merchant Services or Payroll Services</li>
<li>Maintaining an average monthly balance of $15,000</li>
<li>Maintaining a combined average monthly balance of $35,000&nbsp; in linked business accounts</li>
</ul>
							 </div>
						  </li>
						
						
						
							
					    <li><a href="javascript:void(0);" class="tab-content-link" name="Business_Interest_Checking"><span class="ada-hidden ada-action">Hide </span>Business Interest Checking</a>
							<div class="content-area">
								<p class="bold">Fee Type:&nbsp;Monthly maintenance fee</p>
							  
								<p class="bold">Fee:&nbsp;
									<span class="urgent-info">$16</span>
								</p>
													<p>To prevent this fee, maintain at least one of the following balances:</p>
<ul>
<li>$5,000 minimum daily balance</li>
<li>$10,000 average monthly balance</li>
<li>$10,000 combined minimum daily balance</li>
<li>$20,000 combined average monthly balance</li>
</ul>

												
							 </div>
						  </li>
						
						
						
							
					    <li><a href="javascript:void(0);" class="tab-content-link" name="Full_Analysis_Business_Checking"><span class="ada-hidden ada-action">Hide </span>Full Analysis Business Checking</a>
							<div class="content-area">
							  
								<p class="bold urgent-info">For pricing and fee details, please call the number on the front of your deposit statement.</p>
											<p>A cost-effective analyzed account for businesses with high checking balances to offset some or all monthly fees and greater banking-service needs. Full Analysis Business Checking is designed for larger businesses that:</p>
<ul>
<li>Have high checking balances, typically greater than $60,000</li>
<li>Have more than 400 checks paid and 200 deposited items each month</li>
<li>Use Treasury Management services, such as Electronic Positive Pay and Automated Clearing House (ACH) services</li>
</ul>
							 </div>
						  </li>
						
						
						
							
					    <li><a href="javascript:void(0);" class="tab-content-link" name="Public_Service_Trust_Account"><span class="ada-hidden ada-action">Hide </span>Public Service Trust Account</a>
							<div class="content-area">
							  
								<p class="bold urgent-info">Any fees are deducted from interest.</p>
											<ul>
<li>This account complies with the requirements of the IOLTA program for the state where it is opened.</li>
<li>Interest, less permissible fees, is paid to the state program.</li>
<li>You are responsible for fees that the state program does not permit to be paid from the interest. Consult your financial advisor about your state's requirements.</li>
</ul>
							 </div>
						  </li>
				 </ul>
          	</div>
          </div>
						
		  
			
		  <h3><a href="javascript:void(0);" name="Savings_Accounts">Savings Accounts</a></h3>
          
		  <div class="accordion-section">
		  	<div class="accordion-inner">
				<a href="javascript:void(0);" class="show-all" name="savingsAccounts_showAll_link">Show All<span class="ada-hidden">&nbsp; content</span></a>
				<span>&nbsp;|&nbsp;</span>
				<a href="javascript:void(0);" class="hide-all" name="savingsAccounts_hideAll_link">Hide All<span class="ada-hidden">&nbsp; content</span></a>
				<ul class="question-group">					
						
						
						
							
					    <li><a href="javascript:void(0);" class="tab-content-link" name="Business_Interest_Maximizertrade;"><span class="ada-hidden ada-action">Hide </span>Business Interest Maximizer&trade;</a>
							<div class="content-area">
								<p class="bold">Fee Type:&nbsp;Monthly maintenance fee</p>
							  
								<p class="bold">Fee:&nbsp;
									<span class="urgent-info">$15</span>
								</p>
											<p>To prevent this fee, maintain the following balance:</p>
<ul>
<li>$5,000 minimum daily balance</li>
</ul>
							 </div>
						  </li>
						
						
						
							
					    <li><a href="javascript:void(0);" class="tab-content-link" name="Business_Investment_Account"><span class="ada-hidden ada-action">Hide </span>Business Investment Account</a>
							<div class="content-area">
								<p class="bold">Fee Type:&nbsp;Monthly maintenance fee</p>
							  
								<p class="bold">Fee:&nbsp;
									<span class="urgent-info">$5</span>
								</p>
											<p>To prevent this fee, maintain the following balance:</p>
<ul>
<li>$2,500 minimum daily balance</li>
</ul>
							 </div>
						  </li>
				 </ul>
          	</div>
          </div>
						
		  
			
		  <h3><a href="javascript:void(0);" name="Time_Deposits/CDs">Time Deposits/CDs</a></h3>
          
		  <div class="accordion-section">
		  	<div class="accordion-inner">
				<a href="javascript:void(0);" class="show-all" name="timeDeposits_showAll_link">Show All<span class="ada-hidden">&nbsp; content</span></a>
				<span>&nbsp;|&nbsp;</span>
				<a href="javascript:void(0);" class="hide-all" name="timeDeposits_hideAll_link">Hide All<span class="ada-hidden">&nbsp; content</span></a>
				<ul class="question-group">					
						
						
						
							
					    <li><a href="javascript:void(0);" class="tab-content-link" name="CD_Terms_of_7 days_mdash;_27 days"><span class="ada-hidden ada-action">Hide </span>CD Terms of 7 days &mdash; 27 days</a>
							<div class="content-area">
							  
								<p class="bold urgent-info">A penalty is imposed for early withdrawal.</p>
											<p><strong>A $15,000 minimum deposit is needed to open an account.</strong></p>
<ul>
<li>This account features a fixed interest rate until maturity.</li>
<li>No additional deposits can be made until maturity.</li>
<li>Automatically renews at maturity unless you choose the single maturity option. Single maturity CDs will not earn interest after the maturity date.</li>
</ul>
							 </div>
						  </li>
						
						
						
							
					    <li><a href="javascript:void(0);" class="tab-content-link" name="CD_Terms_of_28 days_mdash;_10 years"><span class="ada-hidden ada-action">Hide </span>CD Terms of 28 days &mdash; 10 years</a>
							<div class="content-area">
							  
								<p class="bold urgent-info">A penalty is imposed for early withdrawal.</p>
											<p><strong>A $1,000 minimum deposit is needed to open an account.</strong></p>
<p>For CDs with terms longer than 31 days, we will send you a maturity notice prior to renewal. Please read it carefully. If we change the type, term or any other features of your CD, you will be advised of these changes in the maturity notice.</p>
<ul>
<li>This account features a fixed interest rate until maturity.</li>
<li>No additional deposits can be made until maturity.</li>
<li>Automatically renews at maturity unless you choose the single maturity option. Single maturity CDs will not earn interest after the maturity date.</li>
</ul>
							 </div>
						  </li>
						
						
						
							
					    <li><a href="javascript:void(0);" class="tab-content-link" name="Business_Risk_Free_CD<sup>reg;</sup>"><span class="ada-hidden ada-action">Hide </span>Business Risk Free CD<sup>&reg;</sup></a>
							<div class="content-area">
							  
								<p class="bold urgent-info">There is no penalty for withdrawals made any time after the first six days that the CD is open, or within six days of an earlier partial withdrawal.</p>
											<p><strong>$5,000 minimum deposit is needed to open an account.</strong></p>
<ul>
<li>This account features a fixed interest rate until maturity.</li>
<li>Automatically renews.</li>
<li>No additional deposits can be made until maturity.</li>
<li>Prior to renewal, we will send you a maturity notice. Please read it carefully. If we change the type, term or any other features of your CD, you will be advised of these changes in the maturity notice.</li>
</ul>
							 </div>
						  </li>
				 </ul>
          	</div>
          </div>
						
				 </div>
		  
			
					<div id="tabs-2" class="accordion-group">
		  <h3><a href="javascript:void(0);" name="Checking_Accounts">Checking Accounts</a></h3>
          
		  <div class="accordion-section">
		  	<div class="accordion-inner">
				<a href="javascript:void(0);" class="show-all" name="checkingAcctsOtherFees_showAll_link">Show All<span class="ada-hidden">&nbsp; content</span></a>
				<span>&nbsp;|&nbsp;</span>
				<a href="javascript:void(0);" class="hide-all" name="checkingAcctsOtherFees_hideAll_link">Hide All<span class="ada-hidden">&nbsp; content</span></a>
				<ul class="question-group">					
						
						
						
							
					    <li><a href="javascript:void(0);" class="tab-content-link" name="Business_Fundamentals<sup>reg;</sup>"><span class="ada-hidden ada-action">Hide </span>Business Fundamentals<sup>&reg;</sup></a>
							<div class="content-area">
							  
													<table border="0" summary="Business Fundamentals Information">
<thead>
<tr><th scope="col">Fee Type</th><th scope="col">Fee</th></tr>
</thead>
<tbody>
<tr>
<td>Transactions including: Checks paid/Other debits/Deposited items&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
<td>No fee for first 200 transactions per statement cycle; $0.45 per item thereafter</td>
</tr>
<tr>
<td>
<p></p>
<p>Cash Deposit Processing</p>
</td>
<td>
<p></p>
<p></p>
<p>No fee for first $7,500 in cash deposited per statement cycle; then $0.30 per $100 deposited thereafter</p>
</td>
</tr>
</tbody>
</table>
							 </div>
						  </li>
						
						
						
							
					    <li><a href="javascript:void(0);" class="tab-content-link" name="Business_Advantage"><span class="ada-hidden ada-action">Hide </span>Business Advantage</a>
							<div class="content-area">
							  
													<table border="0" summary="Business Advantage Information">
<thead>
<tr><th scope="col">Fee Type</th><th scope="col">Fee</th></tr>
</thead>
<tbody>
<tr>
<td>Transactions including: Checks paid/Other debits/Deposited items&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
<td>No fee for first 500 transactions per statement cycle; $0.45 per item thereafter</td>
</tr>
<tr>
<td><br />Cash Deposit Processing</td>
<td>
<p></p>
<p>No fee for first $20,000 in cash deposited per statement cycle; then $0.30 per $100 deposited thereafter</p>
</td>
</tr>
</tbody>
</table>
							 </div>
						  </li>
						
						
						
							
					    <li><a href="javascript:void(0);" class="tab-content-link" name="Business_Interest_Checking"><span class="ada-hidden ada-action">Hide </span>Business Interest Checking</a>
							<div class="content-area">
							  
													<p>You may link this account to your business checking account for overdraft protection on the checking account. After doing so, the business checking account will be protected from overdraft fees if sufficient funds are in the linked savings.</p>
<p>Point-of-sale transactions include use of your debit card to pay for goods and services.</p>
<table summary="Business Interest Maximizer Information" border="0">
<thead>
<tr><th scope="col">Fee Type</th><th scope="col">Fee</th></tr>
</thead>
<tbody>
<tr>
<td>Transactions including: Checks paid/Other debits/Deposited items</td>
<td>No fee for first 150 transactions per statement cycle; $0.45 per item thereafter</td>
</tr>
<tr>
<td>
<p></p>
<p>Cash Deposit Processing</p>
</td>
<td>
<p></p>
<p></p>
<p>No fee for first $7,500 in cash deposited per statement cycle; then $0.30 per $100 deposited thereafter</p>
</td>
</tr>
</tbody>
</table>
							 </div>
						  </li>
						
						
						
							
					    <li><a href="javascript:void(0);" class="tab-content-link" name="Full_Analysis_Business_Checking"><span class="ada-hidden ada-action">Hide </span>Full Analysis Business Checking</a>
							<div class="content-area">
							  
								<p class="bold urgent-info">For pricing and fee details, please call the number on the front of your deposit statement.</p>
							 </div>
						  </li>
						
						
						
							
					    <li><a href="javascript:void(0);" class="tab-content-link" name="Public_Service_Trust_Account"><span class="ada-hidden ada-action">Hide </span>Public Service Trust Account</a>
							<div class="content-area">
							  
								<p class="bold urgent-info">Any fees are deducted from interest.</p>
							 </div>
						  </li>
				 </ul>
          	</div>
          </div>
						
		  
			
		  <h3><a href="javascript:void(0);" name="Savings_Accounts">Savings Accounts</a></h3>
          
		  <div class="accordion-section">
		  	<div class="accordion-inner">
				<a href="javascript:void(0);" class="show-all" name="savingsAcctsOtherFees_showAll_link">Show All<span class="ada-hidden">&nbsp; content</span></a>
				<span>&nbsp;|&nbsp;</span>
				<a href="javascript:void(0);" class="hide-all" name="savingsAcctsOtherFees_hideAll_link">Hide All<span class="ada-hidden">&nbsp; content</span></a>
				<ul class="question-group">					
						
						
						
							
					    <li><a href="javascript:void(0);" class="tab-content-link" name="Business_Interest_Maximizertrade;"><span class="ada-hidden ada-action">Hide </span>Business Interest Maximizer&trade;</a>
							<div class="content-area">
							  
													<p>You may link this account to your business checking account for overdraft protection on the checking account. After doing so, the business checking account will be protected from overdraft fees if sufficient funds are in the linked savings.</p>
<p>Point-of-sale transactions include use of your debit card to pay for goods and services.</p>
<table border="0" summary="Business Interest Maximizer Information">
<thead>
<tr><th scope="col">Fee Type</th><th scope="col">Fee</th></tr>
</thead>
<tbody>
<tr>
<td><br />Cash Deposit Processing</td>
<td>
<p></p>
<p>No fee for first $5,000 in cash deposited per statement cycle; then $0.30 per $100 deposited thereafter</p>
</td>
</tr>
<tr>
<td>Deposited Items</td>
<td>No fee for first 25 transactions per statement cycle; $0.45 per item thereafter</td>
</tr>
</tbody>
</table>
							 </div>
						  </li>
						
						
						
							
					    <li><a href="javascript:void(0);" class="tab-content-link" name="Business_Investment_Account"><span class="ada-hidden ada-action">Hide </span>Business Investment Account</a>
							<div class="content-area">
							  
													<p>You may link this account to your business checking account for overdraft protection on the checking account. After doing so, the business checking account will be protected from overdraft fees if sufficient funds are in the linked savings.</p>
<p>You may write checks on this account up to a total of 3 checks and point-of-sale transactions each statement cycle.</p>
<ul>
<li>A Business ATM Card lets you access Bank of America ATMs to make deposits, withdrawals or transfers.</li>
<li>A Business Deposit Card lets you or your employees make deposits to your business checking or savings accounts at Bank of America ATMs.</li>
</ul>
<table border="0" summary="Business Investment Account Information">
<thead>
<tr><th scope="col">Fee Type</th><th scope="col">Fee</th></tr>
</thead>
<tbody>
<tr>
<td><br />Cash Deposit Processing &nbsp; &nbsp;</td>
<td>
<p></p>
<p>No fee for first $5,000 in cash deposited per statement cycle; then $0.30 per $100 deposited thereafter</p>
</td>
</tr>
<tr>
<td>Deposited Items</td>
<td>No fee for first 25 transactions per statement cycle; $0.45 per item thereafter</td>
</tr>
</tbody>
</table>
							 </div>
						  </li>
				 </ul>
          	</div>
          </div>
						
		  
			
		  <h3><a href="javascript:void(0);" name="Other_Account_Fees_and_Services">Other Account Fees and Services</a></h3>
          
		  <div class="accordion-section">
		  	<div class="accordion-inner">
				<a href="javascript:void(0);" class="show-all" name="otherAcctFeesServices_showAll_link">Show All<span class="ada-hidden">&nbsp; content</span></a>
				<span>&nbsp;|&nbsp;</span>
				<a href="javascript:void(0);" class="hide-all" name="otherAcctFeesServices_hideAll_link">Hide All<span class="ada-hidden">&nbsp; content</span></a>
				<ul class="question-group">					
						
						
						
							
					    <li><a href="javascript:void(0);" class="tab-content-link" name="Analyzed_Accounts"><span class="ada-hidden ada-action">Hide </span>Analyzed Accounts</a>
							<div class="content-area">
							  
											<p>Please note: Separate fees apply to analyzed accounts.</p>
							 </div>
						  </li>
						
						
						
							
					    <li><a href="javascript:void(0);" class="tab-content-link" name="ATM"><span class="ada-hidden ada-action">Hide </span>ATM</a>
							<div class="content-area">
							  
											<p><span class="bold">Fee Type: Bank of America ATM</span> (an ATM that prominently displays the Bank of America name and logo)</p>
<p class="bold">Fee: <span class="urgent-info">No fee</span></p>
<p>Fee for withdrawals, deposits, transfers, payments and balance inquiries at a Bank of America ATM</p>
<ul class="pbtm-10">
<li>Deposits and payments may not be available at some ATMs.</li>
<li>Transaction fees may apply to some accounts. See the disclosure information that accompanied your card for other fees that may apply. To obtain a copy of that information, call the number on your statement or visit your nearest banking center.</li>
</ul>
<p><span class="bold">Fee Type: Non-Bank of America ATM</span> (an ATM that does not prominently display the Bank of America name and logo)</p>
<p class="bold">Fee: <span class="urgent-info">$2.50 per transaction</span></p>
<p class="pbtm-10">Fee for withdrawals, transfers and balance inquiries at a non-Bank of America ATM located in the United States.</p>
<p class="bold">Fee Type: Fee for withdrawals, transfers and balance inquiries at a non-Bank of America ATM located in a foreign country.</p>
<p class="bold">Fee: <span class="urgent-info">$5 per transaction</span></p>
<p>Please note:</p>
<ul>
<li>When you use a non-Bank of America ATM, you may also be charged a fee by the ATM operator or any network used and you may be charged a fee for a balance inquiry even if you do not complete a funds transfer.</li>
<li>Non-Bank of America ATM fees are in addition to other account fees that may apply to the transaction, such as the fee for an excess withdrawal from savings.</li>
</ul>
<p>See the disclosure information that accompanied your card for other fees that may apply. To obtain a copy of that information, call the number on your statement or visit your nearest banking center.</p>
<p>The non-Bank of America ATM fees do not apply at some ATMs located outside the United States. You will not pay a transaction fee when you use ATMs of our Global Alliance partner banks in the following countries:</p>
<ul>
<ul>
<li>Barclays (United Kingdom)</li>
<li>BNP Paribas (France)</li>
<li>China Construction Bank (China)</li>
<li>Deutsche Bank (Germany)</li>
<li>Scotiabank (Canada and Mexico)</li>
<li>Westpac (Australia and New Zealand)</li>
Note: Participation in this program is subject to change, please review participating Financial Institutions prior to travelling internationally and using International Partner ATMs.</ul>
</ul>
							 </div>
						  </li>
						
						
						
							
					    <li><a href="javascript:void(0);" class="tab-content-link" name="Cash_Processing"><span class="ada-hidden ada-action">Hide </span>Cash Processing</a>
							<div class="content-area">
							  
											<p class="bold">Fee Type: Bulk Coin</p>
<p class="bold">Fee: <span class="urgent-info">No fee</span></p>
<p>Fee for withdrawals, deposits, transfers, payments and balance inquiries at a Bank of America ATM</p>
<p>Full Fed bag (bags containing loose coin in standard amounts ready for shipment to the Federal Reserve)</p>
<p>Standard coin amounts:</p>
<ul class="pbtm-10">
<li>Quarters - $1,000</li>
<li>Dimes - $1,000</li>
<li>Nickels - $200</li>
<li>Pennies - $50</li>
</ul>
<p class="bold">Fee Type: Mixed denomination bag (loose coin/partial bags)</p>
<p class="bold">Fee: <span class="urgent-info">No fee<br /></span></p>
<p>&nbsp;</p>
							 </div>
						  </li>
						
						
						
							
					    <li><a href="javascript:void(0);" class="tab-content-link" name="Check_Cashing"><span class="ada-hidden ada-action">Hide </span>Check Cashing</a>
							<div class="content-area">
							  
											<p>Please note: A payee presenting a check that you issued may be assessed a fee if the payee is not a Bank of America customer.</p>
<p>Business Checking account holders can agree to assume the responsibility for this fee on behalf of their payee(s) &mdash; an analyzed account is required to do so. Please visit your banking center or call the number on the front of your deposit statement to learn more about alternatives.</p>
<table border="0" summary="Check Cashing Information">
<thead>
<tr><th scope="col">Fee Type</th><th scope="col">Fee</th></tr>
</thead>
<tbody>
<tr>
<td>Bank of America customer</td>
<td>No fee</td>
</tr>
<tr>
<td>Non-relationship customer
<ul>
<li>Checks drawn on Bank of America business accounts</li>
</ul>
</td>
<td>$8 per check</td>
</tr>
</tbody>
</table>
							 </div>
						  </li>
						
						
						
							
					    <li><a href="javascript:void(0);" class="tab-content-link" name="Check_Image_Service_Fee"><span class="ada-hidden ada-action">Hide </span>Check Image Service Fee</a>
							<div class="content-area">
							  
								<p class="bold">Fee:&nbsp;
									<span class="urgent-info">$3 per statement cycle (Fee waived for Business Advantage accounts)</span>
								</p>
											<ul>
<li>We provide you with images of the front and back of your canceled checks with your monthly statement.</li>
<li>Each account statement includes images of checks (up to five per page) that posted to your account during the statement cycle.</li>
<li>We do not return your cancelled checks.</li>
<li>Our Online Banking service allows you to view and print copies of checks that posted to your account within the last 12 months. Or you can request check copies by visiting your nearest Bank of America banking center, or calling the customer service number on your statement.</li>
</ul>
							 </div>
						  </li>
						
						
						
							
					    <li><a href="javascript:void(0);" class="tab-content-link" name="Check_Safekeeping_Services"><span class="ada-hidden ada-action">Hide </span>Check Safekeeping Services</a>
							<div class="content-area">
							  
								<p class="bold">Fee:&nbsp;
									<span class="urgent-info">No fee</span>
								</p>
											<ul>
<li>We store copies of cancelled checks for seven years and do not return them with your statement.</li>
<li>Our Online Banking service allows you to view and print copies of checks that posted to your account within the last 90 days.</li>
</ul>
							 </div>
						  </li>
						
						
						
							
					    <li><a href="javascript:void(0);" class="tab-content-link" name="Check_Copy_Fee"><span class="ada-hidden ada-action">Hide </span>Check Copy Fee</a>
							<div class="content-area">
							  
											<table border="0" summary="Copy Fee Information">
<thead>
<tr>
<th scope="col">Fee Type</th><th scope="col">Fee</th>
</tr>
</thead>
<tbody>
<tr>
<td>Check copies: 
<ul>
<li>No fee for the first 2 copies of each request. After 2 copies there is a $3 fee for each copy, up to a maximum of $75 per request. This fee does not apply to accounts opened in Massachusetts and New Hampshire.</li>
<li>You can often avoid this fee by viewing and printing your available checks in Online Banking. To determine what checks are available, please sign into Online Banking, and select the Activity tab.</li>
</ul>
</td>
<td>$3</td>
</tr>
<tr>
<td>Deposit slips and other credit items</td>
<td>$3</td>
</tr>
</tbody>
</table>
							 </div>
						  </li>
						
						
						
							
					    <li><a href="javascript:void(0);" class="tab-content-link" name="Debit_Card_Fees"><span class="ada-hidden ada-action">Hide </span>Debit Card Fees</a>
							<div class="content-area">
							  
											<p class="bold">Fee Type: Replacement ATM or Debit Card Fee</p>
<p class="bold">Fee: <span class="urgent-info">$5 per card</span></p>
<p>Fee for each requested replacement of an ATM card or debit card, including the replacement of a debit sticker (tag) or other debit access device. The replacement fee does not apply when we replace a card upon its expiration.</p>
<p class="pbtm-10">Bank of America Advantage&reg; accounts qualify for a waiver of this fee.</p>
<p class="bold">Fee Type: Rush Replacement ATM or Debit Card Fee</p>
<p class="bold">Fee: <span class="urgent-info">$15</span></p>
<p>Fee for each requested rush delivery of an ATM card or debit card, including the requested rush delivery of a debit sticker (tag) or other debit access device. A replacement ATM card or debit card fee may also apply and would be in addition to the rush delivery fee.</p>
<p>Bank of America Advantage&reg; accounts qualify for a waiver of this fee.</p>
							 </div>
						  </li>
						
						
						
							
					    <li><a href="javascript:void(0);" class="tab-content-link" name="Deposit_Bags"><span class="ada-hidden ada-action">Hide </span>Deposit Bags</a>
							<div class="content-area">
							  
											<table border="0" summary="Deposit Bags Information">
<thead>
<tr>
<th scope="col">Fee Type</th><th scope="col">Fee</th>
</tr>
</thead>
<tbody>
<tr>
<td>Quick Business Deposit<sup>&reg;</sup> (QBD<sup>&reg;</sup>) bag processing, with sealable plastic bag to hold checks and cash for deposit</td>
<td>No fee</td>
</tr>
<tr>
<td>Canvas Bag Processing (lockable canvas bag to holds checks and cash for deposit)</td>
<td>
<p>No fee</p>
</td>
</tr>
<tr>
<td>Plastic Deposit Bags Purchase (plastic bags used for QBD service and deposit processing)</td>
<td>At cost</td>
</tr>
</tbody>
</table>
							 </div>
						  </li>
						
						
						
							
					    <li><a href="javascript:void(0);" class="tab-content-link" name="Deposited_Item_Recleared"><span class="ada-hidden ada-action">Hide </span>Deposited Item Recleared</a>
							<div class="content-area">
							  
								<p class="bold">Fee:&nbsp;
									<span class="urgent-info">$14 each item</span>
								</p>
							 </div>
						  </li>
						
						
						
							
					    <li><a href="javascript:void(0);" class="tab-content-link" name="Deposited_Item_Returned_or_Cashed_Item_Returned"><span class="ada-hidden ada-action">Hide </span>Deposited Item Returned or Cashed Item Returned</a>
							<div class="content-area">
							  
											<table border="0" summary="Deposited Item Returned or Cashed Item Returned Information">
<thead>
<tr>
<th scope="col">Fee Type</th><th scope="col">Fee</th>
</tr>
</thead>
<tbody>
<tr>
<td>Domestic deposited item returned</td>
<td>$12 per item</td>
</tr>
<tr>
<td>Foreign deposited item returned</td>
<td>$15 per item</td>
</tr>
</tbody>
</table>
							 </div>
						  </li>
						
						
						
							
					    <li><a href="javascript:void(0);" class="tab-content-link" name="Non-Bank_of_America_Teller_Withdrawal"><span class="ada-hidden ada-action">Hide </span>Non-Bank of America Teller Withdrawal</a>
							<div class="content-area">
							  
								<p class="bold">Fee:&nbsp;
									<span class="urgent-info">$5.00  per withdrawal OR 3% of the dollar amount of the transaction, whichever is greater</span>
								</p>
											<p>Fee applies when you use a teller at another bank to withdraw cash using your debit card.</p>
							 </div>
						  </li>
						
						
						
							
					    <li><a href="javascript:void(0);" class="tab-content-link" name="Overdraft_and_Returned_Items"><span class="ada-hidden ada-action">Hide </span>Overdraft and Returned Items</a>
							<div class="content-area">
							  
											<p class="bold">Fee Type: Overdraft Items</p>
<p class="bold">Fee: <span class="urgent-info">$35 per item</span></p>
<p>We charge an Overdraft Item Fee when you make a transaction for an amount that is more than the available balance in your checking or savings account. Transactions include writing a check, using a debit card, withdrawing cash from an ATM and any other transfer from your account(s).</p>
<p class="pbtm-10">While Bank of America is not required by law to pay Overdraft Items, we may do so from time to time.</p>
<p class="plt-15"><span class="bold">Important Information</span></p>
<p class="plt-15">The standard Overdraft Item Fee is $35. The standard NSF: Returned Item Fee of $35 applies if we return the item unpaid.</p>
<p class="bold">Please note: You may be charged for a combination of no more than 8 overdraft and returned items per day. If we determine that your account has a negative balance for 5 consecutive business days, you receive an additional Extended Overdrawn Balance charge of $35 on the sixth day.</p>
<p class="bold">Fee Type: Insufficient Funds: Returned Items</p>
<p class="bold">Fee: $35 <span class="urgent-info">per item</span></p>
<p>We charge an NSF: Returned Items Fee when you make a transaction for an amount that is more than the balance in your checking or savings account and we decline or return the item unpaid (a returned item).</p>
							 </div>
						  </li>
						
						
						
							
					    <li><a href="javascript:void(0);" class="tab-content-link" name="Overdraft_Protection_Transfer"><span class="ada-hidden ada-action">Hide </span>Overdraft Protection Transfer</a>
							<div class="content-area">
							  
											<p class="pbtm-10">Overdraft Protection links your Bank of America business checking account to another Bank of America business account- such as business savings, a second business checking, or a business credit card &ndash; and automatically transfers funds to cover purchases and prevent returned checks when you don&rsquo;t have enough money in your checking account.</p>
<p class="bold">For Transfers from Business Savings or Business Checking</p>
<p class="bold">Fee: $12 per transfer</p>
<p class="pbtm-10">Available funds from your savings or second checking account are automatically transferred to your checking account if you should overdraw your account.</p>
<p class="bold">For Transfers from a Business Credit Card</p>
<p class="urgent-info">Please see your Business Card Agreement or call the number on your statement for information about Overdraft Protection fees</p>
<p>Available funds from your Bank of America business credit card are automatically transferred to your checking account if you should overdraw your account</p>
							 </div>
						  </li>
						
						
						
							
					    <li><a href="javascript:void(0);" class="tab-content-link" name="Overdrafts_mdash;_Extended_Overdrawn_Balance"><span class="ada-hidden ada-action">Hide </span>Overdrafts &mdash; Extended Overdrawn Balance</a>
							<div class="content-area">
							  
								<p class="bold">Fee:&nbsp;
									<span class="urgent-info">$35</span>
								</p>
											<p>The Extended Overdrawn Balance Charge applies when we determine that your account has been overdrawn for five or more consecutive business days. For each time that your account is overdrawn five or more consecutive business days, we charge one Extended Overdrawn Balance Charge.</p>
<p>You can prevent this fee by depositing enough available funds in your account to cover your overdraft plus any fees we assessed within the first five consecutive business days.</p>
<p>Please note: The Extended Overdrawn Balance Charge fee is in addition to applicable Overdraft Item Fees and NSF: Returned Item Fees.</p>
							 </div>
						  </li>
						
						
						
							
					    <li><a href="javascript:void(0);" class="tab-content-link" name="Statement_Copy_Fee"><span class="ada-hidden ada-action">Hide </span>Statement Copy Fee</a>
							<div class="content-area">
							  
								<p class="bold">Fee:&nbsp;
									<span class="urgent-info">$5 per copy</span>
								</p>
											<p>You can often avoid this fee by viewing and printing your available statements in Online Banking instead of ordering the copy from us.</p>
<p>To determine what statements are available, sign into Online Banking and select the Statements and Documents tab.</p>
							 </div>
						  </li>
						
						
						
							
					    <li><a href="javascript:void(0);" class="tab-content-link" name="Stop_Payment"><span class="ada-hidden ada-action">Hide </span>Stop Payment</a>
							<div class="content-area">
							  
								<p class="bold">Fee:&nbsp;
									<span class="urgent-info">$30 per request or renewal</span>
								</p>
											<p>Fee waived for Business Advantage accounts</p>
							 </div>
						  </li>
						
						
						
							
					    <li><a href="javascript:void(0);" class="tab-content-link" name="Wire_Transfers_and_Drafts"><span class="ada-hidden ada-action">Hide </span>Wire Transfers and Drafts</a>
							<div class="content-area">
							  
								<p class="bold">Fee:&nbsp;
									<span class="urgent-info">Fee varies</span>
								</p>
											<p>Incoming or Outgoing wire transfers and drafts (U.S. or International)</p>
<p>Incoming Domestic and Incoming International Wire Transfer fees are waived for the primary and included accounts in the Business Advantage solution.</p>
							 </div>
						  </li>
				 </ul>
          	</div>
          </div>
						
				 </div>
		  
          <div class="clearboth"><!--  --></div>
	</div>
	
								<p>For a printed version of the complete list of account fees, see the <a rel="nofollow" name="feesAtAGlance_businessScheduleFees_link" href="/smallbusiness/resources/business-schedule-fees.go" target="_new">Business Schedule of Fees</a>, also available at your banking center.</p>

	</div>
</div>

</div>
						<div class="flex-col rt-col" ><script type="text/javascript">

</script>










<div class="state-selector-aps-sb-module">
    <div class="modal-skin sw-inner">
		<p class="pbtm-5">Information for Virginia</p>
	  	<a id="change-state-util" class="show-state-select-modal" rel="state-select-modal" href="javascript:void(0);">Change state <span class="ada-hidden">layer</span></a>
        <div class="state-select-aps-sb-modal hide" id="state-select-modal">
         <div class="modal-content">
            <h3>Select Your State</h3>
                <p>Please tell us where you bank so we can give you accurate rate and fee information for your location.</p>
                <form method="post" action="" id="submitState">
                    <fieldset>
                        <legend>State Selection Form</legend>
                        <input type="hidden" id="requestedUrl" value="" />
                        <label for="stateList">Current State</label>
<select name="stateListName" id="stateList" class="select-box" required="true">
    <option value=" ">Select state</option>
    <option value="AL">Alabama</option>
    <option value="AK">Alaska</option>
    <option value="AZ">Arizona</option>
    <option value="AR">Arkansas</option>
    <option value="CA">California</option>
    <option value="CO">Colorado</option>
    <option value="CT">Connecticut</option>
    <option value="DE">Delaware</option>
    <option value="DC">District of Columbia</option>
    <option value="FL">Florida</option>
    <option value="GA">Georgia</option>
    <option value="HI">Hawaii</option>
    <option value="ID">Idaho</option>
    <option value="IL">Illinois</option>
    <option value="IN">Indiana</option>
    <option value="IA">Iowa</option>
    <option value="KS">Kansas</option>
    <option value="KY">Kentucky</option>
    <option value="LA">Louisiana</option>
    <option value="ME">Maine</option>
    <option value="MD">Maryland</option>
    <option value="MA">Massachusetts</option>
    <option value="MI">Michigan</option>
    <option value="MN">Minnesota</option>
    <option value="MS">Mississippi</option>
    <option value="MO">Missouri</option>
    <option value="MT">Montana</option>
    <option value="NE">Nebraska</option>
    <option value="NV">Nevada</option>
    <option value="NH">New Hampshire</option>
    <option value="NJ">New Jersey</option>
    <option value="NM">New Mexico</option>
    <option value="NY">New York</option>
    <option value="NC">North Carolina</option>
    <option value="ND">North Dakota</option>
    <option value="OH">Ohio</option>
    <option value="OK">Oklahoma</option>
    <option value="OR">Oregon</option>
    <option value="PA">Pennsylvania</option>
    <option value="RI">Rhode Island</option>
    <option value="SC">South Carolina</option>
    <option value="SD">South Dakota</option>
    <option value="TN">Tennessee</option>
    <option value="TX">Texas</option>
    <option value="UT">Utah</option>
    <option value="VT">Vermont</option>
    <option value="VA">Virginia</option>
    <option value="WA">Washington</option>
    <option value="WV">West Virginia</option>
    <option value="WI">Wisconsin</option>
    <option value="WY">Wyoming</option>


</select>

                        <div class="button-cont">
	                        <a id="state_select_submit" class="btn-bofa btn-bofa-small state-select-modal-go-button" href="javascript:void(0);" role="button">Go</a>
	                    </div>
                    </fieldset>
                </form>
		 </div>
		</div>
	</div>
</div>


</div>
						<div class="clearboth"></div>
					</div>
					<div class="footer">
						<div class="footer-top">&nbsp;</div>
						<div class="footer-inner">



<div class="power-footer-module">

  <div class="four-col-all-links-skin sup-ie">
    <div class="breadcrumbs">
						<a class="bold-bc" href="/" name="bank_of_america_fees_at_a_glance_breadcrumbs">Bank of America</a>
						<a href="/smallbusiness" name="small_business_fees_at_a_glance_breadcrumbs" >Small Business</a>
		
					<a href="/smallbusiness/education.go" name="resources_fees_at_a_glance_breadcrumbs">Resources</a>
		      	 <span>Fees at a Glance</span>
		    
      <div class="clearboth"></div>
    </div>
    <div class="pf-columns">
      
			<div class="pf-col" style="margin-right:50px;">
				<ul>
					<li>	
					<a href="/smallbusiness/deposits/checking-accounts/" class="bold" name="business_checking_fees_at_a_glance_power_footer" >Business Checking</a> 
					</li>
						<li> <a href="/smallbusiness/deposits/checking-accounts/business-advantage/" name="business_advantage_fees_at_a_glance_power_footer">Business Advantage</a> </li>
						<li> <a href="/smallbusiness/deposits/checking-accounts/business-fundamentals/" name="business_fundamentals_fees_at_a_glance_power_footer">Business Fundamentals<sup>&reg;</sup></a> </li>
						<li> <a href="/smallbusiness/checking-accounts/business-interest-checking.go" name="business_interest_checking_fees_at_a_glance_power_footer">Business Interest Checking</a> </li>
						<li> <a href="/smallbusiness/checking-accounts/full-analysis-business-checking.go" name="full_analysis_business_checking__fees_at_a_glance_power_footer">Full Analysis Business Checking </a> </li>
						<li> <a href="/smallbusiness/business-debit-card.go" name="business_debit_card_fees_at_a_glance_power_footer">Business Debit Card</a> </li>
				</ul>
		      </div>
			<div class="pf-col" style="margin-right:50px;">
				<ul>
					<li>	
					<a href="/smallbusiness/cd-savings-accounts.go" class="bold" name="business_savings_and_cd_fees_at_a_glance_power_footer" >Business Savings & CDs</a> 
					</li>
						<li> <a href="/smallbusiness/savings-accounts/business-interest-maximizer.go" name="business_interest_maximizer_fees_at_a_glance_power_footer">Business Interest Maximizer&trade;</a> </li>
						<li> <a href="/smallbusiness/savings-accounts/business-investment-account.go" name="business_investment_account_fees_at_a_glance_power_footer">Business Investment Account</a> </li>
						<li> <a href="/smallbusiness/cds/business-featured-cd.go" name="business_featured_cd_fees_at_a_glance_power_footer">Business Featured CD</a> </li>
						<li> <a href="/smallbusiness/cds/risk-free-cd.go" name="business_risk_free_cd_fees_at_a_glance_power_footer">Business Risk Free CD<sup>&reg;</sup></a> </li>
						<li> <a href="/smallbusiness/standard-cds.go" name="standard_business_cd_fees_at_a_glance_power_footer">Standard Business CD</a> </li>
				</ul>
		      </div>
			<div class="pf-col" style="margin-right:50px;">
				<ul>
					<li>	
					<a href="/smallbusiness/online-banking.go" class="bold" name="manage_your_account_fees_at_a_glance_power_footer" >Manage Your Account</a> 
					</li>
						<li> <a href="/smallbusiness/online-banking.go" name="online_banking_fees_at_a_glance_power_footer">Online Banking</a> </li>
						<li> <a href="/smallbusiness/online-banking/cash-management.go" name="business_tools_fees_at_a_glance_power_footer">Business Tools</a> </li>
						<li> <a href="/smallbusiness/business-debit-card.go" name="request_a_debit_card_fees_at_a_glance_power_footer">Request a Debit Card</a> </li>
				</ul>
		      </div>
			<div class="pf-col" style="">
				<ul>
					<li>	
					<a href="/smallbusiness/education.go" class="bold" name="resources_fees_at_a_glance_power_footer" >Resources</a> 
					</li>
						<li> <a href="/smallbusiness/resources/faqs.go" name="faqs_fees_at_a_glance_power_footer">FAQs</a> </li>
						<li> <a href="/smallbusiness/resources/glossary.go" name="glossary_fees_at_a_glance_power_footer">Glossary</a> </li>
						<li> <a href="/smallbusiness/resources/fees-at-a-glance.go" name="fees_at_a_glance_fees_at_a_glance_power_footer">Fees at a Glance</a> </li>
						<li> <a href="/deposits/bank-account-interest-rates/?flow=BCS" name="account_rates_fees_at_a_glance_power_footer">Account Rates</a> </li>
						<li> <a href="/smallbusiness/platinum-privileges.go" name="business_platinum_privileges_fees_at_a_glance_power_footer">Business Platinum Privileges&trade;</a> </li>
						<li> <a href="/smallbusiness/resources/overdraft-protection.go" name="overdraft_protection_fees_at_a_glance_power_footer">Overdraft Protection</a> </li>
				</ul>
		      </div>
      
      <div class="clearboth"></div>
    </div>
  </div>
</div>




 



		<div class="global-footer-module">
			<div class="fsd-skin">

				<div class="footer-bottom-left" style="float:left;max-width:66%;">
	    			<div class="gf-links">	          	
						
					
									
									<a  target="_self" href="/smallbusiness/index.jsp" 
									    name="global-footer-home">Home
									</a>
									
						
					
									
									<a  target="_self" href="/privacy/index.jsp" 
									    name="global-footer-privacy-security">Privacy & Security
									</a>
									
						
					
									
									<a  target="_self" href="http://careers.bankofamerica.com/careershome.aspx" 
									    name="footer_careers">Careers
									</a>
									
						
					
									
									<a  target="_self" href="/sitemap/sitemap/smallbusiness.go" 
									    name="global-footer-site-map">Site Map
									</a>
									
						
					
									<a href="javascript:void(0);" class="gf-last-link boa-dialog boa-com-info-layer-link" name="global_footer_ad_practices_lnk" rel="global_footer_ad_practices">Advertising Practices</a>
								<div id="global_footer_ad_practices" class="hide">
									<h3>Advertising Practices</h3>
										<p>We strive to provide you with information about products and services you might find interesting and useful. Relationship-based ads and online behavioral advertising help us do that.</p>
<p>Here's how it works: We gather information about your online activities, such as the searches you conduct on our Sites and the pages you visit. This information may be used to deliver advertising on our Sites and offline (for example, by phone, email and direct mail) that's customized to meet specific interests you may have.</p>
<p>If you prefer that we do not use this information, you may <a onclick="$('.ui-dialog').remove();" name="WebsiteAdPractices_OptOut" href="/privacy/online-privacy-notice.go#advertising-on-our-sites" target="_blank">opt out of online behavioral advertising</a>. If you opt out, though, you may still receive generic advertising. In addition, financial advisors/Client Managers may continue to use information collected online to provide product and service information in accordance with account agreements.</p>
<p>Also, if you opt out of online behavioral advertising, you may still see ads when you sign in to your account, for example through Online Banking or MyMerrill. These ads are based on your specific account relationships with us.</p>
<p>To learn more about relationship-based ads, online behavioral advertising and our privacy practices, please review the <a onclick="$('.ui-dialog').remove();" name="WebsiteAdPractices_PrivacyNotice" href="/privacy/online-privacy-notice.go" target="_blank">Bank of America Online Privacy Notice</a> and our <a onclick="$('.ui-dialog').remove();" name="Online-privacy-faqs" href="/privacy/faq/online-privacy-faq.go" target="_blank">Online Privacy FAQs</a>.</p>
								</div>
						<div class="clearboth"></div>
	    			</div>
	      			<p>Bank of America, N.A. Member FDIC. <a onclick="function onclick() { window.open('/help/equalhousing_popup.go','newwin','width=640,height=371,scrollbars=yes,resizable=yes,left=35,top=161'); return false;}" name="Equal_Housing_Lender" href="/help/equalhousing_popup.go">Equal Housing Lender<img src="/content/images/ContextualSiteGraphics/Logos/en_US/icon_equal_housing_lender.gif" alt="" width="14" height="9" /></a> <br />&copy;&nbsp;2017 Bank of America Corporation. All rights reserved.</p>
         		</div>
         		<div class="footer-social-container" style="float:right;max-width:30%;padding-left:50px;padding-top:19px;">




<div class="boa-social-loader" data-loaded="false" data-platform="borneo"  data-options=''></div>

         		</div>
         		<div class="clearboth"></div>
  			</div>
		</div>




 
<script type="text/javascript">
var axel = Math.random()+"";var a = axel * 10000000000000;document.write('<iframe title="iFrame used for layout purpose" src="https://fls.doubleclick.net/activityi;src=1359940;type=bacal484;cat=smb_b092;ord=1;num='+ a + '?" width="1" height="1" frameborder="0" style="display:none;"></iframe>');
</script>
<noscript>
	<iframe title="iFrame used for layout purpose" src="https://fls.doubleclick.net/activityi;src=1359940;type=bacal484;cat=smb_b092;ord=1?" width="0" height="0" frameborder="0" style="display:none;"></iframe>
</noscript>
<script language="javascript" src="/pa/global-assets/external/coremetrics/hp/eluminate.js"></script>
<script language="javascript" src="/pa/global-assets/external/coremetrics/hp/cmdatatagutils.js"></script>

<script language="javascript">
var testString = window.location.href;
    if (testString.toLowerCase().indexOf('.bankofamerica.com') > -1){
        testString = testString.toLowerCase();
        var tempArr = testString.split('.bankofamerica.com');var tempStr = tempArr[0];
        if (tempStr.indexOf('\/\/') > -1) {
            tempArr = tempStr.split('\/\/');tempStr = tempArr[1];
            if (tempStr.indexOf('.') > -1) {
                tempArr = tempStr.split('.');tempStr = tempArr[0];
            }
            if (tempStr.indexOf('www') > -1) {
                if (tempStr.indexOf('-') > -1) {cmSetStaging();}
                else {cmSetProduction();}
            }
            else {
                if (tempStr.indexOf('sitekey') > -1){
                    if (tempStr == 'sitekey') {cmSetProduction();}
                    else {cmSetStaging();}
                }
                else if (tempStr.indexOf('pssit') > -1){
                    if (tempStr == 'pssit') {cmSetStaging();}
                }
                if (tempStr.indexOf('-') > -1) {cmSetStaging();}
                else {cmSetProduction();}    
            }
        }
    }
  </script> 
  
		<script type="text/javascript">
		cmCreatePageviewTag('smbus:Content:Dep:Resources;fees-at-a-glance', null, null, 'smbus:Content:Dep:Resources', false, false, null, false, false, null, null, null, null, null, null, null, null, null, null, null, null);
		</script>
								
				
				
				
					
			
			
								
		<script type="text/javascript">
			
	// CoreMetrics 
		$('document').ready(function(){
			// Compare Tab click event.
			$('.tabs-bdf-module a[name*=Compare_tabLink]').bind('click.CM', function(){ 
	
				
						
			
		});
		
		});
			</script>
</div>
					</div>
				</div>
			</div>
		</div>
	</body>	
</html>

