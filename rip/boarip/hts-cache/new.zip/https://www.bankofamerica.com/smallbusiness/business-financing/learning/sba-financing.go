
 

				<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
				<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
				<head>


<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta http-equiv="content-type" content="text/html;charset=utf-8">





<title>SBA Loans from Bank of America</title>

<meta name="Description" CONTENT="SBA loans may help your business qualify for financing more easily and receive more flexible terms. That means you can preserve working capital for other expenses.">
<meta name="Keywords" CONTENT="SBA loans, SBA financing, SBA financing at Bank of America, SBA business loans, SBA loans at Bank of America">

		<link rel="canonical" href="https://www.bankofamerica.com/smallbusiness/business-financing/learning/sba-financing.go"/>

<link rel="shortcut icon" href="/pa/global-assets/1.0/graphic/favicon.ico" type="image/ico" />

			<link rel="stylesheet" type="text/css" href="/pa/components/bundles/gzip-compressed/xengine/APS-small-business/2017.03.0/style/bcs-aps-sb-jawr.css" media="all" />
			<script src="/pa/components/bundles/gzip-compressed/xengine/APS-small-business/2017.03.0/script/bcs-aps-sb-jawr.js" type="text/javascript"></script>
				<script type="text/javascript">
					$(window).load(function(){asyncPrintCssInclude('https://www.bankofamerica.com/pa/components/bundles/gzip-compressed/xengine/APS-small-business/2017.03.0/style/bcs-aps-sb-jawr-print.css');});
				</script>
<script type="text/javascript">
(function() {
	if (typeof mboxUpdate == "function") {
		var windowURL = window.location.href
	    windowURL = windowURL.slice( windowURL.indexOf('.')+1);
		windowURL = windowURL.split( '?' )[0];
		windowURL = windowURL.toLowerCase();
		//alert(windowURL);
		if (
		    //If no mboxes on page, mbox count will be < 1
		    (mboxFactoryDefault.getMboxes().length() < 1) &&

			//Also check for high-volume pages that do not need global logging
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go") &&
			(windowURL != "bankofamerica.com/myaccounts/signin/signin.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/entry/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signonscreen.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatechallengeanswer.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatePassword.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/mobile/banking.go")&&
			(windowURL != "bankofamerica.com/content/preload/olb-myaccount-preload-jawr-module.htm")
			)
		{

			var mboxDiv = document.createElement("div");
			mboxDiv.id = "adobe_touch_clarity_replacement";
			mboxDiv.style.display = "none";
			if (document.body && document.body.firstChild) document.body.insertBefore(mboxDiv,document.body.firstChild);
			mboxDefine(mboxDiv.id,'bac_global_bottom');
			mboxUpdate('bac_global_bottom');
		}
	}
})();
</script>

		<script src="/pa/components/bundles/gzip-compressed/xengine/Global/1.0/script/tealeafbundle.js" type="text/javascript"></script>
			<script>
				var boaPageDataJS = {};
					boaPageDataJS.isLLE = "false";
			</script>
				<style>body{display:none;}</style>
	</head>		

	<body class="fsd-layout-body">	

				<script type="text/javascript">if(self == top){var theBody=document.getElementsByTagName("body")[0];theBody.style.display="block";}else{top.location=self.location;}</script>
				<noscript><style>body{display:block;}</style></noscript>
					<a class='ada-hidden ada-visible-focus' href='#skip-to-h1' id='ada-skip-link'>Skip to main content</a>
		<div class="fsd-layout fsd-2c-700lt-layout">
			<div class="fsd-border">
				<div class="center-content">
					<div class="header">
		  



<script language="javascript" src="/pa/components/modules/tag-manager-module/1.1/script/tag-manager-module-borneo-global-skin.js"></script>
<script>

(function() {
  var fireCallback = function( cb ) {
    if ( typeof cb === "function" ) cb();
  };
  
  function ddoPopulateBase( callback ) {
    try {
		  var DDO = window.digitalData,
		  	bactm_mergeDDO = function( newDDO, priorDDO ) {
		  		if( typeof priorDDO === "undefined" ) {
				  	priorDDO = digitalData || {};
				  }

			    for (var l in newDDO) {
			        if (typeof priorDDO[l] === "undefined") {
			            priorDDO[l] = newDDO[l];
			        }
			        if (newDDO[l] !== null) {
			            if (typeof newDDO[l] === "object") {
			                bactm_mergeDDO(newDDO[l], priorDDO[l]);
			            } else {
			                priorDDO[l] = bactm_validateValue( newDDO[l] ) ? newDDO[l] : priorDDO[l];
			            }
			        }
			    }

			    return priorDDO;
				},
				bactm_olb3rdPartyId = "null";

			if (typeof DDO === "undefined") {
				var simpleDDO = { page: { pageInfo:[{ pageID: null }], attributes: {}, category: { primaryCategory: null }}};

				DDO = (typeof digitalData === "object") ? digitalData : simpleDDO; 
			}

				DDO = bactm_mergeDDO( {pageInstanceID:"notprod",load_coremetrics:false,load_opinionlabs:false,load_touchcommerce:true,load_audiencemanager:true,page:{pageInfo:[{pageID:null,destinationURL:null,referringURL:null,issueDate:null,language:null,segmentValue:null,appName:null,appStepNumber:null,appStepName:null,attr:"-_--_--_--_--_--_--_--_--_--_--_--_--_--_-"}],category:{primaryCategory:null,addlCategory:null,pageType:null},attributes:{searchString:null,searchResults:null,olbSessionID:null,subCampaignCode:null,DARTUrl:null,stateCookie:null,SASIEnabled:false,needOLBcookie:false,standardDART:[],standardDARTes:[],clickDART:[],clickDARTes:[],gaId:[],chat:{account_type:null,boa_associate:null,boa_retiree:null,customer_lob:null,customer_segment:null,data:null,email_campaign:null,entitlement_code:null,error_category:null,error_count:null,first_login:null,inqSalesProductTypes:{},invitation_background:null,invitation_template:null,referral_campaign:null,getStateValue:false,cust_fn:null,cust_ln:null,target:null}}},user:{segment:null,online_id:null,preferred_rewards_tier:null,olb3rdpartyid:null},version:"BAC_0.12"}, DDO );

			DDO.page.pageInfo[0].pageID = "smbus:Content:SB_Financing:Learning;sba-financing";
			DDO.page.category.primaryCategory  = "smbus:Content:SB_Financing:Learning";
			DDO.page.pageInfo[0].language = "en-US";
			DDO.page.attributes.olbSessionID = "null";
			DDO.page.attributes.SASIEnabled =  "false";
			if (typeof DDO.user != "undefined" && typeof DDO.user.olb3rdpartyid != "undefined") {
				DDO.user.olb3rdpartyid = bactm_olb3rdPartyId;
			}

			window.utag_data = {};
			window.bactm_envSelector = bactm_setTMLib();
			window.digitalData = DDO;

      return fireCallback( callback );

    } catch(e) { }
  }
	if( window.boa && window.boa.digitalData ) {
    window.boa.digitalData.register( ddoPopulateBase );
	}
	else {
	  // Handle scenario where the header isn't available (and thus the default digitalData object and utag loader are missing).
	  //
		var writeScript = function(a,b,c,d){
			a='//tags.tiqcdn.com/utag/bofa/main/' + bactm_envSelector + '/utag.js';
			b=document;
			c='script';
			d=b.createElement(c);
			d.src=a;
			d.type='text/java'+c;
			d.async=true;
			a=b.getElementsByTagName(c)[0];
			a.parentNode.insertBefore(d,a);
		};

		ddoPopulateBase( writeScript );
	}
})();			
</script>





	
	
				<noscript>
				
					<div class="fauxdal-overlay"></div>
					<div class="fauxdal-module">
						<div class="js-disabled-skin">
							<div class="fauxdal-top"></div>
							<div class="fauxdal-bottom">
								<div class="fauxdal-content">
										<div class="fauxdal-title">
											Please Use JavaScript
										</div>
											<p>You need a web browser that supports JavaScript to use our site. Without it, some pages won't work as designed. To make sure JavaScript is turned on, please adjust your browser settings.</p><p><a name="Browser_Help_And_Tips" href="http://www.bankofamerica.com/onlinebanking/index.cfm?template=browser_help_and_tips" target="_blank">Browser Help and Tips</a></p>
										
								</div>        
								<div class="fauxdal-close"> 
									<a class="btn-bofa btn-bofa-small" href=?js=y>Close</a>
								</div>
								
							</div>
						</div>
					</div>
				</noscript>



 


<div class="header-module">
	<div class="text-w-logo-skin">
		<div class="header-left">
	  
			<div itemscope itemtype="http://schema.org/Corporation" class="bofa-logo">
				<a itemprop="url" name="anc-business-advantage" title="Bank of America logo" href="/smallbusiness/">
					<img itemprop="logo" height="28" width="221" 
					     alt="Bank of America logo" src="/content/images/ContextualSiteGraphics/Logos/en_US/boa_logo.gif"/>
				</a>
			</div>
				<div class="product" data-font="cnx-regular">Business Advantage</div>
			
			<div class="clearboth"></div>

		</div>
		
		<div class="header-right">
			<ul class="header-links">
			
				
					
				
							<li class="sign-in">
		<a					href="/sitemap/hub/signin.go" target="_self"
		name="Sign_In">Sign In</a> 
							</li>
					
				
							<li>		<a					href="/smallbusiness/" target="_self"
		name="Home_Header">Home</a> 
</li>
					
				
							<li>		<a					href="https://locators.bankofamerica.com" target="_self"
		name="Locations">Locations</a> 
</li>
					
				
							<li>		<a					href="/contactus/contactus.go?topicId=small_business_banking " target="_self"
		name="Contact_Us">Contact Us</a> 
</li>
					
				
							<li class="last-link">	
		<a					href="/smallbusiness/business-financing/learning/faqs-applying-for-financing.go" target="_self"
		name="Help">Help</a> 
							</li>
			</ul>
			
			<div class="clearboth"></div>

			<!-- include search-dotcom-util -->



<div class="header-search nlh">
  
  <div class="nav-search">
    <form class="search-form" action="https://secure.bankofamerica.com/myaccounts/public/search-results/unAuthenticatedSearch.go" data-js="/pa/components/utilities/search-util/1.0/script/nav-search.min.js" data-css="/pa/components/utilities/search-util/1.0/style/nav-search.css" data-text-unavailable="Search Currently Unavailable">
      <div class="search-input-container cf" data-icon="search">
        <label for="nav-search-query" class="ada-hidden">Search Term</label>
        <input type="text" placeholder="How can we help you?" name="query" class="search-query" id="nav-search-query" 
          maxlength="99" rel="Search" autocomplete="off"><input type="submit" alt="Search" title="Search" value="Submit Search" name="Search Module - Top Result – Search Button" class="submit track-me">
      </div>
    </form>
  </div>

</div>

		</div>

 		<div class="clearboth"></div>
 	</div>
</div>







	<div class="top-nav-module">
		<div class="fsd-skin sup-ie">
			<ul class="nav-list">
					
					
					<li>
						
									<a href="/smallbusiness/business-financing.go" class="top-menu-item"
									name="overview_topnav" id="overview_topnav">Overview</a>
					</li>
					
					
					<li>
						
								<a href="/smallbusiness/business-financing/working-capital.go" class="top-menu-item"
								name="business_credit_lines_and_loans_topnav" id="business_credit_lines_and_loans_topnav">Business Credit Lines & Loans<span class="ada-hidden"> link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/smallbusiness/business-financing/working-capital.go"  name="overview_topnav" id="overview_topnav"><span class="ada-hidden">Business credit lines and loans </span>Overview </a>
															<a href="/smallbusiness/business-financing/working-capital/business-line-of-credit.go"  name="business_line_of_credit_topnav" id="business_line_of_credit_topnav">Business Line of Credit </a>
															<a href="/smallbusiness/business-financing/working-capital/business-loans.go"  name="secured_business_loans_topnav" id="secured_business_loans_topnav">Secured Business Loans </a>
															<a href="/smallbusiness/business-financing/working-capital/unsecured-business-line-of-credit.go"  name="unsecured_line_of_credit_topnav" id="unsecured_line_of_credit_topnav">Unsecured Line of Credit </a>
									</div>
								
									<div class="hasSub">
														<a class="with-info" href="/smallbusiness/credit-cards/"  name="business_credit_cards_topnav" id="business_credit_cards_topnav">Business Credit Cards 
															
															<span class="sub-nav-item-info">Pay for everyday expenses and get online management tools</span>
														</a>
									</div>
									<span class="ada-hidden"> End of submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
					
					
					<li>
						
									<a href="/smallbusiness/business-financing/commercial-real-estate-loans.go" class="top-menu-item"
									name="commercial_real_estate_topnav" id="commercial_real_estate_topnav">Commercial Real Estate</a>
					</li>
					
					
					<li>
						
								<a href="/smallbusiness/business-financing/equipment-vehicle-loans/overview.go" class="top-menu-item"
								name="equipment_and_vehicles_topnav" id="equipment_and_vehicles_topnav">Equipment & Vehicles<span class="ada-hidden"> link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/smallbusiness/business-financing/equipment-vehicle-loans/overview.go"  name="overview_topnav" id="overview_topnav"><span class="ada-hidden">Equipment and vehicles </span>Overview </a>
															<a href="/smallbusiness/business-financing/equipment-financing/equipment-loans.go"  name="equipment__topnav" id="equipment__topnav">Equipment  </a>
															<a href="/smallbusiness/business-financing/commercial-vehicle-financing/commercial-vehicle-loans.go"  name="vehicles_topnav" id="vehicles_topnav">Vehicles </a>
									</div>
								
									<div class="hasSub">
														<a class="with-info" href="/smallbusiness/business-financing/equipment-financing/loans-leasing-compare.go"  name="should_i_buy_or_lease_topnav" id="should_i_buy_or_lease_topnav">Should I Buy or Lease? 
															
															<span class="sub-nav-item-info">Compare the advantages to see what's right for your business</span>
														</a>
									</div>
									<span class="ada-hidden"> End of submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
					
					
					<li>
						
								<a href="/smallbusiness/business-financing/learning.go" class="top-menu-item selected"
								name="resources_topnav" id="resources_topnav">Resources<span class="ada-hidden"> link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/smallbusiness/business-financing/learning.go"  name="learn_about_financing_topnav" id="learn_about_financing_topnav"><span class="ada-hidden">Resources </span>Learn about Financing </a>
															<a href="/smallbusiness/business-financing/recommendation.go"  name="get_a_recommendation_topnav" id="get_a_recommendation_topnav">Get a Recommendation </a>
															<a href="/smallbusiness/business-financing/learning/faqs-applying-for-financing.go"  name="faqs_topnav" id="faqs_topnav">FAQs </a>
									</div>
								
									<div class="hasSub">
														<a class="with-info" href="/smallbusiness/business-financing/learning/sba-financing.go#url-things-to-know-tab-content"  name="is_sba_financing_right_for_me_topnav" id="is_sba_financing_right_for_me_topnav">Is SBA Financing Right For Me? 
															
															<span class="sub-nav-item-info">5 things you should know about SBA loans</span>
														</a>
									</div>
									<span class="ada-hidden"> End of submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
			</ul>
				<div class="clearboth"></div>
		</div>
	</div>



<div class="page-title-fsd-module h-100" id="skip-to-h1">
	<div class="standard-gray-skin sup-ie">
		<h1 data-font="cnx-regular">Small Business Administration Financing (SBA Loans)</h1>
  </div>
</div>

</div>
					<div class="columns">
						<div class="flex-col lt-col" >



 
	<div class="tab-group-content-module">
		<div class="article-skin">
			<p class="intro-text fsd-font">The Small Business Administration (SBA) is a federal agency that helps established businesses grow and new businesses get started.</p>
			<ul class="tab-main-bdr">	
				<li class="tab">
					<div class="tab-cap"></div>
					<a href="#sba-loan-types-tab-content" id="sba-loan-types-tab" name="sba-loan-types-tab">SBA loan types</a>
					<div class="tab-cap rt-cap"></div>
					<div class="clearboth"></div>
				</li>
				<li class="tab">
					<div class="tab-cap"></div>
					<a href="#things-to-know-tab-content" id="things-to-know-tab" name="things-to-know-tab">Things to know</a>
					<div class="tab-cap rt-cap"></div>
					<div class="clearboth"></div>
				</li>
				<li class="tab">
					<div class="tab-cap"></div>
					<a href="#faq-tab-content" id="faq-tab" name="faq-tab">FAQs</a>
					<div class="tab-cap rt-cap"></div>
					<div class="clearboth"></div>
				</li>				
			</ul>
			<div class="clearboth"></div>
			
			<div class="tab-panel">
				<div class="corner top-right"></div>
				<div class="corner bottom-left"></div>
				<div class="corner bottom-right"></div>
				<div class="sba-loan-types-tab-content  com-main-well-content" id="sba-loan-types-tab-content">
						<h2 class="ada-hidden">SBA loan types</h2>
						<p>SBA loans may help your business qualify for financing more easily and receive more flexible terms.That means you can preserve working capital for other expenses.</p>
						<p><a href="javascript:void(0);" class="boa-dialog boa-com-info-layer-link boa-com-info-layer-width-520" rel="dialog-com-dynamic-financing" name="are_you_eligible_for_an_SBA_loan">Are you eligible for an SBA loan?</a></p>
					<div class="table-wrapper table-vzd3-common">
							<table id="tbl-sba-loan-type" border="0" summary="Small Business Administration Loan Types">
<thead>
<tr><th scope="col">&nbsp;</th><th width="190" scope="col">SBA 504</th><th width="160" scope="col">SBA 7(a)</th><th width="160" scope="col">SBA Express</th></tr>
</thead>
<tbody>
<tr>
<td class="row-header" scope="row">Use it for</td>
<td width="190">
<ul>
<li>Purchase equipment or real estate (no refinancing)</li>
<li>Construction and renovation</li>
</ul>
</td>
<td width="160">
<ul>
<li>Purchase or expand a business</li>
<li>Purchase equipment or inventory</li>
<li>Working capital</li>
<li>Refinance debt</li>
</ul>
</td>
<td width="160">
<ul>
<li>Working capital</li>
<li>Purchase equipment</li>
<li>Purchase vehicles or inventory</li>
</ul>
</td>
</tr>
<tr>
<td class="row-header" scope="row">Benefits</td>
<td width="190">
<ul>
<li>Longer maturity than conventional loan</li>
<li>Lower down payments on fixed assets</li>
<li>Easier qualification than a conventional loan</li>
</ul>
</td>
<td width="160">
<ul>
<li>Longer maturity than conventional loan</li>
<li>Lower down payments on fixed assets</li>
<li>Easier qualification than a conventional loan</li>
</ul>
</td>
<td width="160">
<ul>
<li>Longer maturity than some conventional loans</li>
<li>Easier qualification than a conventional loan</li>
</ul>
</td>
</tr>
<tr>
<td class="row-header" scope="row">Amount</td>
<td width="190">
<p>$350,000 minimum, no maximum</p>
</td>
<td width="160">
<p>$350,000-$3.5 million</p>
</td>
<td width="160">
<p>$10,000-$350,000</p>
</td>
</tr>
<tr>
<td class="row-header" scope="row">Terms</td>
<td width="190">
<ul>
<li>Up to 2 years interim construction period</li>
<li>7-10 years on equipment</li>
<li>10-20 years on real estate</li>
</ul>
</td>
<td width="160">
<ul>
<li>Up to 7 years for working capital</li>
<li>Up to 10 years for equipment or business acquisition</li>
<li>Up to 25 years for real estate</li>
</ul>
</td>
<td width="160">
<ul>
<li>7-year term with first-year revolving option and balance amortized across the remainder of the term</li>
</ul>
</td>
</tr>
</tbody>
</table>

							<div id="dialog-com-dynamic" class="hide">
								<h3>SBA Patriot Express loans</h3>
								<p>SBA Patriot Express loans are available to applicants who qualify for SBA, own more than 51% of the business and are either:</p>
<ul>
<li>Veterans</li>
<li>Active-duty military</li>
<li>Reservist or National Guard</li>
<li>Spouse of the above</li>
</ul>
<p>Applications for SBA Patriot Express and Express loans are only accepted when conventional financing options do not apply. All SBA loan applications must meet both SBA and Bank of America lending guidelines.</p>
							</div>							
							<div id="dialog-com-dynamic-financing" class="hide">
								<h3>Are you eligible for an SBA loan?</h3>
								<p>SBA loans from Bank of America are for businesses that are:</p>
<ul>
<li>Owner-operated </li>
<li>For profit </li>
<li>Legally organized (for example, as a sole proprietorship, corporation, partnership or limited liability company) </li>
<li>Within the size guidelines designated by the SBA </li>
<li>Generally unable to receive conventional credit under reasonable terms</li>
</ul>
<p>All SBA loan applications must meet both SBA and Bank of America lending guidelines.</p>
							</div>							
					</div>
				</div>
			
				<div class="things-to-know-tab-content com-main-well-content" id="things-to-know-tab-content">
							<h2 class="ada-hidden">Things to know</h2>
							<h2>5 things you should know about SBA loans</h2>
							<p>The SBA backs loans, they don&rsquo;t lend money. Understanding a little more about loans backed by the Small Business Administration can help you decide whether they&rsquo;re right for your business.</p>
							<ol>
						<li>
							<strong>The SBA does not engage in direct lending</strong>
							The SBA offers a variety of loan programs for very specific purposes. When you apply for an SBA loan, though, you do so through a bank, not through the SBA itself. While the bank is providing the actual loan, the SBA is guaranteeing a portion of that loan. In effect, the SBA is serving as a co-signer, which in turn helps banks provide more flexible terms to borrowers.
						</li>
						<li>
							<strong>Not all banks offer the same SBA programs</strong>
							The SBA has several loan programs, including 7(a) for general small business loans, 504 for real estate and equipment, microloans and disaster loans. An SBA loan must first be approved by the issuing bank, which may choose which programs to offer. Also, the lending requirements for any given SBA loan may vary from bank to bank, depending on specific bank policies.
						</li>
						<li>
							<strong>SBA loan programs are not just for new businesses</strong>
							The SBA exists to provide small businesses with financial assistance programs that have been specifically designed to meet key financing needs, including debt financing, surety bonds and equity financing. While many entrepreneurs and new businesses look to the SBA for financing, many established business take advantage of SBA-backed lending each year.
						</li>
						<li>
							<strong>An SBA loan means additional paperwork</strong>
							Applying for an SBA loan means you need to provide paperwork to both the bank and the SBA. In addition to the documentation a bank will typically require (<a onclick="displayPopup('/smallbusiness/business-financing/learning/what-you-need-to-apply.go')" name="anc-what-you-need-to-apply-link" href="javascript:void();">see a list of Bank of America requirements</a>), the SBA requirements (some of which may also be bank requirements) typically include an SBA loan application, a business plan, a personal financial statement, 3 years of business financial statements, 3 years of federal business tax returns, a one-year cash flow projection, information about all owners and an explanation of how a loan will help the business; and a copy of the business lease or proposed terms. By the way, that&rsquo;s not a complete list; other documentation and information may be requested.
						</li>
						<li>
							<strong>You can get better terms with an SBA loan</strong>
							SBA loans are designed to help borrowers who may not meet the lending standards set by most banks. These can include issues such as a recent change in business ownership, a shortfall in collateral to secure the loan, business principals who have a low net worth or the need for extended payment terms.
						</li>
							</ol>
				</div>

				<div class="faq-tab-content com-main-well-content" id="faq-tab-content">
					<h2 class="ada-hidden">FAQs</h2>
						<div class="show-hide-all">
							<a href="javascript:void(0);" class="show-all-answers mrt-5" name="anc-show-ll">Show all<span class="ada-hidden"> Answers</span></a> | 
							<a href="javascript:void(0);" class="hide-all-answers mlt-5" name="anc-hide-all" >Hide all<span class="ada-hidden"> Answers</span></a>				
						</div>
					<ul class="accordion">
								<li>										
									<a href="javascript:void(0);" class="heading" name="What_is_a_Small_Business_Administration_(SBA)_loan_"><span class="ada-hidden">Show Answer</span><span class="title"></span><span class="text">What is a Small Business Administration (SBA) loan? </span></a>
									<div class="content-area">
										<p>The SBA is a federal agency that helps established businesses grow and helps new businesses get started. As a borrower, you&rsquo;re not borrowing from the SBA, you&rsquo;re borrowing from a financial institution like Bank of America that works with the SBA to provide loans to small business customers.</p>									
									</div>
								</li>
								<li>										
									<a href="javascript:void(0);" class="heading" name="Is_an_SBA_loan_only_for_a_new_business"><span class="ada-hidden">Show Answer</span><span class="title"></span><span class="text">Is an SBA loan only for a new business?</span></a>
									<div class="content-area">
										<p>No. Bank of America provides SBA loans to many established businesses so they can grow and expand.</p>									
									</div>
								</li>
								<li>										
									<a href="javascript:void(0);" class="heading" name="What's_the_difference_between_an_SBA_loan_and_a_business_loan_from_Bank_of_America"><span class="ada-hidden">Show Answer</span><span class="title"></span><span class="text">What's the difference between an SBA loan and a business loan from Bank of America?</span></a>
									<div class="content-area">
										<p>A conventional business loan from Bank of America is solely the bank&rsquo;s risk and is subject to Bank lending guidelines. An SBA Express or 7(a) program loan, on the other hand, is a business loan that splits the risk between the Bank and the SBA, which guarantees a portion of those loans. Because of this split risk, SBA loans are subject to the lending guidelines of both the SBA and Bank of America, which in turn is able to take on more risk and provide more flexible terms.</p><p>SBA 504 (the third SBA program in which Bank of America participates) is an SBA loan participation program in which Bank of America directly lends a portion of the total financing need, with the remainder being lent by the Certified Development Company (CDC). The CDC portion is guaranteed by the SBA.</p>									
									</div>
								</li>
								<li>										
									<a href="javascript:void(0);" class="heading" name="Is_an_SBA_loan_from_one_bank_the_same_as_from_another_bank"><span class="ada-hidden">Show Answer</span><span class="title"></span><span class="text">Is an SBA loan from one bank the same as from another bank?</span></a>
									<div class="content-area">
										<p>No. An SBA loan must still be approved by the issuing bank, and each bank has its own lending criteria. You should discuss specific terms with a bank representative to understand all the terms of your loan. In addition, a bank that's an SBA Preferred Lender is likely to provide you with better terms and a smoother application and closing process than a bank that is not an SBA Preferred Lender.</p>									
									</div>
								</li>
								<li>										
									<a href="javascript:void(0);" class="heading" name="Is_Bank_of_America_an_SBA_Preferred_Lender"><span class="ada-hidden">Show Answer</span><span class="title"></span><span class="text">Is Bank of America an SBA Preferred Lender?</span></a>
									<div class="content-area">
										<p>Yes. This means we meet all Preferred Lender Program eligibility criteria, including a proficiency in processing and servicing SBA-guaranteed loans. As an SBA Preferred Lender, we're part of the SBA's effort to streamline the procedures necessary to provide financial assistance to the small business community. <a class="com-interstitial-modal-link" rel="http://www.sba.gov/content/preferred-lenders-program-plp" name="sba_preferred_lenders" href="javascript:void(0);" target="_self">Learn more about SBA Preferred Lenders</a></p>									
									</div>
								</li>
								<li>										
									<a href="javascript:void(0);" class="heading" name="What_types_of_SBA_loans_are_available_from_Bank_of_America"><span class="ada-hidden">Show Answer</span><span class="title"></span><span class="text">What types of SBA loans are available from Bank of America?</span></a>
									<div class="content-area">
										<p class="p-0">Bank of America primarily offers 2 SBA loan products: SBA 7(a) for equipment, inventory, working capital, purchasing an existing business or refinancing business debt and SBA 504 for real estate construction or the purchase of land, a building or long-term equipment. Under certain circumstances, we also offer SBA Express (including Patriot Express) for equipment and working capital.</p>									
									</div>
								</li>
					</ul>
				</div>
			</div>
		</div>
	</div>
</div>
						<div class="flex-col rt-col" >

<div class="print-module-browser-dialog-skin" style=""> 
	<a href="javascript:window.print();" name="print">PRINT<span class="ada-hidden"> this page</span></a>
</div>


	
	<div class="cta-module target-sidewell-sbf location-top">
		<div class="cta focus-call">
			<div class="intro">
				<h3>Contact us</h3>
			</div>
			<ul class="options ">
					<li class="call">
						<h4><a href="javascript:void(0);" name="call-small-business-speacialist"> <span class="ada-hidden ada-closed">Get details on how to</span> <span class="ada-hidden ada-open" style="display:none;">Hide details on how to</span> Call <span class="ada-hidden">a smallbusiness specialist</span> </a></h4>
						<div class="details ">							
									<p class="large">866.543.2808</p>
							<p class="small">You can apply by calling or<br /> making an appointment<br /> Mon-Fri 8 a.m. - 10 p.m. ET</p>							
						</div>
					</li>
				<li class="hide"></li>
							<li class="chat first hide">
								<h4>
									<a href="#" name="chat-small-business-speacialist">
										<span class="ada-hidden ada-closed">Show information for </span> 
										<span class="ada-hidden ada-open">Hide information for </span>
										Chat online
									</a>
								</h4>
								<div class="details">
									<p></p>
										<div id="lpButtonDivChat">										
										</div>
								</div>
							</li>
							<li class="qualify last after ">
								<h4>						
									<a href="#" name="schedule-callback-small-business-specialist">
										 <span class="ada-hidden ada-closed">Show information for </span> 
										 <span class="ada-hidden ada-open">Hide information for </span>
										 Let's get started 
									</a>
								</h4>
								<div class="details ">
									<a href="https://secure.bankofamerica.com/mycommunications/public/appointments/getTopics.go?marketingCode=SBFINRR_ECBBA_A2000_A2400&amp;comment=Please%20share%20the%20following:%20Months%20in%20Business,%20Gross%20revenue,%20Use%20of%20financing%20proceeds" target="_self">Schedule an appointment</a><br /> to meet with a small<br /> business specialist who can <br />answer your questions and<br /> start your application by<br /> phone or in-person					
								</div>
							</li>
			</ul>
		</div>
	</div>
	<div class="side-well-module"> </div>

<div class="side-well-module">
   <div class="img-wrap-skin">
      <div class="sw-outer">
         <div class="sw-inner">
            <div class="sw-corner sw-tleft"></div>
            <div class="sw-corner sw-tright"></div>
            <div class="sw-main sw-std-pad">
               <h2>Learn more</h2>
               <p>
               	<img alt="U.S Small Business Administration" src="/content/images/ContextualSiteGraphics/Logos/en_US/SBA-logo-100x45.jpg" class="sba-img-block">
                  Visit the <a class="com-interstitial-modal-link" rel="http://www.sba.gov/" name="visit-sba-website" href="javascript:void(0);">SBA.gov website</a> to learn more about SBA loan programs.
                
               </p>
            </div>
            <div class="sw-bottom"></div>
         </div>
         <div class="sw-corner sw-bleft"></div>
         <div class="sw-corner sw-bright"></div>
      </div>
   </div>
</div>
<script type="text/javascript">

</script>







<div class="state-selector-aps-sb-module">
<div class="modal-skin">
		<div class="state-select-aps-sb-modal hide" id="state-select-modal">
         <div class="modal-content">
            <h3>Select Your State</h3>
                <p>Please tell us where you bank so we can give you accurate rate and fee information for your location.</p>
                <form method="post" action="" id="submitState">
                    <fieldset>
                        <legend>State Selection Form</legend>
                        <input type="hidden" id="requestedUrl" value="" />
                        <label for="stateList">Current State</label>
<select name="stateListName" id="stateList" class="select-box" required="true">
    <option value=" ">Select state</option>
    <option value="AL">Alabama</option>
    <option value="AK">Alaska</option>
    <option value="AZ">Arizona</option>
    <option value="AR">Arkansas</option>
    <option value="CA">California</option>
    <option value="CO">Colorado</option>
    <option value="CT">Connecticut</option>
    <option value="DE">Delaware</option>
    <option value="DC">District of Columbia</option>
    <option value="FL">Florida</option>
    <option value="GA">Georgia</option>
    <option value="HI">Hawaii</option>
    <option value="ID">Idaho</option>
    <option value="IL">Illinois</option>
    <option value="IN">Indiana</option>
    <option value="IA">Iowa</option>
    <option value="KS">Kansas</option>
    <option value="KY">Kentucky</option>
    <option value="LA">Louisiana</option>
    <option value="ME">Maine</option>
    <option value="MD">Maryland</option>
    <option value="MA">Massachusetts</option>
    <option value="MI">Michigan</option>
    <option value="MN">Minnesota</option>
    <option value="MS">Mississippi</option>
    <option value="MO">Missouri</option>
    <option value="MT">Montana</option>
    <option value="NE">Nebraska</option>
    <option value="NV">Nevada</option>
    <option value="NH">New Hampshire</option>
    <option value="NJ">New Jersey</option>
    <option value="NM">New Mexico</option>
    <option value="NY">New York</option>
    <option value="NC">North Carolina</option>
    <option value="ND">North Dakota</option>
    <option value="OH">Ohio</option>
    <option value="OK">Oklahoma</option>
    <option value="OR">Oregon</option>
    <option value="PA">Pennsylvania</option>
    <option value="RI">Rhode Island</option>
    <option value="SC">South Carolina</option>
    <option value="SD">South Dakota</option>
    <option value="TN">Tennessee</option>
    <option value="TX">Texas</option>
    <option value="UT">Utah</option>
    <option value="VT">Vermont</option>
    <option value="VA">Virginia</option>
    <option value="WA">Washington</option>
    <option value="WV">West Virginia</option>
    <option value="WI">Wisconsin</option>
    <option value="WY">Wyoming</option>


</select>

                        <div class="button-cont">
	                        <a id="state_select_submit" class="btn-bofa btn-bofa-small state-select-modal-go-button" href="javascript:void(0);" role="button">Go</a>
	                    </div>
                    </fieldset>
                </form>
		 </div>
		</div>
</div>
</div>

</div>
						<div class="clearboth"></div>
					</div>
					<div class="footer">
						<div class="footer-top">&nbsp;

 


	<div class="apply-banner-module">
		<div class="product-skin lt-blue-skin small-text-no-btn">
			<div class="apply-banner">
				<div class="no-button">
					<p style="padding: 10px 0 7px 0;">Talk to a small business specialist by phone or in person to get a recommendation and start your application.&nbsp;<a href="https://secure.bankofamerica.com/mycommunications/public/appointments/getTopics.go?marketingCode=SBFINBLUE_ECBBA_A2000_A2400&amp;
comment=Please%20share%20the%20following:%20Months%20in%20Business,%20Gross%20revenue,%20Use%20of%20financing%20proce
eds" target="_self">Let's get started</a> &raquo;</p>
				</div>
			</div>
		</div>
	</div>
</div>
						<div class="footer-inner">



<div class="power-footer-module">

  <div class="four-col-all-links-skin sup-ie">
    <div class="breadcrumbs">
						<a class="bold-bc" href="/" name="bank_of_america_sba_financing_breadcrumbs">Bank of America</a>
						<a href="/smallbusiness/" name="small_business_sba_financing_breadcrumbs" >Small Business</a>
		
					<a href="/smallbusiness/business-financing/learning.go" name="resources_sba_financing_breadcrumbs">Resources</a>
		      	 <span>Small Business Administration Financing (SBA Loans)</span>
		    
      <div class="clearboth"></div>
    </div>
    <div class="pf-columns">
      
			<div class="pf-col" style="margin-right:50px;">
				<ul>
					<li>	
					<a href="/smallbusiness/business-financing/working-capital.go" class="bold" name="operating_cash_sba_financing_power_footer" >Operating Cash</a> 
					</li>
						<li> <a href="/smallbusiness/business-financing/working-capital/business-line-of-credit.go" name="business_line_of_credit_sba_financing_power_footer">Business Line of Credit</a> </li>
						<li> <a href="/smallbusiness/business-financing/working-capital/business-loans.go" name="business_loan_sba_financing_power_footer">Business Loans</a> </li>
						<li> <a href="/smallbusiness/credit-cards/" name="business_credit_cards_sba_financing_power_footer">Business Credit Cards</a> </li>
				</ul>
		      </div>
			<div class="pf-col" style="margin-right:50px;">
				<ul>
					<li>	
					<a href="/smallbusiness/business-financing/commercial-real-estate-loans.go" class="bold" name="commercial_real_estate_sba_financing_power_footer" >Commercial Real Estate</a> 
					</li>
						<li> <a href="/smallbusiness/business-financing/commercial-real-estate-loans.go#tabs-3" name="buy_or_rent_sba_financing_power_footer">Buy or rent?</a> </li>
				</ul>
		      </div>
			<div class="pf-col" style="margin-right:50px;">
				<ul>
					<li>	
					<a href="/smallbusiness/business-financing/equipment-vehicle-loans/overview.go" class="bold" name="equipment__vehicles_sba_financing_power_footer" >Equipment & Vehicles</a> 
					</li>
						<li> <a href="/smallbusiness/business-financing/equipment-financing/equipment-loans.go" name="equipment_financing_sba_financing_power_footer">Equipment</a> </li>
						<li> <a href="/smallbusiness/business-financing/commercial-vehicle-financing/commercial-vehicle-loans.go" name="vehicles_sba_financing_power_footer">Vehicles</a> </li>
						<li> <a href="/smallbusiness/business-financing/equipment-financing/loans-leasing-compare.go" name="should_i_buy_or_lease_sba_financing_power_footer">Should I Buy or Lease?</a> </li>
				</ul>
		      </div>
			<div class="pf-col" style="margin-right:50px;">
				<ul>
					<li>	
					<a href="/smallbusiness/business-financing/learning.go" class="bold" name="resources_sba_financing_power_footer" >Resources</a> 
					</li>
						<li> <a href="/smallbusiness/business-financing/recommendation.go" name="get_recommendation_sba_financing_power_footer">Get a Recommendation</a> </li>
						<li> <a href="/smallbusiness/business-financing/learning/faqs-applying-for-financing.go" name="faqs_sba_financing_power_footer">FAQs</a> </li>
						<li> <a href="/smallbusiness/business-financing/learning/sba-financing.go" name="is_sba_financing_right_for_me_sba_financing_power_footer">Is SBA Financing Right For Me?</a> </li>
				</ul>
		      </div>
      
      <div class="clearboth"></div>
    </div>
  </div>
</div>




 



		<div class="global-footer-module">
			<div class="fsd-skin">

				<div class="footer-bottom-left" style="float:left;max-width:66%;">
	    			<div class="gf-links">	          	
						
					
									
									<a  target="_self" href="/smallbusiness" 
									    name="global_footer_home">Home
									</a>
									
						
					
									
									<a  target="_self" href="/privacy/overview.go" 
									    name="global_footer_privacy_security">Privacy & Security
									</a>
									
						
					
									
									<a  target="_self" href="http://careers.bankofamerica.com/careershome.aspx" 
									    name="global_footer_careers">Careers
									</a>
									
						
					
									
									<a  target="_self" href="/sitemap/sitemap/smallbusiness.go" 
									    name="global_footer_site_map">Site Map
									</a>
									
						
					
									<a href="javascript:void(0);" class="gf-last-link boa-dialog boa-com-info-layer-link" name="global_footer_ad_practices_lnk" rel="global_footer_ad_practices">Advertising Practices</a>
								<div id="global_footer_ad_practices" class="hide">
									<h3>Advertising Practices</h3>
										<p>We strive to provide you with information about products and services you might find interesting and useful. Relationship-based ads and online behavioral advertising help us do that.</p>
<p>Here's how it works: We gather information about your online activities, such as the searches you conduct on our Sites and the pages you visit. This information may be used to deliver advertising on our Sites and offline (for example, by phone, email and direct mail) that's customized to meet specific interests you may have.</p>
<p>If you prefer that we do not use this information, you may <a onclick="$('.ui-dialog').remove();" name="WebsiteAdPractices_OptOut" href="/privacy/online-privacy-notice.go#advertising-on-our-sites" target="_blank">opt out of online behavioral advertising</a>. If you opt out, though, you may still receive generic advertising. In addition, financial advisors/Client Managers may continue to use information collected online to provide product and service information in accordance with account agreements.</p>
<p>Also, if you opt out of online behavioral advertising, you may still see ads when you sign in to your account, for example through Online Banking or MyMerrill. These ads are based on your specific account relationships with us.</p>
<p>To learn more about relationship-based ads, online behavioral advertising and our privacy practices, please review the <a onclick="$('.ui-dialog').remove();" name="WebsiteAdPractices_PrivacyNotice" href="/privacy/online-privacy-notice.go" target="_blank">Bank of America Online Privacy Notice</a> and our <a onclick="$('.ui-dialog').remove();" name="Online-privacy-faqs" href="/privacy/faq/online-privacy-faq.go" target="_blank">Online Privacy FAQs</a>.</p>
								</div>
						<div class="clearboth"></div>
	    			</div>
	      			<p>Bank of America, N.A. Member FDIC. <a title="Equal Housing Lender information." onclick="window.open('/help/equalhousing_popup.go','newwin','width=640,height=371,scrollbars=yes,resizable=yes,left=35,top=161'); return false;" name="Equal_Housing_Lender" href="/help/equalhousing_popup.go" target="_blank">Equal Housing Lender<img src="/content/images/ContextualSiteGraphics/Logos/en_US/gfoot-home-icon.png" alt="" width="14" height="9" /></a> <br />&copy;&nbsp;2017 Bank of America Corporation. All rights reserved.</p>
         		</div>
         		<div class="footer-social-container" style="float:right;max-width:30%;padding-left:50px;padding-top:19px;">




<div class="boa-social-loader" data-loaded="false" data-platform="borneo"  data-options=''></div>

         		</div>
         		<div class="clearboth"></div>
  			</div>
		</div>




 




	<div class="hide com-interstitial-modal">
     	<h3>Important Notice</h3>
   		<div class="flex-modal-main-content">
   		
      		<p><strong>You're continuing to another website</strong></p>
      		<p>You're continuing to another website that Bank of America doesn't own or operate. Its owner is solely responsible for the website's content, offerings and level of security, so please refer to the website's posted privacy policy and terms of use.</p>
   	
   	<div class="flex-modal-buttons">
	      	<a href="javascript:void(0);" class="button-common button-blue" name="leaving_bank_modal_continue"><span>Continue</span></a>
	         
	      	<a href="javascript:void(0);" class="button-common button-gray close-com-interstitial" name="leaving_bank_modal_cancel"><span>Return to Bank of America</span></a>
	         
          <div class="clearboth"></div>
      </div>
   </div>
</div>


<script language="javascript" src="/pa/global-assets/external/coremetrics/hp/eluminate.js"></script>
<script language="javascript" src="/pa/global-assets/external/coremetrics/hp/cmdatatagutils.js"></script>

<script language="javascript">
var testString = window.location.href;
    if (testString.toLowerCase().indexOf('.bankofamerica.com') > -1){
        testString = testString.toLowerCase();
        var tempArr = testString.split('.bankofamerica.com');var tempStr = tempArr[0];
        if (tempStr.indexOf('\/\/') > -1) {
            tempArr = tempStr.split('\/\/');tempStr = tempArr[1];
            if (tempStr.indexOf('.') > -1) {
                tempArr = tempStr.split('.');tempStr = tempArr[0];
            }
            if (tempStr.indexOf('www') > -1) {
                if (tempStr.indexOf('-') > -1) {cmSetStaging();}
                else {cmSetProduction();}
            }
            else {
                if (tempStr.indexOf('sitekey') > -1){
                    if (tempStr == 'sitekey') {cmSetProduction();}
                    else {cmSetStaging();}
                }
                else if (tempStr.indexOf('pssit') > -1){
                    if (tempStr == 'pssit') {cmSetStaging();}
                }
                if (tempStr.indexOf('-') > -1) {cmSetStaging();}
                else {cmSetProduction();}    
            }
        }
    }
	$('.modal-unique-content-opt-out-behavioral-targetting .opt-out-action').click(function(){
		cmCreatePageviewTag('Privacy:Tool:Privacy;behavioral-targeting-opt-out-success', null, null, 'Privacy:Tool:Privacy', false, false, null, false, false, null, null, null, null, null, null, null, null, null, null, null, null);
	});
	$('.modal-unique-content-opt-out-behavioral-targetting').bind('dialogclose', function() {
		cG7.cM0[cm_ClientID] = 'smbus:Content:SB_Financing:Learning;sba-financing';
	});
</script>

		<script type="text/javascript">
		cmCreatePageviewTag('smbus:Content:SB_Financing:Learning;sba-financing', null, null, 'smbus:Content:SB_Financing:Learning', false, false, null, false, false, null, null, null, null, null, null, null, null, null, null, null, null);
		</script>
</div>
					</div>
				</div>
			</div>
		</div>
	</body>	
</html>

