
 

				<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
				<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
				<head>


<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<title>Mobile Banking Features Offered by Bank of America - Small Business</title>

                   <meta name="Keywords" CONTENT="mobile banking features,mobile banking services,mobile banking solutions,mobile banking service" />
                   <meta name="Description" CONTENT="Get business account information and more services with Mobile Banking for small business,  offered by Bank of America." />
        <link REL="canonical" HREF="https://www.bankofamerica.com/smallbusiness/online-banking/mobile/features.go"/>                  
        
<link rel="shortcut icon" href="https://www2.bac-assets.com/pa/global-assets/1.0/graphic/favicon.ico" type="image/ico" />

			<link rel="stylesheet" type="text/css" media="all" href="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/APS-mobile-products/2017.03.0/style/aps-mp-sb-jawr.css"/>	
			<script type="text/javascript" src="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/APS-mobile-products/2017.03.0/script/aps-mp-sb-jawr.js"></script>
		
			<script type="text/javascript"> 
				$(window).load(function(){asyncPrintCssInclude('https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/APS-mobile-products/2017.03.0/style/aps-mp-jawr-print.css');});
			</script>	
<script type="text/javascript">
(function() {
	if (typeof mboxUpdate == "function") {
		var windowURL = window.location.href
	    windowURL = windowURL.slice( windowURL.indexOf('.')+1);
		windowURL = windowURL.split( '?' )[0];
		windowURL = windowURL.toLowerCase();
		//alert(windowURL);
		if (
		    //If no mboxes on page, mbox count will be < 1
		    (mboxFactoryDefault.getMboxes().length() < 1) &&  
			
			//Also check for high-volume pages that do not need global logging
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go") &&
			(windowURL != "bankofamerica.com/myaccounts/signin/signin.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/entry/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signonscreen.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatechallengeanswer.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatePassword.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/mobile/banking.go")&&
			(windowURL != "bankofamerica.com/content/preload/olb-myaccount-preload-jawr-module.htm")
			)
		{

			var mboxDiv = document.createElement("div");
			mboxDiv.id = "adobe_touch_clarity_replacement";
			mboxDiv.style.display = "none";
			if (document.body && document.body.firstChild) document.body.insertBefore(mboxDiv,document.body.firstChild);
			mboxDefine(mboxDiv.id,'bac_global_bottom');
			mboxUpdate('bac_global_bottom');
		}
	}	
})();
</script>

		<script src="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/Global/1.0/script/tealeafbundle.js" type="text/javascript"></script>
			<script>
				var boaPageDataJS = {};
					boaPageDataJS.isLLE = "false";
			</script>
				<style>body{display:none;}</style>
	</head>	

	<body class="fsd-layout-body">	

				<script type="text/javascript">if(self == top){var theBody=document.getElementsByTagName("body")[0];theBody.style.display="block";}else{top.location=self.location;}</script>
				<noscript><style>body{display:block;}</style></noscript>
					<a class='ada-hidden ada-visible-focus' href='#skip-to-h1' id='ada-skip-link'>Skip to main content</a>
		<div class="fsd-layout fsd-1c-layout">
			<div class="center-content">
				<div class="header">
		  



<script language="javascript" src="/pa/components/modules/tag-manager-module/1.1/script/tag-manager-module-borneo-global-skin.js"></script>
<script>

(function() {
  var fireCallback = function( cb ) {
    if ( typeof cb === "function" ) cb();
  };
  
  function ddoPopulateBase( callback ) {
    try {
		  var DDO = window.digitalData,
		  	bactm_mergeDDO = function( newDDO, priorDDO ) {
		  		if( typeof priorDDO === "undefined" ) {
				  	priorDDO = digitalData || {};
				  }

			    for (var l in newDDO) {
			        if (typeof priorDDO[l] === "undefined") {
			            priorDDO[l] = newDDO[l];
			        }
			        if (newDDO[l] !== null) {
			            if (typeof newDDO[l] === "object") {
			                bactm_mergeDDO(newDDO[l], priorDDO[l]);
			            } else {
			                priorDDO[l] = bactm_validateValue( newDDO[l] ) ? newDDO[l] : priorDDO[l];
			            }
			        }
			    }

			    return priorDDO;
				},
				bactm_olb3rdPartyId = "null";

			if (typeof DDO === "undefined") {
				var simpleDDO = { page: { pageInfo:[{ pageID: null }], attributes: {}, category: { primaryCategory: null }}};

				DDO = (typeof digitalData === "object") ? digitalData : simpleDDO; 
			}

				DDO = bactm_mergeDDO( {pageInstanceID:"notprod",load_coremetrics:false,load_opinionlabs:false,load_touchcommerce:true,load_audiencemanager:true,page:{pageInfo:[{pageID:"smbus:Content:Mobile;features",destinationURL:null,referringURL:null,issueDate:null,language:null,segmentValue:null,appName:null,appStepNumber:null,appStepName:null,attr:"-_--_--_--_--_--_--_--_--_--_--_--_--_--_-"}],category:{primaryCategory:null,addlCategory:null,pageType:null},attributes:{searchString:null,searchResults:null,olbSessionID:null,subCampaignCode:null,DARTUrl:null,stateCookie:null,SASIEnabled:false,needOLBcookie:false,standardDART:[],standardDARTes:[],clickDART:[],clickDARTes:[],gaId:[],chat:{account_type:null,boa_associate:null,boa_retiree:null,customer_lob:null,customer_segment:null,data:null,email_campaign:null,entitlement_code:null,error_category:null,error_count:null,first_login:null,inqSalesProductTypes:{},invitation_background:null,invitation_template:null,referral_campaign:null,getStateValue:false,cust_fn:null,cust_ln:null,target:null}}},user:{segment:null,online_id:null,preferred_rewards_tier:null,olb3rdpartyid:null},version:"BAC_0.12"}, DDO );

			DDO.page.pageInfo[0].pageID = "smbus:Content:OLBs:Mobile_Banking;features";
			DDO.page.category.primaryCategory  = "smbus:Content:OLBs:Mobile_Banking";
			DDO.page.pageInfo[0].language = "en-US";
			DDO.page.attributes.olbSessionID = "null";
			DDO.page.attributes.SASIEnabled =  "false";
			if (typeof DDO.user != "undefined" && typeof DDO.user.olb3rdpartyid != "undefined") {
				DDO.user.olb3rdpartyid = bactm_olb3rdPartyId;
			}

			window.utag_data = {};
			window.bactm_envSelector = bactm_setTMLib();
			window.digitalData = DDO;

      return fireCallback( callback );

    } catch(e) { }
  }
	if( window.boa && window.boa.digitalData ) {
    window.boa.digitalData.register( ddoPopulateBase );
	}
	else {
	  // Handle scenario where the header isn't available (and thus the default digitalData object and utag loader are missing).
	  //
		var writeScript = function(a,b,c,d){
			a='//tags.tiqcdn.com/utag/bofa/main/' + bactm_envSelector + '/utag.js';
			b=document;
			c='script';
			d=b.createElement(c);
			d.src=a;
			d.type='text/java'+c;
			d.async=true;
			a=b.getElementsByTagName(c)[0];
			a.parentNode.insertBefore(d,a);
		};

		ddoPopulateBase( writeScript );
	}
})();			
</script>




 


<div class="header-module">
	<div class="text-w-logo-skin">
		<div class="header-left">
	  
			<div itemscope itemtype="http://schema.org/Corporation" class="bofa-logo">
				<a itemprop="url" name="anc-business-advantage" title="Bank of America" href="/">
					<img itemprop="logo" height="28" width="221" 
					     alt="Bank of America" src="https://www2.bac-assets.com/content/images/ContextualSiteGraphics/Logos/en_US/new-bac-logo.gif"/>
				</a>
			</div>
				<div class="product" data-font="cnx-regular">Business Advantage</div>
			
			<div class="clearboth"></div>

		</div>
		
		<div class="header-right">
			<ul class="header-links">
			
				
					
				
							<li class="sign-in">
		<a					href="/sitemap/hub/signin.go" target="_self"
		name="anc-signin">Sign in</a> 
							</li>
					
				
							<li>		<a					href="/smallbusiness/" target="_self"
		name="anc-small-business-home">Small Business Home</a> 
</li>
					
				
							<li>		<a					href="http://locators.bankofamerica.com/locator/locator/LocatorAction.do" target="_self"
		name="anc-sb-locations">Locations</a> 
</li>
					
				
							<li>		<a					href="/contactus/contactus.go?topicId=mobile_text_banking" target="_self"
		name="anc-sb-contact-us">Contact us</a> 
</li>
					
				
							<li class="last-link">	
		<a					href="/smallbusiness/online-banking/mobile/faqs.go" target="_self"
		name="anc-sb-help">Help</a> 
							</li>
			</ul>
			
			<div class="clearboth"></div>

			<!-- include search-dotcom-util -->



<div class="header-search nlh">
  
  <div class="nav-search">
    <form class="search-form" action="https://secure.bankofamerica.com/myaccounts/public/search-results/unAuthenticatedSearch.go" data-js="/pa/components/utilities/search-util/1.0/script/nav-search.min.js" data-css="/pa/components/utilities/search-util/1.0/style/nav-search.css" data-text-unavailable="Search Currently Unavailable">
      <div class="search-input-container cf" data-icon="search">
        <label for="nav-search-query" class="ada-hidden">Search Term</label>
        <input type="text" placeholder="How can we help you?" name="query" class="search-query" id="nav-search-query" 
          maxlength="99" rel="Search" autocomplete="off"><input type="submit" alt="Search" title="Search" value="Submit Search" name="Search Module - Top Result – Search Button" class="submit track-me">
      </div>
    </form>
  </div>

</div>

		</div>

 		<div class="clearboth"></div>
 	</div>
</div>
<!-- module start here -->
<!-- top nav 1.7 with fsd skin -->

	<div class="top-nav-module">
		<div class="fsd-skin sup-ie">
			<ul class="nav-list">
					
					
					<li>
						
								<a href="/smallbusiness/online-banking.go" class="top-menu-item"
								name="anc_sb_online_banking_topnav" id="anc_sb_online_banking_topnav">Online Banking<span class="ada-hidden">  link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/smallbusiness/online-banking.go"  name="anc_sb_biz_online_banking_features_topnav" id="anc_sb_biz_online_banking_features_topnav">Business Online Banking </a>
															<a href="/smallbusiness/online-banking/account-management.go"  name="anc_sb_acct_perm_features_topnav" id="anc_sb_acct_perm_features_topnav">Account Permissions </a>
															<a href="/smallbusiness/online-banking/quickbooks.go"  name="anc_sb_quickbooks_features_topnav" id="anc_sb_quickbooks_features_topnav">QuickBooks<sup>&reg;</sup> </a>
									</div>
								
									<div class="hasSub">
														<a class="with-info" href="/smallbusiness/online-banking/features.go"  name="anc_business_empo_features_topnav" id="anc_business_empo_features_topnav">Empower Your Business 
															
															<span class="sub-nav-item-info">See a full list of Online Banking and optional add-on services</span>
														</a>
									</div>
									<span class="ada-hidden">End of sub menu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
					
					
					<li>
						
								<a href="/smallbusiness/online-banking/cash-management.go" class="top-menu-item"
								name="anc_sb_cash_mgmt_topnav" id="anc_sb_cash_mgmt_topnav">Cash Management<span class="ada-hidden">  link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/smallbusiness/online-banking/cash-management.go"  name="anc_sb_cash_mgmt_overview_features_topnav" id="anc_sb_cash_mgmt_overview_features_topnav">Cash Management Tools </a>
															<a href="/smallbusiness/online-banking/cash-management/remote-deposit.go"  name="anc_sb_remote_deposits_features_topnav" id="anc_sb_remote_deposits_features_topnav">Remote Deposit </a>
															<a href="http://promo.bankofamerica.com/olbs/olbs_directpayment.html"  name="anc_sb_invoicing_features_topnav" id="anc_sb_invoicing_features_topnav">Invoicing and Payments </a>
															<a href="/smallbusiness/online-banking/cash-management/tax-services.go"  name="anc_sb_tax_services_features_topnav" id="anc_sb_tax_services_features_topnav">Tax Services </a>
															<a href="/smallbusiness/online-banking/cash-management/merchant-services.go"  name="anc_sb_merchant_services_features_topnav" id="anc_sb_merchant_services_features_topnav">
																Merchant Services 
															</a>
									</div>
								
									<div class="hasSub">
									</div>
									<span class="ada-hidden">End of sub menu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
					
					
					<li>
						
								<a href="/smallbusiness/online-banking/payroll.go" class="top-menu-item"
								name="anc_sb_payroll_topnav" id="anc_sb_payroll_topnav">Payroll<span class="ada-hidden">  link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/smallbusiness/online-banking/payroll.go"  name="anc_sb_online_payroll_overview_features_topnav" id="anc_sb_online_payroll_overview_features_topnav">Online Payroll Overview </a>
															<a href="/smallbusiness/online-banking/payroll/self-service.go"  name="anc_sb_self_service_payroll_features_topnav" id="anc_sb_self_service_payroll_features_topnav">Self Service Payroll </a>
															<a href="/smallbusiness/online-banking/payroll/full-service.go"  name="anc_sb_full_service_payroll_features_topnav" id="anc_sb_full_service_payroll_features_topnav">Full Service Payroll </a>
															<a href="/smallbusiness/online-banking/payroll/compare-services.go"  name="anc_compare_payroll_options_features_topnav" id="anc_compare_payroll_options_features_topnav">Compare Payroll Options </a>
									</div>
								
									<div class="hasSub">
									</div>
									<span class="ada-hidden">End of sub menu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
					
					
					<li>
						
								<a href="/smallbusiness/online-banking/mobile.go" class="top-menu-item selected"
								name="anc_sb_mobile_banking_topnav" id="anc_sb_mobile_banking_topnav">Mobile Banking<span class="ada-hidden">  link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/smallbusiness/online-banking/mobile/features.go"  name="anc_sb_mobile_banking_features_features_topnav" id="anc_sb_mobile_banking_features_features_topnav">Mobile Banking Features </a>
															<a href="/smallbusiness/online-banking/mobile/app/overview.go"  name="anc_sb_understanding_basics_features_topnav" id="anc_sb_understanding_basics_features_topnav">Understanding the Basics </a>
									</div>
								
									<div class="hasSub">
														<a class="with-info" href="http://merch.bankofamerica.com/clovergo-overview"  name="anc_mobile_pay_features_topnav" id="anc_mobile_pay_features_topnav">Mobile Pay 
															<img class="externalLinkArrow" src="/content/images/ContextualSiteGraphics/Instructional/en_US/arrow-external-link.gif" alt="" />
															<span class="sub-nav-item-info">Bank of America Merchant Services MobilePay&#8480; provides fast, secure payment processing using your smartphone</span>
														</a>
									</div>
									<span class="ada-hidden">End of sub menu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
			</ul>
				<div class="clearboth"></div>
		</div>
	</div>

<!-- module ends here -->

<div class="page-title-fsd-module h-100" id="skip-to-h1">
	<div class="standard-gray-skin sup-ie">
		<h1 data-font="cnx-regular">Mobile Banking Services</h1>
  </div>
</div>


<!-- banner-module-top-left-c2a 1.7 r2 -->


	
		
	<div class="banner-module">
		<div class="top-left-c2a-skin" style="background:#b8d8f3 url('/content/images/ContextualSiteGraphics/Instructional/en_US/SB/Hero_Image.jpg') no-repeat;width:980px;height:325px;">
			<div class="banner-c2a" style="width:415px;">
				<p class="c2a-title">Mobile app: the best choice for your smartphone or tablet</p>
						<!-- DART Coremetrics -->
						<a href="javascript:void(0);" class="button-common-large button-blue-large show-mobile-app-download-modal" name="anc-get-app-for-smallbusiness-mobile-features" rel="mobile-app-download-modal" onClick="dartFireOnClick('1359940','bacal484','mb_sm452');cmCreatePageviewTag('smbus:Content:Mobile;send-communication', null, null, 'smbus:Content:Mobile', false, false, null, false, false, null, null, null, null, null, null, null, null, null, null, null, null);"><span>Get the app</span><span class="ada-hidden"> layer</span></a>
				<div class="clearboth"></div>
			</div>
		</div>
	</div>	



<div class="in-page-nav-module">
	<div class="icon-bar-skin">
	   	<div id="in-page-nav-back-to-top" class="ip-nav">
					
					<a href="#accounts-section" name="in-page-nav-accounts" class="ipn-accounts">
						<span>
							<span class="ipn-inner">
								<span>Accounts</span>
							</span>
						</span>
					</a>
					
					<a href="#transfers-section" name="in-page-nav-transfers" class="ipn-transfers">
						<span>
							<span class="ipn-inner">
								<span>Transfers</span>
							</span>
						</span>
					</a>
					
					<a href="#deposits-section" name="in-page-nav-deposits" class="ipn-deposits">
						<span>
							<span class="ipn-inner">
								<span>Deposits</span>
							</span>
						</span>
					</a>
					
					<a href="#secure-section" name="in-page-nav-secure" class="ipn-secure">
						<span>
							<span class="ipn-inner">
								<span>Security</span>
							</span>
						</span>
					</a>
					
					<a href="#billpay-section" name="in-page-nav-billpay" class="ipn-billpay">
						<span>
							<span class="ipn-inner">
								<span>Bill Pay</span>
							</span>
						</span>
					</a>
					
					<a href="#alerts-section" name="in-page-nav-alerts" class="ipn-alerts">
						<span>
							<span class="ipn-inner">
								<span>Alerts</span>
							</span>
						</span>
					</a>
					
					<a href="#deals-section" name="in-page-nav-deals" class="ipn-deals">
						<span>
							<span class="ipn-inner">
								<span>BankAmeriDeals&trade;</span>
							</span>
						</span>
					</a>
					
					<a href="#locations-section" name="in-page-nav-locations" class="ipn-locations">
						<span>
							<span class="ipn-inner">
								<span>Locations <span class="ada-hidden">feature</span></span>
							</span>
						</span>
					</a>
					
					<a href="#calview-section" name="in-page-nav-calview" class="ipn-calview last-ipn-link">
						<span>
							<span class="ipn-inner">
								<span>Calendar</span>
							</span>
						</span>
					</a>
		<div class="clearboth"></div> 
	    </div>
	</div>
</div>	


<SCRIPT language="JavaScript">

if (document.referrer){
var ord = Math.random()*1000000000000;
document.write('<SCRIPT language="JavaScript1.1" SRC="https://ad.doubleclick.net/adj/N4359.nso.codesrv/B7578164;dcadv=4104884;sz=1x2;ord;ord=' + ord + '?"><\/SCRIPT>');
}
var naturalSearchComplete = true;

</SCRIPT>

</div>
				<div class="columns">
					<div class="one-col">




<div class="in-page-content-module">
	<div class="split-img-skin">
					<!-- Image right -->
					<div class="ipc-section" id="accounts-section">
						<div class="ipc-col ipc-left-col">
							<div class="ipc-main-content">
								<div class="ipc-header">
										<div class="ipc-icon ipc-accounts"></div>
										<h2>Access your accounts</h2>
									<div class="clearboth"></div>
								</div>
								<h3>The information you need, available anytime</h3><p>Double-check the balance on your accounts right before you take your sales team to lunch, set off on an emergency supply run, or when you&rsquo;re making a transfer or paying bills. Your account information is there when you want it.</p><h3>Manage your finances, whatever your schedule</h3><ul class="gray-sq-bullet"><li>Check balances for all of your Bank of America banking accounts&mdash;business, personal and Merrill Edge<sup>&reg;</sup> investment accounts</li><li>Transfer balances between accounts to pay suppliers or employees</li><li>Easily check to ensure that monthly payments from your supplier have posted</li><li>Track your recent posted and pending transactions</li></ul><p>Access your accounts via an app developed specifically for your iPhone<sup>&reg;</sup>, Windows<sup>&reg;</sup> phone, iPod touch<sup>&reg;</sup>, Android&trade; phone, iPad<sup>&reg; </sup>or Android&trade; tablet.</p><div class="inline-aware-msg"><div class="inline-aware-msg-nobg"><p>Mobile account access is available in our Mobile Banking App. <a class="show-mobile-app-download-modal" onclick="dartFireOnClick(&quot;1359940&quot;,&quot;bacal484&quot;,&quot;mb_sm452&quot;);cmCreatePageviewTag('smbus:Content:Mobile;send-communication', null, null, 'smbus:Content:Mobile', false, false, null, false, false, null, null, null, null, null, null, null, null, null, null, null, null);" rel="mobile-app-download-modal" name="anc-get-app-accounts" href="javascript:void;">Get the app<span class="ada-hidden">&nbsp;layer</span></a>&nbsp;It&rsquo;s also available with <a name="anc-text-banking-accounts" href="/smallbusiness/online-banking/mobile/text.go" target="_self">Text Banking</a> and on our <a name="anc-mobile-website-accounts" href="/smallbusiness/online-banking/mobile/website.go" target="_self">Mobile Website.</a></p>
<p>Our mobile app gives you more Mobile Banking options and features while <a name="anc-text-banking-accounts-feature" href="/smallbusiness/online-banking/mobile/text.go" target="_self">Text Banking</a> is the fastest way to get your account balances and recent transaction history from any mobile phone, without signing in. Use either depending on your time and need.</p></div></div>
							</div>
								
								<a href="#in-page-nav-back-to-top" name="ipn-back-to-top-accounts-access" class="ipc-back2top">Back to top</a>
						</div>
						<div class="ipc-col">
									<img width="225" src="https://www2.bac-assets.com/content/images/ContextualSiteGraphics/Instructional/en_US/SB/Accounts_Screenshot.jpg" alt="" />
						</div>
						<div class="clearboth"></div>
					</div>
					<!-- Image left -->
					<div class="ipc-section ipc-alt-section" id="transfers-section">
						<div class="ipc-col ipc-left-col">
									<img width="225" src="https://www2.bac-assets.com/content/images/ContextualSiteGraphics/Instructional/en_US/SB/Transfers_Screenshot.jpg" alt="" />
						</div>
						<div class="ipc-col">
							<div class="ipc-main-content">
								<div class="ipc-header">
										<div class="ipc-icon ipc-transfers"></div>
										<h2>Make transfers</h2>
									<div class="clearboth"></div>
								</div>
								<h3>Regular account transfers are fast, simple and secure</h3><ul class="gray-sq-bullet"><li>Make transfers immediately between your Bank of America accounts</li><li>Schedule transfers for later</li><li>Review or cancel scheduled transfers</li></ul><p>Make transfers via an app developed specifically for your iPhone, iPod touch, Android phone, Windows phone, iPad or&nbsp;Android tablet.</p><div class="inline-aware-msg"><div class="inline-aware-msg-nobg"><p>Mobile transfers are available in our Mobile Banking App. <a class="show-mobile-app-download-modal" onclick="dartFireOnClick(&quot;1359940&quot;,&quot;bacal484&quot;,&quot;mb_sm452&quot;);cmCreatePageviewTag('smbus:Content:Mobile;send-communication', null, null, 'smbus:Content:Mobile', false, false, null, false, false, null, null, null, null, null, null, null, null, null, null, null, null);" rel="mobile-app-download-modal" name="anc-get-app-transfers" href="javascript:void;">Get the app<span class="ada-hidden">&nbsp;layer</span></a></p>
<p>Mobile transfers are also available on our <a name="anc-mobile-website-transfer" href="/smallbusiness/online-banking/mobile/website.go" target="_self">Mobile Website</a>.</p></div></div>
							</div>

								<a href="#in-page-nav-back-to-top" name="ipn-back-to-top-accounts-transfers" class="ipc-back2top">Back to top</a>
						</div>
						<div class="clearboth"></div>
					</div> 
					<!-- Image right -->
					<div class="ipc-section" id="deposits-section">
						<div class="ipc-col ipc-left-col">
							<div class="ipc-main-content">
								<div class="ipc-header">
										<div class="ipc-icon ipc-deposits"></div>
										<h2>Make deposits</h2>
									<div class="clearboth"></div>
								</div>
								<p><strong>We offer remote deposit options for your business that allow you to bank where you want and on your schedule, not ours.</strong></p><h3>On the mobile app: Mobile Check Deposit</h3><p>Say you&rsquo;re visiting with a client and the client hands you a check. With Mobile Check Deposit, you can use select devices to simply snap pictures of the check, choose your account, enter the amount and send.</p><h3>Available at your convenience</h3><p>After the deposit has been processed and posted to your account, you&rsquo;ll see the check images displayed with the deposit transaction item in Mobile Banking and Small Business Online Banking. In Small Business Online Banking, just click on the images and you&rsquo;ll be able to print copies for your records. Your check images are stored only at the bank, not on your device.</p><p>Make deposits via an app developed specifically and exclusively for your iPhone, iPod touch, Android phone, Windows phone, iPad or Android tablet.</p><div class="inline-aware-msg"><div class="inline-aware-msg-nobg"><p>Mobile Check Deposit is available exclusively in our Mobile Banking App. <a class="show-mobile-app-download-modal" onclick="dartFireOnClick(&quot;1359940&quot;,&quot;bacal484&quot;,&quot;mb_sm452&quot;);cmCreatePageviewTag('smbus:Content:Mobile;send-communication', null, null, 'smbus:Content:Mobile', false, false, null, false, false, null, null, null, null, null, null, null, null, null, null, null, null);" rel="mobile-app-download-modal" name="anc-get-app-deposits" href="javascript:void;">Get the app<span class="ada-hidden">&nbsp;layer</span></a></p>
<p><strong>Want even more convenience?</strong> Learn about Small Business Remote Deposit Online. Deposit and view multiple checks with our scanner from your home or office, without going to a bank location. <a href="/smallbusiness/online-banking/cash-management/remote-deposit.go">Compare remote deposit options for small business</a></p></div></div>
							</div>
								
								<a href="#in-page-nav-back-to-top" name="ipn-back-to-top-deposits" class="ipc-back2top">Back to top</a>
						</div>
						<div class="ipc-col">
									<img width="225" src="https://www2.bac-assets.com/content/images/ContextualSiteGraphics/Instructional/en_US/SB/Deposits_Screenshot.jpg" alt="" />
						</div>
						<div class="clearboth"></div>
					</div>
					<!-- Image left -->
					<div class="ipc-section ipc-alt-section" id="secure-section">
						<div class="ipc-col ipc-left-col">
									<img width="225" src="https://www2.bac-assets.com/content/images/ContextualSiteGraphics/Instructional/en_US/SB/Security_Screenshot.jpg" alt="" />
						</div>
						<div class="ipc-col">
							<div class="ipc-main-content">
								<div class="ipc-header">
										<div class="ipc-icon ipc-secure"></div>
										<h2>Security is our first priority</h2>
									<div class="clearboth"></div>
								</div>
								<p>Millions of customers rely on our proven privacy and security. Our fraud prevention and security systems protect you with the latest encryption technology.</p><h3>Multiple layers of security</h3><p>Our app requires you to sign in the same way you do with Small Business Online Banking. We do not allow your Passcode or any account information to be stored on your device. As additional security, you can use <a class="boa-dialog boa-com-info-layer-link" rel="glossary-popup-1" name="anc-safepass" href="javascript:void(0);">SafePass</a>.</p><div class="inline-aware-msg"><div class="inline-aware-msg-nobg"><p>Security is our priority no matter how you choose to bank with us.</p></div></div>
							</div>

								<a href="#in-page-nav-back-to-top" name="ipn-back-to-top-security" class="ipc-back2top">Back to top</a>
						</div>
						<div class="clearboth"></div>
					</div> 
					<!-- Image right -->
					<div class="ipc-section" id="billpay-section">
						<div class="ipc-col ipc-left-col">
							<div class="ipc-main-content">
								<div class="ipc-header">
										<div class="ipc-icon ipc-billpay"></div>
										<h2>Pay bills on time, even when you&rsquo;re away</h2>
									<div class="clearboth"></div>
								</div>
								<p>No stamps, no envelopes, no worries. On a business trip or long-awaited vacation, paying your bills is easy with Bill Pay.</p><h3>On-time flexible payments</h3><p>Choose the amount and when to pay. You can pay a bill to a company or individual once or plan recurring payments, schedule it a few days from now or next month if you like. With Bank of America, your payments are paid to your designated Pay To accounts on dates you choose in Bill Pay and for the dollar amounts you specify.</p><p>To take advantage of this feature on your mobile device, be sure you&rsquo;ve first set up the Pay To accounts you want in Small Business Online Banking.</p><h3>eBills instead of paper</h3><p>Get your bills online from any company participating in eBills (there are thousands). If you&rsquo;re not already receiving eBills, first set up eBills in Small Business Online Banking. Once you have payees and eBills in your Small Business Online Banking account, you can easily pay your bills using Mobile Banking. Your online payment history confirms whom you paid, the date and the amount. Your payments are now on time, wherever you are.</p><p>Use Bill Pay via an app developed specifically for your iPhone, iPod touch, Android phone, Windows phone, iPad or&nbsp;Android tablet.</p><div class="inline-aware-msg"><div class="inline-aware-msg-nobg"><p>Mobile Bill Pay is available in our Mobile Banking App. <a class="show-mobile-app-download-modal" onclick="dartFireOnClick(&quot;1359940&quot;,&quot;bacal484&quot;,&quot;mb_sm452&quot;);cmCreatePageviewTag('smbus:Content:Mobile;send-communication', null, null, 'smbus:Content:Mobile', false, false, null, false, false, null, null, null, null, null, null, null, null, null, null, null, null);" rel="mobile-app-download-modal" name="anc-get-app-billpay" href="javascript:void;">Get the app<span class="ada-hidden">&nbsp;layer</span></a></p>
<p>Mobile Bill Pay is also available on our <a name="anc-mobile-website-billpay" href="/smallbusiness/online-banking/mobile/website.go" target="_self">Mobile Website</a>.</p></div></div>
							</div>
								
								<a href="#in-page-nav-back-to-top" name="ipn-back-to-top-billpay" class="ipc-back2top">Back to top</a>
						</div>
						<div class="ipc-col">
									<img width="225" src="https://www2.bac-assets.com/content/images/ContextualSiteGraphics/Instructional/en_US/SB/BillPay_Screenshot.jpg" alt="" />
						</div>
						<div class="clearboth"></div>
					</div>
					<!-- Image left -->
					<div class="ipc-section ipc-alt-section" id="alerts-section">
						<div class="ipc-col ipc-left-col">
									<img width="225" src="https://www2.bac-assets.com/content/images/ContextualSiteGraphics/Instructional/en_US/SB/Alerts_Screenshot.jpg" alt="" />
						</div>
						<div class="ipc-col">
							<div class="ipc-main-content">
								<div class="ipc-header">
										<div class="ipc-icon ipc-alerts"></div>
										<h2>Choose your alerts</h2>
									<div class="clearboth"></div>
								</div>
								<p>Whether you&rsquo;re at the airport, in the warehouse or on a loading dock, you can rely on alerts to inform you of changes and updates to your account. When you set up Mobile App Alerts, you&rsquo;ll receive the account information you care about as push notifications on your iPhone, iPod touch, iPad, Android phone, Windows phone&nbsp;and&nbsp;Android tablet. You can also get BankAmeriDeals&trade; alerts when new cash back deals are available or about to expire.</p><h3>Peace of mind</h3><p>Help prevent late fees and overdraft fees by knowing when your business checking account balance drops below an amount you set or when an eBill is due but no payment is scheduled yet. Best of all, you can take immediate action, like using the <strong>Make transfer</strong> link in the low balance alert.</p><h3>Security</h3><p>You can also set alerts for irregular account activity or changes to your Small Business Online Banking profile.</p><p>Get alerts via an app developed specifically and exclusively for your iPhone, iPod touch, Android phone, Windows phone, iPad or Android tablet.</p><div class="inline-aware-msg"><div class="inline-aware-msg-nobg"><p>Mobile App Alerts are available in our Mobile Banking App. <a class="show-mobile-app-download-modal" onclick="dartFireOnClick(&quot;1359940&quot;,&quot;bacal484&quot;,&quot;mb_sm452&quot;);cmCreatePageviewTag('smbus:Content:Mobile;send-communication', null, null, 'smbus:Content:Mobile', false, false, null, false, false, null, null, null, null, null, null, null, null, null, null, null, null);" rel="mobile-app-download-modal" name="anc-get-app-alerts" href="javascript:void;">Get the app<span class="ada-hidden">&nbsp;layer</span></a></p>
<p>You can also set up Online Banking Alerts to get the same information sent as email and text messages.</p></div></div>
							</div>

								<a href="#in-page-nav-back-to-top" name="ipn-back-to-top-alerts" class="ipc-back2top">Back to top</a>
						</div>
						<div class="clearboth"></div>
					</div> 
					<!-- Image right -->
					<div class="ipc-section" id="deals-section">
						<div class="ipc-col ipc-left-col">
							<div class="ipc-main-content">
								<div class="ipc-header">
										<div class="ipc-icon ipc-deals"></div>
										<h2>BankAmeriDeals&trade;</h2>
									<div class="clearboth"></div>
								</div>
								<h3>Easier than ever to earn cash back</h3><p>When you&rsquo;re out replenishing inventory or having lunch, check BankAmeriDeals&trade; on your device and see if you can earn cash back.</p><h3>Simple to select</h3><p>BankAmeriDeals&trade; retail and restaurant cash back deals can be selected on your compatible device. The deals you select are added automatically to your eligible debit cards.</p><h3>Simple to use</h3><p>Pay for your purchases with your eligible Bank of America cards. When you swipe your card, your cash back is automatically calculated and credited to your business checking account on a monthly basis.</p><p>Enjoy BankAmeriDeals&trade; via an app developed specifically and exclusively for your iPhone, iPod touch, Android phone, Windows phone,&nbsp;iPad or Android tablet.</p><div class="inline-aware-msg"><div class="inline-aware-msg-nobg"><p>Mobile BankAmeriDeals&trade; are available exclusively in our Mobile Banking App. <a class="show-mobile-app-download-modal" onclick="dartFireOnClick(&quot;1359940&quot;,&quot;bacal484&quot;,&quot;mb_sm452&quot;);cmCreatePageviewTag('smbus:Content:Mobile;send-communication', null, null, 'smbus:Content:Mobile', false, false, null, false, false, null, null, null, null, null, null, null, null, null, null, null, null);" rel="mobile-app-download-modal" name="anc-get-app-deals" href="javascript:void;">Get the app<span class="ada-hidden">&nbsp;layer</span></a></p></div></div><p class="disclaimerText">Offers shown for illustrative purposes only. Participating merchants may vary.</p>
							</div>
								
								<a href="#in-page-nav-back-to-top" name="ipn-back-to-top-deals" class="ipc-back2top">Back to top</a>
						</div>
						<div class="ipc-col">
									<img width="225" src="https://www2.bac-assets.com/content/images/ContextualSiteGraphics/Instructional/en_US/SB/BankAmerideals_Screenshot.jpg" alt="" />
						</div>
						<div class="clearboth"></div>
					</div>
					<!-- Image left -->
					<div class="ipc-section ipc-alt-section" id="locations-section">
						<div class="ipc-col ipc-left-col">
									<img width="225" src="https://www2.bac-assets.com/content/images/ContextualSiteGraphics/Instructional/en_US/SB/Locations_Screenshot.jpg" alt="" />
						</div>
						<div class="ipc-col">
							<div class="ipc-main-content">
								<div class="ipc-header">
										<div class="ipc-icon ipc-locations"></div>
										<h2>Locations for ATMs and banking centers</h2>
									<div class="clearboth"></div>
								</div>
								<p>Traveling in an unfamiliar city is a lot less stressful when you know exactly where to find your bank, especially if you need something extra like a 24-hour or Talking ATM or a banking center open on Saturday.</p><h3>Pinpoint your search for the following:</h3><ul class="gray-sq-bullet"><li>ATMs</li><li>24-hour ATMs</li><li>Talking ATMs</li><li>Drive-up ATMs</li><li>Banking center</li><li>Banking centers open on Saturday</li></ul><h3>Locations near you</h3><p>Find locations via an app developed specifically for your iPhone, iPod touch, Android phone, Windows phone, iPad or Android tablet.</p><div class="inline-aware-msg"><div class="inline-aware-msg-nobg"><p>The Locations feature is available in our Mobile Banking App. <a class="show-mobile-app-download-modal" onclick="dartFireOnClick(&quot;1359940&quot;,&quot;bacal484&quot;,&quot;mb_sm452&quot;);cmCreatePageviewTag('smbus:Content:Mobile;send-communication', null, null, 'smbus:Content:Mobile', false, false, null, false, false, null, null, null, null, null, null, null, null, null, null, null, null);" rel="mobile-app-download-modal" name="anc-get-app-locations" href="javascript:void;">Get the app<span class="ada-hidden">&nbsp;layer</span></a></p>
<p>The Locations feature (without the capability to detect nearest location) is also available on our <a name="anc-mobile-website-locations" href="/smallbusiness/online-banking/mobile/website.go" target="_self">Mobile Website</a>.</p></div></div>
							</div>

								<a href="#in-page-nav-back-to-top" name="ipn-back-to-top-locations" class="ipc-back2top">Back to top</a>
						</div>
						<div class="clearboth"></div>
					</div> 
					<!-- Image right -->
					<div class="ipc-section ipc-section-last" id="calview-section">
						<div class="ipc-col ipc-left-col">
							<div class="ipc-main-content">
								<div class="ipc-header">
										<div class="ipc-icon ipc-calview"></div>
										<h2>Payments and transfers calendar</h2>
									<div class="clearboth"></div>
								</div>
								<p>The calendar&mdash;available on the iPad and Android tablet&mdash;is the fastest way to view, check and manage your outgoing payments and transfers each month.</p><h3>Monthly calendar view</h3><p>A quick glance shows you the eBills, outgoing payments and Scheduled Transfers you&rsquo;re expecting for each month so you have even more control over your business accounts.</p><h3>Take immediate action</h3><p>Make changes to any payments or transfers directly in the calendar. Select a date to pay a bill or schedule a transfer, change a date or cancel a payment.</p><div class="inline-aware-msg"><div class="inline-aware-msg-nobg"><p>Our calendar is available exclusively in our Mobile Banking App for iPad and Android tablet. <a class="show-mobile-app-download-modal" onclick="dartFireOnClick(&quot;1359940&quot;,&quot;bacal484&quot;,&quot;mb_sm452&quot;);cmCreatePageviewTag('smbus:Content:Mobile;send-communication', null, null, 'smbus:Content:Mobile', false, false, null, false, false, null, null, null, null, null, null, null, null, null, null, null, null);" rel="mobile-app-download-modal" name="anc-get-app-calender" href="javascript:void;">Get the app<span class="ada-hidden">&nbsp;layer</span></a></p></div></div>
							</div>
								
								<a href="#in-page-nav-back-to-top" name="ipn-back-to-top-calview" class="ipc-back2top">Back to top</a>
						</div>
						<div class="ipc-col">
									<img width="255" src="https://www2.bac-assets.com/content/images/ContextualSiteGraphics/Instructional/en_US/SB/calendar.jpg" alt="" />
						</div>
						<div class="clearboth"></div>
					</div>
	</div>
</div>


</div>
				</div>
				<div class="footer">
					<div class="footer-top">&nbsp;






<script type="text/javascript">
$(function() {
  try {
		boa.form.init();
  } catch(error) {};
});
</script>








<script type="text/javascript">
	setCurrentLocale("en-US");
	setDeviceName("");
</script>

	<div id="mobile-app-download-modal" class="hide">
		<div class="mobile-app-download-module">
			<div class="modal-skin">
				<h3>Get the app</h3>
				<div class="flex-modal-main-content">
				<div class="download-form">
				<!-- CMS replace action with actual URL -->
				<form class="common-form" data-common-form="validation gis-mask" id="mobile_app_download_url" action="https://www.bankofamerica.com/online-banking/smallbusiness/send-communication.go">
					<div class="select-mobile-device">
						<label>Select your device</label>
						<div class="clearboth"></div>
						<p>(You must be enrolled in <a id="sb_online_banking_enroll" name="sb_online_banking_enroll" href="https://secure.bankofamerica.com/login/enroll/entry/olbEnroll.go" target="_self" title="">Small Business Online Banking</a>)</p>
						<div class="clearboth"></div>
						<label for="mobile_app_device" class="ada-hidden">Select your device.  Press TAB to continue after making selection.</label>
						<select id="mobile_app_device" name="mobile_app_device" class="custom-select">
							<option value="" selected="selected">(Select)</option>
							<option value="iPhone">iPhone</option>
							<option value=""></option>
							<option value="Android">Android phone</option>
							<option value="Windows">Windows Phone</option>
							<option value=""></option>
							<option value="iPad">iPad</option>
							<option value="Android tablet">Android tablet</option>
							<option value=""></option>
							<!-- <option value="Other device">Other device</option> -->
						</select>
					</div>
					<div class="download-app">
						<label>Download the free Mobile App</label>
						<div id="device-address-prompt"> Enter your <span id="device-name-prompt"></span>
							<span id="phone-number-prompt">phone number and we&rsquo;ll text you a download link:</span>
							<span id="email-address-prompt">email address and we&rsquo;ll email you a download link:</span>
						</div>
						<div class="validation-error" aria-live="rude"> Please enter a valid email address. </div>
						<div class="validation-error-phNum" aria-live="rude"> Please enter a valid phone number  </div>
						<div class="validation-error-only-numbers" aria-live="rude"> Please use only numbers.  </div>
						<div class="validation-error-num-len" aria-live="rude"> Please use exactly 10 numbers.  </div>
						<div class="validation-error-email-addr" aria-live="rude"> Please remove special characters #, $, %, ^, & </div>
						<label id="mobile_app_download_phone_prompt" name="mobile_app_download_phone_prompt" for="tlpvt-mob_app_download_phone_num" class="ada-hidden">Please enter your phone number and we'll text you a download link</label>
						<span class="inputBoxfirst"></span>
						<input id="tlpvt-mob_app_download_phone_num" name="mobile_app_download_phone_number" type="text" class="tl-private gis-mask" data-field-type="phone">
						<input id="tlpvt-mob_app_download_email" name="mobile_app_download_email" type="text" class="tl-private gis-mask" data-field-type="email">
						
						<a id="mobile_app_download_send_button" href="javascript:void(0);" class="button-common button-gray" name="anc-send-email-button"><span>Send</span><span class="ada-hidden"> mobile app download link via text</span></a>
						<div class="clearboth"></div>
						<div id="mobile_app_static_text">
							By providing your mobile number you are consenting to receive a text message. Text message fees may apply from your carrier.  Text messages may be transmitted automatically.
						</div>

						<div class="app-store">
						<a id="apple-app-store-logo" href="http://itunes.apple.com/us/app/bank-america-mobile-banking/id284847138?mt=8" name="AppleAppStore"><img alt="Apple App Store" src="https://www2.bac-assets.com/content/images/ContextualSiteGraphics/Logos/en_US/Icons_mobile_products/icon_Apple_CTA.png"/></a>
						<a id="apple-app-store-logo-ipad" href="http://itunes.apple.com/us/app/bank-of-america-for-ipad/id433508740?mt=8&ls=1" name="AppleAppStoreIpad"><img alt="Apple App Store" src="https://www2.bac-assets.com/content/images/ContextualSiteGraphics/Logos/en_US/Icons_mobile_products/icon_Apple_CTA.png"/></a>
						<a id="android-app-store-logo" href="https://play.google.com/store/apps/details?id=com.infonow.bofa" name="AndroidAppStore"><img alt="Android App Store" src="https://www2.bac-assets.com/content/images/ContextualSiteGraphics/Logos/en_US/Icons_mobile_products/icon_android_badge.png"/></a>
						<a id="android-app-store-logo-tab" href="https://play.google.com/store/apps/details?id=com.tablet.bofa" name="AndroidAppStoreTablet"><img alt="Android App Store" src="https://www2.bac-assets.com/content/images/ContextualSiteGraphics/Logos/en_US/Icons_mobile_products/icon_android_badge.png"/></a>
						
						<a id="windows-app-store-logo" href="http://www.windowsphone.com/en-US/apps/ad8a76fa-ca71-e011-81d2-78e7d1fa76f8" name="WindowsAppStore"><img alt="Windows App Store" src="https://www2.bac-assets.com/content/images/ContextualSiteGraphics/Instructional/en_US/WindowsAppStore.png"/></a>
						
						</div>
					</div>
				</form>
			</div>
			<div class="processing">
				<span class="ada-hidden">Please wait. Your request is being processed.</span>
				<span class="modal-skin-processing-text">Please wait&hellip;</span>
			</div>
			<div class="modal-skin-vendor-error" aria-live="rude">We were unable to process your request. You can try again or use your mobile device to get the app from your device&rsquo;s app store.</div>
			<div class="modal-skin-web-service-error" aria-live="rude">We were unable to process your request. You can try again or use your mobile device to get the app from your device&rsquo;s app store.</div>
			<div class="modal-skin-quota-error" aria-live="rude">We allow up to 3 text message attempts in 24 hours. You can try again later or use your mobile phone to get the app from your device&rsquo;s app store instead.</div>
			<div class="text-sent">
				<span id="sent-to-phone" aria-live="rude">A text message with the download link has been sent to </span>
			</div>
			<div class="mail-sent">
				<span id="sent-to-mail" aria-live="rude">An email with the download link has been sent to </span>
			</div>
			<div class="sms-links">
				<a id="mobile_app_send_another_message" name="mobile_app_send_another_message" class="send-another-message" href="javascript:void(0);">Send another link</a>
				<a id="mobile_app_close_message" name="mobile_app_close_message" class="close-message" href="javascript:void(0);">Close</a>
				<div class="clearboth"></div>
			</div>
			<div class="mobile-website">
				<p>Get the app</p>
			</div>
			<div class="accordion">
				<div>
				   <h4>
					  <a class="accordion-h3-link" href="javascript:void(0);" name="anc-text-web-banking-accordian" ><span class="ada-hidden" id="exp-col-q-a"></span>Text Banking and Mobile Website</a>
				   </h4>
				   <div class="accordion-content">
						<h5>Bank as fast as you can text</h5>
						<p> Get information about your Small Business checking, savings and credit card accounts within seconds. 
To enroll in Text Banking, <a name="anc-signin-sbolb" href="https://secure.bankofamerica.com/login/sign-in/signOnScreen.go">sign in to Small Business Online Banking</a> or call <strong>1.800.604.9961 </strong>(you don&rsquo;t need to be enrolled in Small Business Online Banking to use Text Banking).
 </p>
						<h5>Any web-enabled mobile phone can access our Mobile Website</h5>
						<p> Visit bankofamerica.com from your mobile phone web browser.</p>
				   </div>
				</div>
			 </div>
			 <div class="web-and-text-banking">
				<h5>Get the app</h5>
				<p> Get the app </p>
				<h2>Get the app</h2>
				<p> Get the app</p>
			 </div>
			 </div>
		  </div>
	   </div>
	</div>

					<div id="glossary-popup-1" class="hide">
						<h3>SafePass<sup>&reg;</sup></h3>
						<p>SafePass is Bank of America&rsquo;s strongest protection against Mobile and Online Banking fraud and identity theft. This additional layer of security lets you authorize transactions using one-time, 6-digit Passcodes sent by text message directly to your mobile phone or tablet.</p> <p><a name="anc-learn-more-safepass" href="/privacy/online-mobile-banking-privacy/safepass.go" target="_self">Learn more about SafePass</a></p>
					</div>
		




	<div class="hide" id="mobile-app-download-remote-deposit">
		<h3>Small business remote deposit options</h3>
		<div class="flex-modal-main-content table-vzd3-common">
			<p>With Mobile Check Deposit (available on most of our Mobile Banking Apps) and Small Business Remote Deposit Online service, you can use the options that make the most sense for your business.</p>
			<p>Compare deposit options:</p>
			<table summary="5 column table with comparisons of various services and their related check deposit recommendations, maximum deposits per month, fees and how they work.">
						<thead>
							<tr>
									<th scope="col" id="madm-rms-table-col1">Service</th>
									<th scope="col" id="madm-rms-table-col2">Recommended monthly checks to deposit</th>
									<th scope="col" id="madm-rms-table-col3">Max deposit amount/mth</th>
									<th scope="col" id="madm-rms-table-col4">Fees</th>
									<th scope="col" id="madm-rms-table-col5">How it works</th>
							</tr>
						</thead>
						<tbody>
							<tr>
									<th scope="row">Mobile Check Deposit<a name="footnote-mobile-check-deposits" href="#footnote1"><span class="ada-hidden">Footnote:</span><sup>1</sup></a></th>
									<td>Up to 21</td>
									<td>Up to $50,000<a name="footnote-max-deposit" href="#footnote2"><span class="ada-hidden">Footnote:</span><sup>2</sup></a></td>
									<td>None</td>
									<td>Use your mobile device to take a picture<a name="footnote-how-it-works" href="#footnote3"><span class="ada-hidden">Footnote:</span><sup>3</sup></a></td>
							</tr>
						</tbody>
						<tbody>
							<tr>
									<th scope="row"><a class="sb-deposit-online-link" name="anc-small-bus-remote-dep-modal" href="/smallbusiness/online-banking/cash-management/remote-deposit.go">Small Business Remote Deposit Online</a><a name="footnote-small-business-remote-deposit" href="#footnote4"><span class="ada-hidden">Footnote:</span><sup>4</sup></a></th>
									<td>More than 21</td>
									<td>$99,999,999 per day</td>
									<td>Low monthly fee<a name="footnote-low-monthly-fee" href="#footnote5"><span class="ada-hidden">Footnote:</span><sup>5</sup></a></td>
									<td>Use a free scanner and log in to Remote Deposit Online</td>
							</tr>
						</tbody>
			</table>
			<div class="modal-footnotes">
						<div id="footnote1" class="sup-ie clear-both"><span class="footnotes-NumHolder">1.</span> <span class="footnotes-TextHolder">Terms and conditions apply to the Mobile Check Deposit service.</span></div>
						<div id="footnote2" class="sup-ie clear-both"><span class="footnotes-NumHolder">2.</span> <span class="footnotes-TextHolder">If your Bank of America business checking or savings account has been open for less than 4 months, the Mobile Check Deposit monthly limit is $3,000.</span></div>
						<div id="footnote3" class="sup-ie clear-both"><span class="footnotes-NumHolder">3.</span> <span class="footnotes-TextHolder">Mobile Check Deposit is available on the mobile app for iPhone<sup>&reg;</sup>, iPod touch<sup>&reg;</sup>, Android&trade; phone, Windows<sup>&reg;</sup> Phone, iPad<sup>&reg;</sup> and Android&trade; tablet.</span></div>
						<div id="footnote4" class="sup-ie clear-both"><span class="footnotes-NumHolder">4.</span> <span class="footnotes-TextHolder">Remote Deposit Online is subject to approval and availability in your area.</span></div>
						<div id="footnote5" class="sup-ie clear-both"><span class="footnotes-NumHolder">5.</span> <span class="footnotes-TextHolder">Transaction fees associated with your checking account still apply. Please refer to your deposit agreement.</span></div>
			</div>
		</div>
	</div>
</div>
					<div class="footer-inner">
<div class="disclaimers-module">
	<div class="fsd-skin sup-ie">
			<p>Mobile Banking requires enrollment through the Mobile Banking app, Mobile website or Online Banking. Enrollment through the Mobile Banking app is not available on all devices. View the <a href="http://www.bankofamerica.com/serviceagreement" target="_self">Online Banking Service Agreement</a> for more information. Data connection required. Wireless carrier fees may apply.</p>
<p>The Mobile Banking app is available on iPad, iPhone, Android and Windows 10 (except Xbox) devices.&nbsp;Not all Mobile Banking app features are available on all devices.&nbsp;</p>
<p>Mobile Check Deposits are subject to verification and not available for immediate withdrawal. In the Mobile Banking app, select <strong>Help &amp; Support</strong>, then <strong>Mobile Check Deposit</strong> for details, including funds availability, deposit limits, proper disposal of checks, restrictions and terms and conditions. Requires at least a 2-megapixel camera. Data connection required. Wireless carrier fees may apply.</p>
<p>Email and mobile transfers require enrollment in the service and must be made from a Bank of America consumer checking or savings account to a domestic bank account. Recipients have 14 days to register to receive money or the transfer will be cancelled. Dollar and frequency limits apply. See the <a href="http://www.bankofamerica.com/serviceagreement" target="_self">Online Banking Service Agreement</a> for details, including cut-off and delivery times.&nbsp;Data connection required. Wireless carrier charges may apply.</p>
<p>Mobile Banking app alerts are not available on&nbsp;the Mobile website.&nbsp;Data connection required. Wireless carrier fees may apply. ?Before using Bill Pay in Mobile Banking, you will need to first enroll in the service through Online Banking. Alerts received as text messages on your mobile access device may incur a charge from your mobile access service provider. This feature is not available on the Mobile website. Wireless carrier fees may apply.</p>
<p>Fees apply to wires and certain transfers. See the <a href="http://www.bankofamerica.com/serviceagreement" target="_self">Online Banking Service Agreement</a> for details. Data connection required for online and mobile transfers. Wireless carrier fees may apply.</p>
<p>Apple, the Apple logo, iPhone and iPad are trademarks of Apple Inc., registered in the U.S. and other countries. App Store is a service mark of Apple Inc. Android is a trademark of Google Inc. Bank of America and the Bank of America logo are registered trademarks of the Bank of America Corporation.</p>
	</div>
</div>

<!-- added only for cards project-->


	
	

		<div class="power-footer-module">
			<div class="fsd-four-col-skin sup-ie">
				<div class="breadcrumbs">	
										<a class="bold-bc" href="/" name="anc_bc_boa_features_breadcrumbs" target="_self">Bank of America</a>
										<a href="/smallbusiness/" name="anc_bc_sb_olb_services_features_breadcrumbs" target="_self">Small Business</a>
										<a href="/smallbusiness/online-banking/mobile.go" name="mobile_banking_features_breadcrumbs" target="_self">Mobile Banking</a>
							<span>Mobile Banking Features</span>
					<div class="clearboth"></div>
				</div>
			
				<div class="pf-columns">
									<div class="pf-col pf-one">
							  
										<a href="/smallbusiness/online-banking.go" name="anc_pf_business_onl_banking_features_power_footer" class="bold" target="_self">Business Online Banking</a>
								
											<a href="/smallbusiness/online-banking/account-management.go" name="anc_pf_acc_permmissions_features_power_footer" target="_self">Account Permissions</a>
											<a href="/smallbusiness/online-banking/quickbooks.go" name="anc_pf_quickbooks_features_power_footer" target="_self">QuickBooks<sup>&reg;</sup></a>
								</div>   
						  
									<div class="pf-col pf-two">
							  
										<a href="/smallbusiness/online-banking/cash-management.go" name="anc_pf_cash_mgmt_tools_features_power_footer" class="bold" target="_self">Cash Management</a>
								
											<a href="/smallbusiness/online-banking/cash-management/remote-deposit.go" name="anc_pf_remote_deposit_features_power_footer" target="_self">Remote Deposit</a>
											<a href="http://promo.bankofamerica.com/olbs/olbs_directpayment.html" name="anc_pf_invoicing_features_power_footer" target="_self">Invoicing and Payments</a>
											<a href="/smallbusiness/online-banking/cash-management/tax-services.go" name="anc_pf_tax_services_features_power_footer" target="_self">Tax Services</a>
											<a href="/smallbusiness/online-banking/cash-management/merchant-services.go" name="anc_sb_merchant_services_features_power_footer" target="_self">Merchant Services</a>
								</div>   
						  
									<div class="pf-col pf-three">				
							  
										<a href="/smallbusiness/online-banking/payroll.go" name="anc_pf_payroll_features_power_footer" class="bold" target="_self">Payroll</a>
								
											<a href="/smallbusiness/online-banking/payroll/self-service.go" name="anc_pf_self_srv_payroll_features_power_footer" target="_self">Self Service Payroll</a>
											<a href="/smallbusiness/online-banking/payroll/full-service.go" name="anc_pf_full_srv_payroll_features_power_footer" target="_self">Full Service Payroll</a>
											<a href="/smallbusiness/online-banking/payroll/compare-services.go" name="anc_pf_compare_features_power_footer" target="_self">Compare Payroll Options</a>
								</div>   
						  
									<div class="pf-col pf-four pf-last">
							  
										<a href="/smallbusiness/online-banking/mobile.go" name="anc_pf_mobile_banking_features_power_footer" class="bold" target="_self">Mobile Banking</a>
								
											<a href="/smallbusiness/online-banking/mobile/features.go" name="anc_pf_mob_bank_features_features_power_footer" target="_self">Mobile Banking Features</a>
											<a href="/smallbusiness/online-banking/mobile/app/overview.go" name="anc_pf_understanding_basics_features_power_footer" target="_self">Understanding the basics</a>
								</div>   
						  
						  
						<div class="clearboth"></div>
				</div>
			</div>
		</div>



 



		<div class="global-footer-module">
			<div class="fsd-skin">

				<div class="footer-bottom-left" style="float:left;max-width:66%;">
	    			<div class="gf-links">	          	
						
					
									
									<a  target="_self" href="/" 
									    name="anc-global-footer-home">Home
									</a>
									
						
					
									
									<a  target="_self" href="/privacy/overview.go" 
									    name="anc-privacy-and-security">Privacy &amp; Security
									</a>
									
						
					
									
									<a  target="_self" href="http://careers.bankofamerica.com/careershome.aspx" 
									    name="anc-global-footer-careers">Careers
									</a>
									
						
					
									
									<a  target="_self" href="/sitemap/personal.go" 
									    name="anc-global-footer-sitemap">Site Map
									</a>
									
						
					
									<a href="javascript:void(0);" class="gf-last-link boa-dialog boa-com-info-layer-link" name="global_footer_advertising_practices_lnk" rel="global_footer_advertising_practices">Advertising Practices</a>
								<div id="global_footer_advertising_practices" class="hide">
									<h3>Advertising Practices</h3>
										<p>We strive to provide you with information about products and services you might find interesting and useful. Relationship-based ads and online behavioral advertising help us do that.</p>
<p>Here's how it works: We gather information about your online activities, such as the searches you conduct on our Sites and the pages you visit. This information may be used to deliver advertising on our Sites and offline (for example, by phone, email and direct mail) that's customized to meet specific interests you may have.</p>
<p>If you prefer that we do not use this information, you may <a onclick="$('.ui-dialog').remove();" name="WebsiteAdPractices_OptOut" href="/privacy/online-privacy-notice.go#advertising-on-our-sites" target="_blank">opt out of online behavioral advertising</a>. If you opt out, though, you may still receive generic advertising. In addition, financial advisors/Client Managers may continue to use information collected online to provide product and service information in accordance with account agreements.</p>
<p>Also, if you opt out of online behavioral advertising, you may still see ads when you sign in to your account, for example through Online Banking or MyMerrill. These ads are based on your specific account relationships with us.</p>
<p>To learn more about relationship-based ads, online behavioral advertising and our privacy practices, please review the <a onclick="$('.ui-dialog').remove();" name="WebsiteAdPractices_PrivacyNotice" href="/privacy/online-privacy-notice.go" target="_blank">Bank of America Online Privacy Notice</a> and our <a onclick="$('.ui-dialog').remove();" name="Online-privacy-faqs" href="/privacy/faq/online-privacy-faq.go" target="_blank">Online Privacy FAQs</a>.</p>
								</div>
						<div class="clearboth"></div>
	    			</div>
	      			<p>Bank of America, N.A. Member FDIC. <a onclick="window.open('/help/equalhousing_popup.go','newwin','width=640,height=371,scrollbars=yes,resizable=yes,left=35,top=161'); return false;" name="Equal_Housing_Lender" href="/help/equalhousing_popup.go">Equal Housing Lender<img src="https://www2.bac-assets.com/content/images/ContextualSiteGraphics/Logos/en_US/icon_equal_housing_lender.gif" alt="" width="14" height="9" /> </a><br />&copy; 2017 Bank of America Corporation. All rights reserved.</p>
         		</div>
         		<div class="footer-social-container" style="float:right;max-width:30%;padding-left:50px;padding-top:19px;">




<div class="boa-social-loader" data-loaded="false" data-platform="borneo"  data-options=''></div>

         		</div>
         		<div class="clearboth"></div>
  			</div>
		</div>

<script src="https://www2.bac-assets.com/pa/global-assets/external/coremetrics/hp/eluminate.js" type="text/javascript"></script>
<script src="https://www2.bac-assets.com/pa/global-assets/external/coremetrics/hp/cmdatatagutils.js" type="text/javascript"></script>


<script type="text/javascript" id="coremetrics-bdf-module-mobilesales-skin">
	var cmPageId = "smbus:Content:OLBs:Mobile_Banking;features";
	var cmCategoryId = "smbus:Content:OLBs:Mobile_Banking"; 
	var testString = window.location.href;		
	var cmReqLocale = $('html').attr('lang');
	var locAppendage;
	if (cmReqLocale.toLowerCase().indexOf('en') !== -1) {
		locAppendage = '';
	} else if (cmReqLocale.toLowerCase().indexOf('es') !== -1) {
		locAppendage = '_ES';
	}
	

function cmSetDD(){var testString=window.location.href;if(testString.toLowerCase().indexOf(".bankofamerica.com")>-1){testString=testString.toLowerCase();var tempArr=testString.split(".bankofamerica.com");var tempStr=tempArr[0];if(tempStr.indexOf("//")>-1){tempArr=tempStr.split("//");tempStr=tempArr[1];if(tempStr.indexOf(".")>-1){tempArr=tempStr.split(".");tempStr=tempArr[0];var tempStrPt2=tempArr[1]}if(tempStr.indexOf("www")>-1){if(tempStr.indexOf("-")>-1){cmSetStaging()}else{if(tempStrPt2!=null){if(tempStrPt2.indexOf("ecnp")>-1){cmSetStaging()}}else{cmSetProduction()}}}else{if(tempStr.indexOf("-")>-1){if(tempStr.indexOf("sitekey")>-1){if(tempStr=="sitekey"){cmSetProduction()}else{cmSetStaging()}}else{cmSetStaging()}}else{if(tempStrPt2!=null){if(tempStrPt2.indexOf("ecnp")>-1){cmSetStaging()}}else{cmSetProduction()}}}}}}if(typeof cmSetStaging=="function"){cmSetDD()};
	
	if (typeof cmSetStaging == 'function') {cmSetDD()}

	cmCreatePageviewTag(cmPageId+locAppendage, null, null, cmCategoryId, false, false, null, false, false, null, null, null, null, null, null, null, null, null, null, null, null);

</script>
<script type="text/javascript">
var axel = Math.random()+"";var a = axel * 10000000000000;document.write('<iframe title="iFrame used for layout purpose" src="https://fls.doubleclick.net/activityi;src=1359940;type=bacal484;cat=mb_sm369;ord=1;num='+ a + '?" width="1" height="1" frameborder="0" style="display:none;"></iframe>');
</script>
<noscript>
	<iframe title="iFrame used for layout purpose" src=" ?" width="0" height="0" frameborder="0" style="display:none;"></iframe>
</noscript>



 
</div>
				</div>
			</div>
		</div>	
	</body>	
</html>

