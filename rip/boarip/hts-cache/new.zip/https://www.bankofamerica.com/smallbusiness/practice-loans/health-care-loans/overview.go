
 

				<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
				<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
				<head>


<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta http-equiv="content-type" content="text/html;charset=utf-8">





<title>Health Care Professional Loans Overview Page</title>

<meta name="Description" CONTENT="Comprehensive conventional and SBA lending services to make your loan process easy and less time-consuming">
<meta name="Keywords" CONTENT="loan process">

		<link rel="canonical" href="https://www.bankofamerica.com/smallbusiness/practice-loans/health-care-loans/overview.go"/>

<link rel="shortcut icon" href="/pa/global-assets/1.0/graphic/favicon.ico" type="image/ico" />

			<link rel="stylesheet" type="text/css" href="/pa/components/bundles/gzip-compressed/xengine/APS-small-business/2017.03.0/style/olbs-aps-sb-jawr.css" media="all" />
			<script src="/pa/components/bundles/gzip-compressed/xengine/APS-small-business/2017.03.0/script/olbs-aps-sb-jawr.js" type="text/javascript"></script>
				<script type="text/javascript">
					$(window).load(function(){asyncPrintCssInclude('https://www.bankofamerica.com/pa/components/bundles/gzip-compressed/xengine/APS-small-business/2017.03.0/style/olbs-aps-sb-jawr-print.css');});
				</script>
<script type="text/javascript">
(function() {
	if (typeof mboxUpdate == "function") {
		var windowURL = window.location.href
	    windowURL = windowURL.slice( windowURL.indexOf('.')+1);
		windowURL = windowURL.split( '?' )[0];
		windowURL = windowURL.toLowerCase();
		//alert(windowURL);
		if (
		    //If no mboxes on page, mbox count will be < 1
		    (mboxFactoryDefault.getMboxes().length() < 1) &&

			//Also check for high-volume pages that do not need global logging
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go") &&
			(windowURL != "bankofamerica.com/myaccounts/signin/signin.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/entry/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signonscreen.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatechallengeanswer.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatePassword.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/mobile/banking.go")&&
			(windowURL != "bankofamerica.com/content/preload/olb-myaccount-preload-jawr-module.htm")
			)
		{

			var mboxDiv = document.createElement("div");
			mboxDiv.id = "adobe_touch_clarity_replacement";
			mboxDiv.style.display = "none";
			if (document.body && document.body.firstChild) document.body.insertBefore(mboxDiv,document.body.firstChild);
			mboxDefine(mboxDiv.id,'bac_global_bottom');
			mboxUpdate('bac_global_bottom');
		}
	}
})();
</script>

		<script src="/pa/components/bundles/gzip-compressed/xengine/Global/1.0/script/tealeafbundle.js" type="text/javascript"></script>
			<script>
				var boaPageDataJS = {};
					boaPageDataJS.isLLE = "false";
			</script>
				<style>body{display:none;}</style>
	</head>		

	<body class="fsd-layout-body">	

				<script type="text/javascript">if(self == top){var theBody=document.getElementsByTagName("body")[0];theBody.style.display="block";}else{top.location=self.location;}</script>
				<noscript><style>body{display:block;}</style></noscript>
					<a class='ada-hidden ada-visible-focus' href='#skip-to-h1' id='ada-skip-link'>Skip to main content</a>
		<div class="fsd-layout fsd-2c-700lt-layout">
			<div class="fsd-border">
				<div class="center-content">
					<div class="header">
		  



<script language="javascript" src="/pa/components/modules/tag-manager-module/1.1/script/tag-manager-module-borneo-global-skin.js"></script>
<script>

(function() {
  var fireCallback = function( cb ) {
    if ( typeof cb === "function" ) cb();
  };
  
  function ddoPopulateBase( callback ) {
    try {
		  var DDO = window.digitalData,
		  	bactm_mergeDDO = function( newDDO, priorDDO ) {
		  		if( typeof priorDDO === "undefined" ) {
				  	priorDDO = digitalData || {};
				  }

			    for (var l in newDDO) {
			        if (typeof priorDDO[l] === "undefined") {
			            priorDDO[l] = newDDO[l];
			        }
			        if (newDDO[l] !== null) {
			            if (typeof newDDO[l] === "object") {
			                bactm_mergeDDO(newDDO[l], priorDDO[l]);
			            } else {
			                priorDDO[l] = bactm_validateValue( newDDO[l] ) ? newDDO[l] : priorDDO[l];
			            }
			        }
			    }

			    return priorDDO;
				},
				bactm_olb3rdPartyId = "null";

			if (typeof DDO === "undefined") {
				var simpleDDO = { page: { pageInfo:[{ pageID: null }], attributes: {}, category: { primaryCategory: null }}};

				DDO = (typeof digitalData === "object") ? digitalData : simpleDDO; 
			}

				DDO = bactm_mergeDDO( {   "pageInstanceID": "notprod",   "load_coremetrics": true,   "load_opinionlabs": false,   "load_touchcommerce": true,   "load_audiencemanager": true,   "page": {     "pageInfo": [       {         "pageID": null,         "destinationURL": null,         "referringURL": null,         "issueDate": null,         "language": null,         "segmentValue": null,         "appName": null,         "appStepNumber": null,         "appStepName": null,         "attr": "-_--_--_--_--_--_--_--_--_--_--_--_--_--_-"       }     ],     "category": {       "primaryCategory": null,       "addlCategory": null,       "pageType": null     },     "attributes": {       "searchString": null,       "searchResults": null,       "olbSessionID": null,       "subCampaignCode": null,       "DARTUrl": null,       "stateCookie": null,       "SASIEnabled": false,       "needOLBcookie": false,       "standardDART": ["https://fls.doubleclick.net/activityi;src=1359940;type=sdlpb511;cat=2015_02o;ord=1"],       "standardDARTes": [],       "clickDART": [],       "clickDARTes": [],       "gaId": [],       "chat": {         "site_id": 36533213,         "target": {           "lpButtonDiv-Practice-Solutions": "SB-Fixed13"         },         "account_type": "smallbusiness",         "customer_lob": "sbob"       }     }   },   "user": {     "segment": null,     "online_id": null,     "preferred_rewards_tier": null,     "olb3rdpartyid": null   },   "version": "BAC_0.12" }, DDO );

			DDO.page.pageInfo[0].pageID = "smbus:Content:practice_loans:health_care;overview";
			DDO.page.category.primaryCategory  = "smbus:Content:practice_loans:health_care";
			DDO.page.pageInfo[0].language = "en-US";
			DDO.page.attributes.olbSessionID = "null";
			DDO.page.attributes.SASIEnabled =  "false";
			if (typeof DDO.user != "undefined" && typeof DDO.user.olb3rdpartyid != "undefined") {
				DDO.user.olb3rdpartyid = bactm_olb3rdPartyId;
			}

			window.utag_data = {};
			window.bactm_envSelector = bactm_setTMLib();
			window.digitalData = DDO;

      return fireCallback( callback );

    } catch(e) { }
  }
	if( window.boa && window.boa.digitalData ) {
    window.boa.digitalData.register( ddoPopulateBase );
	}
	else {
	  // Handle scenario where the header isn't available (and thus the default digitalData object and utag loader are missing).
	  //
		var writeScript = function(a,b,c,d){
			a='//tags.tiqcdn.com/utag/bofa/main/' + bactm_envSelector + '/utag.js';
			b=document;
			c='script';
			d=b.createElement(c);
			d.src=a;
			d.type='text/java'+c;
			d.async=true;
			a=b.getElementsByTagName(c)[0];
			a.parentNode.insertBefore(d,a);
		};

		ddoPopulateBase( writeScript );
	}
})();			
</script>



	
	
		
			<noscript>
				<div class="fauxdal-overlay"></div>
				<div class="fauxdal-module">
					<div class="js-disabled-skin">
						<div class="fauxdal-top"></div>
						<div class="fauxdal-bottom">
							<div class="fsd-fauxdal-content">
									<div class="fsd-fauxdal-title">
										Please Use JavaScript
									</div>
										<p>You need a web browser that supports JavaScript to use our site. Without it, some pages won&rsquo;t work as designed. To make sure JavaScript is turned on, please adjust your browser settings.</p>
<p><a name="Browser_Help_And_Tips" href="/onlinebanking/online-banking-security-faqs.go" target="_blank">Browser Help and Tips</a></p>
							</div>        
							<div class="fsd-fauxdal-close"> 
								<a class="btn-bofa btn-bofa-small" name="close_button_js_disabled_modal" href=?js=y>Close</a>
							</div>
							<div class="clearboth"></div>
						</div>
					</div>
				</div>
			</noscript>



 


<div class="header-module">
	<div class="text-w-logo-skin">
		<div class="header-left">
	  
			<div itemscope itemtype="http://schema.org/Corporation" class="bofa-logo">
				<a itemprop="url" name="anc-practice-loans" title="Bank of America logo" href="/smallbusiness/index.jsp">
					<img itemprop="logo" height="25" width="201" 
					     alt="Bank of America logo" src="/content/images/ContextualSiteGraphics/Logos/en_US/bofa-logo.gif"/>
				</a>
			</div>
				<div class="product" data-font="cnx-regular">Practice Loans</div>
			
			<div class="clearboth"></div>

		</div>
		
		<div class="header-right">
			<ul class="header-links">
			
				
					
				
							<li class="sign-in">
		<a					href="/sitemap/hub/signin.go" target="_self"
		name="sign-in-header">Sign In</a> 
							</li>
					
				
							<li>		<a					href="/smallbusiness/" target="_self"
		name="home-header">Home</a> 
</li>
					
				
							<li>		<a					href="https://locators.bankofamerica.com" target="_self"
		name="locations-header">Locations</a> 
</li>
					
				
							<li>		<a					href="/contactus/contactus.go?topicId=small_business_banking" target="_self"
		name="contact-us-header">Contact Us</a> 
</li>
					
				
							<li class="last-link">	
		<a					href="/smallbusiness/practice-loans/resources/FAQs.go" target="_self"
		name="help-header">Help</a> 
							</li>
			</ul>
			
			<div class="clearboth"></div>

			<!-- include search-dotcom-util -->



<div class="header-search nlh">
  
  <div class="nav-search">
    <form class="search-form" action="https://secure.bankofamerica.com/myaccounts/public/search-results/unAuthenticatedSearch.go" data-js="/pa/components/utilities/search-util/1.0/script/nav-search.min.js" data-css="/pa/components/utilities/search-util/1.0/style/nav-search.css" data-text-unavailable="Search Currently Unavailable">
      <div class="search-input-container cf" data-icon="search">
        <label for="nav-search-query" class="ada-hidden">Search Term</label>
        <input type="text" placeholder="How can we help you?" name="query" class="search-query" id="nav-search-query" 
          maxlength="99" rel="Search" autocomplete="off"><input type="submit" alt="Search" title="Search" value="Submit Search" name="Search Module - Top Result – Search Button" class="submit track-me">
      </div>
    </form>
  </div>

</div>

		</div>

 		<div class="clearboth"></div>
 	</div>
</div>







	<div class="top-nav-module">
		<div class="fsd-skin sup-ie">
			<ul class="nav-list">
					
					
					<li>
						
									<a href="/smallbusiness/practice-loans/health-care-loans/overview.go" class="top-menu-item selected"
									name="health_care_practice_loans_topnav" id="health_care_practice_loans_topnav">Health Care Practice Loans</a>
					</li>
					
					
					<li>
						
									<a href="/smallbusiness/practice-loans/health-care-loans/dentist-loans.go" class="top-menu-item"
									name="dentists_topnav" id="dentists_topnav">Dentists</a>
					</li>
					
					
					<li>
						
									<a href="/smallbusiness/practice-loans/health-care-loans/veterinary-loans.go" class="top-menu-item"
									name="veterinarians_topnav" id="veterinarians_topnav">Veterinarians</a>
					</li>
					
					
					<li>
						
									<a href="/smallbusiness/practice-loans/health-care-loans/medical-loans.go" class="top-menu-item"
									name="physicians__optometrists_topnav" id="physicians__optometrists_topnav">Physicians & Optometrists</a>
					</li>
					
					
					<li>
						
								<a href="/smallbusiness/practice-loans/resources/overview.go" class="top-menu-item"
								name="resources_topnav" id="resources_topnav">Resources<span class="ada-hidden"> &nbsp;link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/smallbusiness/practice-loans/resources/overview.go"  name="resources_overview_topnav" id="resources_overview_topnav">Resources Overview </a>
															<a href="/smallbusiness/practice-loans/resources/FAQs.go"  name="faqs_topnav" id="faqs_topnav">FAQs </a>
															<a href="/smallbusiness/practice-loans/resources/events-dentists.go"  name="events_topnav" id="events_topnav">Events </a>
															<a href="/smallbusiness/practice-loans/resources/endorsements.go"  name="endorsements_topnav" id="endorsements_topnav">Endorsements </a>
									</div>
								
									<div class="hasSub">
														<a class="with-info" href="https://host.visualcalc.com/practicesolutions/ "  name="equipment_loan_calculator_topnav" id="equipment_loan_calculator_topnav">Equipment Loan Calculator 
															
															<span class="sub-nav-item-info">Estimate monthly payments, ROI and tax benefits</span>
														</a>
														<a class="with-info" href="https://smallbusinessonlinecommunity.bankofamerica.com/"  name="online_community_topnav" id="online_community_topnav">Online Community 
															
															<span class="sub-nav-item-info">Access small business news, articles & more</span>
														</a>
									</div>
									<span class="ada-hidden"> End of Submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
			</ul>
				<div class="clearboth"></div>
		</div>
	</div>



<div class="page-title-fsd-module h-100" id="skip-to-h1">
	<div class="standard-gray-skin sup-ie">
		<h1 data-font="cnx-regular">Small Business Health Care Practice Loans</h1>
  </div>
</div>


	<div class="banner-aps-sb-module">
		<div class="left-content-skin sup-ie" style="background-color:#d3ebfc;background-image:url('/content/images/ContextualSiteGraphics/Instructional/en_US/SmallBusiness/healthcare_PracticeSolutions.jpg')">
			<div class="banner-content blue-style" style="background-image:url('/content/images/ContextualSiteGraphics/Instructional/en_US/SmallBusiness/healthcare_PracticeSolutions.jpg')">
				<h2><strong><span style="color: #c41230; font-family: Connections; font-size: 38px;">Save on financing when you<br/>purchase a practice</span></strong></h2>				
				<p><strong>Limited time offer: 1.89% interest rate for the first year</strong><a href="#Footnote 1" name="FootNote1"><span class="ada-hidden">Footnote</span><sup>1</sup></a></p>
					<div class="call-to-action">
						<span class="cta-html-dest">8600</span>
					</div>
				<p>Call to speak with a Practice Specialist</p>
				<div class="clearboth"><!--  --></div>
			</div>
		</div>	 
	</div>

<div class="print-module-browser-dialog-skin" style=""> 
	<a href="javascript:window.print();" name="print">PRINT<span class="ada-hidden"> this page</span></a>
</div></div>
					<div class="columns">
						<div class="flex-col lt-col" >

	
<div class="generic-content-module tabs-main-content">
	<div class="overview-vzd3-skin com-main-well-content" style="">
			
			
							<p class="pad-adjust">Health care professionals nationwide rely on the industry leadership provided by Bank of America Practice Solutions. Our Practice Specialists have a keen understanding of:</p>
			


			
			
				<ul>
					<li>
					<a name="financing-dentists" href="/smallbusiness/practice-loans/health-care-loans/dentist-loans.go" target="_self">Financing for dentists</a>
					
					
					</li>
					<li>
					<a name="financing-veterinarians" href="/smallbusiness/practice-loans/health-care-loans/veterinary-loans.go" target="_self">Financing for veterinarians</a>
					
					
					</li>
					<li>
					<a name="financing-medical-professionals" href="/smallbusiness/practice-loans/health-care-loans/medical-loans.go" target="_self">Financing for medical professionals</a>
					
					
					</li>
				</ul>


			
			
						<p>(If you're unsure whether you qualify for financing, <a class="boa-dialog boa-com-info-layer-link dotted force-visited" rel="glossary-popup-1" name="medical-specialties" href="javaScript:void;">view our list of qualified medical specialties</a>.)</p>
			


			
			
						<p>We understand the unique challenges you face and are ready to help you succeed with:</p>
			


	</div>
</div>




<div class="list-aps-sb-module">
	<div class="two-col-bullet-skin">
			<ul class="ui-helper-clearfix">	
					<li>
						New office start-ups
					</li>
					<li>
						Office improvement, expansion and relocation
					</li>
					<li>
						Practice sales and purchases
					</li>
					<li>
						Owner-occupied commercial real estate<a name="1" href="#footnote2"><span class="ada-hidden">Footnote </span><sup>2</sup></a>
					</li>
					<li>
						Business debt consolidation
					</li>
					<li>
						Equipment financing
					</li>
					<li>
						Lines of credit
					</li>
			</ul>
	</div>
</div>


	
<div class="generic-content-module tabs-main-content">
	<div class="overview-vzd3-skin com-main-well-content" style="">
			
			
						<p><span> </span><span>(we are moving this offer out of the engagement area and down on the page &ndash; it will be fully removed end of the month)</span></p>
<p><span><strong>Debt consolidation offer:</strong> Consolidate your practice debt now and get a low 3% interest rate<a href="#Footnote 3" name="fn1"><span class="ada-hidden">Footnote</span><sup>3</sup></a></span></p>
			


			
			
						<p>With flexible terms and repayment options on loans up to $5 million, we can work with you to develop a financial plan that can assist in moving your business forward.</p>
			


			
			
						<p>Plus, our <a name="practice_heartbeat" href="/smallbusiness/practice-loans/resources/practice-heartbeat.go" target="_self">Practice Heartbeat</a> program and <a class="boa-dialog boa-com-info-layer-link dotted force-visited" rel="glossary-popup-2" name="demographic_site_analysis" href="javaScript:void(0);">demographic site analysis</a> tools help provide you with the critical knowledge you need in today&rsquo;s competitive business environment.</p>
			


	</div>
</div>






<div class="featured-content-module">
   <div class="c2a-feature-skin featured-box-vzd3-common sup-ie">
      <div class="fc-drop-shadow-outer">
         <div class="fc-drop-shadow-inner">
            <div class="fc-content-border">
               <div class="fc-content">					
					<div class="top-section">
						<!-- inline style on above img tag should be sourced from CMS. This will allow flexible space/placement around the image for different images. -->
						<!-- End logical img container include -->
						
						<div class="content-container fcm-c2a-container">
									<h2 class="cnx-medium">Practice Heartbeat<sup>&reg;</sup></h2>
										<p>Practice Heartbeat<sup>&reg;</sup>&mdash;100% complimentary when you're enrolled in start-up financing or you're purchasing a practice for the first time&mdash;gives you the vital management skills you need to succeed.</p><p><a title="Practice Heartbeat" name="learn_more_about_practice_heartbeat" href="/smallbusiness/practice-loans/resources/practice-heartbeat.go" target="_self">Learn more about Practice Heartbeat<span class="raquo-link">&rsaquo;&rsaquo;</span></a></p>
						</div>
					</div>				
					
				</div>
            </div>
         </div>
      </div>
   </div>
</div>

</div>
						<div class="flex-col rt-col" >

<!-- touchCommerceEnabled -->

 


<div class="cta-module target-sidewell">	
	<div class="cta focus-call">
		<div class="intro">
			<h3>We're here to help</h3>
		</div>		
		<ul class="options">
				<li class="call first">							
					<div class="details">							
						<p>Our Practice Specialists are standing by to assist you.</p>
									<p class="large"><span class="cta-html-src">800.497.6076</span></p>
							<p class="small">Mon.-Thu. 8 a.m.-8 p.m. ET<br />Fri. 8 a.m.-7 p.m. ET</p>
						<p><br />Existing account support</p>
							<p class="large">888.852.5000</p>
							<p class="small">Mon.-Fri.&nbsp;7 a.m.-9 p.m. ET</p>
					</div>						
				</li>

			<!-- New condition for S83320 -->
			<!-- updated to merge all conditions related to practice loans for story S130354 -->
				
					<li class="qualify">
						<h4><a href="#" name="Request_information"><span class="ada-hidden ada-closed">Show details on how to </span><span class="ada-hidden ada-open" style="display:none;">Hide details on how to </span>Request information<span class="ada-hidden"> about practice specialist</span></a></h4>
						<div class="details">
							<p>Complete a brief and secure email form and one of our Practice Specialists will get back to you as soon as possible.</p>
								<p><a name="Request_information_now" onclick="location.reload();location.href=/contact-us/practice-loans-email.go;dartFireOnClick('1359940','gcibl189','pracs994'); return false;" href="/contact-us/practice-loans-email.go">Request information now
								<span class="ada-hidden"> about practice specialist</span></a></p>
						</div>
					</li>
					 
					 
					 
					
					<li class="chat">
							<h4><a href="#" name="Chat_online"onClick="return dartFireOnClick('1359940','gcibl189','pracs947');">
							<span class="ada-hidden ada-closed">Show details on how to </span><span class="ada-hidden ada-open" style="display:none;">Hide details on how to </span>Chat online<span class="ada-hidden"> about practice financing</span></a></h4>
						<div class="details">						
							<div id="lpButtonDiv-Practice-Solutions">
							</div>							
						</div>					
					</li>				


				
		</ul>
	</div>
</div>

<div class="side-well-module"> </div>
		
<script type="text/javascript">
	$('.cta-html-dest').html($('.cta-html-src').html());
	cta_module.skins = {
	"Side Well" : {
	"id" : "sidewell",
	"container" :  ".side-well-module:first",
	"bind" : ".side-well-module:first",
	"location" : "first"
	}
	};
</script>

<div class="c2a-aps-sb-module">
	<div class="sw-link-skin">
		<div class="sw-outer">
			<div class="sw-inner">
				<div class="sw-corner sw-tleft"></div>
				<div class="sw-corner sw-tright"></div>
				<div class="sw-main sw-std-pad">
					<h2 class="h2-fsd-sw-gray">Endorsements</h2>
					<div class="sw-main-content">
								<p>We&rsquo;re proud to be endorsed by more dental, veterinary and medical associations than any other lending institution.</p>
								<div class="c2a-link"><a href="/smallbusiness/practice-loans/resources/endorsements.go" name="see_endorsements">See endorsements <span class="raquo-link"> </span></a></div>
					</div>
				</div>
				<div class="sw-bottom"></div>
			</div>
			<div class="sw-corner sw-bleft"></div>
			<div class="sw-corner sw-bright"></div>
		</div>
	</div>
</div>


<div class="c2a-aps-sb-module">
	<div class="sw-link-skin">
		<div class="sw-outer">
			<div class="sw-inner">
				<div class="sw-corner sw-tleft"></div>
				<div class="sw-corner sw-tright"></div>
				<div class="sw-main sw-std-pad">
					<h2 class="h2-fsd-sw-gray">You might also like</h2>
					<div class="sw-main-content">
								<div class="c2a-link first"><a href="/smallbusiness/credit-cards/" name="business_credit_cards">Business credit cards <span class="raquo-link"> </span></a></div>							
								<div class="c2a-link"><a href="http://merch.bankofamerica.com/?cm_mmc=General-_-vanity-_-ZZ01VN007G_merchant-_-NA " name="merchant_services">Merchant services <span class="raquo-link"> </span></a></div>
								<div class="c2a-link"><a href="http://healthaccounts.bankofamerica.com/explore-sm-business.shtml" name="employer_sponsored_HSA">Employer-sponsored HSA <span class="raquo-link"> </span></a></div>
					</div>
				</div>
				<div class="sw-bottom"></div>
			</div>
			<div class="sw-corner sw-bleft"></div>
			<div class="sw-corner sw-bright"></div>
		</div>
	</div>
</div>
</div>
						<div class="clearboth"></div>
					</div>
					<div class="footer">
						<div class="footer-top">&nbsp;</div>
						<div class="footer-inner">

<div class="footnote-com-module">
   <div class="fsd-layout-skin sup-ie">
   
   <script>
		$(function() {
			if ($('.footnote-com-module .fsd-layout-skin').text().length > 10) {
				$('.footnote-com-module .fsd-layout-skin').addClass('wfootnote');
			}
		});
	</script>
   
					<div class="h-100">
						<div class="footnote" id="footnote1">
							<div class="fn-num">1.</div>
							<div class="fn-text"><span>All programs subject to credit approval and loan amounts are subject to creditworthiness. Some restrictions may apply. The term, amount, interest rate and repayment schedule for your loan, and any product features, including interest rate locks, may vary depending on your creditworthiness and on the type, amount and collateral for your loan. Bank of America may prohibit use of an account to pay off or pay down another Bank of America account. Promotional rate available only with a prepayment fee. One of three prepayment fees will be required, depending on the option you choose. Applications must be submitted by July 31, 2017 and close by November 30, 2017. Loans with interest only periods are not eligible for the promotional offer.</span> </div>
							<div class="clearboth"></div>
						</div>
					</div>
					<div class="h-100">
						<div class="footnote" id="footnote2">
							<div class="fn-num">2.</div>
							<div class="fn-text">51% owner occupancy required for commercial real estate loans. </div>
							<div class="clearboth"></div>
						</div>
					</div>
					<div class="h-100">
						<div class="footnote" id="footnote3">
							<div class="fn-num">3.</div>
							<div class="fn-text">All programs subject to credit approval and loan amounts are subject to creditworthiness. Some restrictions may apply. The term, amount, interest rate and repayment schedule for your loan, and any product features, including interest rate locks, may vary depending on your creditworthiness and on the type, amount and collateral for your loan. Promotional rate available only with a prepayment fee. One of three prepayment fees will be required, depending on the option you choose. Applications must be submitted by April 30, 2017 and close by July 31, 2017. </div>
							<div class="clearboth"></div>
						</div>
					</div>
   </div>
</div>


      <div class="disclaimers-module">
         <div class="dsp-skin sup-ie">
             <p>All programs subject to credit approval and loan amounts are subject to creditworthiness. Some restrictions may apply. Bank of America may prohibit use of an account to pay off or pay down another Bank of America account. Bank of America Practice Solutions is a division of Bank of America Corporation. Bank of America is a registered trademark of Bank of America Corporation.</p>
         </div>
      </div>



 



		<div class="global-footer-module">
			<div class="fsd-skin">

				<div class="footer-bottom-left" style="float:left;max-width:66%;">
	    			<div class="gf-links">	          	
						
					
									
									<a  target="_self" href="/smallbusiness/index.jsp" 
									    name="global-footer-home">Home
									</a>
									
						
					
									
									<a  target="_self" href="/privacy/overview.go" 
									    name="global-footer-privacy-security">Privacy & Security
									</a>
									
						
					
									
									<a  target="_self" href="http://careers.bankofamerica.com/careershome.aspx" 
									    name="global-footer-careers">Careers
									</a>
									
						
					
									
									<a  target="_self" href="/sitemap/sitemap/smallbusiness.go" 
									    name="global-footer-site-map">Site Map
									</a>
									
						
					
									<a href="javascript:void(0);" class="gf-last-link boa-dialog boa-com-info-layer-link" name="global_footer_ad_practices_lnk" rel="global_footer_ad_practices">Advertising Practices</a>
								<div id="global_footer_ad_practices" class="hide">
									<h3>Advertising Practices</h3>
										<p>We strive to provide you with information about products and services you might find interesting and useful. Relationship-based ads and online behavioral advertising help us do that.</p>
<p>Here's how it works: We gather information about your online activities, such as the searches you conduct on our Sites and the pages you visit. This information may be used to deliver advertising on our Sites and offline (for example, by phone, email and direct mail) that's customized to meet specific interests you may have.</p>
<p>If you prefer that we do not use this information, you may <a onclick="$('.ui-dialog').remove();" name="WebsiteAdPractices_OptOut" href="/privacy/online-privacy-notice.go#advertising-on-our-sites" target="_blank">opt out of online behavioral advertising</a>. If you opt out, though, you may still receive generic advertising. In addition, financial advisors/Client Managers may continue to use information collected online to provide product and service information in accordance with account agreements.</p>
<p>Also, if you opt out of online behavioral advertising, you may still see ads when you sign in to your account, for example through Online Banking or MyMerrill. These ads are based on your specific account relationships with us.</p>
<p>To learn more about relationship-based ads, online behavioral advertising and our privacy practices, please review the <a onclick="$('.ui-dialog').remove();" name="WebsiteAdPractices_PrivacyNotice" href="/privacy/online-privacy-notice.go" target="_blank">Bank of America Online Privacy Notice</a> and our <a onclick="$('.ui-dialog').remove();" name="Online-privacy-faqs" href="/privacy/faq/online-privacy-faq.go" target="_blank">Online Privacy FAQs</a>.</p>
								</div>
						<div class="clearboth"></div>
	    			</div>
	      			<p>Bank of America, N.A. Member FDIC. <a onclick="function onclick() { window.open('/help/equalhousing_popup.go','newwin','width=640,height=371,scrollbars=yes,resizable=yes,left=35,top=161'); return false; }" name="Equal_Housing_Lender" href="/help/equalhousing_popup.go">Equal Housing Lender<img src="/content/images/ContextualSiteGraphics/Logos/en_US/icon_equal_housing_lender.gif" alt="" width="14" height="9" /></a> <br />&copy; 2017 Bank of America Corporation. All rights reserved.</p>
         		</div>
         		<div class="footer-social-container" style="float:right;max-width:30%;padding-left:50px;padding-top:19px;">




<div class="boa-social-loader" data-loaded="false" data-platform="borneo"  data-options=''></div>

         		</div>
         		<div class="clearboth"></div>
  			</div>
		</div>


				<div id="glossary-popup-1" class="hide tabs-main-content">
					<h3>Medical specialties</h3>
					<p>The medical specialties we finance vary depending on whether you are seeking financing for an established practice or starting up a practice from scratch.</p> <p><strong>Established practices:</strong> We offer financing for a wide range of specialties. Call 800.497.6076 to speak with a Practice Specialist and discuss your particular specialty and financing needs.</p> <p><strong>Start-up practices:</strong> We offer financing for anesthesiology: pain management, cardiology, colon &amp; rectal surgery, dermatology, family practice, gastroenterology, general surgery, internal medicine, neurology, OB/GYN, oncology, ophthalmology, optometry, orthopedic surgery, otolaryngology, pathology, pediatrics, plastic surgery, podiatric surgery, pulmonary, radiology, thoracic surgery, urology and vascular surgery.</p>
				</div>
				<div id="glossary-popup-2" class="hide tabs-main-content">
					<h3>Demographic Site Analysis</h3>
					<p>Your practice is a business, and understanding your market is critical to business success. Our Demographic Site Analysis provides detailed fact-based insight through an analysis of geographic, social, economic and growth potential factors. Whether you&rsquo;re deciding on a location or already have one, this is an excellent tool for helping you understand your target market. With Demographic Site Analysis you can:</p><ul><li>Anticipate the growth potential of your specific area</li><li>Receive in-depth information on area residents including age, income, size of household and more</li><li>Identify lifestyle preferences such as leisure activities, reading habits and purchase patterns</li><li>Discover how to market your services to achieve a higher return on investment</li></ul>
				</div>
			
<!-- start number replacer -->
<script type="text/javascript">
<!--
vs_account_id = "CtjSZVLv_rNmIgEJ";
//-->
</script>


<script type="text/javascript" src="https://www.voicestar.com/euinc/number-changer.js">
</script>

<script>
function getUrlVars() {
var vars = {};
var parts = window.location.href.replace(/[?&]+([^=&]+)=([^&]*)/gi, function(m,key,value) {
vars[key] = value;
});
return vars;
}
var myDynamicID = getUrlVars()["vsaccountid"];
</script>
</div>
					</div>
				</div>
			</div>
		</div>
	</body>	
</html>

