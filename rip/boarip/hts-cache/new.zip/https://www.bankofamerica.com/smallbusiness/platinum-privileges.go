
 

				<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
				<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
				<head>


<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta http-equiv="content-type" content="text/html;charset=utf-8">





<title>Rewards Checking with Business Platinum Privileges from Bank of America</title>

<meta name="Description" CONTENT="Enjoy rewards, recognition and benefits with Business Platinum Privileges from Bank of America Small Business checking.">
<meta name="Keywords" CONTENT="business platinum privileges, business rewards checking, business checking account promotion">

					<meta name="twitter:title" CONTENT="Rewards Checking with Business Platinum Privileges from Bank of America" />
					<meta name="twitter:card" CONTENT="summary" />
					<meta name="twitter:url" CONTENT="https://www.bankofamerica.com/smallbusiness/platinum-privileges.go" />
					<meta name="twitter:image" CONTENT="https://www.bankofamerica.com/content/images/ContextualSiteGraphics/Logos/en_US/Bank_of_America_Flagscape_71x71.gif" />
					<meta name="twitter:description" CONTENT="Enjoy rewards, recognition and benefits with Business Platinum Privileges from Bank of America Small Business checking." />
					<meta name="twitter:site" CONTENT="@BofA_Tips" />
		   			<meta property="og:title" CONTENT="Rewards Checking with Business Platinum Privileges from Bank of America" />
		   			<meta property="og:type" CONTENT="website" />
		   			<meta property="og:url" CONTENT="https://www.bankofamerica.com/smallbusiness/platinum-privileges.go" />
		   			<meta property="og:image" CONTENT="https://www.bankofamerica.com/content/images/ContextualSiteGraphics/Logos/en_US/Bank_of_America_Flagscape_71x71.gif" />
		   			<meta property="og:description" CONTENT="Enjoy rewards, recognition and benefits with Business Platinum Privileges from Bank of America Small Business checking." />
		   			<meta property="og:site_name" CONTENT="Bank of America" />
		<link rel="canonical" href="https://www.bankofamerica.com/smallbusiness/platinum-privileges.go"/>

<link rel="shortcut icon" href="/pa/global-assets/1.0/graphic/favicon.ico" type="image/ico" />

			<link rel="stylesheet" type="text/css" href="/pa/components/bundles/gzip-compressed/xengine/APS-small-business/2017.03.0/style/bcs-aps-sb-jawr.css" media="all" />
			<script src="/pa/components/bundles/gzip-compressed/xengine/APS-small-business/2017.03.0/script/bcs-aps-sb-jawr.js" type="text/javascript"></script>
				<script type="text/javascript">
					$(window).load(function(){asyncPrintCssInclude('https://www.bankofamerica.com/pa/components/bundles/gzip-compressed/xengine/APS-small-business/2017.03.0/style/bcs-aps-sb-jawr-print.css');});
				</script>
				<script src="/pa/components/modules/generic-content-module/2.2/script/generic-content-module-overview-vzd3-skin.js" type="text/javascript"></script>
				<script src="/pa/components/modules/faq-module/1.9/script/faq-module-main-well-skin.js" type="text/javascript"></script>
					<link href="/pa/components/modules/faq-module/1.9/style/faq-module-main-well-skin.css" rel="stylesheet" type="text/css">
					<link href="/pa/components/modules/generic-content-module/2.2/style/generic-content-module-overview-vzd3-skin.css" rel="stylesheet" type="text/css">
<script type="text/javascript">
(function() {
	if (typeof mboxUpdate == "function") {
		var windowURL = window.location.href
	    windowURL = windowURL.slice( windowURL.indexOf('.')+1);
		windowURL = windowURL.split( '?' )[0];
		windowURL = windowURL.toLowerCase();
		//alert(windowURL);
		if (
		    //If no mboxes on page, mbox count will be < 1
		    (mboxFactoryDefault.getMboxes().length() < 1) &&

			//Also check for high-volume pages that do not need global logging
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go") &&
			(windowURL != "bankofamerica.com/myaccounts/signin/signin.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/entry/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signonscreen.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatechallengeanswer.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatePassword.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/mobile/banking.go")&&
			(windowURL != "bankofamerica.com/content/preload/olb-myaccount-preload-jawr-module.htm")
			)
		{

			var mboxDiv = document.createElement("div");
			mboxDiv.id = "adobe_touch_clarity_replacement";
			mboxDiv.style.display = "none";
			if (document.body && document.body.firstChild) document.body.insertBefore(mboxDiv,document.body.firstChild);
			mboxDefine(mboxDiv.id,'bac_global_bottom');
			mboxUpdate('bac_global_bottom');
		}
	}
})();
</script>

		<script src="/pa/components/bundles/gzip-compressed/xengine/Global/1.0/script/tealeafbundle.js" type="text/javascript"></script>
			<script>
				var boaPageDataJS = {};
					boaPageDataJS.isLLE = "false";
			</script>
				<style>body{display:none;}</style>
	</head>		

	<body class="fsd-layout-body">	

				<script type="text/javascript">if(self == top){var theBody=document.getElementsByTagName("body")[0];theBody.style.display="block";}else{top.location=self.location;}</script>
				<noscript><style>body{display:block;}</style></noscript>
					<a class='ada-hidden ada-visible-focus' href='#skip-to-h1' id='ada-skip-link'>Skip to main content</a>
		<div class="fsd-layout fsd-2c-700lt-layout">
			<div class="fsd-border">
				<div class="center-content">
					<div class="header">
		  



<script language="javascript" src="/pa/components/modules/tag-manager-module/1.1/script/tag-manager-module-borneo-global-skin.js"></script>
<script>

(function() {
  var fireCallback = function( cb ) {
    if ( typeof cb === "function" ) cb();
  };
  
  function ddoPopulateBase( callback ) {
    try {
		  var DDO = window.digitalData,
		  	bactm_mergeDDO = function( newDDO, priorDDO ) {
		  		if( typeof priorDDO === "undefined" ) {
				  	priorDDO = digitalData || {};
				  }

			    for (var l in newDDO) {
			        if (typeof priorDDO[l] === "undefined") {
			            priorDDO[l] = newDDO[l];
			        }
			        if (newDDO[l] !== null) {
			            if (typeof newDDO[l] === "object") {
			                bactm_mergeDDO(newDDO[l], priorDDO[l]);
			            } else {
			                priorDDO[l] = bactm_validateValue( newDDO[l] ) ? newDDO[l] : priorDDO[l];
			            }
			        }
			    }

			    return priorDDO;
				},
				bactm_olb3rdPartyId = "null";

			if (typeof DDO === "undefined") {
				var simpleDDO = { page: { pageInfo:[{ pageID: null }], attributes: {}, category: { primaryCategory: null }}};

				DDO = (typeof digitalData === "object") ? digitalData : simpleDDO; 
			}

				DDO = bactm_mergeDDO( {"pageInstanceID":"notprod","load_coremetrics":false,"load_opinionlabs":false,"load_touchcommerce":true,"load_audiencemanager":true,"page":{"pageInfo":[{"pageID":null,"destinationURL":null,"referringURL":null,"issueDate":null,"language":null,"segmentValue":null,"appName":null,"appStepNumber":null,"appStepName":null,"attr":"-_--_--_--_--_--_--_--_--_--_--_--_--_--_-"}],"category":{"primaryCategory":null,"addlCategory":null,"pageType":null},"attributes":{"searchString":null,"searchResults":null,"olbSessionID":null,"subCampaignCode":null,"DARTUrl":null,"stateCookie":null,"SASIEnabled":false,"needOLBcookie":false,"standardDART":[],"standardDARTes":[],"clickDART":[],"clickDARTes":[],"gaId":[],"chat":{"site_id":36533208,"account_type":"smallbusiness","boa_associate":null,"boa_retiree":null,"customer_lob":"sbob","customer_segment":null,"data":null,"email_campaign":null,"entitlement_code":null,"error_category":null,"error_count":null,"first_login":null,"inqSalesProductTypes":{},"invitation_background":null,"invitation_template":null,"referral_campaign":null,"getStateValue":false,"cust_fn":null,"cust_ln":null,"target":{"lpButtonDiv-Resources":"SB-Fixed15"}}}},"user":{"segment":null,"online_id":null,"preferred_rewards_tier":null,"olb3rdpartyid":null},"version":"BAC_0.12"}, DDO );

			DDO.page.pageInfo[0].pageID = "";
			DDO.page.category.primaryCategory  = "";
			DDO.page.pageInfo[0].language = "en-US";
			DDO.page.attributes.olbSessionID = "null";
			DDO.page.attributes.SASIEnabled =  "false";
			if (typeof DDO.user != "undefined" && typeof DDO.user.olb3rdpartyid != "undefined") {
				DDO.user.olb3rdpartyid = bactm_olb3rdPartyId;
			}

			window.utag_data = {};
			window.bactm_envSelector = bactm_setTMLib();
			window.digitalData = DDO;

      return fireCallback( callback );

    } catch(e) { }
  }
	if( window.boa && window.boa.digitalData ) {
    window.boa.digitalData.register( ddoPopulateBase );
	}
	else {
	  // Handle scenario where the header isn't available (and thus the default digitalData object and utag loader are missing).
	  //
		var writeScript = function(a,b,c,d){
			a='//tags.tiqcdn.com/utag/bofa/main/' + bactm_envSelector + '/utag.js';
			b=document;
			c='script';
			d=b.createElement(c);
			d.src=a;
			d.type='text/java'+c;
			d.async=true;
			a=b.getElementsByTagName(c)[0];
			a.parentNode.insertBefore(d,a);
		};

		ddoPopulateBase( writeScript );
	}
})();			
</script>



	
	
		
			<noscript>
				<div class="fauxdal-overlay"></div>
				<div class="fauxdal-module">
					<div class="js-disabled-skin">
						<div class="fauxdal-top"></div>
						<div class="fauxdal-bottom">
							<div class="fsd-fauxdal-content">
									<div class="fsd-fauxdal-title">
										Please Use JavaScript
									</div>
										<p>You need a web browser that supports JavaScript to use our site. Without it, some pages won&rsquo;t work as designed. To make sure JavaScript is turned on, please adjust your browser settings.</p>
<p><a name="Browser_Help_And_Tips" href="/onlinebanking/online-banking-security-faqs.go" target="_blank">Browser Help and Tips</a></p>
							</div>        
							<div class="fsd-fauxdal-close"> 
								<a class="btn-bofa btn-bofa-small" name="close_button_js_disabled_modal" href=?js=y>Close</a>
							</div>
							<div class="clearboth"></div>
						</div>
					</div>
				</div>
			</noscript>



 


<div class="header-module">
	<div class="text-w-logo-skin">
		<div class="header-left">
	  
			<div itemscope itemtype="http://schema.org/Corporation" class="bofa-logo">
				<a itemprop="url" name="anc-business-advantage" title="Bank of America Small Business" href="/smallbusiness/index.jsp">
					<img itemprop="logo" height="28" width="221" 
					     alt="Bank of America Small Business" src="/content/images/ContextualSiteGraphics/Logos/en_US/boa_logo.gif"/>
				</a>
			</div>
				<div class="product" data-font="cnx-regular">Business Advantage</div>
			
			<div class="clearboth"></div>

		</div>
		
		<div class="header-right">
			<ul class="header-links">
			
				
					
				
							<li class="sign-in">
		<a					href="/sitemap/hub/signin.go" target="_self"
		name="Sign_In">Sign In</a> 
							</li>
					
				
							<li>		<a					href="/smallbusiness/index.jsp" target="_self"
		name="Home_Header">Home</a> 
</li>
					
				
							<li>		<a					href="https://locators.bankofamerica.com " target="_self"
		name="Locations">Locations</a> 
</li>
					
				
							<li>		<a					href="/contactus/contactus.go?topicId=small_business_banking" target="_self"
		name="Contact_Us">Contact Us</a> 
</li>
					
				
							<li class="last-link">	
		<a					href="/help/" target="_self"
		name="Help">Help</a> 
							</li>
			</ul>
			
			<div class="clearboth"></div>

			<!-- include search-dotcom-util -->



<div class="header-search nlh">
  
  <div class="nav-search">
    <form class="search-form" action="https://secure.bankofamerica.com/myaccounts/public/search-results/unAuthenticatedSearch.go" data-js="/pa/components/utilities/search-util/1.0/script/nav-search.min.js" data-css="/pa/components/utilities/search-util/1.0/style/nav-search.css" data-text-unavailable="Search Currently Unavailable">
      <div class="search-input-container cf" data-icon="search">
        <label for="nav-search-query" class="ada-hidden">Search Term</label>
        <input type="text" placeholder="How can we help you?" name="query" class="search-query" id="nav-search-query" 
          maxlength="99" rel="Search" autocomplete="off"><input type="submit" alt="Search" title="Search" value="Submit Search" name="Search Module - Top Result – Search Button" class="submit track-me">
      </div>
    </form>
  </div>

</div>

		</div>

 		<div class="clearboth"></div>
 	</div>
</div>







	<div class="top-nav-module">
		<div class="fsd-skin sup-ie">
			<ul class="nav-list">
					
					
					<li>
						
								<a href="/smallbusiness/deposits/checking-accounts/" class="top-menu-item"
								name="business_checking_topnav" id="business_checking_topnav">Business Checking<span class="ada-hidden"> &nbsp;link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/smallbusiness/deposits/checking-accounts/business-advantage/"  name="business_advantage_topnav" id="business_advantage_topnav">Business Advantage </a>
															<a href="/smallbusiness/deposits/checking-accounts/business-fundamentals/"  name="business_fundamentals_topnav" id="business_fundamentals_topnav">Business Fundamentals<sup>&reg;</sup> </a>
															<a href="/smallbusiness/business-debit-card.go"  name="business_debit_card_topnav" id="business_debit_card_topnav">Business Debit Card </a>
									</div>
								
									<span class="ada-hidden"> End of submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
					
					
					<li>
						
								<a href="/smallbusiness/cd-savings-accounts.go" class="top-menu-item"
								name="business_savings_and_cds_topnav" id="business_savings_and_cds_topnav">Business Savings & CDs<span class="ada-hidden"> &nbsp;link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/smallbusiness/savings-accounts/business-interest-maximizer.go"  name="business_interest_maximizer_topnav" id="business_interest_maximizer_topnav">Business Interest Maximizer&trade; </a>
															<a href="/smallbusiness/savings-accounts/business-investment-account.go"  name="business_investment_account_topnav" id="business_investment_account_topnav">Business Investment Account </a>
															<a href="/smallbusiness/cds/business-featured-cd.go"  name="business_featured_cd_topnav" id="business_featured_cd_topnav">Business Featured CD </a>
															<a href="/smallbusiness/cds/risk-free-cd.go"  name="business_risk_free_cd_topnav" id="business_risk_free_cd_topnav">Business Risk Free CD<sup>&reg;</sup> </a>
															<a href="/smallbusiness/standard-cds.go"  name="cds_topnav" id="cds_topnav">Standard Business CD </a>
									</div>
								
									<span class="ada-hidden"> End of submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
					
					
					<li>
						
								<a href="javascript:void(0);" class="top-menu-item"
								name="manage_accounts_topnav" id="manage_accounts_topnav">Manage Your Account<span class="ada-hidden"> &nbsp;link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/smallbusiness/online-banking.go"  name="online_banking_topnav" id="online_banking_topnav">Online Banking </a>
															<a href="/smallbusiness/online-banking/cash-management.go"  name="business_tools_topnav" id="business_tools_topnav">Business Tools </a>
									</div>
								
									<span class="ada-hidden"> End of submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
					
					
					<li>
						
								<a href="javascript:void(0);" class="top-menu-item selected"
								name="resources_topnav" id="resources_topnav">Resources<span class="ada-hidden"> &nbsp;link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/smallbusiness/resources/faqs.go"  name="faqs_topnav" id="faqs_topnav">FAQs </a>
															<a href="/smallbusiness/resources/glossary.go"  name="glossary_topnav" id="glossary_topnav">Glossary </a>
															<a href="/smallbusiness/resources/fees-at-a-glance.go"  name="fees_at_a_glance_topnav" id="fees_at_a_glance_topnav">Fees at a Glance </a>
															<a href="/deposits/bank-account-interest-rates/?flow=BCS"  name="account_rates_topnav" id="account_rates_topnav">Account Rates </a>
															<a href="/smallbusiness/platinum-privileges.go"  name="business_platinum_privileges_topnav" id="business_platinum_privileges_topnav">Business Platinum Privileges&trade; </a>
															<a href="/smallbusiness/resources/overdraft-protection.go"  name="overdraft_protection_topnav" id="overdraft_protection_topnav">Overdraft Protection </a>
									</div>
								
									<div class="hasSub">
														<a class="with-info" href="/smallbusiness/education.go"  name="managing_a_small_business_topnav" id="managing_a_small_business_topnav">Managing A Small Business 
															
															<span class="sub-nav-item-info">Articles, tips and tools to help you and your business grow</span>
														</a>
														<a class="with-info" href="/smallbusiness/online-banking/business-services.go"  name="popular_service_combinations_topnav" id="popular_service_combinations_topnav">Popular service combinations 
															
															<span class="sub-nav-item-info">See how business checking solutions combined with Online Banking services can help your business</span>
														</a>
									</div>
									<span class="ada-hidden"> End of submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
			</ul>
				<div class="clearboth"></div>
		</div>
	</div>


	
 
<div class="page-title-fsd-module h-100" id="skip-to-h1">
	<div class="prod-indicator-skin sup-ie">
		<div class="full-width-wrapper">
			<h1 data-font="cnx-regular">Business Platinum Privileges&trade;</h1>	

			

			<div class="clearboth"></div>
		</div>
  	</div>
</div>


<div class="banner-bdf-module">
   <div class="flagscape-skin vertical sup-ie" style="background-image:url('https://www.bankofamerica.com/content/images/ContextualSiteGraphics/Instructional/en_US/bcs_plat-vert-grad-bg.png')">
   		<div class="banner-content" style="background-image:url('https://www.bankofamerica.com/content/images/ContextualSiteGraphics/Instructional/en_US/bcs_red-flagscape.png')">
		  <h2 class="red-heading">You deserve the rewards of&nbsp; <span class="banner-super">Business Platinum Privileges<sup>&trade;</sup></span></h2>
		  <p>Enjoy recognition and benefits from your banking relationship</p>     
		</div>
   </div>
</div>



	
<script type="text/javascript">
	$(document).ready(function() {
		var $tabsAjaxModuleVzD3Skin = $('.tabs-ajax-module .vzd3-skin');
			/*CMS to set these values as needed*/
		
		      function ajaxContentModuleTabCallback(index) {
                  switch(index) {
						  case 0:
								cX('onload');
								break;
						  case 1:
								cX('onload');
								break;
						  case 2:
								cX('onload');initFAQs();
								break;
                     }
                 }	
				 
			function ajaxTabShowCallback()
			{
				;
			}
			
		var options = {
			selected: 0,
			tabsMainContentTarget: $('.lt-col'),
			replaceElements: [],
			boaTabsAjaxLoadCallback: ajaxContentModuleTabCallback,
			boaTabsShowCallback :ajaxTabShowCallback
		};

		$tabsAjaxModuleVzD3SkinTabs = $tabsAjaxModuleVzD3Skin.jTabs(options);
	});

	function selectVzD3TabLink(tab) {
		$tabsAjaxModuleVzD3SkinTabs.jTabs("selectTab",tab);
	}

</script>

	<div class="tabs-ajax-module">
		<div class="vzd3-skin tabs-com-vzd3-common">
		<ul>
			
				<li class="tab-com">
					<div class="tab-cap-com"></div>
					<a href="/smallbusiness/platinum-privileges.go" name="businessPlatinumPrivilegeOverview_tabLink" >Banking</a>
					<div class="tab-cap-com tab-rt-cap-com"></div>
					<div class="clearboth"></div>
				</li>
				<li class="tab-com">
					<div class="tab-cap-com"></div>
					<a href="/smallbusiness/platinum-privileges/investment.go" name="businessPlatinumPrivilegeInvestment_tabLink" >Investment</a>
					<div class="tab-cap-com tab-rt-cap-com"></div>
					<div class="clearboth"></div>
				</li>
				<li class="tab-com">
					<div class="tab-cap-com"></div>
					<a href="/smallbusiness/platinum-privileges/faqs.go" name="businessPlatinumPrivilegeFaqs_tabLink" >FAQs</a>
					<div class="tab-cap-com tab-rt-cap-com"></div>
					<div class="clearboth"></div>
				</li>
		</ul>
		 <div class="clearboth"></div>
		</div>
	</div>

	




	
<div class="live-person-bdf-module">
   <div class="bcs-skin">
    
     	<a href="javascript:window.print();" name="print">PRINT<span class="ada-hidden">  this page</span></a> 
    
	
		<div id="lpButtonDiv-Resources">
		</div>
		
		<div id="lpButtonDivVoice"></div>
   </div>
</div>

</div>
					<div class="columns">
						<div class="flex-col lt-col" >

	
<div class="generic-content-module tabs-main-content">
	<div class="overview-vzd3-skin com-main-well-content" style="">
				<h3 class="top-element">What is Business Platinum Privileges&trade;?</h3>
			
			
							<p class="pad-adjust">Business Platinum Privileges is an exclusive benefits program for our higher-balance business customers. With Business Platinum Privileges status, you&rsquo;ll receive a greater level of service and extra benefits at no additional cost.<a href="#footnote1" name="fn-1"><sup><span class="ada-hidden">Footnote&nbsp;</span>1</sup></a> All members qualify for:</p>
			


			
			
				<ul>
					<li>
					<strong>Access to our Small Business Priority Service Team</strong> &mdash; a team of dedicated specialists for faster call handling and support
					
					
					</li>
					<li>
					<strong>Platinum Business Interest Maximizer&trade; savings account</strong><a href="#footnote2" name="fn-2"><sup><span class="ada-hidden">Footnote </span>2</sup></a> offering no minimum balance requirement and no monthly maintenance fee
					
					
					</li>
					<li>
					<strong>Reduced rates</strong> on business lines of credit<a href="#footnote3" name="fn-3"><sup><span class="ada-hidden">Footnote </span>3</sup></a>
					
					
					</li>
					<li>
					Special benefits are available through Merrill Edge<sup>&reg;</sup> for Business Platinum Privileges clients. <a href="/smallbusiness/platinum-privileges/investment.go" name="businessPlatinumPrivilege_merrilEdgeSmallBusinessInvestmentSolutions_tab_Link" target="_self">Merrill Edge<sup>&reg;</sup> small business investment solutions</a> are designed to meet the unique investing, retirement and cash-management needs of your business
					
					
					</li>
				</ul>


	</div>
</div>


<div class="tips-module tabs-main-content">
	<div class="lt-blue-content-skin std-content-skin gray-variant">
			<h2>Learn more about Business Platinum Privileges&trade; benefits:</h2>
			<p>Call 1.866.543.2808, or stop by your local <a name="businessPlatinumPrivilege_bankingCenter_Link" href="http://locators.bankofamerica.com/locator/locator/LocatorAction.do?type=adv" target="_self">banking center</a>
			</p>
							<p class="tips-note">*Note: If you are a Business Platinum Privileges client, please call 1.888.BUSINESS (1.888.287.4637) and have your Access ID/PIN or your Bank of America account number on hand to authenticate your account when calling our dedicated Small Business service specialists.</p>
	</div>
</div>

</div>
						<div class="flex-col rt-col" >


<div class="side-well-module">
  <div class="red-w-link-skin c2a-red-skin">
    <div class="sw-outer no-bg">
      <div class="sw-inner">
        <div class="sw-corner sw-tleft"></div>
        <div class="sw-corner sw-tright"></div>
        <div class="sw-main sw-std-pad">
          <h2 class="h2-fsd-sw-red">Business Platinum Privileges&trade; Requirements</h2>
          <div class="sw-main-content no-top-brd">
            <p class="pbtm-15">How to qualify for the Business Platinum Privileges program:</p>
            <ul>
					<li class="pbtm-15"><strong>Balance requirements</strong> &ndash; Maintain $50,000 in combined Bank of America eligible business deposit balances (checking, savings, and/or CDs.) </li>
					<li class="pbtm-15"><strong>Account requirements</strong> &ndash; Have an open <a href="/smallbusiness/checking-accounts/business-advantage.go" target="_self">Business Advantage,</a> <a href="/smallbusiness/deposits/checking-accounts/business-fundamentals/" name="businessFundamentals_rightRail_link">Business Fundamentals<sup>&reg;</sup></a>, <a href="/smallbusiness/checking-accounts/business-interest-checking.go" name="businessInterestChecking_rightRail_link">Business Interest Checking</a> or Business Economy Checking account with Bank of America. </li>
            </ul>
				<a href="/smallbusiness/platinum-privileges/faqs.go" name="platinumpriv_req_link">Still have questions?<br /> Visit our FAQ section.&raquo;
				  <span class="ada-hidden">businessPlatinumPrivileges_faq_tablink</span>
				</a>
          </div>
        </div>
        <div class="sw-bottom"></div>
      </div>
      <div class="sw-corner sw-bleft"></div>
      <div class="sw-corner sw-bright"></div>
    </div>
  </div>
</div>
<script type="text/javascript">

</script>










<div class="state-selector-aps-sb-module">
    <div class="modal-skin sw-inner">
		<p class="pbtm-5">Information for Virginia</p>
	  	<a id="change-state-util" class="show-state-select-modal" rel="state-select-modal" href="javascript:void(0);">Change state <span class="ada-hidden">layer</span></a>
        <div class="state-select-aps-sb-modal hide" id="state-select-modal">
         <div class="modal-content">
            <h3>Select Your State</h3>
                <p>Please tell us where you bank so we can give you accurate rate and fee information for your location.</p>
                <form method="post" action="" id="submitState">
                    <fieldset>
                        <legend>State Selection Form</legend>
                        <input type="hidden" id="requestedUrl" value="" />
                        <label for="stateList">Current State</label>
<select name="stateListName" id="stateList" class="select-box" required="true">
    <option value=" ">Select state</option>
    <option value="AL">Alabama</option>
    <option value="AK">Alaska</option>
    <option value="AZ">Arizona</option>
    <option value="AR">Arkansas</option>
    <option value="CA">California</option>
    <option value="CO">Colorado</option>
    <option value="CT">Connecticut</option>
    <option value="DE">Delaware</option>
    <option value="DC">District of Columbia</option>
    <option value="FL">Florida</option>
    <option value="GA">Georgia</option>
    <option value="HI">Hawaii</option>
    <option value="ID">Idaho</option>
    <option value="IL">Illinois</option>
    <option value="IN">Indiana</option>
    <option value="IA">Iowa</option>
    <option value="KS">Kansas</option>
    <option value="KY">Kentucky</option>
    <option value="LA">Louisiana</option>
    <option value="ME">Maine</option>
    <option value="MD">Maryland</option>
    <option value="MA">Massachusetts</option>
    <option value="MI">Michigan</option>
    <option value="MN">Minnesota</option>
    <option value="MS">Mississippi</option>
    <option value="MO">Missouri</option>
    <option value="MT">Montana</option>
    <option value="NE">Nebraska</option>
    <option value="NV">Nevada</option>
    <option value="NH">New Hampshire</option>
    <option value="NJ">New Jersey</option>
    <option value="NM">New Mexico</option>
    <option value="NY">New York</option>
    <option value="NC">North Carolina</option>
    <option value="ND">North Dakota</option>
    <option value="OH">Ohio</option>
    <option value="OK">Oklahoma</option>
    <option value="OR">Oregon</option>
    <option value="PA">Pennsylvania</option>
    <option value="RI">Rhode Island</option>
    <option value="SC">South Carolina</option>
    <option value="SD">South Dakota</option>
    <option value="TN">Tennessee</option>
    <option value="TX">Texas</option>
    <option value="UT">Utah</option>
    <option value="VT">Vermont</option>
    <option value="VA">Virginia</option>
    <option value="WA">Washington</option>
    <option value="WV">West Virginia</option>
    <option value="WI">Wisconsin</option>
    <option value="WY">Wyoming</option>


</select>

                        <div class="button-cont">
	                        <a id="state_select_submit" class="btn-bofa btn-bofa-small state-select-modal-go-button" href="javascript:void(0);" role="button">Go</a>
	                    </div>
                    </fieldset>
                </form>
		 </div>
		</div>
	</div>
</div>


</div>
						<div class="clearboth"></div>
					</div>
					<div class="footer">
						<div class="footer-top">&nbsp;</div>
						<div class="footer-inner">



      <div class="disclaimers-module">
         <div class="bcs-skin sup-ie">
										<div class="h-100">
											<div class="footnote" id="footnote1">
												<div class="fn-num">1.</div>
													<div class="fn-text">
														You automatically qualify for the Business Platinum Privileges&trade; program when you maintain a combined balance of $50,000 or more in eligible business deposit accounts with Bank of America and you have an open Business Advantage, Business Fundamentals&trade;, Business Economy Checking or Business Interest Checking account with Bank of America. The combined balance requirement is calculated based on the average daily balance for the month in your Bank of America business deposit account(s) and applies when the owner of the business checking account and the owner of the other eligible deposit account(s) share the same Taxpayer Identification Number. Public service trust accounts, such as IOLTA accounts, are not counted toward the combined balance. Your enrollment in Business Platinum Privileges&trade; becomes effective in the month following the month in which you qualify. Some Business Platinum Privileges benefits are automatic; other benefits may require you to open a new account or take other action. Read carefully the terms of any Business Platinum Privileges offer to understand the action required.
													</div>
												<div class="clearboth">&nbsp;</div>
											</div>
										</div>
										<div class="h-100">
											<div class="footnote" id="footnote2">
												<div class="fn-num">2.</div>
													<div class="fn-text">
														New Business Platinum Privileges&trade; customers qualified at point of sale will be eligible to open a Platinum Business Interest Maximizer&trade; immediately, but will be enrolled officially in the program the following month. Limit one per customer. Other benefits will activate upon enrollment. The Platinum Business Interest Maximizer account is only available on request to customers enrolled in the Business Platinum Privileges program, or whose opening balance qualifies them for the Business Platinum Privileges program. Your enrollment in Business Platinum Privileges will not automatically convert any existing or new money market savings account to a Platinum Business Interest Maximizer without your request. See the Business Schedule of Fees for a description of the requirements for enrollment in Business Platinum Privileges. If your enrollment in the Business Platinum Privileges program is discontinued, your Platinum Business Interest Maximizer account will automatically convert to the Business Interest Maximizer account and the interest rate and fees for that subsequent account will apply.
													</div>
												<div class="clearboth">&nbsp;</div>
											</div>
										</div>
										<div class="h-100">
											<div class="footnote" id="footnote3">
												<div class="fn-num">3.</div>
													<div class="fn-text">
														Credit is subject to approval; normal credit standards apply. Credit is issued by Bank of America, N.A.
													</div>
												<div class="clearboth">&nbsp;</div>
											</div>
										</div>
										<div class="h-100">
											<div class="footnote" id="footnote4">
												<div class="fn-num">4.</div>
													<div class="fn-text">
														To qualify for this cash offer, you must open a Merrill Edge&reg; Self-Directed or Merrill Edge Advisory Center&trade; Business Investor Account (&ldquo;BIA&rdquo;) and fund the account within 30 calendar days of account opening from sources outside Merrill Lynch and Bank of America. The balance must be held in the account for a minimum of 90 consecutive days following the funding date. Cash reward qualifications: assets of $25,000 to $49,999 in cash and/or securities receive $100; for $50,000-$99,999, receive $150; for $100,000-$199,999, receive $250; for $200,000 or more, receive $600. Cash reward is a one-time deposit made within 30 days into your BIA after meeting qualifying criteria. The value of this reward you receive may constitute taxable income. In addition, Merrill Lynch may issue an Internal Revenue Service Form 1099 (or other appropriate form) to you that reflects the value of such reward. Please consult your tax advisor, as neither Bank of America, Merrill Lynch, nor its associates provide tax advice.
													</div>
												<div class="clearboth">&nbsp;</div>
											</div>
										</div>
										<div class="h-100">
											<div class="footnote" id="footnote5">
												<div class="fn-num">5.</div>
													<div class="fn-text">
														Offer valid for new Merrill Edge self-directed or Merrill Edge Advisory Center Simplified Employee Pension (SEP) Individual Retirement Account ("IRA").&nbsp; Limit one offer per individual.&nbsp; Limited to Sole-Proprietor SEP IRAs only. This offer does not apply to Business/Corporate Accounts, Investment Club Accounts, Partnership Accounts and certain fiduciary accounts held at MLPF&amp;S. Merrill Edge reserves the right to change or cancel this offer at any time.&nbsp; Open a Merrill Edge SEP IRA, fund the account within 30 days from sources outside Merrill Lynch and Bank of America, and maintain balance for 90 days. Assets held by 401(k) plans through Merrill Lynch are excluded. Cash reward qualifications: assets of $25,000 to $49,999 in cash and/or securities receive $100; for $50,000-$99,999, receive $150; for $100,000-$199,999, receive $250; for $200,000 or more, receive $600. Cash reward is a one-time deposit made within 30 days into your SEP IRA after meeting qualifying criteria.&nbsp; The value of this reward you receive may constitute taxable income. In addition, Merrill Lynch may issue an Internal Revenue Service Form 1099 (or other appropriate form) to you that reflects the value of such reward. Please consult your tax advisor, as neither Bank of America, Merrill Lynch, nor its associates provide tax advice.
													</div>
												<div class="clearboth">&nbsp;</div>
											</div>
										</div>
										<p>
												Banking products are provided by Bank of America, N.A. and affiliated banks, Members FDIC and wholly owned subsidiaries of Bank of America Corporation.
										</p>
										<p>
												<strong>Investment products:</strong>
										</p>
											<table border="0">
<tbody>
<tr>
<td><strong>Are Not FDIC Insured</strong></td>
<td><strong>Are Not Bank Guaranteed</strong></td>
<td><strong>May Lose Value</strong></td>
</tr>
</tbody>
</table>
												Merrill Edge is available through Merrill Lynch, Pierce, Fenner &amp; Smith Incorporated (MLPF&amp;S), and consists of the Merrill Edge Advisory Center (investment guidance) and self-directed online investing.
										<p>
												<br />MLPF&amp;S is a registered broker-dealer, member <a class="com-interstitial-modal-link" rel="http://sipc.org/" name="anc-disclaimer-sipc" href="javascript:void(0);" target="_self">Securities Investor Protection Corporation (SIPC)</a> and a wholly owned subsidiary of Bank of America Corporation.
										</p>
										<p>
												Investing in securities involves risks, and there is always the potential of losing money when you invest in securities.
										</p>
										<p>
												Bank of America and the Bank of America logo are registered trademarks of Bank of America Corporation.
										</p>
										<p>
												Any tax statements contained herein were not intended or written to be used, and cannot be used for the purpose of avoiding U.S. federal, state or local tax penalties. Neither Merrill Edge nor its Financial Solutions Advisors provide tax, accounting or legal advice. Clients should review any planned financial transactions or arrangements that may have tax, accounting or legal implications with their personal professional advisors.
										</p>
										<p>
										</p>
		 </div>
      </div>




<div class="power-footer-module">

  <div class="four-col-all-links-skin sup-ie">
    <div class="breadcrumbs">
						<a class="bold-bc" href="/" name="bank_of_america_platinum_privileges_breadcrumbs">Bank of America</a>
						<a href="/smallbusiness" name="small_business_platinum_privileges_breadcrumbs" >Small Business</a>
		
					<a href="/smallbusiness/education.go" name="resources_platinum_privileges_breadcrumbs">Resources</a>
		      	 <span>Business Platinum Privileges&trade;</span>
		    
      <div class="clearboth"></div>
    </div>
    <div class="pf-columns">
      
			<div class="pf-col" style="margin-right:50px;">
				<ul>
					<li>	
					<a href="/smallbusiness/deposits/checking-accounts/" class="bold" name="business_checking_platinum_privileges_power_footer" >Business Checking</a> 
					</li>
						<li> <a href="/smallbusiness/deposits/checking-accounts/business-advantage/" name="business_advantage_platinum_privileges_power_footer">Business Advantage</a> </li>
						<li> <a href="/smallbusiness/deposits/checking-accounts/business-fundamentals/" name="business_fundamentals_platinum_privileges_power_footer">Business Fundamentals<sup>&reg;</sup></a> </li>
						<li> <a href="/smallbusiness/checking-accounts/business-interest-checking.go" name="business_interest_checking_platinum_privileges_power_footer">Business Interest Checking</a> </li>
						<li> <a href="/smallbusiness/checking-accounts/full-analysis-business-checking.go" name="full_analysis_business_checking__platinum_privileges_power_footer">Full Analysis Business Checking </a> </li>
						<li> <a href="/smallbusiness/business-debit-card.go" name="business_debit_card_platinum_privileges_power_footer">Business Debit Card</a> </li>
				</ul>
		      </div>
			<div class="pf-col" style="margin-right:50px;">
				<ul>
					<li>	
					<a href="/smallbusiness/cd-savings-accounts.go" class="bold" name="business_savings_and_cd_platinum_privileges_power_footer" >Business Savings & CDs</a> 
					</li>
						<li> <a href="/smallbusiness/savings-accounts/business-interest-maximizer.go" name="business_interest_maximizer_platinum_privileges_power_footer">Business Interest Maximizer&trade;</a> </li>
						<li> <a href="/smallbusiness/savings-accounts/business-investment-account.go" name="business_investment_account_platinum_privileges_power_footer">Business Investment Account</a> </li>
						<li> <a href="/smallbusiness/cds/business-featured-cd.go" name="business_featured_cd_platinum_privileges_power_footer">Business Featured CD</a> </li>
						<li> <a href="/smallbusiness/cds/risk-free-cd.go" name="business_risk_free_cd_platinum_privileges_power_footer">Business Risk Free CD<sup>&reg;</sup></a> </li>
						<li> <a href="/smallbusiness/standard-cds.go" name="standard_business_cd_platinum_privileges_power_footer">Standard Business CD</a> </li>
				</ul>
		      </div>
			<div class="pf-col" style="margin-right:50px;">
				<ul>
					<li>	
					<a href="/smallbusiness/online-banking.go" class="bold" name="manage_your_account_platinum_privileges_power_footer" >Manage Your Account</a> 
					</li>
						<li> <a href="/smallbusiness/online-banking.go" name="online_banking_platinum_privileges_power_footer">Online Banking</a> </li>
						<li> <a href="/smallbusiness/online-banking/cash-management.go" name="business_tools_platinum_privileges_power_footer">Business Tools</a> </li>
						<li> <a href="/smallbusiness/business-debit-card.go" name="request_a_debit_card_platinum_privileges_power_footer">Request a Debit Card</a> </li>
				</ul>
		      </div>
			<div class="pf-col" style="">
				<ul>
					<li>	
					<a href="/smallbusiness/education.go" class="bold" name="resources_platinum_privileges_power_footer" >Resources</a> 
					</li>
						<li> <a href="/smallbusiness/resources/faqs.go" name="faqs_platinum_privileges_power_footer">FAQs</a> </li>
						<li> <a href="/smallbusiness/resources/glossary.go" name="glossary_platinum_privileges_power_footer">Glossary</a> </li>
						<li> <a href="/smallbusiness/resources/fees-at-a-glance.go" name="fees_at_a_glance_platinum_privileges_power_footer">Fees at a Glance</a> </li>
						<li> <a href="/deposits/bank-account-interest-rates/?flow=BCS" name="account_rates_platinum_privileges_power_footer">Account Rates</a> </li>
						<li> <a href="/smallbusiness/platinum-privileges.go" name="business_platinum_privileges_platinum_privileges_power_footer">Business Platinum Privileges&trade;</a> </li>
						<li> <a href="/smallbusiness/resources/overdraft-protection.go" name="overdraft_protection_platinum_privileges_power_footer">Overdraft Protection</a> </li>
				</ul>
		      </div>
      
      <div class="clearboth"></div>
    </div>
  </div>
</div>




 



		<div class="global-footer-module">
			<div class="fsd-skin">

				<div class="footer-bottom-left" style="float:left;max-width:66%;">
	    			<div class="gf-links">	          	
						
					
									
									<a  target="_self" href="/smallbusiness/index.jsp" 
									    name="global-footer-home">Home
									</a>
									
						
					
									
									<a  target="_self" href="/privacy/index.jsp" 
									    name="global-footer-privacy-security">Privacy & Security
									</a>
									
						
					
									
									<a  target="_self" href="http://careers.bankofamerica.com/careershome.aspx" 
									    name="footer_careers">Careers
									</a>
									
						
					
									
									<a  target="_self" href="/sitemap/sitemap/smallbusiness.go" 
									    name="global-footer-site-map">Site Map
									</a>
									
						
					
									<a href="javascript:void(0);" class="gf-last-link boa-dialog boa-com-info-layer-link" name="global_footer_ad_practices_lnk" rel="global_footer_ad_practices">Advertising Practices</a>
								<div id="global_footer_ad_practices" class="hide">
									<h3>Advertising Practices</h3>
										<p>We strive to provide you with information about products and services you might find interesting and useful. Relationship-based ads and online behavioral advertising help us do that.</p>
<p>Here's how it works: We gather information about your online activities, such as the searches you conduct on our Sites and the pages you visit. This information may be used to deliver advertising on our Sites and offline (for example, by phone, email and direct mail) that's customized to meet specific interests you may have.</p>
<p>If you prefer that we do not use this information, you may <a onclick="$('.ui-dialog').remove();" name="WebsiteAdPractices_OptOut" href="/privacy/online-privacy-notice.go#advertising-on-our-sites" target="_blank">opt out of online behavioral advertising</a>. If you opt out, though, you may still receive generic advertising. In addition, financial advisors/Client Managers may continue to use information collected online to provide product and service information in accordance with account agreements.</p>
<p>Also, if you opt out of online behavioral advertising, you may still see ads when you sign in to your account, for example through Online Banking or MyMerrill. These ads are based on your specific account relationships with us.</p>
<p>To learn more about relationship-based ads, online behavioral advertising and our privacy practices, please review the <a onclick="$('.ui-dialog').remove();" name="WebsiteAdPractices_PrivacyNotice" href="/privacy/online-privacy-notice.go" target="_blank">Bank of America Online Privacy Notice</a> and our <a onclick="$('.ui-dialog').remove();" name="Online-privacy-faqs" href="/privacy/faq/online-privacy-faq.go" target="_blank">Online Privacy FAQs</a>.</p>
								</div>
						<div class="clearboth"></div>
	    			</div>
	      			<p>Bank of America, N.A. Member FDIC. <a onclick="function onclick() { window.open('/help/equalhousing_popup.go','newwin','width=640,height=371,scrollbars=yes,resizable=yes,left=35,top=161'); return false;}" name="Equal_Housing_Lender" href="/help/equalhousing_popup.go">Equal Housing Lender<img src="/content/images/ContextualSiteGraphics/Logos/en_US/icon_equal_housing_lender.gif" alt="" width="14" height="9" /></a> <br />&copy;&nbsp;2017 Bank of America Corporation. All rights reserved.</p>
         		</div>
         		<div class="footer-social-container" style="float:right;max-width:30%;padding-left:50px;padding-top:19px;">




<div class="boa-social-loader" data-loaded="false" data-platform="borneo"  data-options=''></div>

         		</div>
         		<div class="clearboth"></div>
  			</div>
		</div>




 
<script type="text/javascript">
var axel = Math.random()+"";var a = axel * 10000000000000;document.write('<iframe title="iFrame used for layout purpose" src="https://fls.doubleclick.net/activityi;src=1359940;type=bacal484;cat=smb_b655;ord=1;num='+ a + '?" width="1" height="1" frameborder="0" style="display:none;"></iframe>');
</script>
<noscript>
	<iframe title="iFrame used for layout purpose" src="https://fls.doubleclick.net/activityi;src=1359940;type=bacal484;cat=smb_b655;ord=1?" width="0" height="0" frameborder="0" style="display:none;"></iframe>
</noscript>
<script language="javascript" src="/pa/global-assets/external/coremetrics/hp/eluminate.js"></script>
<script language="javascript" src="/pa/global-assets/external/coremetrics/hp/cmdatatagutils.js"></script>

<script language="javascript">
var testString = window.location.href;
    if (testString.toLowerCase().indexOf('.bankofamerica.com') > -1){
        testString = testString.toLowerCase();
        var tempArr = testString.split('.bankofamerica.com');var tempStr = tempArr[0];
        if (tempStr.indexOf('\/\/') > -1) {
            tempArr = tempStr.split('\/\/');tempStr = tempArr[1];
            if (tempStr.indexOf('.') > -1) {
                tempArr = tempStr.split('.');tempStr = tempArr[0];
            }
            if (tempStr.indexOf('www') > -1) {
                if (tempStr.indexOf('-') > -1) {cmSetStaging();}
                else {cmSetProduction();}
            }
            else {
                if (tempStr.indexOf('sitekey') > -1){
                    if (tempStr == 'sitekey') {cmSetProduction();}
                    else {cmSetStaging();}
                }
                else if (tempStr.indexOf('pssit') > -1){
                    if (tempStr == 'pssit') {cmSetStaging();}
                }
                if (tempStr.indexOf('-') > -1) {cmSetStaging();}
                else {cmSetProduction();}    
            }
        }
    }
  </script> 
  
		<script type="text/javascript">
		cmCreatePageviewTag('smbus:Content:Dep:PlatPriv;platinum-privileges', null, null, 'smbus:Content:Dep:PlatPriv', false, false, null, false, false, null, null, null, null, null, null, null, null, null, null, null, null);
		</script>
								
				
				
				
					
			
			
								
		<script type="text/javascript">
			
	// CoreMetrics 
		$('document').ready(function(){
			// Compare Tab click event.
			$('.tabs-bdf-module a[name*=Compare_tabLink]').bind('click.CM', function(){ 
	
				
						
			
		});
		
		});
			</script>
			<div itemscope="itemscope" itemtype="http://schema.org/WebPage">
					<span style="display:none" itemprop="name">Rewards Checking with Business Platinum Privileges from Bank of America</span>
					<a style="display:none" itemprop="url" href="https://www.bankofamerica.com/smallbusiness/platinum-privileges.go"></a>
					<span style="display:none" itemprop="description">Enjoy rewards, recognition and benefits with Business Platinum Privileges from Bank of America Small Business checking.</span>
					<img style="display:none" class="no-stretch" itemprop="image" alt="Rewards Checking with Business Platinum Privileges from Bank of America" src="https://www.bankofamerica.com/content/images/ContextualSiteGraphics/Logos/en_US/Bank_of_America_Flagscape_71x71.gif">
			</div>




	<div class="hide com-interstitial-modal">
     	<h3>Important Notice</h3>
   		<div class="flex-modal-main-content">
   		
      		<p><strong>You're continuing to another website</strong></p>
      		<p>You're continuing to another website that Bank of America doesn't own or operate. Its owner is solely responsible for the website's content, offerings and level of security, so please refer to the website's posted privacy policy and terms of use.</p>
   	
   	<div class="flex-modal-buttons">
	      	<a href="javascript:void(0);" class="button-common button-blue" name="leaving_bank_modal_continue"><span>Continue</span></a>
	         
	      	<a href="javascript:void(0);" class="button-common button-gray close-com-interstitial" name="leaving_bank_modal_cancel"><span>Return to Bank of America</span></a>
	         
          <div class="clearboth"></div>
      </div>
   </div>
</div>

</div>
					</div>
				</div>
			</div>
		</div>
	</body>	
</html>

