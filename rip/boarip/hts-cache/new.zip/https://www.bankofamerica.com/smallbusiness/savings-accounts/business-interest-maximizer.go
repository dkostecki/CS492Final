
 

				<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
				<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
				<head>


<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta http-equiv="content-type" content="text/html;charset=utf-8">





<title>Business Interest Maximizer - Competitive Yield Savings Account</title>

<meta name="Description" CONTENT="Make your money work harder with Business Interest Maximizer.  A competitive yield savings account brought to you by Bank of America.">
<meta name="Keywords" CONTENT="high yield savings account, interest bearing savings, bank of America business savings">

					<meta name="twitter:title" CONTENT="Business Interest Maximizer - Competitive Yield Savings Account" />
					<meta name="twitter:card" CONTENT="summary" />
					<meta name="twitter:url" CONTENT="https://www.bankofamerica.com/smallbusiness/savings-accounts/business-interest-maximizer.go" />
					<meta name="twitter:image" CONTENT="https://www.bankofamerica.com/content/images/ContextualSiteGraphics/Logos/en_US/Bank_of_America_Flagscape_71x71.gif" />
					<meta name="twitter:description" CONTENT="Make your money work harder with Business Interest Maximizer.  A competitive yield savings account brought to you by Bank of America." />
					<meta name="twitter:site" CONTENT="@BofA_Tips" />
		   			<meta property="og:title" CONTENT="Business Interest Maximizer - Competitive Yield Savings Account" />
		   			<meta property="og:type" CONTENT="website" />
		   			<meta property="og:url" CONTENT="https://www.bankofamerica.com/smallbusiness/savings-accounts/business-interest-maximizer.go" />
		   			<meta property="og:image" CONTENT="https://www.bankofamerica.com/content/images/ContextualSiteGraphics/Logos/en_US/Bank_of_America_Flagscape_71x71.gif" />
		   			<meta property="og:description" CONTENT="Make your money work harder with Business Interest Maximizer.  A competitive yield savings account brought to you by Bank of America." />
		   			<meta property="og:site_name" CONTENT="Bank of America" />
		<link rel="canonical" href="https://www.bankofamerica.com/smallbusiness/savings-accounts/business-interest-maximizer.go"/>

<link rel="shortcut icon" href="/pa/global-assets/1.0/graphic/favicon.ico" type="image/ico" />

			<link rel="stylesheet" type="text/css" href="/pa/components/bundles/gzip-compressed/xengine/APS-small-business/2017.03.0/style/bcs-aps-sb-jawr.css" media="all" />
			<script src="/pa/components/bundles/gzip-compressed/xengine/APS-small-business/2017.03.0/script/bcs-aps-sb-jawr.js" type="text/javascript"></script>
				<script type="text/javascript">
					$(window).load(function(){asyncPrintCssInclude('https://www.bankofamerica.com/pa/components/bundles/gzip-compressed/xengine/APS-small-business/2017.03.0/style/bcs-aps-sb-jawr-print.css');});
				</script>
<script type="text/javascript">
(function() {
	if (typeof mboxUpdate == "function") {
		var windowURL = window.location.href
	    windowURL = windowURL.slice( windowURL.indexOf('.')+1);
		windowURL = windowURL.split( '?' )[0];
		windowURL = windowURL.toLowerCase();
		//alert(windowURL);
		if (
		    //If no mboxes on page, mbox count will be < 1
		    (mboxFactoryDefault.getMboxes().length() < 1) &&

			//Also check for high-volume pages that do not need global logging
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go") &&
			(windowURL != "bankofamerica.com/myaccounts/signin/signin.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/entry/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signonscreen.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatechallengeanswer.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatePassword.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/mobile/banking.go")&&
			(windowURL != "bankofamerica.com/content/preload/olb-myaccount-preload-jawr-module.htm")
			)
		{

			var mboxDiv = document.createElement("div");
			mboxDiv.id = "adobe_touch_clarity_replacement";
			mboxDiv.style.display = "none";
			if (document.body && document.body.firstChild) document.body.insertBefore(mboxDiv,document.body.firstChild);
			mboxDefine(mboxDiv.id,'bac_global_bottom');
			mboxUpdate('bac_global_bottom');
		}
	}
})();
</script>

		<script src="/pa/components/bundles/gzip-compressed/xengine/Global/1.0/script/tealeafbundle.js" type="text/javascript"></script>
			<script>
				var boaPageDataJS = {};
					boaPageDataJS.isLLE = "false";
			</script>
				<style>body{display:none;}</style>
	</head>		

	<body class="fsd-layout-body">	

				<script type="text/javascript">if(self == top){var theBody=document.getElementsByTagName("body")[0];theBody.style.display="block";}else{top.location=self.location;}</script>
				<noscript><style>body{display:block;}</style></noscript>
					<a class='ada-hidden ada-visible-focus' href='#skip-to-h1' id='ada-skip-link'>Skip to main content</a>
		<div class="fsd-layout fsd-2c-700lt-layout">
			<div class="fsd-border">
				<div class="center-content">
					<div class="header">
		  



<script language="javascript" src="/pa/components/modules/tag-manager-module/1.1/script/tag-manager-module-borneo-global-skin.js"></script>
<script>

(function() {
  var fireCallback = function( cb ) {
    if ( typeof cb === "function" ) cb();
  };
  
  function ddoPopulateBase( callback ) {
    try {
		  var DDO = window.digitalData,
		  	bactm_mergeDDO = function( newDDO, priorDDO ) {
		  		if( typeof priorDDO === "undefined" ) {
				  	priorDDO = digitalData || {};
				  }

			    for (var l in newDDO) {
			        if (typeof priorDDO[l] === "undefined") {
			            priorDDO[l] = newDDO[l];
			        }
			        if (newDDO[l] !== null) {
			            if (typeof newDDO[l] === "object") {
			                bactm_mergeDDO(newDDO[l], priorDDO[l]);
			            } else {
			                priorDDO[l] = bactm_validateValue( newDDO[l] ) ? newDDO[l] : priorDDO[l];
			            }
			        }
			    }

			    return priorDDO;
				},
				bactm_olb3rdPartyId = "null";

			if (typeof DDO === "undefined") {
				var simpleDDO = { page: { pageInfo:[{ pageID: null }], attributes: {}, category: { primaryCategory: null }}};

				DDO = (typeof digitalData === "object") ? digitalData : simpleDDO; 
			}

				DDO = bactm_mergeDDO( {"pageInstanceID":"notprod","load_coremetrics":false,"load_opinionlabs":false,"load_touchcommerce":true,"load_audiencemanager":true,"page":{"pageInfo":[{"pageID":null,"destinationURL":null,"referringURL":null,"issueDate":null,"language":null,"segmentValue":null,"appName":null,"appStepNumber":null,"appStepName":null,"attr":"-_--_--_--_--_--_--_--_--_--_--_--_--_--_-"}],"category":{"primaryCategory":null,"addlCategory":null,"pageType":null},"attributes":{"searchString":null,"searchResults":null,"olbSessionID":null,"subCampaignCode":null,"DARTUrl":null,"stateCookie":null,"SASIEnabled":false,"needOLBcookie":false,"standardDART":[],"standardDARTes":[],"clickDART":[],"clickDARTes":[],"gaId":[],"chat":{"site_id":36533231,"account_type":"smallbusiness","boa_associate":null,"boa_retiree":null,"customer_lob":"sbob","customer_segment":null,"data":null,"email_campaign":null,"entitlement_code":null,"error_category":null,"error_count":null,"first_login":null,"inqSalesProductTypes":{},"invitation_background":null,"invitation_template":null,"referral_campaign":null,"getStateValue":false,"cust_fn":null,"cust_ln":null,"target":{"lpButtonDiv-BusinessSavingsCDs":"SB-Fixed15"}}}},"user":{"segment":null,"online_id":null,"preferred_rewards_tier":null,"olb3rdpartyid":null},"version":"BAC_0.12"}, DDO );

			DDO.page.pageInfo[0].pageID = "";
			DDO.page.category.primaryCategory  = "";
			DDO.page.pageInfo[0].language = "en-US";
			DDO.page.attributes.olbSessionID = "null";
			DDO.page.attributes.SASIEnabled =  "false";
			if (typeof DDO.user != "undefined" && typeof DDO.user.olb3rdpartyid != "undefined") {
				DDO.user.olb3rdpartyid = bactm_olb3rdPartyId;
			}

			window.utag_data = {};
			window.bactm_envSelector = bactm_setTMLib();
			window.digitalData = DDO;

      return fireCallback( callback );

    } catch(e) { }
  }
	if( window.boa && window.boa.digitalData ) {
    window.boa.digitalData.register( ddoPopulateBase );
	}
	else {
	  // Handle scenario where the header isn't available (and thus the default digitalData object and utag loader are missing).
	  //
		var writeScript = function(a,b,c,d){
			a='//tags.tiqcdn.com/utag/bofa/main/' + bactm_envSelector + '/utag.js';
			b=document;
			c='script';
			d=b.createElement(c);
			d.src=a;
			d.type='text/java'+c;
			d.async=true;
			a=b.getElementsByTagName(c)[0];
			a.parentNode.insertBefore(d,a);
		};

		ddoPopulateBase( writeScript );
	}
})();			
</script>



	
	
		
			<noscript>
				<div class="fauxdal-overlay"></div>
				<div class="fauxdal-module">
					<div class="js-disabled-skin">
						<div class="fauxdal-top"></div>
						<div class="fauxdal-bottom">
							<div class="fsd-fauxdal-content">
									<div class="fsd-fauxdal-title">
										Please Use JavaScript
									</div>
										<p>You need a web browser that supports JavaScript to use our site. Without it, some pages won&rsquo;t work as designed. To make sure JavaScript is turned on, please adjust your browser settings.</p>
<p><a name="Browser_Help_And_Tips" href="/onlinebanking/online-banking-security-faqs.go" target="_blank">Browser Help and Tips</a></p>
							</div>        
							<div class="fsd-fauxdal-close"> 
								<a class="btn-bofa btn-bofa-small" name="close_button_js_disabled_modal" href=?js=y>Close</a>
							</div>
							<div class="clearboth"></div>
						</div>
					</div>
				</div>
			</noscript>



 


<div class="header-module">
	<div class="text-w-logo-skin">
		<div class="header-left">
	  
			<div itemscope itemtype="http://schema.org/Corporation" class="bofa-logo">
				<a itemprop="url" name="anc-business-advantage" title="Bank of America Small Business" href="/smallbusiness/index.jsp">
					<img itemprop="logo" height="28" width="221" 
					     alt="Bank of America Small Business" src="/content/images/ContextualSiteGraphics/Logos/en_US/boa_logo.gif"/>
				</a>
			</div>
				<div class="product" data-font="cnx-regular">Business Advantage</div>
			
			<div class="clearboth"></div>

		</div>
		
		<div class="header-right">
			<ul class="header-links">
			
				
					
				
							<li class="sign-in">
		<a					href="/sitemap/hub/signin.go" target="_self"
		name="Sign_In">Sign In</a> 
							</li>
					
				
							<li>		<a					href="/smallbusiness/index.jsp" target="_self"
		name="Home_Header">Home</a> 
</li>
					
				
							<li>		<a					href="https://locators.bankofamerica.com " target="_self"
		name="Locations">Locations</a> 
</li>
					
				
							<li>		<a					href="/contactus/contactus.go?topicId=small_business_banking" target="_self"
		name="Contact_Us">Contact Us</a> 
</li>
					
				
							<li class="last-link">	
		<a					href="/help/" target="_self"
		name="Help">Help</a> 
							</li>
			</ul>
			
			<div class="clearboth"></div>

			<!-- include search-dotcom-util -->



<div class="header-search nlh">
  
  <div class="nav-search">
    <form class="search-form" action="https://secure.bankofamerica.com/myaccounts/public/search-results/unAuthenticatedSearch.go" data-js="/pa/components/utilities/search-util/1.0/script/nav-search.min.js" data-css="/pa/components/utilities/search-util/1.0/style/nav-search.css" data-text-unavailable="Search Currently Unavailable">
      <div class="search-input-container cf" data-icon="search">
        <label for="nav-search-query" class="ada-hidden">Search Term</label>
        <input type="text" placeholder="How can we help you?" name="query" class="search-query" id="nav-search-query" 
          maxlength="99" rel="Search" autocomplete="off"><input type="submit" alt="Search" title="Search" value="Submit Search" name="Search Module - Top Result – Search Button" class="submit track-me">
      </div>
    </form>
  </div>

</div>

		</div>

 		<div class="clearboth"></div>
 	</div>
</div>







	<div class="top-nav-module">
		<div class="fsd-skin sup-ie">
			<ul class="nav-list">
					
					
					<li>
						
								<a href="/smallbusiness/deposits/checking-accounts/" class="top-menu-item"
								name="business_checking_topnav" id="business_checking_topnav">Business Checking<span class="ada-hidden"> &nbsp;link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/smallbusiness/deposits/checking-accounts/business-advantage/"  name="business_advantage_topnav" id="business_advantage_topnav">Business Advantage </a>
															<a href="/smallbusiness/deposits/checking-accounts/business-fundamentals/"  name="business_fundamentals_topnav" id="business_fundamentals_topnav">Business Fundamentals<sup>&reg;</sup> </a>
															<a href="/smallbusiness/business-debit-card.go"  name="business_debit_card_topnav" id="business_debit_card_topnav">Business Debit Card </a>
									</div>
								
									<span class="ada-hidden"> End of submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
					
					
					<li>
						
								<a href="/smallbusiness/cd-savings-accounts.go" class="top-menu-item selected"
								name="business_savings_and_cds_topnav" id="business_savings_and_cds_topnav">Business Savings & CDs<span class="ada-hidden"> &nbsp;link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/smallbusiness/savings-accounts/business-interest-maximizer.go"  name="business_interest_maximizer_topnav" id="business_interest_maximizer_topnav">Business Interest Maximizer&trade; </a>
															<a href="/smallbusiness/savings-accounts/business-investment-account.go"  name="business_investment_account_topnav" id="business_investment_account_topnav">Business Investment Account </a>
															<a href="/smallbusiness/cds/business-featured-cd.go"  name="business_featured_cd_topnav" id="business_featured_cd_topnav">Business Featured CD </a>
															<a href="/smallbusiness/cds/risk-free-cd.go"  name="business_risk_free_cd_topnav" id="business_risk_free_cd_topnav">Business Risk Free CD<sup>&reg;</sup> </a>
															<a href="/smallbusiness/standard-cds.go"  name="cds_topnav" id="cds_topnav">Standard Business CD </a>
									</div>
								
									<span class="ada-hidden"> End of submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
					
					
					<li>
						
								<a href="javascript:void(0);" class="top-menu-item"
								name="manage_accounts_topnav" id="manage_accounts_topnav">Manage Your Account<span class="ada-hidden"> &nbsp;link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/smallbusiness/online-banking.go"  name="online_banking_topnav" id="online_banking_topnav">Online Banking </a>
															<a href="/smallbusiness/online-banking/cash-management.go"  name="business_tools_topnav" id="business_tools_topnav">Business Tools </a>
									</div>
								
									<span class="ada-hidden"> End of submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
					
					
					<li>
						
								<a href="javascript:void(0);" class="top-menu-item"
								name="resources_topnav" id="resources_topnav">Resources<span class="ada-hidden"> &nbsp;link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/smallbusiness/resources/faqs.go"  name="faqs_topnav" id="faqs_topnav">FAQs </a>
															<a href="/smallbusiness/resources/glossary.go"  name="glossary_topnav" id="glossary_topnav">Glossary </a>
															<a href="/smallbusiness/resources/fees-at-a-glance.go"  name="fees_at_a_glance_topnav" id="fees_at_a_glance_topnav">Fees at a Glance </a>
															<a href="/deposits/bank-account-interest-rates/?flow=BCS"  name="account_rates_topnav" id="account_rates_topnav">Account Rates </a>
															<a href="/smallbusiness/platinum-privileges.go"  name="business_platinum_privileges_topnav" id="business_platinum_privileges_topnav">Business Platinum Privileges&trade; </a>
															<a href="/smallbusiness/resources/overdraft-protection.go"  name="overdraft_protection_topnav" id="overdraft_protection_topnav">Overdraft Protection </a>
									</div>
								
									<div class="hasSub">
														<a class="with-info" href="/smallbusiness/education.go"  name="managing_a_small_business_topnav" id="managing_a_small_business_topnav">Managing A Small Business 
															
															<span class="sub-nav-item-info">Articles, tips and tools to help you and your business grow</span>
														</a>
														<a class="with-info" href="/smallbusiness/online-banking/business-services.go"  name="popular_service_combinations_topnav" id="popular_service_combinations_topnav">Popular service combinations 
															
															<span class="sub-nav-item-info">See how business checking solutions combined with Online Banking services can help your business</span>
														</a>
									</div>
									<span class="ada-hidden"> End of submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
			</ul>
				<div class="clearboth"></div>
		</div>
	</div>


	
 
<div class="page-title-fsd-module h-100" id="skip-to-h1">
	<div class="prod-indicator-skin sup-ie">
		<div class="full-width-wrapper">
			<h1 data-font="cnx-regular">Business Interest Maximizer&trade;</h1>	

			

			<div class="clearboth"></div>
		</div>
  	</div>
</div>








<div class="banner-bdf-module">
		<div class="red-c2a-skin sup-ie" style="background-color:#c5d4e3;background-image:url('https://www.bankofamerica.com/content/images/ContextualSiteGraphics/Instructional/en_US/SmallBusiness/business_interest_maximizer_FFFFFF_980x285.jpg')">
			<div class="red-c2a-content big-padding" style="background-image:url('https://www.bankofamerica.com/content/images/ContextualSiteGraphics/Instructional/en_US/SmallBusiness/business_interest_maximizer_FFFFFF_980x285.jpg')">
					<h2>Watch your savings grow with Business Interest Maximizer&trade;</h2>
					<p>A money market account great for established businesses with <br />higher balances</p>
										<a class="button-common-large button-red-large " href="/smallbusiness/submitAppToABPA.go?productEPC=FSDPDD00SS0DOHCAT51&productType=SAVINGSPRODUCT&productName=Business-Interest-Maximizer&source_id=10013SIM1910022" name="businessInterestMaximizer_openNow_button_in_banner"><span>Open Now</span>
										<span class="ada-hidden"> &nbsp;Business Interest Maximizer&trade;</span></a>


		  <div class="clearboth"><!--  --></div>
		 </div>
	 </div>
</div>








<div class="tabs-bdf-module">
  <div class="vzd3-skin tabs-com-vzd3-common">
    <ul>
				<li class="tab-com">
				<!-- 0 -->
			  <div class="tab-cap-com"></div>
			  <a href="#tab-0" name="bizInterestMaximizerOverview_tabLink">Overview</a>
			  <div class="tab-cap-com tab-rt-cap-com"></div>
			  <div class="clearboth"></div>
			</li>
				<li class="tab-com">
				<!-- 0 -->
			  <div class="tab-cap-com"></div>
			  <a href="#tab-1" name="bizInterestMaximizerRatesFees_tabLink">Rates & Fees</a>
			  <div class="tab-cap-com tab-rt-cap-com"></div>
			  <div class="clearboth"></div>
			</li>
				<li class="tab-com">
				<!-- 0 -->
			  <div class="tab-cap-com"></div>
			  <a href="#tab-2" name="bizInterestMaximizerFAQs_tabLink">FAQs</a>
			  <div class="tab-cap-com tab-rt-cap-com"></div>
			  <div class="clearboth"></div>
			</li>
				<li class="tab-com">
				<!-- 0 -->
			  <div class="tab-cap-com"></div>
			  <a href="#tab-3" name="bizInterestMaximizerCompare_tabLink">Compare</a>
			  <div class="tab-cap-com tab-rt-cap-com"></div>
			  <div class="clearboth"></div>
			</li>
    </ul>
    <div class="clearboth"></div>
  </div>
</div>




	
<div class="live-person-bdf-module">
   <div class="bcs-skin">
    
     	<a href="javascript:window.print();" name="print">PRINT<span class="ada-hidden">  this page</span></a> 
    
	
		<div id="lpButtonDiv-BusinessSavingsCDs">
		</div>
		
		<div id="lpButtonDivVoice"></div>
   </div>
</div>

</div>
					<div class="columns">
						<div class="flex-col lt-col" ><div class="generic-content-module tabs-main-content" id="tab-0">
   <div class="features-vzd3-skin com-main-well-content sup-ie">
	  <div class="rates-details equal">
        <div class="mrt-30">
			<h3>Get Business Interest Maximizer<a href="#footnote4" name="fn-4"><sup><span class="ada-hidden">Footnote&nbsp;</span>4</sup></a> and earn higher interest rates while maintaining easy access to funds, plus:</h3>
				
				&nbsp;</p>
<ul>
<li>Earn interest on excess funds without locking into a fixed term</li>
<li>No monthly maintenance fee when paired with <a href="/smallbusiness/checking-accounts/business-advantage.go" name="businessAdvantageSolution_link" target="_self">Business Advantage solution</a></li>
<li>Link to the Business Advantage solution and use your combined balances to waive the monthly checking fee<a href="#footnote2" name="fn-2"><sup><span class="ada-hidden">Footnote&nbsp;</span>2</sup></a></li>
<li>Help avoid the inconvenience of overdrafts by enrolling in Overdraft Protection<a href="#footnote3" name="fn-3"><sup><span class="ada-hidden">Footnote&nbsp;</span>3</sup></a></li>
<li>Convenient access to your funds whenever you need them</li>
</ul>
<p>
		 </div>
      </div>
      <div class="rates-highlights">
        <div class="rates-highlights-inner equal">
			<div class="rates-apy">
			   <span class="static-percent d-block">0.02 - 0.04%</span>
				<acronym class="static-apy d-block" title="Annual Percentage Yield">APY<a href="#footnote1" name="fn-1"><sup><span class="ada-hidden">Footnote&nbsp;</span>1</sup></a></acronym>
			</div>
			
			<ul class="bulletless-list terms-list">
					<li>with a $5,000 balance</li>
			</ul>
			
						<p class="sub-info">See <a href="/smallbusiness/savings-accounts/business-interest-maximizer.go#tab-1" name="ratesFees_link" target="_self">Rates &amp; Fees</a> for current interest rate information</p>
         </div>
      </div>
      <div class="clearboth"></div>
	  
   </div>
</div>

			


<!-- feeWaivedIndiactor added for all the fields from eprod/cdm -->	
<div class="sb-products-module tabs-main-content" id="tab-1">
  <div class="static-table-skin static-table-2col-skin sup-ie com-main-well-content">
 	<div class="sb-table-col">
	<h3 class="top-element">Rates</h3>
	
    <table summary="Table comparing rates at various levels of deposit amounts">
      <thead>
        <tr>
					<th scope="col">Business Interest Maximizer&trade; Savings</th>
					
					<th scope="col"><abbr title="Annual Percentage Yield">Interest Rate
					</abbr></th>
					
					
				<th scope="col">APY<a href="#footnote1" name="fn-1"><sup><span class="ada-hidden">Footnote&nbsp;</span>1</sup></a></th>
        </tr>
      </thead>
     
	  <tbody>
	  
				<tr>
					<td>Less than $10,000</td>
					<td>0.02%</td>
					<td>0.02%</td>
				</tr>
				<tr>
					<td>$10,000 - $24,999</td>
					<td>0.02%</td>
					<td>0.02%</td>
				</tr>
				<tr>
					<td>$25,000 - $49,999</td>
					<td>0.02%</td>
					<td>0.02%</td>
				</tr>
				<tr>
					<td>$50,000 - $99,999</td>
					<td>0.03%</td>
					<td>0.03%</td>
				</tr>
				<tr>
					<td>$100,000 - $249,999</td>
					<td>0.03%</td>
					<td>0.03%</td>
				</tr>
				<tr>
					<td>$250,000 - $499,999</td>
					<td>0.03%</td>
					<td>0.03%</td>
				</tr>
				<tr>
					<td>$500,000 - $2,499,999</td>
					<td>0.04%</td>
					<td>0.04%</td>
				</tr>
				<tr>
					<td>$2,500,000 and over</td>
					<td>0.04%</td>
					<td>0.04%</td>
				</tr>
	  </tbody>
    </table>
  </div>
  
   <div class="sb-list-col">
			<h3 class="top-element">Fees</h3>
                &nbsp;</p>
<ul>
<li>$15 monthly maintenance fee</li>
<li>See <a href="/smallbusiness/resources/business-schedule-fees.go" name="businessScheduleOfFees_link" rel="nofollow" target="_blank">Business Schedule of Fees</a> for other potential fees and transaction costs</li>
</ul>

			
         <h3>Or waive the monthly fee by meeting one of the following requirements: </h3>
         &nbsp;</p>
<ul>
<li>Maintain a $5,000 minimum daily balance</li>
<li>Include the Business Interest Maximizer&trade; as part of a <a href="/smallbusiness/checking-accounts/business-advantage.go" name="businessAdvantage_link" target="_self">Business Advantage</a> solution</li>
</ul>
<p>
		 <p>Link Business Interest Maximizer&trade; to the Business Advantage solution and use your combined balances to waive the monthly checking fee </p>
    </div>
    <div class="clearboth"></div>
               
    </div>
  </div>






			




			
<div id="tab-2" class="faq-module tabs-main-content">
    <div class="main-well-skin com-main-well-content table-vzd3-common table-vzd3-com ">
			<div class="show-hide-all ">
			   <a href="javascript:void(0);" class="faq-show-all" name="faqs_show_all" id="faqs_show_all">Show All<span class="ada-hidden"> answers</span></a>
			   &nbsp;|&nbsp;
			   <a href="javascript:void(0);" class="faq-hide-all" name="faqs_hide_all" id="faqs_hide_all">Hide All<span class="ada-hidden"> answers</span></a>
			</div>
      <ul class="faq-main">
						<li>
									<span class="question-link"><a href="javascript:void(0);" name="How_do_I_apply_for_a_Business_Interest_Maximizer_savings_account" id="How_do_I_apply_for_a_Business_Interest_Maximizer_savings_account">
									<span class="ada-hidden ada-action">Hide </span>How do I apply for a Business Interest Maximizer savings account?</a></span>
									<div class="faq-content-area">
										<p>We offer 3 convenient ways of opening a business savings account::</p>
<ul>
<li><a href="https://www.bankofamerica.com/smallbusiness/submitAppToABPA.go?productEPC=FSDPDD00SS0DOHCAT51&amp;productType=SAVINGSPRODUCT&amp;productName=Business-Interest-Maximizer&amp;source_id=10013SIM1910022" target="_self">Open a Business Interest Maximizer savings account online</a></li>
<li><strong>Call&nbsp; 866.543.2808</strong> </li>
<li><a href="http://locators.bankofamerica.com/locator/locator/" target="_self">Visit&nbsp;a financial center</a></li>
</ul>
<p><strong>What you'll need to apply</strong></p>
<p class="pbtm-15"><a onclick="displayPopup('/deposits/resources/sole-proprietor-required-documents.go')" name="anc-what" href="javascript:void();">Sole Proprietor</a></p>
<p class="pbtm-15"><a onclick="displayPopup('/deposits/required-documents-general-partnership.go')" name="anc-what" href="javascript:void();">General Partnership</a></p>
<p class="pbtm-15"><a onclick="displayPopup('/deposits/required-documents-limited-partnership.go')" name="anc-what" href="javascript:void();">Limited Partnership</a></p>
<p class="pbtm-15"><a onclick="displayPopup('/deposits/required-documents-corporation.go')" name="anc-what" href="javascript:void();">Corporation</a></p>
<p class="pbtm-15"><a onclick="displayPopup('/deposits/professional-corporation-required-documents.go')" name="anc-what" href="javascript:void();">Professional Corporation</a></p>
<p class="pbtm-15"><a onclick="displayPopup('/deposits/limited-liability-company-required-documents.go')" name="anc-what" href="javascript:void();">Limited Liability Company</a></p>
<p class="pbtm-15"><a onclick="displayPopup('/deposits/required-documents-uincorporated-association.go')" name="anc-what" href="javascript:void();">Unincorporated Association</a></p>
<p class="pbtm-15"><a onclick="displayPopup('/deposits/required-documents-professional-association.go')" name="anc-what" href="javascript:void();">Professional Association</a></p>
									</div>
						</li>
						<li>
									<span class="question-link closed"><a href="javascript:void(0);" name="How_do_I_make_an_initial_deposit_for_an_account_that_I_just_opened_online" id="How_do_I_make_an_initial_deposit_for_an_account_that_I_just_opened_online">
									<span class="ada-hidden ada-action">Show </span>How do I make an initial deposit for an account that I just opened online?</a></span>
									<div class="faq-content-area hide">
										<p>If you are already a customer, you can make your opening deposit by transferring money from your existing account. If you&rsquo;re transferring money from another bank, you can use a Visa&reg; or MasterCard&reg; debit card, check or money order.</p>
<p>If for some reason your account isn&rsquo;t approved, your deposit request will be canceled.</p>
									</div>
						</li>
						<li>
									<span class="question-link closed"><a href="javascript:void(0);" name="What_is_the_monthly_fee_for_a_Business_Interest_Maximizer_savings_account" id="What_is_the_monthly_fee_for_a_Business_Interest_Maximizer_savings_account">
									<span class="ada-hidden ada-action">Show </span>What is the monthly fee for a Business Interest Maximizer savings account?</a></span>
									<div class="faq-content-area hide">
										<P>The monthly fee varies by state. However, there is no monthly maintenance fee if you pair this savings account with a Business Advantage checking account. <A class=mceItemAnchor title="Get more information on rates and fees" href="/smallbusiness/savings-accounts/business-interest-maximizer.go#tab-1" target=_self name=anc-get-more-information-on-rates-and-fees mce_href="/smallbusiness/savings-accounts/business-interest-maximizer.go#tab-1">Get more information on rates and fees</A></P>
									</div>
						</li>
						<li>
									<span class="question-link closed"><a href="javascript:void(0);" name="How_is_interest_calculated_on_my_business_savings_account" id="How_is_interest_calculated_on_my_business_savings_account">
									<span class="ada-hidden ada-action">Show </span>How is interest calculated on my business savings account?</a></span>
									<div class="faq-content-area hide">
										<p>Interest rates are tiered according to your account balance. <a href="/smallbusiness/savings-accounts/business-investment-account.go#tab-1" title="See a complete listing of rates" name="see_a_complete_listing_of_rates" target="_self">See a complete listing of rates</a></p>
									</div>
						</li>
						<li>
									<span class="question-link closed"><a href="javascript:void(0);" name="Can_I_write_checks_with_my_Business_Interest_Maximizer_savings_account" id="Can_I_write_checks_with_my_Business_Interest_Maximizer_savings_account">
									<span class="ada-hidden ada-action">Show </span>Can I write checks with my Business Interest Maximizer savings account?</a></span>
									<div class="faq-content-area hide">
										<p>No, you may not write checks on this account or use a debit card for point-of-sale purchases and transactions.  However, you can link this account to your business checking account so you have overdraft protection.</p>
									</div>
						</li>
						<li>
									<span class="question-link closed"><a href="javascript:void(0);" name="Do_I_pay_an_additional_fee_for_Bank_of_America_Small_Business_Online_Banking" id="Do_I_pay_an_additional_fee_for_Bank_of_America_Small_Business_Online_Banking">
									<span class="ada-hidden ada-action">Show </span>Do I pay an additional fee for Bank of America Small Business Online Banking?</a></span>
									<div class="faq-content-area hide">
										<p>No. There are no additional fees to sign up for and use Bank of America Small Business Online Banking. In fact, once you sign up you&rsquo;ll have access to our online and mobile features such as mobile check deposit, online account management tools and access to your account online 24/7. Fees may apply for additional services.</p>
									</div>
						</li>
	  </ul>
	  
	  </div>
  </div>



	
 
<div id="tab-3" class="sb-products-module tabs-main-content">
    <div class="toggle-table-skin sup-ie">
			<h2 class="h2-fsd-red mbtm-10" >Savings Products</h2>
			<p>Earn interest on your balances while maintaining full access to your funds with a Bank of America business savings account. Whether you have a small business and are looking to grow your savings or are an established company with a large balance, Bank of America has a savings account that is sure to work for your business. In addition to low maintenance fees and healthy interest rates, all business savings accounts come with standard benefits, including online banking features.</p>
		
      <table summary="Business Savings Products Comparison" class="two-product-table">	  
	   <thead>
			<tr>
            <td class="blank-cell"></td>
					<th scope="col" class="para-text">
					<h3>
							<a href="/smallbusiness/savings-accounts/business-interest-maximizer.go" name="businessSavingsCDs_businessInterestMaximizer_link_top">
							Business Interest Maximizer&trade;
							</a>
						
					</h3>
					
										<a class="button-common button-blue mtop-10" href="/smallbusiness/submitAppToABPA.go?productEPC=FSDPDD00SS0DOHCAT51&productType=SAVINGSPRODUCT&productName=Business-Interest-Maximizer&source_id=10013SIM1910024"  name="businessSavingsCDs_businessInterestMaximizer_openNow_button_top"><span>Open Now<span class="ada-hidden">&nbsp;Business Interest Maximizer&trade;</span></span></a>
					<div class="clearboth"></div>					
					
					</th>
					<th scope="col" class="para-text">
					<h3>
							<a href="/smallbusiness/savings-accounts/business-investment-account.go" name="businessSavingsCDs_businessInvestmentAccount_link_top">
							Business Investment Account
							</a>
						
					</h3>
					
										<a class="button-common button-blue mtop-10" href="/smallbusiness/submitAppToABPA.go?productEPC=FSDPDD00BM0DOHDV1H1&productType=SAVINGSPRODUCT&productName=Business-Investment-Account&source_id=10013SSV1910025"  name="businessSavingsCDs_businessInvestmentAccount_openNow_button_top"><span>Open Now<span class="ada-hidden">&nbsp;Business Investment Account</span></span></a>
					<div class="clearboth"></div>					
					
					</th>
			</tr>			
		  </thead>  
		  
		  <tbody class="compare-products">
				
			  
				
			  
				
					<tr>
						<th scope="row">
							Good for you if 
						</th>
									<td class="para-text">
								
									You have an established business with larger balances
								
								
								
							</td>
									<td class="para-text">
								
									You have a growing business and you're looking to build savings
								
								
								
							</td>
				  </tr>
			  
				
					<tr>
						<th scope="row">
							Annual Percentage Yield 
						</th>
									<td class="para-text">
								
									<span class="rate-fee">0.02 - 0.04%</span>
								
								
								
							</td>
									<td class="para-text">
								
									<span class="rate-fee">0.02%&nbsp;</span>$100 minimum deposit
								
								
								
							</td>
				  </tr>
			  
				
					<tr>
						<th scope="row">
							Benefits 
						</th>
									<td class="para-text">
								
									Earn interest without locking into a term while maintaining fast access to your funds. No limit on daily deposits. Fees may apply.
								
								
								
							</td>
									<td class="para-text">
								
									Write up to 3 checks per statement cycle. No limit on daily deposits. Fees may apply.
								
								
								
							</td>
				  </tr>
			  
				
					<tr>
						<th scope="row">
							Monthly maintenance fee 
						</th>
									<td class="para-text">
								
									<span class="rate-fee">$15&nbsp;</span>
								
								
								
																	
													<p><a href="javascript:void(0);" class="inline-note boa-action boa-com-task-layer-link dotted close-dialogs" rel="inline-popup-1" name="popup_1">How can I have this fee waived?
													<span class="ada-hidden">for Business Interest Maximizer&trade;</span></a></p>
											
													<div id="inline-popup-1" class="hide sb-products-popup">
															<h3>How can I have this fee waived?</h3>
															<p>You can have this monthly maintenance fee waived by meeting one of the following requirements:</p>
<ul class="gray-sq-bullet">
<li>Maintain a $5,000 minimum daily balance</li>
<li>Include Business Interest Maximizer as part of a Business Advantage solution</li>
</ul>
													</div>
							</td>
									<td class="para-text">
								
									<span class="rate-fee">$5&nbsp;</span>
								
								
								
																	
													<p><a href="javascript:void(0);" class="inline-note boa-action boa-com-task-layer-link dotted close-dialogs" rel="inline-popup-2" name="popup_2">How can I have this fee waived?
													<span class="ada-hidden">for Business Investment Account</span></a></p>
											
													<div id="inline-popup-2" class="hide sb-products-popup">
															<h3>How can I have this fee waived?</h3>
															<p>You can have this monthly maintenance fee waived by meeting one of the following requirements:</p>
<ul class="gray-sq-bullet">
<li>Maintain a $2,500 minimum daily balance</li>
<li>Include your Business Investment Account as part of a Business Fundamentals<sup>&reg;</sup> solution</li>
</ul>

													</div>
							</td>
				  </tr>
			  
				
					<tr>
						<th scope="row">
							FDIC insured up to applicable limits 
						</th>
									<td class="confirmed">
								
										<span class="confirmation-marker included"><span class="print-only">X</span><span class="ada-hidden">Yes</span></span>
								
								
								
							</td>
									<td class="confirmed">
								
										<span class="confirmation-marker included"><span class="print-only">X</span><span class="ada-hidden">Yes</span></span>
								
								
								
							</td>
				  </tr>
			  
				
					<tr>
						<th scope="row">
							<a href="javascript:void(0);" class="boa-dialog boa-com-info-layer-link dotted force-visited" name="businessSavingsCDs_savingsProducts_smallBusinessOnlineBanking_modalLink" rel="glossary-popup-1">Small Business Online Banking</a> 
						</th>
									<td class="confirmed">
								
										<span class="confirmation-marker included"><span class="print-only">X</span><span class="ada-hidden">Yes</span></span>
								
								
								
							</td>
									<td class="confirmed">
								
										<span class="confirmation-marker included"><span class="print-only">X</span><span class="ada-hidden">Yes</span></span>
								
								
								
							</td>
				  </tr>
			  
				
					<tr>
						<th scope="row">
							<a href="javascript:void(0);" class="boa-dialog boa-com-info-layer-link dotted force-visited" name="businessSavingsCDs_savingsProducts_overdraftProtection_modalLink" rel="glossary-popup-2">Overdraft Protection</a> 
						</th>
									<td class="confirmed">
								
										<span class="confirmation-marker included"><span class="print-only">X</span><span class="ada-hidden">Yes</span></span>
								
								
								
							</td>
									<td class="confirmed">
								
										<span class="confirmation-marker included"><span class="print-only">X</span><span class="ada-hidden">Yes</span></span>
								
								
								
							</td>
				  </tr>
			  
				
					<tr>
						<th scope="row">
							Included in a checking solution 
						</th>
									<td class="confirmed">
								
										<span class="confirmation-marker included"><span class="print-only">X</span></span>
								
								
								
											
														<p class="inline-note">Yes, can be included with Business Advantage </p>
							</td>
									<td class="confirmed">
								
										<span class="confirmation-marker included"><span class="print-only">X</span></span>
								
								
								
											
														<p class="inline-note">Yes, can be included with Business Fundamentals<sup>&reg;</sup> </p>
							</td>
				  </tr>
			  
         <tr class="tfoot">
            <td class="blank-cell"></td>
					<th class="para-text">
						<a href="/smallbusiness/savings-accounts/business-interest-maximizer.go" name="businessSavingsCDs_businessInterestMaximizer_link_bottom">
						Business Interest Maximizer&trade;
						</a>
										<a class="button-common button-blue mtop-10" href="/smallbusiness/submitAppToABPA.go?productEPC=FSDPDD00SS0DOHCAT51&productType=SAVINGSPRODUCT&productName=Business-Interest-Maximizer&source_id=10013SIM1910024"   name="businessSavingsCDs_businessInterestMaximizer_openNow_button_bottom" ><span>Open Now<span class="ada-hidden">&nbsp;Business Interest Maximizer&trade;</span></span></a>
					<div class="clearboth"></div>
					</th>
					<th class="para-text">
						<a href="/smallbusiness/savings-accounts/business-investment-account.go" name="businessSavingsCDs_businessInvestmentAccount_link_bottom">
						Business Investment Account
						</a>
										<a class="button-common button-blue mtop-10" href="/smallbusiness/submitAppToABPA.go?productEPC=FSDPDD00BM0DOHDV1H1&productType=SAVINGSPRODUCT&productName=Business-Investment-Account&source_id=10013SSV1910025"   name="businessSavingsCDs_businessInvestmentAccount_openNow_button_bottom" ><span>Open Now<span class="ada-hidden">&nbsp;Business Investment Account</span></span></a>
					<div class="clearboth"></div>
					</th>
          </tr>
		  </tbody>
			</table>
		</div>
		
	</div>
	
				<div id="glossary-popup-1" class="hide tabs-main-content">
					<h3>Small Business Online Banking</h3>
					<p>Small Business Online Banking allows you to access information for multiple accounts, view current daily balances, get detailed transaction reports, and perform a wide range of other essential banking services.</p>
				</div>
				<div id="glossary-popup-2" class="hide tabs-main-content">
					<h3>Overdraft Protection</h3>
					<p>Overdraft Protection enables you to link a business checking account to a business savings account to cover any overdrafts that may occur in your checking account. Funds are automatically transferred from your savings account when the overdraft occurs. <br /><br />An overdraft transfer fee will be applied to most Overdraft Protection transactions.</p>
				</div>



<script type="text/javascript">
		//Code to reset the coremetrics pageid when the compare modal is closed	
		function cm_compare_close_modal(){
			cG7.cM0[cm_ClientID] = 'smbus:Prod:Dep:Savings;business-interest-maximizer';
		}		
</script> 

<div class="modal-unique-content-module hide">
  <div class="bcs-compare-skin">
    <h2 class="page-error-icon">
	</h2>
	<div class="bcs-compare-content">
    <div class="table-vzd3-common table-vzd3-com table-vzd-alt-row">
      <form name="frm-container-compare-swtich-modal" action="">
		<table border="0" cellpadding="5" width="600" cellspacing="0" summary="Compare table of Business Fundamentals and Business Advantage">
          <thead>
            <tr>
				  <td class="blank-cell">&nbsp;</td>
					<th scope="col">Business Advantage</th>
					<th scope="col">Business Fundamentals<sup>&reg;</sup></th>
            </tr>
          </thead>
          <tbody>
            <tr class="even">
				<th align="left"><strong>Checking accounts</strong></th>
					<td align="center" valign="top">2</td>
					<td align="center" valign="top">1</td>
            </tr>
			
            <tr>
				<th align="left"><strong>Savings account</strong></th>
					<td align="center" valign="top">Business Interest Maximizer<sup>&trade;</sup></td>
					<td align="center" valign="top">Business Investment Account</td>
            </tr>
            <tr class="even">
				<th align="left"><strong>Online Banking</strong></th>
					<td align="center" valign="top">x</td>
					<td align="center" valign="top">x</td>
            </tr>
            <tr>
				<th align="left"><strong>Account Management</strong></th>
					<td align="center" valign="top">x</td>
					<td align="center" valign="top"></td>
            </tr>
            <tr class="even">
				<th align="left"><strong>Business Debit card</strong></th>
					<td align="center" valign="top">x</td>
					<td align="center" valign="top">x</td>
            </tr>
            <tr>
				<th align="left"><strong>Monthly fee</strong></th>
					<td align="center" valign="top">$29.95</td>
					<td align="center" valign="top">$15</td>
			</tr>
			<tr class="even">
						<td colspan="3" align="left" scope="rowgroup"><strong>Monthly fee waived when you meet one of the following requirements:</strong></th>
			</tr>
            <tr>
				<th align="left"><strong>Minimum daily balance</strong></th>
					<td align="center" valign="top">n/a</td>
					<td align="center" valign="top">$3,000</td>
			</tr>
             <tr>
				<th align="left"><strong>Average monthly balance</strong></th>
					<td align="center" valign="top">$15,000</td>
					<td align="center" valign="top">$5,000</td>
			</tr>
             <tr>
				<th align="left"><strong>Combined average monthly balance of linked accounts</strong></th>
					<td align="center" valign="top">$35,000</td>
					<td align="center" valign="top">$15,000</td>
			</tr>
             <tr>
				<th align="left"><strong>Spend</strong></th>
					<td align="center" valign="top">$2,500 a month in new purchases on a business credit card</td>
					<td align="center" valign="top">$250 a month in new purchases on a business debit or credit card</td>
			</tr>
             <tr>
				<th align="left"><strong>Actively use one or more of the following business services</strong></th>
					<td align="center" valign="top">Bank of America Merchant Services, Intuit<sup>&reg;</sup> Payroll Services, Remote Deposit Online</td>
					<td align="center" valign="top">n/a</td>
			</tr>
			</tbody>
			<tfoot>
            <tr>
				<td class="blank-cell">&nbsp;</td>
			</tr>
			</tfoot>
        </table>
      </form>
	  </div>
	</div>
  </div>
</div>
</div>
						<div class="flex-col rt-col" >



<div id="modal-ref" class="modal-content-bdf-module hide css3-pie">
    <div class="infotext-flex-skin">
					<div class="columns column-gutter">
							<h3 class="column-heading">Enjoy more rewards and recognition with Business Platinum Privileges&trade;:</h3>
							<ul>
							<li>Priority customer service</li>
							<li>The benefits of investment and retirement solutions through Merrill Edge<sup>&reg;</sup></li>
					  </ul>
					</div>
					<div class="columns ">
							<p class="column-heading"><br />Here's what you need to qualify:</p>
							<ul class="checks">
							<li>$50,000 in combined Bank of America eligible business checking, savings and/or CD balances</li>
							<li>An open business checking account with Bank of America</li>
					  </ul>
					</div>
			<div class="clearboth"><!--  --></div>
					<a href="/smallbusiness/platinum-privileges.go" name="view_businessPlatinumPrivileges_page_link" class="end-link">View all Business Platinum Privileges benefits &raquo;
						
					</a>
        </div>
      </div>






<script type="text/javascript">

</script>










<div class="state-selector-aps-sb-module">
    <div class="modal-skin sw-inner">
		<p class="pbtm-5">Information for Virginia</p>
	  	<a id="change-state-util" class="show-state-select-modal" rel="state-select-modal" href="javascript:void(0);">Change state <span class="ada-hidden">layer</span></a>
        <div class="state-select-aps-sb-modal hide" id="state-select-modal">
         <div class="modal-content">
            <h3>Select Your State</h3>
                <p>Please tell us where you bank so we can give you accurate rate and fee information for your location.</p>
                <form method="post" action="" id="submitState">
                    <fieldset>
                        <legend>State Selection Form</legend>
                        <input type="hidden" id="requestedUrl" value="" />
                        <label for="stateList">Current State</label>
<select name="stateListName" id="stateList" class="select-box" required="true">
    <option value=" ">Select state</option>
    <option value="AL">Alabama</option>
    <option value="AK">Alaska</option>
    <option value="AZ">Arizona</option>
    <option value="AR">Arkansas</option>
    <option value="CA">California</option>
    <option value="CO">Colorado</option>
    <option value="CT">Connecticut</option>
    <option value="DE">Delaware</option>
    <option value="DC">District of Columbia</option>
    <option value="FL">Florida</option>
    <option value="GA">Georgia</option>
    <option value="HI">Hawaii</option>
    <option value="ID">Idaho</option>
    <option value="IL">Illinois</option>
    <option value="IN">Indiana</option>
    <option value="IA">Iowa</option>
    <option value="KS">Kansas</option>
    <option value="KY">Kentucky</option>
    <option value="LA">Louisiana</option>
    <option value="ME">Maine</option>
    <option value="MD">Maryland</option>
    <option value="MA">Massachusetts</option>
    <option value="MI">Michigan</option>
    <option value="MN">Minnesota</option>
    <option value="MS">Mississippi</option>
    <option value="MO">Missouri</option>
    <option value="MT">Montana</option>
    <option value="NE">Nebraska</option>
    <option value="NV">Nevada</option>
    <option value="NH">New Hampshire</option>
    <option value="NJ">New Jersey</option>
    <option value="NM">New Mexico</option>
    <option value="NY">New York</option>
    <option value="NC">North Carolina</option>
    <option value="ND">North Dakota</option>
    <option value="OH">Ohio</option>
    <option value="OK">Oklahoma</option>
    <option value="OR">Oregon</option>
    <option value="PA">Pennsylvania</option>
    <option value="RI">Rhode Island</option>
    <option value="SC">South Carolina</option>
    <option value="SD">South Dakota</option>
    <option value="TN">Tennessee</option>
    <option value="TX">Texas</option>
    <option value="UT">Utah</option>
    <option value="VT">Vermont</option>
    <option value="VA">Virginia</option>
    <option value="WA">Washington</option>
    <option value="WV">West Virginia</option>
    <option value="WI">Wisconsin</option>
    <option value="WY">Wyoming</option>


</select>

                        <div class="button-cont">
	                        <a id="state_select_submit" class="btn-bofa btn-bofa-small state-select-modal-go-button" href="javascript:void(0);" role="button">Go</a>
	                    </div>
                    </fieldset>
                </form>
		 </div>
		</div>
	</div>
</div>


</div>
						<div class="clearboth"></div>
					</div>
					<div class="footer">
						<div class="footer-top">&nbsp;

<div class="featured-benefits-bdf-module">
		<div class="vzd3-horizontal-icon-skin sup-ie "  >
			<h2 class="h2-fsd-red">Bank of America Small Business Savings & CDs</h2>
				<div class="benefit security">
				  <div class="benefit-content"><p>Balances are FDIC insured up to&nbsp;applicable limits</p></div>
				</div>
				<div class="benefit bank">
				  <div class="benefit-content"><p>Access to thousands of banking centers and ATMs coast to coast</p></div>
				</div>
				<div class="benefit web">
				  <div class="benefit-content"><p>Manage your accounts with our award-winning Online Banking service</p></div>
				</div>
			<div class="clearboth"></div>
		</div>
</div>






 


<div class="apply-banner-module">
  <div class="product-skin lt-blue-skin ">
    <div class="apply-banner  ">
							 <a href="/smallbusiness/submitAppToABPA.go?productEPC=FSDPDD00SS0DOHCAT51&productType=SAVINGSPRODUCT&productName=Business-Interest-Maximizer&source_id=10013SIM1910023" class="button-common-large button-blue-large " name="businessinterestmaximizer_opennow_button_business_interest_maximizer"><span>Open Now</span><span class="ada-hidden"> &nbsp;Business Interest Maximizer&trade;</span></a></a>
							   <div class="ab-text" >You can also <a href="https://secure.bankofamerica.com/mycommunications/public/appointments/discussionsubtopic.go?topicSelected=A2000" title="appointments" target="_self">schedule an appointment</a> </div>
	  <div class="clearboth"><!-- --></div>
    </div>
  </div>
</div>







</div>
						<div class="footer-inner">




      <div class="disclaimers-module">
         <div class="bcs-skin sup-ie">
										<div class="h-100">
											<div class="footnote" id="footnote1">
												<div class="fn-num">1.</div>
													<div class="fn-text">
														Annual Percentage Yield is accurate as of 04/14/2017. This is a variable rate account. Rates may change at any time without prior notice.
													</div>
												<div class="clearboth">&nbsp;</div>
											</div>
										</div>
										<div class="h-100">
											<div class="footnote" id="footnote2">
												<div class="fn-num">2.</div>
													<div class="fn-text">
														One Business Interest Maximizer account can be included with a Business Advantage solution for no additional monthly fee. Additional linked Business Interest Maximizer Savings accounts will incur a fee if the minimum daily balance requirement is not met.
													</div>
												<div class="clearboth">&nbsp;</div>
											</div>
										</div>
										<div class="h-100">
											<div class="footnote" id="footnote3">
												<div class="fn-num">3.</div>
													<div class="fn-text">
														Overdraft Protection Transfer fees may apply. Please refer to the Business Schedule of Fees for details.
													</div>
												<div class="clearboth">&nbsp;</div>
											</div>
										</div>
										<div class="h-100">
											<div class="footnote" id="footnote4">
												<div class="fn-num">4.</div>
													<div class="fn-text">
														States, cities, counties and other public agencies are not eligible for this type of account and should contact their banking representative to discuss alternatives.
													</div>
												<div class="clearboth">&nbsp;</div>
											</div>
										</div>
										<p>
												<strong>Important Notice</strong>: Federal regulations and the Deposit Agreement and Disclosures limit the number of the following types of withdrawals and transfers from a savings account to a total of 6 each monthly statement cycle (each month for savings accounts with a quarterly statement cycle): automatic or pre-authorized transfers, telephone transfers, Online Banking transfers or payments, or, if checks or debit cards are allowed on the account, check, draft and point-of-sale transactions. If you exceed these limits on more than an occasional basis, we convert your account to another type of account and your account may no longer earn interest.
										</p>
										<p>
												Some accounts and services, and the fees that apply to them, vary from state to state. Please review the information for your state in the <a rel="nofollow" name="businessInterestMaximizer_businessScheduleOfFees_disclaimer_link" href="/smallbusiness/resources/business-schedule-fees.go" target="_blank">Business Schedule of Fees</a> and in the Online Banking Service Agreement at <a name="businessInterestMaximizer_serviceAgreement_link" href="http://www.bankofamerica.com/serviceagreement" target="_blank">www.bankofamerica.com/serviceagreement</a>.
										</p>
										<p>
										</p>
		 </div>
      </div>




<div class="power-footer-module">

  <div class="four-col-all-links-skin sup-ie">
    <div class="breadcrumbs">
						<a class="bold-bc" href="/" name="bank_of_america_business_interest_maximizer_breadcrumbs">Bank of America</a>
						<a href="/smallbusiness" name="small_business_business_interest_maximizer_breadcrumbs" >Small Business</a>
		
					<a href="/smallbusiness/cd-savings-accounts.go" name="business_savings__cds_business_interest_maximizer_breadcrumbs">Business Savings & CDs</a>
		      	 <span>Business Interest Maximizer&trade;</span>
		    
      <div class="clearboth"></div>
    </div>
    <div class="pf-columns">
      
			<div class="pf-col" style="margin-right:50px;">
				<ul>
					<li>	
					<a href="/smallbusiness/deposits/checking-accounts/" class="bold" name="business_checking_business_interest_maximizer_power_footer" >Business Checking</a> 
					</li>
						<li> <a href="/smallbusiness/deposits/checking-accounts/business-advantage/" name="business_advantage_business_interest_maximizer_power_footer">Business Advantage</a> </li>
						<li> <a href="/smallbusiness/deposits/checking-accounts/business-fundamentals/" name="business_fundamentals_business_interest_maximizer_power_footer">Business Fundamentals<sup>&reg;</sup></a> </li>
						<li> <a href="/smallbusiness/checking-accounts/business-interest-checking.go" name="business_interest_checking_business_interest_maximizer_power_footer">Business Interest Checking</a> </li>
						<li> <a href="/smallbusiness/checking-accounts/full-analysis-business-checking.go" name="full_analysis_business_checking__business_interest_maximizer_power_footer">Full Analysis Business Checking </a> </li>
						<li> <a href="/smallbusiness/business-debit-card.go" name="business_debit_card_business_interest_maximizer_power_footer">Business Debit Card</a> </li>
				</ul>
		      </div>
			<div class="pf-col" style="margin-right:50px;">
				<ul>
					<li>	
					<a href="/smallbusiness/cd-savings-accounts.go" class="bold" name="business_savings_and_cd_business_interest_maximizer_power_footer" >Business Savings & CDs</a> 
					</li>
						<li> <a href="/smallbusiness/savings-accounts/business-interest-maximizer.go" name="business_interest_maximizer_business_interest_maximizer_power_footer">Business Interest Maximizer&trade;</a> </li>
						<li> <a href="/smallbusiness/savings-accounts/business-investment-account.go" name="business_investment_account_business_interest_maximizer_power_footer">Business Investment Account</a> </li>
						<li> <a href="/smallbusiness/cds/business-featured-cd.go" name="business_featured_cd_business_interest_maximizer_power_footer">Business Featured CD</a> </li>
						<li> <a href="/smallbusiness/cds/risk-free-cd.go" name="business_risk_free_cd_business_interest_maximizer_power_footer">Business Risk Free CD<sup>&reg;</sup></a> </li>
						<li> <a href="/smallbusiness/standard-cds.go" name="standard_business_cd_business_interest_maximizer_power_footer">Standard Business CD</a> </li>
				</ul>
		      </div>
			<div class="pf-col" style="margin-right:50px;">
				<ul>
					<li>	
					<a href="/smallbusiness/online-banking.go" class="bold" name="manage_your_account_business_interest_maximizer_power_footer" >Manage Your Account</a> 
					</li>
						<li> <a href="/smallbusiness/online-banking.go" name="online_banking_business_interest_maximizer_power_footer">Online Banking</a> </li>
						<li> <a href="/smallbusiness/online-banking/cash-management.go" name="business_tools_business_interest_maximizer_power_footer">Business Tools</a> </li>
						<li> <a href="/smallbusiness/business-debit-card.go" name="request_a_debit_card_business_interest_maximizer_power_footer">Request a Debit Card</a> </li>
				</ul>
		      </div>
			<div class="pf-col" style="">
				<ul>
					<li>	
					<a href="/smallbusiness/education.go" class="bold" name="resources_business_interest_maximizer_power_footer" >Resources</a> 
					</li>
						<li> <a href="/smallbusiness/resources/faqs.go" name="faqs_business_interest_maximizer_power_footer">FAQs</a> </li>
						<li> <a href="/smallbusiness/resources/glossary.go" name="glossary_business_interest_maximizer_power_footer">Glossary</a> </li>
						<li> <a href="/smallbusiness/resources/fees-at-a-glance.go" name="fees_at_a_glance_business_interest_maximizer_power_footer">Fees at a Glance</a> </li>
						<li> <a href="/deposits/bank-account-interest-rates/?flow=BCS" name="account_rates_business_interest_maximizer_power_footer">Account Rates</a> </li>
						<li> <a href="/smallbusiness/platinum-privileges.go" name="business_platinum_privileges_business_interest_maximizer_power_footer">Business Platinum Privileges&trade;</a> </li>
						<li> <a href="/smallbusiness/resources/overdraft-protection.go" name="overdraft_protection_business_interest_maximizer_power_footer">Overdraft Protection</a> </li>
				</ul>
		      </div>
      
      <div class="clearboth"></div>
    </div>
  </div>
</div>




 



		<div class="global-footer-module">
			<div class="fsd-skin">

				<div class="footer-bottom-left" style="float:left;max-width:66%;">
	    			<div class="gf-links">	          	
						
					
									
									<a  target="_self" href="/smallbusiness/index.jsp" 
									    name="global-footer-home">Home
									</a>
									
						
					
									
									<a  target="_self" href="/privacy/index.jsp" 
									    name="global-footer-privacy-security">Privacy & Security
									</a>
									
						
					
									
									<a  target="_self" href="http://careers.bankofamerica.com/careershome.aspx" 
									    name="footer_careers">Careers
									</a>
									
						
					
									
									<a  target="_self" href="/sitemap/sitemap/smallbusiness.go" 
									    name="global-footer-site-map">Site Map
									</a>
									
						
					
									<a href="javascript:void(0);" class="gf-last-link boa-dialog boa-com-info-layer-link" name="global_footer_ad_practices_lnk" rel="global_footer_ad_practices">Advertising Practices</a>
								<div id="global_footer_ad_practices" class="hide">
									<h3>Advertising Practices</h3>
										<p>We strive to provide you with information about products and services you might find interesting and useful. Relationship-based ads and online behavioral advertising help us do that.</p>
<p>Here's how it works: We gather information about your online activities, such as the searches you conduct on our Sites and the pages you visit. This information may be used to deliver advertising on our Sites and offline (for example, by phone, email and direct mail) that's customized to meet specific interests you may have.</p>
<p>If you prefer that we do not use this information, you may <a onclick="$('.ui-dialog').remove();" name="WebsiteAdPractices_OptOut" href="/privacy/online-privacy-notice.go#advertising-on-our-sites" target="_blank">opt out of online behavioral advertising</a>. If you opt out, though, you may still receive generic advertising. In addition, financial advisors/Client Managers may continue to use information collected online to provide product and service information in accordance with account agreements.</p>
<p>Also, if you opt out of online behavioral advertising, you may still see ads when you sign in to your account, for example through Online Banking or MyMerrill. These ads are based on your specific account relationships with us.</p>
<p>To learn more about relationship-based ads, online behavioral advertising and our privacy practices, please review the <a onclick="$('.ui-dialog').remove();" name="WebsiteAdPractices_PrivacyNotice" href="/privacy/online-privacy-notice.go" target="_blank">Bank of America Online Privacy Notice</a> and our <a onclick="$('.ui-dialog').remove();" name="Online-privacy-faqs" href="/privacy/faq/online-privacy-faq.go" target="_blank">Online Privacy FAQs</a>.</p>
								</div>
						<div class="clearboth"></div>
	    			</div>
	      			<p>Bank of America, N.A. Member FDIC. <a onclick="function onclick() { window.open('/help/equalhousing_popup.go','newwin','width=640,height=371,scrollbars=yes,resizable=yes,left=35,top=161'); return false;}" name="Equal_Housing_Lender" href="/help/equalhousing_popup.go">Equal Housing Lender<img src="/content/images/ContextualSiteGraphics/Logos/en_US/icon_equal_housing_lender.gif" alt="" width="14" height="9" /></a> <br />&copy;&nbsp;2017 Bank of America Corporation. All rights reserved.</p>
         		</div>
         		<div class="footer-social-container" style="float:right;max-width:30%;padding-left:50px;padding-top:19px;">




<div class="boa-social-loader" data-loaded="false" data-platform="borneo"  data-options=''></div>

         		</div>
         		<div class="clearboth"></div>
  			</div>
		</div>




 
<script type="text/javascript">
var axel = Math.random()+"";var a = axel * 10000000000000;document.write('<iframe title="iFrame used for layout purpose" src="https://fls.doubleclick.net/activityi;src=1359940;type=bacal484;cat=smb_b280;ord=1;num='+ a + '?" width="1" height="1" frameborder="0" style="display:none;"></iframe>');
</script>
<noscript>
	<iframe title="iFrame used for layout purpose" src="https://fls.doubleclick.net/activityi;src=1359940;type=bacal484;cat=smb_b280;ord=1?" width="0" height="0" frameborder="0" style="display:none;"></iframe>
</noscript>
<script language="javascript" src="/pa/global-assets/external/coremetrics/hp/eluminate.js"></script>
<script language="javascript" src="/pa/global-assets/external/coremetrics/hp/cmdatatagutils.js"></script>

<script language="javascript">
var testString = window.location.href;
    if (testString.toLowerCase().indexOf('.bankofamerica.com') > -1){
        testString = testString.toLowerCase();
        var tempArr = testString.split('.bankofamerica.com');var tempStr = tempArr[0];
        if (tempStr.indexOf('\/\/') > -1) {
            tempArr = tempStr.split('\/\/');tempStr = tempArr[1];
            if (tempStr.indexOf('.') > -1) {
                tempArr = tempStr.split('.');tempStr = tempArr[0];
            }
            if (tempStr.indexOf('www') > -1) {
                if (tempStr.indexOf('-') > -1) {cmSetStaging();}
                else {cmSetProduction();}
            }
            else {
                if (tempStr.indexOf('sitekey') > -1){
                    if (tempStr == 'sitekey') {cmSetProduction();}
                    else {cmSetStaging();}
                }
                else if (tempStr.indexOf('pssit') > -1){
                    if (tempStr == 'pssit') {cmSetStaging();}
                }
                if (tempStr.indexOf('-') > -1) {cmSetStaging();}
                else {cmSetProduction();}    
            }
        }
    }
  </script> 
  
		<script type="text/javascript">
		cmCreatePageviewTag('smbus:Prod:Dep:Savings;business-interest-maximizer', null, null, 'smbus:Prod:Dep:Savings', false, false, null, false, false, null, null, null, null, null, null, null, null, null, null, null, null);
		</script>
								
				
				
						<script type="text/javascript">
						  cmCreateProductviewTag('FSDPDD00SS0DOHCAT51', 'Business Interest Maximizer', 'smbus:Dep:Savings', null, false, false, null, false, null, null, false, null);
						</script>
			
			
								
		<script type="text/javascript">
			
	// CoreMetrics 
		$('document').ready(function(){
			// Compare Tab click event.
			$('.tabs-bdf-module a[name*=Compare_tabLink]').bind('click.CM', function(){ 
	
				
						
				
					 cmCreateProductviewTag('FSDPDD00SS0DOHCAT51', 'Business Interest Maximizer', 'smbus:Dep:Savings', null, false, false, null, false, null, null, false, null);       
				
					 cmCreateProductviewTag('FSDPDD00BM0DOHDV1H1', 'Business Investment Account', 'smbus:Dep:Savings', null, false, false, null, false, null, null, false, null);       
			
						
			
			
		});
		
		});
			</script>
			<div itemscope="itemscope" itemtype="http://schema.org/WebPage">
					<span style="display:none" itemprop="name">Business Interest Maximizer - Competitive Yield Savings Account</span>
					<a style="display:none" itemprop="url" href="https://www.bankofamerica.com/smallbusiness/savings-accounts/business-interest-maximizer.go"></a>
					<span style="display:none" itemprop="description">Make your money work harder with Business Interest Maximizer.  A competitive yield savings account brought to you by Bank of America.</span>
					<img style="display:none" class="no-stretch" itemprop="image" alt="Business Interest Maximizer - Competitive Yield Savings Account" src="https://www.bankofamerica.com/content/images/ContextualSiteGraphics/Logos/en_US/Bank_of_America_Flagscape_71x71.gif">
			</div>
</div>
					</div>
				</div>
			</div>
		</div>
	</body>	
</html>

