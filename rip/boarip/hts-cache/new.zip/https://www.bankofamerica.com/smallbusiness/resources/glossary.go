
 

				<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
				<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
				<head>


<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta http-equiv="content-type" content="text/html;charset=utf-8">





<title>Bank of America Financial Glossary of Banking Terms</title>

<meta name="Description" CONTENT="View a comprehensive glossary of financial terms related to checking and savings accounts on Bank of America's website.">
<meta name="Keywords" CONTENT="financial terms, financial glossary, bank of america glossary, banking terms">

		<link rel="canonical" href="https://www.bankofamerica.com/smallbusiness/resources/glossary.go"/>

<link rel="shortcut icon" href="/pa/global-assets/1.0/graphic/favicon.ico" type="image/ico" />

			<link rel="stylesheet" type="text/css" href="/pa/components/bundles/gzip-compressed/xengine/APS-small-business/2017.03.0/style/bcs-aps-sb-jawr.css" media="all" />
			<script src="/pa/components/bundles/gzip-compressed/xengine/APS-small-business/2017.03.0/script/bcs-aps-sb-jawr.js" type="text/javascript"></script>
				<script type="text/javascript">
					$(window).load(function(){asyncPrintCssInclude('https://www.bankofamerica.com/pa/components/bundles/gzip-compressed/xengine/APS-small-business/2017.03.0/style/bcs-aps-sb-jawr-print.css');});
				</script>
<script type="text/javascript">
(function() {
	if (typeof mboxUpdate == "function") {
		var windowURL = window.location.href
	    windowURL = windowURL.slice( windowURL.indexOf('.')+1);
		windowURL = windowURL.split( '?' )[0];
		windowURL = windowURL.toLowerCase();
		//alert(windowURL);
		if (
		    //If no mboxes on page, mbox count will be < 1
		    (mboxFactoryDefault.getMboxes().length() < 1) &&

			//Also check for high-volume pages that do not need global logging
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go") &&
			(windowURL != "bankofamerica.com/myaccounts/signin/signin.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/entry/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signonscreen.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatechallengeanswer.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatePassword.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/mobile/banking.go")&&
			(windowURL != "bankofamerica.com/content/preload/olb-myaccount-preload-jawr-module.htm")
			)
		{

			var mboxDiv = document.createElement("div");
			mboxDiv.id = "adobe_touch_clarity_replacement";
			mboxDiv.style.display = "none";
			if (document.body && document.body.firstChild) document.body.insertBefore(mboxDiv,document.body.firstChild);
			mboxDefine(mboxDiv.id,'bac_global_bottom');
			mboxUpdate('bac_global_bottom');
		}
	}
})();
</script>

		<script src="/pa/components/bundles/gzip-compressed/xengine/Global/1.0/script/tealeafbundle.js" type="text/javascript"></script>
			<script>
				var boaPageDataJS = {};
					boaPageDataJS.isLLE = "false";
			</script>
				<style>body{display:none;}</style>
	</head>		

	<body class="fsd-layout-body">	

				<script type="text/javascript">if(self == top){var theBody=document.getElementsByTagName("body")[0];theBody.style.display="block";}else{top.location=self.location;}</script>
				<noscript><style>body{display:block;}</style></noscript>
					<a class='ada-hidden ada-visible-focus' href='#skip-to-h1' id='ada-skip-link'>Skip to main content</a>
		<div class="fsd-layout fsd-2c-700lt-layout">
			<div class="fsd-border">
				<div class="center-content">
					<div class="header">
		  



<script language="javascript" src="/pa/components/modules/tag-manager-module/1.1/script/tag-manager-module-borneo-global-skin.js"></script>
<script>

(function() {
  var fireCallback = function( cb ) {
    if ( typeof cb === "function" ) cb();
  };
  
  function ddoPopulateBase( callback ) {
    try {
		  var DDO = window.digitalData,
		  	bactm_mergeDDO = function( newDDO, priorDDO ) {
		  		if( typeof priorDDO === "undefined" ) {
				  	priorDDO = digitalData || {};
				  }

			    for (var l in newDDO) {
			        if (typeof priorDDO[l] === "undefined") {
			            priorDDO[l] = newDDO[l];
			        }
			        if (newDDO[l] !== null) {
			            if (typeof newDDO[l] === "object") {
			                bactm_mergeDDO(newDDO[l], priorDDO[l]);
			            } else {
			                priorDDO[l] = bactm_validateValue( newDDO[l] ) ? newDDO[l] : priorDDO[l];
			            }
			        }
			    }

			    return priorDDO;
				},
				bactm_olb3rdPartyId = "null";

			if (typeof DDO === "undefined") {
				var simpleDDO = { page: { pageInfo:[{ pageID: null }], attributes: {}, category: { primaryCategory: null }}};

				DDO = (typeof digitalData === "object") ? digitalData : simpleDDO; 
			}

				DDO = bactm_mergeDDO( {"pageInstanceID":"notprod","load_coremetrics":false,"load_opinionlabs":false,"load_touchcommerce":true,"load_audiencemanager":true,"page":{"pageInfo":[{"pageID":null,"destinationURL":null,"referringURL":null,"issueDate":null,"language":null,"segmentValue":null,"appName":null,"appStepNumber":null,"appStepName":null,"attr":"-_--_--_--_--_--_--_--_--_--_--_--_--_--_-"}],"category":{"primaryCategory":null,"addlCategory":null,"pageType":null},"attributes":{"searchString":null,"searchResults":null,"olbSessionID":null,"subCampaignCode":null,"DARTUrl":null,"stateCookie":null,"SASIEnabled":false,"needOLBcookie":false,"standardDART":[],"standardDARTes":[],"clickDART":[],"clickDARTes":[],"gaId":[],"chat":{"site_id":36533229,"account_type":"smallbusiness","boa_associate":null,"boa_retiree":null,"customer_lob":"sbob","customer_segment":null,"data":null,"email_campaign":null,"entitlement_code":null,"error_category":null,"error_count":null,"first_login":null,"inqSalesProductTypes":{},"invitation_background":null,"invitation_template":null,"referral_campaign":null,"getStateValue":false,"cust_fn":null,"cust_ln":null,"target":{"lpButtonDiv-Resources":"SB-Fixed15"}}}},"user":{"segment":null,"online_id":null,"preferred_rewards_tier":null,"olb3rdpartyid":null},"version":"BAC_0.12"}, DDO );

			DDO.page.pageInfo[0].pageID = "";
			DDO.page.category.primaryCategory  = "";
			DDO.page.pageInfo[0].language = "en-US";
			DDO.page.attributes.olbSessionID = "null";
			DDO.page.attributes.SASIEnabled =  "false";
			if (typeof DDO.user != "undefined" && typeof DDO.user.olb3rdpartyid != "undefined") {
				DDO.user.olb3rdpartyid = bactm_olb3rdPartyId;
			}

			window.utag_data = {};
			window.bactm_envSelector = bactm_setTMLib();
			window.digitalData = DDO;

      return fireCallback( callback );

    } catch(e) { }
  }
	if( window.boa && window.boa.digitalData ) {
    window.boa.digitalData.register( ddoPopulateBase );
	}
	else {
	  // Handle scenario where the header isn't available (and thus the default digitalData object and utag loader are missing).
	  //
		var writeScript = function(a,b,c,d){
			a='//tags.tiqcdn.com/utag/bofa/main/' + bactm_envSelector + '/utag.js';
			b=document;
			c='script';
			d=b.createElement(c);
			d.src=a;
			d.type='text/java'+c;
			d.async=true;
			a=b.getElementsByTagName(c)[0];
			a.parentNode.insertBefore(d,a);
		};

		ddoPopulateBase( writeScript );
	}
})();			
</script>



	
	
		
			<noscript>
				<div class="fauxdal-overlay"></div>
				<div class="fauxdal-module">
					<div class="js-disabled-skin">
						<div class="fauxdal-top"></div>
						<div class="fauxdal-bottom">
							<div class="fsd-fauxdal-content">
									<div class="fsd-fauxdal-title">
										Please Use JavaScript
									</div>
										<p>You need a web browser that supports JavaScript to use our site. Without it, some pages won&rsquo;t work as designed. To make sure JavaScript is turned on, please adjust your browser settings.</p>
<p><a name="Browser_Help_And_Tips" href="/onlinebanking/online-banking-security-faqs.go" target="_blank">Browser Help and Tips</a></p>
							</div>        
							<div class="fsd-fauxdal-close"> 
								<a class="btn-bofa btn-bofa-small" name="close_button_js_disabled_modal" href=?js=y>Close</a>
							</div>
							<div class="clearboth"></div>
						</div>
					</div>
				</div>
			</noscript>



 


<div class="header-module">
	<div class="text-w-logo-skin">
		<div class="header-left">
	  
			<div itemscope itemtype="http://schema.org/Corporation" class="bofa-logo">
				<a itemprop="url" name="anc-business-advantage" title="Bank of America Small Business" href="/smallbusiness/index.jsp">
					<img itemprop="logo" height="28" width="221" 
					     alt="Bank of America Small Business" src="/content/images/ContextualSiteGraphics/Logos/en_US/boa_logo.gif"/>
				</a>
			</div>
				<div class="product" data-font="cnx-regular">Business Advantage</div>
			
			<div class="clearboth"></div>

		</div>
		
		<div class="header-right">
			<ul class="header-links">
			
				
					
				
							<li class="sign-in">
		<a					href="/sitemap/hub/signin.go" target="_self"
		name="Sign_In">Sign In</a> 
							</li>
					
				
							<li>		<a					href="/smallbusiness/index.jsp" target="_self"
		name="Home_Header">Home</a> 
</li>
					
				
							<li>		<a					href="https://locators.bankofamerica.com " target="_self"
		name="Locations">Locations</a> 
</li>
					
				
							<li>		<a					href="/contactus/contactus.go?topicId=small_business_banking" target="_self"
		name="Contact_Us">Contact Us</a> 
</li>
					
				
							<li class="last-link">	
		<a					href="/help/" target="_self"
		name="Help">Help</a> 
							</li>
			</ul>
			
			<div class="clearboth"></div>

			<!-- include search-dotcom-util -->



<div class="header-search nlh">
  
  <div class="nav-search">
    <form class="search-form" action="https://secure.bankofamerica.com/myaccounts/public/search-results/unAuthenticatedSearch.go" data-js="/pa/components/utilities/search-util/1.0/script/nav-search.min.js" data-css="/pa/components/utilities/search-util/1.0/style/nav-search.css" data-text-unavailable="Search Currently Unavailable">
      <div class="search-input-container cf" data-icon="search">
        <label for="nav-search-query" class="ada-hidden">Search Term</label>
        <input type="text" placeholder="How can we help you?" name="query" class="search-query" id="nav-search-query" 
          maxlength="99" rel="Search" autocomplete="off"><input type="submit" alt="Search" title="Search" value="Submit Search" name="Search Module - Top Result – Search Button" class="submit track-me">
      </div>
    </form>
  </div>

</div>

		</div>

 		<div class="clearboth"></div>
 	</div>
</div>







	<div class="top-nav-module">
		<div class="fsd-skin sup-ie">
			<ul class="nav-list">
					
					
					<li>
						
								<a href="/smallbusiness/deposits/checking-accounts/" class="top-menu-item"
								name="business_checking_topnav" id="business_checking_topnav">Business Checking<span class="ada-hidden"> &nbsp;link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/smallbusiness/deposits/checking-accounts/business-advantage/"  name="business_advantage_topnav" id="business_advantage_topnav">Business Advantage </a>
															<a href="/smallbusiness/deposits/checking-accounts/business-fundamentals/"  name="business_fundamentals_topnav" id="business_fundamentals_topnav">Business Fundamentals<sup>&reg;</sup> </a>
															<a href="/smallbusiness/business-debit-card.go"  name="business_debit_card_topnav" id="business_debit_card_topnav">Business Debit Card </a>
									</div>
								
									<span class="ada-hidden"> End of submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
					
					
					<li>
						
								<a href="/smallbusiness/cd-savings-accounts.go" class="top-menu-item"
								name="business_savings_and_cds_topnav" id="business_savings_and_cds_topnav">Business Savings & CDs<span class="ada-hidden"> &nbsp;link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/smallbusiness/savings-accounts/business-interest-maximizer.go"  name="business_interest_maximizer_topnav" id="business_interest_maximizer_topnav">Business Interest Maximizer&trade; </a>
															<a href="/smallbusiness/savings-accounts/business-investment-account.go"  name="business_investment_account_topnav" id="business_investment_account_topnav">Business Investment Account </a>
															<a href="/smallbusiness/cds/business-featured-cd.go"  name="business_featured_cd_topnav" id="business_featured_cd_topnav">Business Featured CD </a>
															<a href="/smallbusiness/cds/risk-free-cd.go"  name="business_risk_free_cd_topnav" id="business_risk_free_cd_topnav">Business Risk Free CD<sup>&reg;</sup> </a>
															<a href="/smallbusiness/standard-cds.go"  name="cds_topnav" id="cds_topnav">Standard Business CD </a>
									</div>
								
									<span class="ada-hidden"> End of submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
					
					
					<li>
						
								<a href="javascript:void(0);" class="top-menu-item"
								name="manage_accounts_topnav" id="manage_accounts_topnav">Manage Your Account<span class="ada-hidden"> &nbsp;link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/smallbusiness/online-banking.go"  name="online_banking_topnav" id="online_banking_topnav">Online Banking </a>
															<a href="/smallbusiness/online-banking/cash-management.go"  name="business_tools_topnav" id="business_tools_topnav">Business Tools </a>
									</div>
								
									<span class="ada-hidden"> End of submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
					
					
					<li>
						
								<a href="javascript:void(0);" class="top-menu-item selected"
								name="resources_topnav" id="resources_topnav">Resources<span class="ada-hidden"> &nbsp;link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/smallbusiness/resources/faqs.go"  name="faqs_topnav" id="faqs_topnav">FAQs </a>
															<a href="/smallbusiness/resources/glossary.go"  name="glossary_topnav" id="glossary_topnav">Glossary </a>
															<a href="/smallbusiness/resources/fees-at-a-glance.go"  name="fees_at_a_glance_topnav" id="fees_at_a_glance_topnav">Fees at a Glance </a>
															<a href="/deposits/bank-account-interest-rates/?flow=BCS"  name="account_rates_topnav" id="account_rates_topnav">Account Rates </a>
															<a href="/smallbusiness/platinum-privileges.go"  name="business_platinum_privileges_topnav" id="business_platinum_privileges_topnav">Business Platinum Privileges&trade; </a>
															<a href="/smallbusiness/resources/overdraft-protection.go"  name="overdraft_protection_topnav" id="overdraft_protection_topnav">Overdraft Protection </a>
									</div>
								
									<div class="hasSub">
														<a class="with-info" href="/smallbusiness/education.go"  name="managing_a_small_business_topnav" id="managing_a_small_business_topnav">Managing A Small Business 
															
															<span class="sub-nav-item-info">Articles, tips and tools to help you and your business grow</span>
														</a>
														<a class="with-info" href="/smallbusiness/online-banking/business-services.go"  name="popular_service_combinations_topnav" id="popular_service_combinations_topnav">Popular service combinations 
															
															<span class="sub-nav-item-info">See how business checking solutions combined with Online Banking services can help your business</span>
														</a>
									</div>
									<span class="ada-hidden"> End of submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
			</ul>
				<div class="clearboth"></div>
		</div>
	</div>


	
 
<div class="page-title-fsd-module h-100" id="skip-to-h1">
	<div class="prod-indicator-skin sup-ie">
		<div class="full-width-wrapper">
			<h1 data-font="cnx-regular">Glossary</h1>	

			

			<div class="clearboth"></div>
		</div>
  	</div>
</div>


<div class="olb-dsp-glossary-nav-module">
	<div class="nav-box" id="top-page">
			<a href="#alp-A">A</a>
			<a href="#alp-B">B</a>
			<a href="#alp-C">C</a>
			<a href="#alp-D">D</a>
			<a href="#alp-E">E</a>
			<a href="#alp-F">F</a>
			<span>G</span>
			<span>H</span>
			<a href="#alp-I">I</a>
			<span>J</span>
			<span>K</span>
			<a href="#alp-L">L</a>
			<a href="#alp-M">M</a>
			<a href="#alp-N">N</a>
			<a href="#alp-O">O</a>
			<a href="#alp-P">P</a>
			<span>Q</span>
			<a href="#alp-R">R</a>
			<a href="#alp-S">S</a>
			<a href="#alp-T">T</a>
			<a href="#alp-U">U</a>
			<a href="#alp-V">V</a>
			<a href="#alp-W">W</a>
			<span>X</span>
			<span>Y</span>
			<a href="#alp-Z">Z</a>
	<div class="clearboth"></div>
	</div>
</div>



	
<div class="live-person-bdf-module">
   <div class="bcs-skin">
    
     	<a href="javascript:window.print();" name="print">PRINT<span class="ada-hidden">  this page</span></a> 
    
	
		<div id="lpButtonDiv-Resources">
		</div>
		
	
   </div>
</div>

</div>
					<div class="columns">
						<div class="flex-col lt-col" >


<div class="olb-dsp-glossary-module">
   <div class="glossary-content">
		<div class="alp-A">
			<a name="alp-A" class="glossary-sub-section-title">A</a>
				<div class="bold" id="A_id_0">Account balance</div>
				<p>The amount of money in an account at the start of the business day, including all deposits and withdrawals posted the previous night, whether or not the funds have been collected. See &ldquo;collected balance.&rdquo;</p>
				<div class="bold" id="A_id_1">Account statement</div>
				<p>A printed or online statement of all the funds paid out by or paid into your account during a statement cycle.</p>
				<div class="bold" id="A_id_2">Active account</div>
				<p>An open bank account in which transactions can be made; usually an account that has had activity within the last 3 years.</p>
				<div class="bold" id="A_id_3">Annual percentage yield (APY)</div>
				<p>The total amount of interest paid by the bank on your deposit account (<a title="Business Checking" name="BCS_Business_Checking_glossary" href="/smallbusiness/checking-accounts.go" target="_self">checking</a>, <a title="Business CDs" name="BCS_Business_CDs_Glossary_APY" href="/smallbusiness/cd-savings-accounts.go" target="_self">savings</a>, <a title="Business CDs" name="BCS_Business_CDs_Glossary_APY_CD" href="/smallbusiness/cd-savings-accounts.go" target="_self">CDs</a>, IRAs) during the year. Includes both interest paid on the amount held in the account, as well as compounded interest for the year.</p>
				<div class="bold" id="A_id_4">Automated Clearing House (ACH)</div>
				<p>A nationwide funds transfer network that enables participating financial institutions to electronically credit, debit and settle entries to bank accounts.</p>
				<div class="bold" id="A_id_5">Automatic funds transfer</div>
				<p>An arrangement that automatically moves funds from your account to another on a date you choose; for example, every payday.</p>
				<div class="bold" id="A_id_6">Automatic payment</div>
				<p>An arrangement that automatically deducts funds from your account (usually a <a title="Business Checking" name="BCS_Business_Checking_Automatic_Pymt_Glossary" href="/smallbusiness/checking-accounts.go" target="_self">checking account</a>) on the day you choose in order to pay a recurring bill (such as car, insurance, mortgage payments, etc.)</p>
				<div class="bold" id="A_id_7">Available balance</div>
				<p>The amount of money in your account that is available for immediate use.</p>
				<div class="bold" id="A_id_8">Average daily balance</div>
				<p>The sum of all the daily account balances during an accounting period (usually a monthly statement cycle), divided by the number of days in the same period. May be used to determine whether a service charge applies or whether your account qualifies for special services or discounts. See "minimum daily balance."</p>
			<div class="back-top"> <a class="back-to-top" href="#top-page">Back to top</a> </div>
			<div class="clearboth"></div>
		</div>
		<div class="alp-B">
			<a name="alp-B" class="glossary-sub-section-title">B</a>
				<div class="bold" id="B_id_0">Banking center</div>
				<p>A Bank of America branch office. There are more than 5,700 Bank of America banking center locations.</p>
				<div class="bold" id="B_id_1">Bill Pay</div>
				<p>An optional service from Bank of America that lets you pay your bills online.</p>
				<div class="bold" id="B_id_2">Bounced check</div>
				<p>A check that is returned to the depositor because there are not sufficient funds to pay the amount of the check.</p>
			<div class="back-top"> <a class="back-to-top" href="#top-page">Back to top</a> </div>
			<div class="clearboth"></div>
		</div>
		<div class="alp-C">
			<a name="alp-C" class="glossary-sub-section-title">C</a>
				<div class="bold" id="C_id_0">Canceled check</div>
				<p>A check that has been paid. A canceled check is usually acceptable as legal proof of payment.</p>
				<div class="bold" id="C_id_1">Cashed Item Returned Fee</div>
				<p>(see Deposited Item Returned Fee)</p>
				<div class="bold" id="C_id_2">Cashier&rsquo;s check</div>
				<p>A check issued by a bank and paid from its funds. A cashier's check will not usually bounce because the amount it is written for is paid to the bank when it is issued, and the bank then assumes the obligation.</p>
				<div class="bold" id="C_id_3">Certificate of Deposit (CD)</div>
				<p>A time deposit that is payable at the end of a specified amount of time or "term." <a title="Business CDs" name="BCS_Business_CD_Glossary_CertofDep" href="/smallbusiness/cd-savings-accounts.go" target="_self">CDs</a> generally pay a fixed rate of interest and offer a higher interest rate than other types of deposit accounts. Terms can range from 7 days to 10 years. CDs are insured by the FDIC up to applicable limits. If early withdrawal from the CD prior to the end of the term is permitted, a penalty is usually assessed. See "Federal Deposit Insurance Corporation."</p>
				<div class="bold" id="C_id_4">Certified check</div>
				<p>A check for which the bank guarantees payment.</p>
				<div class="bold" id="C_id_5">Checking account</div>
				<p>A type of deposit account that enables customers to deposit funds and withdraw available funds on demand, typically by writing a check or using a debit card. These <a title="Business Checking" name="BCS_Business_Checking_Glossary_Checking_Account" href="/smallbusiness/checking-accounts.go" target="_self">accounts</a> are sometimes interest-bearing.</p>
				<div class="bold" id="C_id_6">Check card</div>
				<p>See "Debit Card."</p>
				<div class="bold" id="C_id_7">Check image</div>
				<p>A service that provides images of canceled checks. Each account statement includes images of checks (up to 10 per page) that posted to the account during the statement cycle. You can view and print copies of the front and back of checks posted within the last 12 months by signing on to Online Banking. You can also request copies of checks by visiting your nearest Bank of America banking center, or by calling the customer service number on your statement.</p>
				<div class="bold" id="C_id_8">Check safekeeping</div>
				<p>A service where the bank keeps copies or digital images of all checks written against your account for 7 years, instead of returning them with account statements. You can view photocopies of canceled checks posted within the last 12 months by signing in to Online Banking or visiting your nearest Bank of America banking center.</p>
				<div class="bold" id="C_id_9">Collected balance</div>
				<p>The balance in a deposit account, not including items that have not yet been paid or collected. See "Account balance."</p>
				<div class="bold" id="C_id_10">Combined balance</div>
				<p>The total funds in all of your linked accounts, such as savings, checking and CDs. For some checking accounts, the combined balance determines whether you may avoid the monthly fee.</p>
				<div class="bold" id="C_id_11">Compound interest</div>
				<p>Interest that is calculated on both the accumulated interest and the principal balance in the account. The more frequently interest is compounded, the higher the effective yield.</p>
				<div class="bold" id="C_id_12">Credit</div>
				<p>The increase in a deposit account balance that occurs when a deposit is made to the account. See also "debit."</p>
				<div class="bold" id="C_id_13">Credit card</div>
				<p>A plastic card issued to an individual that allows that person to use credit to purchase goods and services. A credit limit is established for each card holder.</p>
			<div class="back-top"> <a class="back-to-top" href="#top-page">Back to top</a> </div>
			<div class="clearboth"></div>
		</div>
		<div class="alp-D">
			<a name="alp-D" class="glossary-sub-section-title">D</a>
				<div class="bold" id="D_id_0">Debit</div>
				<p>A decrease in a deposit account's balance, such as occurs when a check posted to the account. See also "credit."</p>
				<div class="bold" id="D_id_1">Debit card</div>
				<p>A plastic card that deducts money directly from the designated Bank of America checking account to pay for goods or services. It can be used anywhere Visa<sup>&reg;</sup> or MasterCard<sup>&reg;</sup> debit cards are accepted and no interest is charged. A <a title="Business Debit Card" name="BCS_Business_Debit_Card_Glossary_Debit_Card" href="/smallbusiness/business-debit-card.go" target="_self">debit card</a> can also be used at ATMs to withdraw cash.</p>
				<div class="bold" id="D_id_2">Deposit</div>
				<p>Money added into a customer's bank account.</p>
				<div class="bold" id="D_id_3">Deposited Item Returned Fee or Cashed Item Returned Fee</div>
				<p>A fee we charge each time a check or other item that we either cashed for you or accepted for deposit to your account is returned to us unpaid.</p>
				<div class="bold" id="D_id_4">Direct deposit</div>
				<p>A service that automatically transfers recurring deposits into your checking, savings or money market account. Deposits can include salary, pension, Social Security and Supplemental Security Income (SSI) benefits, or other regular monthly income.</p>
				<div class="bold" id="D_id_5">Disclosure</div>
				<p>Information about an account's services, fees and regulatory requirements.</p>
			<div class="back-top"> <a class="back-to-top" href="#top-page">Back to top</a> </div>
			<div class="clearboth"></div>
		</div>
		<div class="alp-E">
			<a name="alp-E" class="glossary-sub-section-title">E</a>
				<div class="bold" id="E_id_0">Electronic funds transfer (EFT)</div>
				<p>Any transfer of funds initiated by electronic means from an electronic terminal, telephone, computer, ATM or magnetic tape.</p>
			<div class="back-top"> <a class="back-to-top" href="#top-page">Back to top</a> </div>
			<div class="clearboth"></div>
		</div>
		<div class="alp-F">
			<a name="alp-F" class="glossary-sub-section-title">F</a>
				<div class="bold" id="F_id_0">Federal Deposit Insurance Corporation (FDIC)</div>
				<p>The FDIC is an independent agency of the United States government that protects people who have funds on deposit with FDIC-insured banks and savings associations against the loss of their insured deposits if their bank or savings association fails. FDIC insurance is backed by the full faith and credit of the United States government.<br />The FDIC guarantees deposit accounts (checking, savings, money market savings and CDs) up to applicable limits, which is $250,000 per depositor, per insured bank, for each account ownership category.</p>
				<div class="bold" id="F_id_1">Float</div>
				<p>The time between the date when a check is deposited to an account and the date the funds become available.</p>
			<div class="back-top"> <a class="back-to-top" href="#top-page">Back to top</a> </div>
			<div class="clearboth"></div>
		</div>
		<div class="alp-I">
			<a name="alp-I" class="glossary-sub-section-title">I</a>
				<div class="bold" id="I_id_0">Inactive account</div>
				<p>A bank account in which there have not been any transactions for an extended period of time. In some cases, when there has been no activity in the account within a period specified by state law (generally at least 3 years), the law requires the bank to turn the account over to the state as unclaimed property.</p>
				<div class="bold" id="I_id_1">Interest-bearing account</div>
				<p>An account that earns interest.</p>
				<div class="bold" id="I_id_2">Interest rate</div>
				<p>The percentage of interest paid on an interest-bearing account, such as savings, CDs and some checking accounts; also, the percentage charged on a loan or line of credit. Different types of accounts and loans pay or charge different rates of interest. See "original interest rate."</p>
			<div class="back-top"> <a class="back-to-top" href="#top-page">Back to top</a> </div>
			<div class="clearboth"></div>
		</div>
		<div class="alp-L">
			<a name="alp-L" class="glossary-sub-section-title">L</a>
				<div class="bold" id="L_id_0">Linked account</div>
				<p>Any account linked to another account at the same financial institution so that funds can be transferred electronically between accounts. In some cases, the combined balance of all linked accounts may determine whether monthly service and other fees are applied to the account.</p>
			<div class="back-top"> <a class="back-to-top" href="#top-page">Back to top</a> </div>
			<div class="clearboth"></div>
		</div>
		<div class="alp-M">
			<a name="alp-M" class="glossary-sub-section-title">M</a>
				<div class="bold" id="M_id_0">Maturity date</div>
				<p>The date that a CD term ends, the bank stops paying the agreed-upon interest and you can choose to take the money deposited or renew the term.</p>
				<div class="bold" id="M_id_1">Minimum daily balance</div>
				<p>The lowest end-of-day balance in an account during a statement cycle; a certain minimum daily balance is often required with interest-bearing accounts to avoid a service charge or qualify for special services. See "average daily balance."</p>
				<div class="bold" id="M_id_2">Money market account</div>
				<p>A <a title="Business Savings" name="BCS_Business_Savings_MM_Glossary" href="/smallbusiness/cd-savings-accounts.go" target="_self">savings account</a> that generally earns higher rates than regular savings accounts and limits you to no more than a total of six automatic or preauthorized transfers, telephone transfers or payments (including check, draft and point of sale transactions, if checks or debit cards are allowed on the account) from a savings account each monthly statement cycle.</p>
				<div class="bold" id="M_id_3">Money order</div>
				<p>A financial instrument, issued by a bank or other institution, allowing the individual named on the order to receive a specified amount of cash on demand. Often used by people who do not have checking accounts.</p>
				<div class="bold" id="M_id_4">Monthly fee</div>
				<p>The fee charged to maintain a particular account, such as a checking account. Bank of America offers many options to help avoid the maintenance fees on <a title="Business Checking" name="BCS_Business_Checking_Monthlyfee_Glossary" href="/smallbusiness/checking-accounts.go" target="_self">checking</a> and <a title="Business Savings" name="BCS_Business_Savings_Monthly_Fee_Glossary" href="/smallbusiness/cd-savings-accounts.go" target="_self">savings</a> accounts.</p>
			<div class="back-top"> <a class="back-to-top" href="#top-page">Back to top</a> </div>
			<div class="clearboth"></div>
		</div>
		<div class="alp-N">
			<a name="alp-N" class="glossary-sub-section-title">N</a>
				<div class="bold" id="N_id_0">Non-bank ATM</div>
				<p>An ATM or cash machine that provides ATM cardholders with access to their accounts, but is owned and operated by an independent bank or financial institution. Fees generally apply to cash withdrawals at non-bank ATMs and they don't generally accept deposits.</p>
			<div class="back-top"> <a class="back-to-top" href="#top-page">Back to top</a> </div>
			<div class="clearboth"></div>
		</div>
		<div class="alp-O">
			<a name="alp-O" class="glossary-sub-section-title">O</a>
				<div class="bold" id="O_id_0">Online Banking</div>
				<p>A <a title="Business Online Banking" name="BCS_OnlineBanking_Glossary_Online_Banking" href="/smallbusiness/online-banking.go" target="_self">service</a> that allows an account holder to obtain account information and manage certain banking transactions via personal computer or mobile device.</p>
				<div class="bold" id="O_id_1">Original interest rate</div>
				<p>Rate assigned when you open a CD account. The original interest rate is listed on your CD account receipt and statement.</p>
				<div class="bold" id="O_id_2">Overdraft</div>
				<p>An overdraft occurs when a bank makes a payment that has been requested (such as a check), even though there are not enough funds available in the account to cover it. This type of payment is known as an "overdraft" and the account is said to have been "overdrawn." See also "Overdraft protection."</p>
				<div class="bold" id="O_id_3">Overdraft Item and NSF: Returned Item</div>
				<p>An Overdraft Item Fee is charged when you write a check or make a withdrawal for an amount that is more than the balance in your checking or savings account and the bank pays the overdraft item.</p>
				<div class="bold" id="O_id_4">Overdraft protection</div>
				<p><a title="Business Overdraft Protection" name="BCS_Business_Overdraft_Protection_Glossary_Overdraft_Protection" href="/smallbusiness/resources/overdraft-protection.go" target="_self">Overdraft Protection</a> links your Bank of America checking account to another Bank of America account-such as savings, credit card, second checking account, or line of credit-and automatically transfers available funds to cover purchases, prevent returned checks and declined items when you don't have enough money in your checking account. You can apply for Overdraft Protection by visiting a banking center or calling us at 1.800.432.1000 between Monday-Friday 7a.m.-10 p.m. and Saturday-Sunday 8a.m.-5 p.m. ET.</p>
				<div class="bold" id="O_id_5">Overdraft Protection Transfer Fee</div>
				<p>An Overdraft Protection Transfer fee occurs whenever funds must be provided to cover a transaction that overdraws your checking account. When a debit clears that exceeds the funds available in your account, money will be transferred from the linked Overdraft Protection account.</p>
				<div class="bold" id="O_id_6">Overdraft Settings</div>
				<p>The Overdraft Setting for your checking account determines how the bank handles your transactions when you don't have enough money in your checking account or your linked Overdraft Protection account at the time of the transaction. We pay overdrafts at our discretion based on factors such as the purchase or withdrawal amount and your account history, which means we don't guarantee that we'll always authorize and pay any type of transaction. We typically don't pay overdrafts if your account isn't in good standing or you aren't making regular deposits. We reserve the right to require you to pay overdrafts immediately.</p>
			<div class="back-top"> <a class="back-to-top" href="#top-page">Back to top</a> </div>
			<div class="clearboth"></div>
		</div>
		<div class="alp-P">
			<a name="alp-P" class="glossary-sub-section-title">P</a>
				<div class="bold" id="P_id_0">Personal identification number (PIN)</div>
				<p>The unique number you must use to access your account at an ATM or make a purchase with a debit card. Your ATM number should always be kept confidential.</p>
			<div class="back-top"> <a class="back-to-top" href="#top-page">Back to top</a> </div>
			<div class="clearboth"></div>
		</div>
		<div class="alp-R">
			<a name="alp-R" class="glossary-sub-section-title">R</a>
				<div class="bold" id="R_id_0">Rate</div>
				<p>See "interest rate."</p>
				<div class="bold" id="R_id_1">Regulation E</div>
				<p>Regulation E carries out the purposes of the Electronic Funds Transfer Act, which establishes the basic rights, liabilities and responsibilities of consumers who use electronic fund transfer services and of financial institutions that offer these services. The primary objective of the Act and Regulation E is the protection of individual consumers engaging in electronic fund transfers.</p><p>&nbsp;</p><p>Electronic fund transfer systems include automated teller machine transfers, telephone bill-payment services, point-of-sale (POS) terminal transfers in stores, and preauthorized transfers from or to a consumer's account (such as direct deposit and Social Security payments). The term "electronic funds transfer" (EFT) generally refers to a transaction initiated through an electronic terminal, telephone, computer, or magnetic tape that instructs a financial institution either to credit or to debit a consumer's account.</p>
			<div class="back-top"> <a class="back-to-top" href="#top-page">Back to top</a> </div>
			<div class="clearboth"></div>
		</div>
		<div class="alp-S">
			<a name="alp-S" class="glossary-sub-section-title">S</a>
				<div class="bold" id="S_id_0">Savings account</div>
				<p>A <a title="Business Savings" name="BCS_Business_Savings_Glossary_Savings_Account" href="/smallbusiness/cd-savings-accounts.go" target="_self">deposit account</a> which pays interest, but does not allow funds to be withdrawn by writing a check.</p>
				<div class="bold" id="S_id_1">Simple interest</div>
				<p>The interest calculated only on the principal funds that have been deposited in the account; no interest is earned on interest that has already been earned on the principal.</p>
				<div class="bold" id="S_id_2">Stop payment</div>
				<p>A request that the bank not pay a check or payment you have written or authorized. Stop-payment orders are generally placed for checks that have been lost or stolen or in situations where a purchase is disputed. A stop payment order generally expires after 6 months and a fee is usually charged for this service.</p>
			<div class="back-top"> <a class="back-to-top" href="#top-page">Back to top</a> </div>
			<div class="clearboth"></div>
		</div>
		<div class="alp-T">
			<a name="alp-T" class="glossary-sub-section-title">T</a>
				<div class="bold" id="T_id_0">Time deposit or CD</div>
				<p>An agreement to deposit a stated amount in the bank for a fixed length of time during which a fixed rate of interest will be paid. Penalties are assessed if the funds are withdrawn before the end of the agreed-upon period.</p>
				<div class="bold" id="T_id_1">Transfer</div>
				<p>The movement of funds from one account to another.</p>
				<div class="bold" id="T_id_2">Travelers cheque/travelers check</div>
				<p>Check issued by a financial institution that functions as cash, but is protected against loss or theft. Useful when traveling.</p>
			<div class="back-top"> <a class="back-to-top" href="#top-page">Back to top</a> </div>
			<div class="clearboth"></div>
		</div>
		<div class="alp-U">
			<a name="alp-U" class="glossary-sub-section-title">U</a>
				<div class="bold" id="U_id_0">Uncollected funds</div>
				<p>Refers to items deposited in an account that have not yet been collected (paid) by the bank on which they were drawn.</p>
			<div class="back-top"> <a class="back-to-top" href="#top-page">Back to top</a> </div>
			<div class="clearboth"></div>
		</div>
		<div class="alp-V">
			<a name="alp-V" class="glossary-sub-section-title">V</a>
				<div class="bold" id="V_id_0">Variable rate</div>
				<p>An interest rate that may fluctuate (adjust) during the term of a loan, line of credit, or deposit account. Rates may adjust due to changes in an index rate (such as the prime rate); in some situations, the bank may set its own rate.</p>
			<div class="back-top"> <a class="back-to-top" href="#top-page">Back to top</a> </div>
			<div class="clearboth"></div>
		</div>
		<div class="alp-W">
			<a name="alp-W" class="glossary-sub-section-title">W</a>
				<div class="bold" id="W_id_0">Wire transfer</div>
				<p>An electronic payment service for transferring funds (for example, through the Federal Reserve Wire Network or the Clearing House Interbank Payments System).</p>
			<div class="back-top"> <a class="back-to-top" href="#top-page">Back to top</a> </div>
			<div class="clearboth"></div>
		</div>
		<div class="alp-Z">
			<a name="alp-Z" class="glossary-sub-section-title">Z</a>
				<div class="bold" id="Z_id_0">Zero Liability Protection*</div>
				<p>The guarantee Bank of America makes to its credit and debit cardholders: if your card is lost or stolen, and you report the loss promptly, you may not be responsible for fraudulent purchases made with your card. There is no charge for the Zero Liability Protection program and it is automatically available on all Bank of America consumer credit cards, debit cards, and Home Equity line of credit access cards.</p><p>*&nbsp;Claims may only be filed against posted and settled transactions subject to dollar limits and subsequent verification, including providing all requested information supporting fraudulent use claim. For debit card transactions, claims must be reported within 60 days of the statement.</p>
			<div class="back-top"> <a class="back-to-top" href="#top-page">Back to top</a> </div>
			<div class="clearboth"></div>
		</div>
	</div>
</div></div>
						<div class="flex-col rt-col" ><script type="text/javascript">

</script>










<div class="state-selector-aps-sb-module">
    <div class="modal-skin sw-inner">
		<p class="pbtm-5">Information for Virginia</p>
	  	<a id="change-state-util" class="show-state-select-modal" rel="state-select-modal" href="javascript:void(0);">Change state <span class="ada-hidden">layer</span></a>
        <div class="state-select-aps-sb-modal hide" id="state-select-modal">
         <div class="modal-content">
            <h3>Select Your State</h3>
                <p>Please tell us where you bank so we can give you accurate rate and fee information for your location.</p>
                <form method="post" action="" id="submitState">
                    <fieldset>
                        <legend>State Selection Form</legend>
                        <input type="hidden" id="requestedUrl" value="" />
                        <label for="stateList">Current State</label>
<select name="stateListName" id="stateList" class="select-box" required="true">
    <option value=" ">Select state</option>
    <option value="AL">Alabama</option>
    <option value="AK">Alaska</option>
    <option value="AZ">Arizona</option>
    <option value="AR">Arkansas</option>
    <option value="CA">California</option>
    <option value="CO">Colorado</option>
    <option value="CT">Connecticut</option>
    <option value="DE">Delaware</option>
    <option value="DC">District of Columbia</option>
    <option value="FL">Florida</option>
    <option value="GA">Georgia</option>
    <option value="HI">Hawaii</option>
    <option value="ID">Idaho</option>
    <option value="IL">Illinois</option>
    <option value="IN">Indiana</option>
    <option value="IA">Iowa</option>
    <option value="KS">Kansas</option>
    <option value="KY">Kentucky</option>
    <option value="LA">Louisiana</option>
    <option value="ME">Maine</option>
    <option value="MD">Maryland</option>
    <option value="MA">Massachusetts</option>
    <option value="MI">Michigan</option>
    <option value="MN">Minnesota</option>
    <option value="MS">Mississippi</option>
    <option value="MO">Missouri</option>
    <option value="MT">Montana</option>
    <option value="NE">Nebraska</option>
    <option value="NV">Nevada</option>
    <option value="NH">New Hampshire</option>
    <option value="NJ">New Jersey</option>
    <option value="NM">New Mexico</option>
    <option value="NY">New York</option>
    <option value="NC">North Carolina</option>
    <option value="ND">North Dakota</option>
    <option value="OH">Ohio</option>
    <option value="OK">Oklahoma</option>
    <option value="OR">Oregon</option>
    <option value="PA">Pennsylvania</option>
    <option value="RI">Rhode Island</option>
    <option value="SC">South Carolina</option>
    <option value="SD">South Dakota</option>
    <option value="TN">Tennessee</option>
    <option value="TX">Texas</option>
    <option value="UT">Utah</option>
    <option value="VT">Vermont</option>
    <option value="VA">Virginia</option>
    <option value="WA">Washington</option>
    <option value="WV">West Virginia</option>
    <option value="WI">Wisconsin</option>
    <option value="WY">Wyoming</option>


</select>

                        <div class="button-cont">
	                        <a id="state_select_submit" class="btn-bofa btn-bofa-small state-select-modal-go-button" href="javascript:void(0);" role="button">Go</a>
	                    </div>
                    </fieldset>
                </form>
		 </div>
		</div>
	</div>
</div>


</div>
						<div class="clearboth"></div>
					</div>
					<div class="footer">
						<div class="footer-top">&nbsp;</div>
						<div class="footer-inner">



<div class="power-footer-module">

  <div class="four-col-all-links-skin sup-ie">
    <div class="breadcrumbs">
						<a class="bold-bc" href="/" name="bank_of_america_glossary_breadcrumbs">Bank of America</a>
						<a href="/smallbusiness" name="small_business_glossary_breadcrumbs" >Small Business</a>
		
					<a href="/smallbusiness/education.go" name="resources_glossary_breadcrumbs">Resources</a>
		      	 <span>Glossary</span>
		    
      <div class="clearboth"></div>
    </div>
    <div class="pf-columns">
      
			<div class="pf-col" style="margin-right:50px;">
				<ul>
					<li>	
					<a href="/smallbusiness/deposits/checking-accounts/" class="bold" name="business_checking_glossary_power_footer" >Business Checking</a> 
					</li>
						<li> <a href="/smallbusiness/deposits/checking-accounts/business-advantage/" name="business_advantage_glossary_power_footer">Business Advantage</a> </li>
						<li> <a href="/smallbusiness/deposits/checking-accounts/business-fundamentals/" name="business_fundamentals_glossary_power_footer">Business Fundamentals<sup>&reg;</sup></a> </li>
						<li> <a href="/smallbusiness/checking-accounts/business-interest-checking.go" name="business_interest_checking_glossary_power_footer">Business Interest Checking</a> </li>
						<li> <a href="/smallbusiness/checking-accounts/full-analysis-business-checking.go" name="full_analysis_business_checking__glossary_power_footer">Full Analysis Business Checking </a> </li>
						<li> <a href="/smallbusiness/business-debit-card.go" name="business_debit_card_glossary_power_footer">Business Debit Card</a> </li>
				</ul>
		      </div>
			<div class="pf-col" style="margin-right:50px;">
				<ul>
					<li>	
					<a href="/smallbusiness/cd-savings-accounts.go" class="bold" name="business_savings_and_cd_glossary_power_footer" >Business Savings & CDs</a> 
					</li>
						<li> <a href="/smallbusiness/savings-accounts/business-interest-maximizer.go" name="business_interest_maximizer_glossary_power_footer">Business Interest Maximizer&trade;</a> </li>
						<li> <a href="/smallbusiness/savings-accounts/business-investment-account.go" name="business_investment_account_glossary_power_footer">Business Investment Account</a> </li>
						<li> <a href="/smallbusiness/cds/business-featured-cd.go" name="business_featured_cd_glossary_power_footer">Business Featured CD</a> </li>
						<li> <a href="/smallbusiness/cds/risk-free-cd.go" name="business_risk_free_cd_glossary_power_footer">Business Risk Free CD<sup>&reg;</sup></a> </li>
						<li> <a href="/smallbusiness/standard-cds.go" name="standard_business_cd_glossary_power_footer">Standard Business CD</a> </li>
				</ul>
		      </div>
			<div class="pf-col" style="margin-right:50px;">
				<ul>
					<li>	
					<a href="/smallbusiness/online-banking.go" class="bold" name="manage_your_account_glossary_power_footer" >Manage Your Account</a> 
					</li>
						<li> <a href="/smallbusiness/online-banking.go" name="online_banking_glossary_power_footer">Online Banking</a> </li>
						<li> <a href="/smallbusiness/online-banking/cash-management.go" name="business_tools_glossary_power_footer">Business Tools</a> </li>
						<li> <a href="/smallbusiness/business-debit-card.go" name="request_a_debit_card_glossary_power_footer">Request a Debit Card</a> </li>
				</ul>
		      </div>
			<div class="pf-col" style="">
				<ul>
					<li>	
					<a href="/smallbusiness/education.go" class="bold" name="resources_glossary_power_footer" >Resources</a> 
					</li>
						<li> <a href="/smallbusiness/resources/faqs.go" name="faqs_glossary_power_footer">FAQs</a> </li>
						<li> <a href="/smallbusiness/resources/glossary.go" name="glossary_glossary_power_footer">Glossary</a> </li>
						<li> <a href="/smallbusiness/resources/fees-at-a-glance.go" name="fees_at_a_glance_glossary_power_footer">Fees at a Glance</a> </li>
						<li> <a href="/deposits/bank-account-interest-rates/?flow=BCS" name="account_rates_glossary_power_footer">Account Rates</a> </li>
						<li> <a href="/smallbusiness/platinum-privileges.go" name="business_platinum_privileges_glossary_power_footer">Business Platinum Privileges&trade;</a> </li>
						<li> <a href="/smallbusiness/resources/overdraft-protection.go" name="overdraft_protection_glossary_power_footer">Overdraft Protection</a> </li>
				</ul>
		      </div>
      
      <div class="clearboth"></div>
    </div>
  </div>
</div>




 



		<div class="global-footer-module">
			<div class="fsd-skin">

				<div class="footer-bottom-left" style="float:left;max-width:66%;">
	    			<div class="gf-links">	          	
						
					
									
									<a  target="_self" href="/smallbusiness/index.jsp" 
									    name="global-footer-home">Home
									</a>
									
						
					
									
									<a  target="_self" href="/privacy/index.jsp" 
									    name="global-footer-privacy-security">Privacy & Security
									</a>
									
						
					
									
									<a  target="_self" href="http://careers.bankofamerica.com/careershome.aspx" 
									    name="footer_careers">Careers
									</a>
									
						
					
									
									<a  target="_self" href="/sitemap/sitemap/smallbusiness.go" 
									    name="global-footer-site-map">Site Map
									</a>
									
						
					
									<a href="javascript:void(0);" class="gf-last-link boa-dialog boa-com-info-layer-link" name="global_footer_ad_practices_lnk" rel="global_footer_ad_practices">Advertising Practices</a>
								<div id="global_footer_ad_practices" class="hide">
									<h3>Advertising Practices</h3>
										<p>We strive to provide you with information about products and services you might find interesting and useful. Relationship-based ads and online behavioral advertising help us do that.</p>
<p>Here's how it works: We gather information about your online activities, such as the searches you conduct on our Sites and the pages you visit. This information may be used to deliver advertising on our Sites and offline (for example, by phone, email and direct mail) that's customized to meet specific interests you may have.</p>
<p>If you prefer that we do not use this information, you may <a onclick="$('.ui-dialog').remove();" name="WebsiteAdPractices_OptOut" href="/privacy/online-privacy-notice.go#advertising-on-our-sites" target="_blank">opt out of online behavioral advertising</a>. If you opt out, though, you may still receive generic advertising. In addition, financial advisors/Client Managers may continue to use information collected online to provide product and service information in accordance with account agreements.</p>
<p>Also, if you opt out of online behavioral advertising, you may still see ads when you sign in to your account, for example through Online Banking or MyMerrill. These ads are based on your specific account relationships with us.</p>
<p>To learn more about relationship-based ads, online behavioral advertising and our privacy practices, please review the <a onclick="$('.ui-dialog').remove();" name="WebsiteAdPractices_PrivacyNotice" href="/privacy/online-privacy-notice.go" target="_blank">Bank of America Online Privacy Notice</a> and our <a onclick="$('.ui-dialog').remove();" name="Online-privacy-faqs" href="/privacy/faq/online-privacy-faq.go" target="_blank">Online Privacy FAQs</a>.</p>
								</div>
						<div class="clearboth"></div>
	    			</div>
	      			<p>Bank of America, N.A. Member FDIC. <a onclick="function onclick() { window.open('/help/equalhousing_popup.go','newwin','width=640,height=371,scrollbars=yes,resizable=yes,left=35,top=161'); return false;}" name="Equal_Housing_Lender" href="/help/equalhousing_popup.go">Equal Housing Lender<img src="/content/images/ContextualSiteGraphics/Logos/en_US/icon_equal_housing_lender.gif" alt="" width="14" height="9" /></a> <br />&copy;&nbsp;2017 Bank of America Corporation. All rights reserved.</p>
         		</div>
         		<div class="footer-social-container" style="float:right;max-width:30%;padding-left:50px;padding-top:19px;">




<div class="boa-social-loader" data-loaded="false" data-platform="borneo"  data-options=''></div>

         		</div>
         		<div class="clearboth"></div>
  			</div>
		</div>




 
<script type="text/javascript">
var axel = Math.random()+"";var a = axel * 10000000000000;document.write('<iframe title="iFrame used for layout purpose" src="https://fls.doubleclick.net/activityi;src=1359940;type=bacal484;cat=smb_b177;ord=1;num='+ a + '?" width="1" height="1" frameborder="0" style="display:none;"></iframe>');
</script>
<noscript>
	<iframe title="iFrame used for layout purpose" src="https://fls.doubleclick.net/activityi;src=1359940;type=bacal484;cat=smb_b177;ord=1?" width="0" height="0" frameborder="0" style="display:none;"></iframe>
</noscript>
<script language="javascript" src="/pa/global-assets/external/coremetrics/hp/eluminate.js"></script>
<script language="javascript" src="/pa/global-assets/external/coremetrics/hp/cmdatatagutils.js"></script>

<script language="javascript">
var testString = window.location.href;
    if (testString.toLowerCase().indexOf('.bankofamerica.com') > -1){
        testString = testString.toLowerCase();
        var tempArr = testString.split('.bankofamerica.com');var tempStr = tempArr[0];
        if (tempStr.indexOf('\/\/') > -1) {
            tempArr = tempStr.split('\/\/');tempStr = tempArr[1];
            if (tempStr.indexOf('.') > -1) {
                tempArr = tempStr.split('.');tempStr = tempArr[0];
            }
            if (tempStr.indexOf('www') > -1) {
                if (tempStr.indexOf('-') > -1) {cmSetStaging();}
                else {cmSetProduction();}
            }
            else {
                if (tempStr.indexOf('sitekey') > -1){
                    if (tempStr == 'sitekey') {cmSetProduction();}
                    else {cmSetStaging();}
                }
                else if (tempStr.indexOf('pssit') > -1){
                    if (tempStr == 'pssit') {cmSetStaging();}
                }
                if (tempStr.indexOf('-') > -1) {cmSetStaging();}
                else {cmSetProduction();}    
            }
        }
    }
  </script> 
  
		<script type="text/javascript">
		cmCreatePageviewTag('smbus:Content:Dep:Resources;glossary', null, null, 'smbus:Content:Resources', false, false, null, false, false, null, null, null, null, null, null, null, null, null, null, null, null);
		</script>
								
				
				
				
					
			
			
								
		<script type="text/javascript">
			
	// CoreMetrics 
		$('document').ready(function(){
			// Compare Tab click event.
			$('.tabs-bdf-module a[name*=Compare_tabLink]').bind('click.CM', function(){ 
	
				
						
			
		});
		
		});
			</script>
</div>
					</div>
				</div>
			</div>
		</div>
	</body>	
</html>

