
 

				<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
				<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
				<head>


<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta http-equiv="content-type" content="text/html;charset=utf-8">





<title>Cash Management Services by Bank of America Small Business</title>

<meta name="Description" CONTENT="Choose from several Bank of America cash management services including: Payroll Services by Intuit<sup>&reg;</sup>, Account Management, Express Invoicing<sup>&reg;</sup>, and Remote Deposit.">
<meta name="Keywords" CONTENT="cash management tools, business cash management, cash management services, cash management">

					<meta name="twitter:title" CONTENT="Cash Management Services by Bank of America Small Business" />
					<meta name="twitter:card" CONTENT="summary" />
					<meta name="twitter:url" CONTENT="https://www.bankofamerica.com/smallbusiness/online-banking/cash-management.go" />
					<meta name="twitter:image" CONTENT="https://www.bankofamerica.com/content/images/ContextualSiteGraphics/Logos/en_US/Bank_of_America_Flagscape_71x71.gif" />
					<meta name="twitter:description" CONTENT="Choose from several Bank of America cash management services including: Payroll Services by Intuit&reg;, Account Management, Express Invoicing&reg;, and Remote Deposit." />
					<meta name="twitter:site" CONTENT="@BofA_Tips" />
		   			<meta property="og:title" CONTENT="Cash Management Services by Bank of America Small Business" />
		   			<meta property="og:type" CONTENT="website" />
		   			<meta property="og:url" CONTENT="https://www.bankofamerica.com/smallbusiness/online-banking/cash-management.go" />
		   			<meta property="og:image" CONTENT="https://www.bankofamerica.com/content/images/ContextualSiteGraphics/Logos/en_US/Bank_of_America_Flagscape_71x71.gif" />
		   			<meta property="og:description" CONTENT="Choose from several Bank of America cash management services including: Payroll Services by Intuit&reg;, Account Management, Express Invoicing&reg;, and Remote Deposit." />
		   			<meta property="og:site_name" CONTENT="Bank of America" />
		<link rel="canonical" href="https://www.bankofamerica.com/smallbusiness/online-banking/cash-management.go"/>

<link rel="shortcut icon" href="/pa/global-assets/1.0/graphic/favicon.ico" type="image/ico" />

			<link rel="stylesheet" type="text/css" href="/pa/components/bundles/gzip-compressed/xengine/APS-small-business/2017.03.0/style/olbs-aps-sb-jawr.css" media="all" />
			<script src="/pa/components/bundles/gzip-compressed/xengine/APS-small-business/2017.03.0/script/olbs-aps-sb-jawr.js" type="text/javascript"></script>
				<script type="text/javascript">
					$(window).load(function(){asyncPrintCssInclude('https://www.bankofamerica.com/pa/components/bundles/gzip-compressed/xengine/APS-small-business/2017.03.0/style/olbs-aps-sb-jawr-print.css');});
				</script>
<script type="text/javascript">
(function() {
	if (typeof mboxUpdate == "function") {
		var windowURL = window.location.href
	    windowURL = windowURL.slice( windowURL.indexOf('.')+1);
		windowURL = windowURL.split( '?' )[0];
		windowURL = windowURL.toLowerCase();
		//alert(windowURL);
		if (
		    //If no mboxes on page, mbox count will be < 1
		    (mboxFactoryDefault.getMboxes().length() < 1) &&

			//Also check for high-volume pages that do not need global logging
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go") &&
			(windowURL != "bankofamerica.com/myaccounts/signin/signin.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/entry/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signonscreen.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatechallengeanswer.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatePassword.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/mobile/banking.go")&&
			(windowURL != "bankofamerica.com/content/preload/olb-myaccount-preload-jawr-module.htm")
			)
		{

			var mboxDiv = document.createElement("div");
			mboxDiv.id = "adobe_touch_clarity_replacement";
			mboxDiv.style.display = "none";
			if (document.body && document.body.firstChild) document.body.insertBefore(mboxDiv,document.body.firstChild);
			mboxDefine(mboxDiv.id,'bac_global_bottom');
			mboxUpdate('bac_global_bottom');
		}
	}
})();
</script>

		<script src="/pa/components/bundles/gzip-compressed/xengine/Global/1.0/script/tealeafbundle.js" type="text/javascript"></script>
			<script>
				var boaPageDataJS = {};
					boaPageDataJS.isLLE = "false";
			</script>
				<style>body{display:none;}</style>
	</head>		

	<body class="fsd-layout-body">	

				<script type="text/javascript">if(self == top){var theBody=document.getElementsByTagName("body")[0];theBody.style.display="block";}else{top.location=self.location;}</script>
				<noscript><style>body{display:block;}</style></noscript>
					<a class='ada-hidden ada-visible-focus' href='#skip-to-h1' id='ada-skip-link'>Skip to main content</a>
		<div class="fsd-layout fsd-2c-700lt-layout">
			<div class="fsd-border">
				<div class="center-content">
					<div class="header">
		  



<script language="javascript" src="/pa/components/modules/tag-manager-module/1.1/script/tag-manager-module-borneo-global-skin.js"></script>
<script>

(function() {
  var fireCallback = function( cb ) {
    if ( typeof cb === "function" ) cb();
  };
  
  function ddoPopulateBase( callback ) {
    try {
		  var DDO = window.digitalData,
		  	bactm_mergeDDO = function( newDDO, priorDDO ) {
		  		if( typeof priorDDO === "undefined" ) {
				  	priorDDO = digitalData || {};
				  }

			    for (var l in newDDO) {
			        if (typeof priorDDO[l] === "undefined") {
			            priorDDO[l] = newDDO[l];
			        }
			        if (newDDO[l] !== null) {
			            if (typeof newDDO[l] === "object") {
			                bactm_mergeDDO(newDDO[l], priorDDO[l]);
			            } else {
			                priorDDO[l] = bactm_validateValue( newDDO[l] ) ? newDDO[l] : priorDDO[l];
			            }
			        }
			    }

			    return priorDDO;
				},
				bactm_olb3rdPartyId = "null";

			if (typeof DDO === "undefined") {
				var simpleDDO = { page: { pageInfo:[{ pageID: null }], attributes: {}, category: { primaryCategory: null }}};

				DDO = (typeof digitalData === "object") ? digitalData : simpleDDO; 
			}

				DDO = bactm_mergeDDO( {   "pageInstanceID": "notprod",   "load_coremetrics": false,   "load_opinionlabs": false,   "load_touchcommerce": true,   "load_audiencemanager": true,   "page": {     "pageInfo": [       {         "pageID": null,         "destinationURL": null,         "referringURL": null,         "issueDate": null,         "language": null,         "segmentValue": null,         "appName": null,         "appStepNumber": null,         "appStepName": null,         "attr": "-_--_--_--_--_--_--_--_--_--_--_--_--_--_-"       }     ],     "category": {       "primaryCategory": null,       "addlCategory": null,       "pageType": null     },     "attributes": {       "searchString": null,       "searchResults": null,       "olbSessionID": null,       "subCampaignCode": null,       "DARTUrl": null,       "stateCookie": null,       "SASIEnabled": false,       "needOLBcookie": false,       "standardDART": [],       "standardDARTes": [],       "clickDART": [],       "clickDARTes": [],       "gaId": [],       "chat": {         "site_id": 36533172,         "target": {           "lpButtonDivChat": "SB-Fixed14"         },         "account_type": "Online Banking",         "customer_lob": "sbob"       }     }   },   "user": {     "segment": null,     "online_id": null,     "preferred_rewards_tier": null,     "olb3rdpartyid": null   },   "version": "BAC_0.12" }, DDO );

			DDO.page.pageInfo[0].pageID = "smbus:Content:OLBs:Cash_Management;cash-management";
			DDO.page.category.primaryCategory  = "smbus:Content:OLBs:Cash_Management";
			DDO.page.pageInfo[0].language = "en-US";
			DDO.page.attributes.olbSessionID = "null";
			DDO.page.attributes.SASIEnabled =  "false";
			if (typeof DDO.user != "undefined" && typeof DDO.user.olb3rdpartyid != "undefined") {
				DDO.user.olb3rdpartyid = bactm_olb3rdPartyId;
			}

			window.utag_data = {};
			window.bactm_envSelector = bactm_setTMLib();
			window.digitalData = DDO;

      return fireCallback( callback );

    } catch(e) { }
  }
	if( window.boa && window.boa.digitalData ) {
    window.boa.digitalData.register( ddoPopulateBase );
	}
	else {
	  // Handle scenario where the header isn't available (and thus the default digitalData object and utag loader are missing).
	  //
		var writeScript = function(a,b,c,d){
			a='//tags.tiqcdn.com/utag/bofa/main/' + bactm_envSelector + '/utag.js';
			b=document;
			c='script';
			d=b.createElement(c);
			d.src=a;
			d.type='text/java'+c;
			d.async=true;
			a=b.getElementsByTagName(c)[0];
			a.parentNode.insertBefore(d,a);
		};

		ddoPopulateBase( writeScript );
	}
})();			
</script>



	
	
		
			<noscript>
				<div class="fauxdal-overlay"></div>
				<div class="fauxdal-module">
					<div class="js-disabled-skin">
						<div class="fauxdal-top"></div>
						<div class="fauxdal-bottom">
							<div class="fsd-fauxdal-content">
									<div class="fsd-fauxdal-title">
										Please Use JavaScript
									</div>
										<p>You need a web browser that supports JavaScript to use our site. Without it, some pages won&rsquo;t work as designed. To make sure JavaScript is turned on, please adjust your browser settings.</p>
<p><a name="Browser_Help_And_Tips" href="/onlinebanking/online-banking-security-faqs.go" target="_blank">Browser Help and Tips</a></p>
							</div>        
							<div class="fsd-fauxdal-close"> 
								<a class="btn-bofa btn-bofa-small" name="close_button_js_disabled_modal" href=?js=y>Close</a>
							</div>
							<div class="clearboth"></div>
						</div>
					</div>
				</div>
			</noscript>



 


<div class="header-module">
	<div class="text-w-logo-skin">
		<div class="header-left">
	  
			<div itemscope itemtype="http://schema.org/Corporation" class="bofa-logo">
				<a itemprop="url" name="anc-business-advantage" title="Bank of America logo" href="/smallbusiness/">
					<img itemprop="logo" height="28" width="221" 
					     alt="Bank of America logo" src="/content/images/ContextualSiteGraphics/Logos/en_US/boa_logo.gif"/>
				</a>
			</div>
				<div class="product" data-font="cnx-regular">Business Advantage</div>
			
			<div class="clearboth"></div>

		</div>
		
		<div class="header-right">
			<ul class="header-links">
			
				
					
				
							<li class="sign-in">
		<a					href="/sitemap/hub/signin.go" target="_self"
		name="Sign_In">Sign In</a> 
							</li>
					
				
							<li>		<a					href="/smallbusiness/" target="_self"
		name="Home_Header">Home</a> 
</li>
					
				
							<li>		<a					href="https://locators.bankofamerica.com" target="_self"
		name="Locations">Locations</a> 
</li>
					
				
							<li>		<a					href="/contactus/contactus.go?topicId=small_business_banking " target="_self"
		name="Contact_Us">Contact Us</a> 
</li>
					
				
							<li class="last-link">	
		<a					href="/smallbusiness/business-financing/learning/faqs-applying-for-financing.go" target="_self"
		name="Help">Help</a> 
							</li>
			</ul>
			
			<div class="clearboth"></div>

			<!-- include search-dotcom-util -->



<div class="header-search nlh">
  
  <div class="nav-search">
    <form class="search-form" action="https://secure.bankofamerica.com/myaccounts/public/search-results/unAuthenticatedSearch.go" data-js="/pa/components/utilities/search-util/1.0/script/nav-search.min.js" data-css="/pa/components/utilities/search-util/1.0/style/nav-search.css" data-text-unavailable="Search Currently Unavailable">
      <div class="search-input-container cf" data-icon="search">
        <label for="nav-search-query" class="ada-hidden">Search Term</label>
        <input type="text" placeholder="How can we help you?" name="query" class="search-query" id="nav-search-query" 
          maxlength="99" rel="Search" autocomplete="off"><input type="submit" alt="Search" title="Search" value="Submit Search" name="Search Module - Top Result – Search Button" class="submit track-me">
      </div>
    </form>
  </div>

</div>

		</div>

 		<div class="clearboth"></div>
 	</div>
</div>







	<div class="top-nav-module">
		<div class="fsd-skin sup-ie">
			<ul class="nav-list">
					
					
					<li>
						
								<a href="/smallbusiness/online-banking.go" class="top-menu-item"
								name="online_banking_topnav" id="online_banking_topnav">Online Banking<span class="ada-hidden"> &nbsp;link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/smallbusiness/online-banking.go"  name="business_online_banking_topnav" id="business_online_banking_topnav">Business Online Banking </a>
															<a href="/smallbusiness/online-banking/account-management.go"  name="account_permissions_topnav" id="account_permissions_topnav">Account Permissions </a>
															<a href="/smallbusiness/online-banking/quickbooks.go"  name="quicken_or_quickbooks_topnav" id="quicken_or_quickbooks_topnav">QuickBooks<sup>&reg;</sup> </a>
									</div>
								
									<div class="hasSub">
														<a class="with-info" href="/smallbusiness/online-banking/features.go"  name="business_empower_topnav" id="business_empower_topnav">Empower Your Business 
															
															<span class="sub-nav-item-info">See a full list of Online Banking and optional add-on services</span>
														</a>
									</div>
									<span class="ada-hidden"> End of Submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
					
					
					<li>
						
								<a href="/smallbusiness/online-banking/cash-management.go" class="top-menu-item selected"
								name="cash_management_topnav" id="cash_management_topnav">Cash Management<span class="ada-hidden"> &nbsp;link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/smallbusiness/online-banking/cash-management.go"  name="cash_management_overview_topnav" id="cash_management_overview_topnav">Cash Management Tools </a>
															<a href="/smallbusiness/online-banking/cash-management/remote-deposit.go"  name="remote_deposit_topnav" id="remote_deposit_topnav">Remote Deposit </a>
															<a href="http://promo.bankofamerica.com/olbs/olbs_directpayment.html"  name="invoicing_and_payments_topnav" id="invoicing_and_payments_topnav">Invoicing and payments </a>
															<a href="/smallbusiness/online-banking/cash-management/tax-services.go"  name="tax_services_topnav" id="tax_services_topnav">Tax Services </a>
															<a href="/smallbusiness/online-banking/cash-management/merchant-services.go"  name="merchant_services_topnav" id="merchant_services_topnav">Merchant Services 
																
															</a>
									</div>
								
									<div class="hasSub">
									</div>
									<span class="ada-hidden"> End of Submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
					
					
					<li>
						
								<a href="/smallbusiness/online-banking/payroll.go" class="top-menu-item"
								name="payroll_topnav" id="payroll_topnav">Payroll<span class="ada-hidden"> &nbsp;link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/smallbusiness/online-banking/payroll.go"  name="online_payroll_overview_topnav" id="online_payroll_overview_topnav">Payroll overview </a>
															<a href="/smallbusiness/online-banking/payroll/adp.go"  name="adpreg_payroll_topnav" id="adpreg_payroll_topnav">ADP<sup>&reg;</sup> Payroll </a>
															<a href="/smallbusiness/online-banking/payroll/intuit.go"  name="intuitreg_payroll_topnav" id="intuitreg_payroll_topnav">Intuit<sup>&reg;</sup> Payroll </a>
									</div>
								
									<div class="hasSub">
									</div>
									<span class="ada-hidden"> End of Submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
					
					
					<li>
						
								<a href="/smallbusiness/online-banking/mobile.go" class="top-menu-item"
								name="mobile_banking_topnav" id="mobile_banking_topnav">Mobile Banking<span class="ada-hidden"> &nbsp;link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href=" /smallbusiness/online-banking/mobile.go"  name="mobile_banking_overview_topnav" id="mobile_banking_overview_topnav">Mobile Banking Overview   </a>
															<a href="/smallbusiness/online-banking/mobile/features.go"  name="mobile_banking_features_topnav" id="mobile_banking_features_topnav">Mobile Banking Features </a>
															<a href="/smallbusiness/online-banking/mobile/app/overview.go"  name="mobile_banking_basics_topnav" id="mobile_banking_basics_topnav">Understanding the basics </a>
									</div>
								
									<div class="hasSub">
														<a class="with-info" href="http://merch.bankofamerica.com/web/pages/CloverGo-overview"  name="mobile_pay_topnav" id="mobile_pay_topnav">Mobile Pay 
															<img class="externalLinkArrow" src="/content/images/ContextualSiteGraphics/Instructional/en_US/arrow-external-link.gif" alt="" />
															<span class="sub-nav-item-info">Bank of America Merchant Services mobile payment solutions provide fast, secure payment processing using your smartphone</span>
														</a>
									</div>
									<span class="ada-hidden"> End of Submenu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
			</ul>
				<div class="clearboth"></div>
		</div>
	</div>


	
 
<div class="page-title-fsd-module h-100" id="skip-to-h1">
	<div class="prod-indicator-skin sup-ie">
		<div class="full-width-wrapper">
			<h1 data-font="cnx-regular">Cash Management Tools for Your Small Business</h1>	

			

			<div class="clearboth"></div>
		</div>
  	</div>
</div>


<div class="print-module-browser-dialog-skin" style=""> 
	<a href="javascript:window.print();" name="print">PRINT<span class="ada-hidden"> this page</span></a>
</div></div>
					<div class="columns">
						<div class="flex-col lt-col" >
<div class="featured-content-module">
   <div class="multi-feature-skin sup-ie">
   <p class="mbtm-30">Focus on what matters most&mdash;your business. With all the great cash and transaction management services available, you can run your business more effectively and efficiently. Take a moment to explore the options below to see which combination of services can improve your business.</p>
     <div class="content-box">
	     <h2>Payroll Services</h2>
	      <img src="/content/images/ContextualSiteGraphics/Instructional/en_US/SB/Payroll-Services-icons-169x148.png" height="148" width="169" alt="" /> 
	      <div class="inner-content">             
             <p class="plt-20">Handle your payroll needs with simplicity and accuracy.</p>
			 <!-- Note for FTL : in case an achor tag has to be used somewhere in between the text then use div tag instead of p tag -->
             <!--<div class="plt-20">Handle all your payroll needs with simplicity and accuracy <a href="javascript:void(0);"> link</a> </div> -->
			 <ul class="gray-sq-bullet">
<li><a href="/smallbusiness/online-banking/payroll/adp.go" target="_self">ADP<sup>&reg;</sup></a> provides personalized attention and recommendations for the right tools, products and services for your business</li>
<li class="gray-sq-bullet"><a href="/smallbusiness/online-banking/payroll/intuit.go" name="intuit-online-payroll" target="_self">Intuit<sup>&reg;</sup></a> Payroll Services provides fast paydays and detailed reporting, with tools you need to keep your finances secure</li>
</ul>
<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <a href="/smallbusiness/online-banking/payroll.go" target="_self">Learn more about payroll services</a></p>		 
		  </div> 
		   <a class="learn-more" href="" name="learn-about-payroll-services">   </a>
		  <div class="clearboth"></div>			  
      </div>
     <div class="content-box">
	     <h2>Remote Deposit Online</h2>
	      <img src="/content/images/ContextualSiteGraphics/Instructional/en_US/SB/RDO-icons-169x148.png" height="148" width="169" alt="" /> 
	      <div class="inner-content">             
             <p class="plt-20">Spend less time depositing checks and more time running your business.</p>
			 <!-- Note for FTL : in case an achor tag has to be used somewhere in between the text then use div tag instead of p tag -->
             <!--<div class="plt-20">Handle all your payroll needs with simplicity and accuracy <a href="javascript:void(0);"> link</a> </div> -->
			 <ul>
<li>Get the flexibility to manage your business on your schedule</li>
<li>Make unlimited deposits from your home or office for a low monthly fee</li>
</ul>
<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <a onclick="MyWindow=window.open('https://promo.bankofamerica.com/sb/remote-deposit/','MyWindow','toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,resizable=no,width=800,height=600'); return false;" href="#">Watch a product demo</a></p>
<p>&nbsp;</p>
<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <a href="/smallbusiness/online-banking/cash-management/remote-deposit.go" target="_self">Learn more about Remote Deposit Online <span class="raquo-link">&rsaquo;&rsaquo;</span></a></p>		 
		  </div> 
		   <a class="learn-more" href="" name="learn-about-remote-deposit-online">  </a>
		  <div class="clearboth"></div>			  
      </div>
     <div class="content-box">
	     <h2>Account Management</h2>
	      <img src="/content/images/ContextualSiteGraphics/Instructional/en_US/SB/Account-Management-icons-169x148.png" height="148" width="169" alt="" /> 
	      <div class="inner-content">             
             <p class="plt-20">Get greater account control&mdash;plus seamless QuickBooks<sup>&reg;</sup> integration.</p>
			 <!-- Note for FTL : in case an achor tag has to be used somewhere in between the text then use div tag instead of p tag -->
             <!--<div class="plt-20">Handle all your payroll needs with simplicity and accuracy <a href="javascript:void(0);"> link</a> </div> -->
			 <ul>
<li>Grant customized access to multiple users</li>
<li>Manage accounts for multiple businesses with one Online ID</li>
</ul>
<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <a href="#" onclick="MyWindow=window.open('https://promo.bankofamerica.com/sb/account-management/','MyWindow','toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,resizable=no,width=800,height=600'); return false;">Watch a product demo</a></p>
<p>&nbsp;</p>
<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <a href="/smallbusiness/online-banking/account-management.go" target="_self">Learn more about Account Management <span class="raquo-link">&rsaquo;&rsaquo;</span></a></p>		 
		  </div> 
		   <a class="learn-more" href="" name="learn-about-account-management">  </a>
		  <div class="clearboth"></div>			  
      </div>
     <div class="content-box">
	     <h2>Invoicing and Payments by Viewpost<sup>&reg;</sup></h2>
	      <img src="/content/images/ContextualSiteGraphics/Instructional/en_US/SB/Direct-Payments-icons-169x148.png" height="148" width="169" alt="" /> 
	      <div class="inner-content">             
             <p class="plt-20">Save time managing your cash flow with paperless invoices and payments</p>
			 <!-- Note for FTL : in case an achor tag has to be used somewhere in between the text then use div tag instead of p tag -->
             <!--<div class="plt-20">Handle all your payroll needs with simplicity and accuracy <a href="javascript:void(0);"> link</a> </div> -->
			 <ul>
<li>Reduce the cost, risk and inefficiency of paper checks</li>
<li>Track invoices for better visibility</li>
</ul>
<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <a href="http://promo.bankofamerica.com/olbs/olbs_directpayment.html" target="_self">Learn more about Invoicing and Payments by Viewpost<sup>&reg;</sup> <span class="raquo-link">&rsaquo;&rsaquo;</span></a></p>		 
		  </div> 
		   <a class="learn-more" href="" name="learn-about-payments-invoicing">  </a>
		  <div class="clearboth"></div>			  
      </div>
     <div class="content-box">
	     <h2>Bank of America Merchant Services</h2>
	      <img src="/content/images/ContextualSiteGraphics/Instructional/en_US/SmallBusiness/Bank of America Merchant Services Image.png" height="148" width="169" alt="" /> 
	      <div class="inner-content">             
             <p class="plt-20"></p>
			 <!-- Note for FTL : in case an achor tag has to be used somewhere in between the text then use div tag instead of p tag -->
             <!--<div class="plt-20">Handle all your payroll needs with simplicity and accuracy <a href="javascript:void(0);"> link</a> </div> -->
			 <p>Enjoy fast and easy electronic payments from one of the top merchant services processors<a href="#footnote1" name="fnote1"><span class="ada-hidden">Footnote</span><sup>1</sup></a></p>
<ul>
<li>Take all payment types&mdash;credit cards, debit cards, electronic checks and gift cards</li>
<li>Process credit or debit card payments through your mobile phone or tablet</li>
</ul>
<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <a href="https://www.bankofamerica.com/smallbusiness/online-banking/cash-management/merchant-services.go" target="_self">Learn more about Merchant Services <span class="raquo-link">&rsaquo;&rsaquo;</span></a></p>		 
		  </div> 
		   <a class="learn-more" href="" name="learn-about-merchant-services">  </a>
		  <div class="clearboth"></div>			  
      </div>
     <div class="content-box">
	     <h2>Express Tax Services</h2>
	      <img src="/content/images/ContextualSiteGraphics/Instructional/en_US/SB/Express-Tax-icons-169x148.png" height="148" width="169" alt="" /> 
	      <div class="inner-content">             
             <p class="plt-20">Pay your taxes on time safely and easily with Express Tax Service.</p>
			 <!-- Note for FTL : in case an achor tag has to be used somewhere in between the text then use div tag instead of p tag -->
             <!--<div class="plt-20">Handle all your payroll needs with simplicity and accuracy <a href="javascript:void(0);"> link</a> </div> -->
			 <ul>
<li>Make single or multiple payments anytime online or over the phone</li>
<li>No software to load or maintain and no enrollment or setup fee</li>
</ul>
<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <a href="/smallbusiness/online-banking/cash-management/tax-services.go" target="_self">Learn more about Tax Services <span class="raquo-link">&rsaquo;&rsaquo;</span></a></p>		 
		  </div> 
		   <a class="learn-more" href="" name="learn-about-tax-services">  </a>
		  <div class="clearboth"></div>			  
      </div>
     <div class="content-box">
	     <h2>Treasury Services for larger businesses</h2>
	      <img src="/content/images/ContextualSiteGraphics/Instructional/en_US/cash_management_add_feat_treasury_man.png" height="148" width="169" alt="" /> 
	      <div class="inner-content">             
             <p class="plt-20">As your volumes and balances grow and your financial needs get more sophisticated, our treasury solutions can provide increased control over your working capital through payment, receipt, liquidity, fraud and account solutions.</p>
			 <!-- Note for FTL : in case an achor tag has to be used somewhere in between the text then use div tag instead of p tag -->
             <!--<div class="plt-20">Handle all your payroll needs with simplicity and accuracy <a href="javascript:void(0);"> link</a> </div> -->
			 <ul>
<li>For businesses with $1MM+ annual revenue, 25 to 2,000 employees, heightened audit and control requirements, international banking needs </li>
<li>Provides for multiple operating account solutions, a full suite of treasury and liquidity management services all powered by CashPro Online<sup>&reg;</sup></li>
</ul>
<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <a href="/smallbusiness/checking-accounts/full-analysis-business-checking/related-products.go" target="_self">Learn more about treasury services <span class="raquo-link">&rsaquo;&rsaquo;</span></a></p>		 
		  </div> 
		   <a class="learn-more" href="" name="Learn_more_about_treasury_services">  </a>
		  <div class="clearboth"></div>			  
      </div>
    </div>  
</div>

	<div class="footnote-module">
   		<div class="sasi-overlay-skin sup-ie">
							<div class="footnote">
									<div class="fn-num"><a id="footnote1" name="sasi-footnote1"><span class="ada-hidden">Footnote: </span>1</a>
									</div>
									<div class="fn-text">Based on bankcard, other credit, and PIN debit sales volume and transactions. Per the Nilson Report, March 2015, Issue 1059.</div>
									<div class="clearboth"></div>
							</div>
		</div>
	</div>
</div>
						<div class="flex-col rt-col" >


	
		

		

			
		
		

<div class="accordion-contact-module target-sidewell-ac location-bottom white-skin">


    <div class="cta focus-call "> 
      <div class="intro">
        <div class="title-h3"><span>Help me choose</span></div>
      </div>
      
      <div class="highlight call">
      <div class="details ">
      				<p class="small">
          					Speak with a small business services specialist:
      				</p>
      				
							<p class="large">
								<b>866.543.2808</b>
							</p>
					
							<p>Mon.&ndash;Fri. 8 a.m.&ndash;10 p.m. ET</p>
								<br/>
					
      				<p class="small">
          					<a href="/smallbusiness/checking-accounts.go" name="Open a small business checking account">Open a small business checking account</a>
      				</p>
      				
							<p class="small">
								<b></b>
							</p>
					
							
					
      				<p class="small">
          					
      				</p>
      				
							<p class="small">
								<b></b>
							</p>
					
					
      </div>
      </div>     
   

      		<ul class="options">
        	<li class="hide"></li>
						
													<li class="chat first">
														<div class="title-h4">
															<a href="javascript:void(0);" name="chat-small-business-speacialist">
																<span class="ada-hidden ada-closed">Show information for </span> <span class="ada-hidden ada-open">Hide information for </span>Chat
															</a>
															<div class="arrow">
															<div class="color"></div>
															<div class="clear"></div>
            												</div>

														</div>
														<div class="details">
																  <div id="lpButtonDivChat">
																  </div>
														</div>
													</li>
        
						
													<li class="clicktocall after">
														<div  class="title-h4">
															<a href="javascript:void(0);" name="callnow-small-business-specialist"> 
																<span class="ada-hidden ada-closed">Show information for </span> <span class="ada-hidden ada-open" style="display:none;">Hide information for </span>Call me now 
															</a>
															 <div class="arrow">
															    <div class="color"></div>
															     <div class="clear"></div>
            														 </div>
														</div>
														<div class="details">
																<div id="lpButtonDivVoice">										
																</div>
														</div>
													</li>
   			</ul>
   	</div>
   		
</div>
<div class="side-well-module"> </div>


<!-- FTL :Module code starts here . All anchor names should begin with prefix 'anc' -->
<div class="side-well-module">  
   <div class="generic-content-skin">
      <div class="sm-top-cap"></div>
      <div class="sm-body">	  
         <h3 class="sm-title-bar">
			Small Business 401(k)
		 </h3>
         <div class="sm-main">
		
					
									<p>Offer your employees a simplified, low-cost 401(k) plan through Merrill Edge.</p>
<p><a href="http://www.merrilledge.com/small-business/401k? name=" learn_more_about_sb401k="" id="learn_more_about_SB401K" src_cd="bac_sb_payroll_services&quot;" title="Merrill Edge SB 401k">Learn more <span class="ada-hidden">&nbsp;about Small Business 401 (k) plans </span></a></p>							
         </div>
      </div>
      <div class="sm-btm-cap"></div>
   </div>   
</div>
</div>
						<div class="clearboth"></div>
					</div>
					<div class="footer">
						<div class="footer-top">&nbsp;</div>
						<div class="footer-inner">
<div class="disclaimers-module">
	<div class="fsd-skin sup-ie">
			<p>Intuit<sup>&reg;</sup> Online Payroll is a product of Intuit Inc. You must go to the Intuit website to enroll in and use the product. Bank of America is not responsible for the product or the performance of Intuit Inc. Intuit and the Intuit logo are registered trademarks of Intuit Inc., used under license. Bank of America does not deliver the services assoicated with ADP products. Internet access may be required. Internet service provider fees may apply. Other bank fees may apply. See <a href="/smallbusiness/resources/business-schedule-fees.go" name="business_schedule_fees" title="business_schedule_fees" target="_blank">Business Schedule of Fees</a> for details.</p>
<p>ADP, the ADP logo, and RUN Powered by ADP are registered trademarks of ADP, LLC, and ADP A more human resource is a service mark of ADP, LLC.</p>
<p>24/7/365 service is offered for RUN Powered by ADP</p>
<p>QuickBooks<sup>&reg;</sup>, Intuit and the Intuit Logo are registered trademarks of Intuit Inc., used under license.</p>
<p>Merrill Edge is the marketing name for two businesses: Merrill Edge Advisory Center, which offers team-based advice and guidance brokerage services; and a self-directed online investing platform. Both are made available through Merrill Lynch, Pierce, Fenner &amp; Smith Incorporated (MLPF&amp;S).</p>
<p>Viewpost&reg; is a registered trademark of Viewpost IP&nbsp;Holdings, LLC. All Rights Reserved. Eligibility&nbsp;requirements, other conditions, and fees may apply.&nbsp;Contact Viewpost for complete details regarding&nbsp;Viewpost products terms and fees.</p>
<p>Investment products:</p>
<table border="0" summary="Investment Products Disclaimer">
<tbody>
<tr>
<td scope="col">Are Not FDIC Insured</td>
<td scope="col">Are Not Bank Guaranteed</td>
<td scope="col">May Lose Value</td>
</tr>
</tbody>
</table>
<p class="last-txt">MLPF&amp;S is a registered broker-dealer, Member <a href="http://www.bankofamerica.com/weblinking/?referredby=sipc" name="Securities Investor Protection Corp" title="Securities Investor Protection Corp">Securities Investor Protection Corporation (SIPC)</a> and a wholly owned subsidiary of Bank of America Corporation.</p>
<p class="last-txt">Investing in securities involves risks, and there is always the potential of losing money when you invest in securities.</p>
<p class="last-txt">Banking products are provided by Bank of America, N.A. and affilliated banks.&nbsp; Members FDIC and wholly-owned subsidiaries of Bank of America Corporation.</p>
<p class="last-txt"></p>
	</div>
</div>





<div class="power-footer-module">

  <div class="four-col-all-links-skin sup-ie">
    <div class="breadcrumbs">
						<a class="bold-bc" href="/" name="bank_of_america_cash_management_breadcrumbs">Bank of America</a>
						<a href="/smallbusiness/" name="small_business_online_banking_and_services_cash_management_breadcrumbs" >Small Business</a>
		
					<a href="/smallbusiness/online-banking/cash-management.go" name="cash_management_cash_management_breadcrumbs">Cash Management</a>
		      	 <span>Cash Management Tools for Your Small Business</span>
		    
      <div class="clearboth"></div>
    </div>
    <div class="pf-columns">
      
			<div class="pf-col" style="margin-right:50px;">
				<ul>
					<li>	
					<a href="/smallbusiness/online-banking.go" class="bold" name="business_online_banking_cash_management_power_footer" >Business Online Banking</a> 
					</li>
						<li> <a href="/smallbusiness/online-banking/account-management.go" name="account_permissions_cash_management_power_footer">Account Permissions</a> </li>
						<li> <a href="/smallbusiness/online-banking/quickbooks.go" name="quickbooks_cash_management_power_footer">QuickBooks<sup>&reg;</sup></a> </li>
				</ul>
		      </div>
			<div class="pf-col" style="margin-right:50px;">
				<ul>
					<li>	
					<a href="/smallbusiness/online-banking/cash-management.go" class="bold" name="cash_management_cash_management_power_footer" >Cash Management</a> 
					</li>
						<li> <a href="/smallbusiness/online-banking/cash-management/remote-deposit.go" name="remote_deposit_cash_management_power_footer">Remote Deposit</a> </li>
						<li> <a href="http://promo.bankofamerica.com/olbs/olbs_directpayment.html" name="invoicing_and_payments_cash_management_power_footer">Invoicing and payments</a> </li>
						<li> <a href="/smallbusiness/online-banking/cash-management/tax-services.go" name="tax_services_cash_management_power_footer">Tax Services</a> </li>
						<li> <a href="/smallbusiness/online-banking/cash-management/merchant-services.go" name="merchant_services_cash_management_power_footer">Merchant Services</a> </li>
				</ul>
		      </div>
			<div class="pf-col" style="margin-right:50px;">
				<ul>
					<li>	
					<a href="/smallbusiness/online-banking/payroll.go" class="bold" name="payroll_cash_management_power_footer" >Payroll</a> 
					</li>
						<li> <a href="/smallbusiness/online-banking/payroll.go" name="payroll_overview_cash_management_power_footer">Payroll overview</a> </li>
						<li> <a href="/smallbusiness/online-banking/payroll/adp.go" name="adp_payroll_cash_management_power_footer">ADP Payroll&reg;</a> </li>
						<li> <a href="/smallbusiness/online-banking/payroll/intuit.go" name="intuit_payroll_cash_management_power_footer">Intuit Payroll&reg;</a> </li>
				</ul>
		      </div>
			<div class="pf-col" style="margin-right:50px;">
				<ul>
					<li>	
					<a href="/smallbusiness/online-banking/mobile.go" class="bold" name="mobile_banking_cash_management_power_footer" >Mobile Banking</a> 
					</li>
						<li> <a href="/smallbusiness/online-banking/mobile/features.go" name="mobile_banking_features_cash_management_power_footer">Mobile Banking Features</a> </li>
						<li> <a href="/smallbusiness/online-banking/mobile/app/overview.go" name="understanding__the_basics_cash_management_power_footer">Understanding the basics</a> </li>
				</ul>
		      </div>
      
      <div class="clearboth"></div>
    </div>
  </div>
</div>




 



		<div class="global-footer-module">
			<div class="fsd-skin">

				<div class="footer-bottom-left" style="float:left;max-width:66%;">
	    			<div class="gf-links">	          	
						
					
									
									<a  target="_self" href="/smallbusiness/index.jsp" 
									    name="global-footer-home">Home
									</a>
									
						
					
									
									<a  target="_self" href="/privacy/index.jsp" 
									    name="global-footer-privacy-security">Privacy & Security
									</a>
									
						
					
									
									<a  target="_self" href="http://www.bankofamerica.com/careers/" 
									    name="global-footer-careers">Careers
									</a>
									
						
					
									
									<a  target="_self" href="/sitemap/sitemap/smallbusiness.go" 
									    name="global-footer-site-map">Site Map
									</a>
									
						
					
									<a href="javascript:void(0);" class="gf-last-link boa-dialog boa-com-info-layer-link" name="global_footer_ad_practices_lnk" rel="global_footer_ad_practices">Advertising Practices</a>
								<div id="global_footer_ad_practices" class="hide">
									<h3>Advertising Practices</h3>
										<p>We strive to provide you with information about products and services you might find interesting and useful. Relationship-based ads and online behavioral advertising help us do that.</p>
<p>Here's how it works: We gather information about your online activities, such as the searches you conduct on our Sites and the pages you visit. This information may be used to deliver advertising on our Sites and offline (for example, by phone, email and direct mail) that's customized to meet specific interests you may have.</p>
<p>If you prefer that we do not use this information, you may <a onclick="$('.ui-dialog').remove();" name="WebsiteAdPractices_OptOut" href="/privacy/online-privacy-notice.go#advertising-on-our-sites" target="_blank">opt out of online behavioral advertising</a>. If you opt out, though, you may still receive generic advertising. In addition, financial advisors/Client Managers may continue to use information collected online to provide product and service information in accordance with account agreements.</p>
<p>Also, if you opt out of online behavioral advertising, you may still see ads when you sign in to your account, for example through Online Banking or MyMerrill. These ads are based on your specific account relationships with us.</p>
<p>To learn more about relationship-based ads, online behavioral advertising and our privacy practices, please review the <a onclick="$('.ui-dialog').remove();" name="WebsiteAdPractices_PrivacyNotice" href="/privacy/online-privacy-notice.go" target="_blank">Bank of America Online Privacy Notice</a> and our <a onclick="$('.ui-dialog').remove();" name="Online-privacy-faqs" href="/privacy/faq/online-privacy-faq.go" target="_blank">Online Privacy FAQs</a>.</p>
								</div>
						<div class="clearboth"></div>
	    			</div>
	      			<p>Bank of America, N.A. Member FDIC. <a onclick="function onclick() { window.open('/help/equalhousing_popup.go','newwin','width=640,height=371,scrollbars=yes,resizable=yes,left=35,top=161'); return false; }" name="Equal_Housing_Lender" href="/help/equalhousing_popup.go">Equal Housing Lender<img src="/content/images/ContextualSiteGraphics/Logos/en_US/icon_equal_housing_lender.gif" alt="" width="14" height="9" /></a> <br />&copy;&nbsp;2017 Bank of America Corporation. All rights reserved.</p>
         		</div>
         		<div class="footer-social-container" style="float:right;max-width:30%;padding-left:50px;padding-top:19px;">




<div class="boa-social-loader" data-loaded="false" data-platform="borneo"  data-options=''></div>

         		</div>
         		<div class="clearboth"></div>
  			</div>
		</div>




 
<script type="text/javascript" src="/pa/global-assets/external/coremetrics/hp/eluminate.js"></script>
<script type="text/javascript" src="/pa/global-assets/external/coremetrics/hp/cmdatatagutils.js"></script>

<script type="text/javascript">
/*Minified version CM Data Direction Code - updated 8-21-2013 */
function cmSetDD(){var testString=window.location.href;if(testString.toLowerCase().indexOf(".bankofamerica.com")>-1){testString=testString.toLowerCase();var tempArr=testString.split(".bankofamerica.com");var tempStr=tempArr[0];if(tempStr.indexOf("//")>-1){tempArr=tempStr.split("//");tempStr=tempArr[1];if(tempStr.indexOf(".")>-1){tempArr=tempStr.split(".");tempStr=tempArr[0];var tempStrPt2=tempArr[1]}if(tempStr.indexOf("www")>-1){if(tempStr.indexOf("-")>-1){cmSetStaging()}else{if(tempStrPt2!=null){if(tempStrPt2.indexOf("ecnp")>-1){cmSetStaging()}}else{cmSetProduction()}}}else{if(tempStr.indexOf("-")>-1){if(tempStr.indexOf("sitekey")>-1){if(tempStr=="sitekey"){cmSetProduction()}else{cmSetStaging()}}else{cmSetStaging()}}else{if(tempStrPt2!=null){if(tempStrPt2.indexOf("ecnp")>-1){cmSetStaging()}}else{cmSetProduction()}}}}}}if(typeof cmSetStaging=="function"){cmSetDD()};
</script>




    <script type="text/javascript">
        var href = window.location.href;
        $('html')
        .on('error', function(e, err) {
            cmCreateCustomError('smbus:Content:OLBs:Cash_Management;cash-management', null, null, null, err.code, 'smbus:Content:OLBs:Cash_Management', err.message);
        })
        .on('click', '[data-cm]', function() {
            cmCreateManualLinkClickTag(href, $(this).data('cm').click, cG7.cM0[cm_ClientID]);
        });
    </script>
			<script type="text/javascript">
				cmCreatePageviewTag('smbus:Content:OLBs:Cash_Management;cash-management', null, null, 'smbus:Content:OLBs:Cash_Management', false, false, null, false, false, null, null, null, null, null, null, null, null, null, null, null, null);
			</script>
			<div itemscope="itemscope" itemtype="http://schema.org/WebPage">
					<span style="display:none" itemprop="name">Cash Management Services by Bank of America Small Business</span>
					<a style="display:none" itemprop="url" href="https://www.bankofamerica.com/smallbusiness/online-banking/cash-management.go"></a>
					<span style="display:none" itemprop="description">Choose from several Bank of America cash management services including: Payroll Services by Intuit�, Account Management, Express Invoicing�, and Remote Deposit.</span>
					<img style="display:none" class="no-stretch" itemprop="image" alt="Cash Management Services by Bank of America Small Business" src="https://www.bankofamerica.com/content/images/ContextualSiteGraphics/Logos/en_US/Bank_of_America_Flagscape_71x71.gif">
			</div>
</div>
					</div>
				</div>
			</div>
		</div>
	</body>	
</html>

