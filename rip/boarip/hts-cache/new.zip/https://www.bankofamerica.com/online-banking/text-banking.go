
 

				<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
				<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
				<head>


<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<title>Text Banking from Bank of America</title>

                   <meta name="Keywords" CONTENT="text banking, text message banking" />
                   <meta name="Description" CONTENT="Text message banking on your handheld device gives you information about your Bank of America accounts within seconds. Start using text banking today." />
                   <meta name="twitter:title" CONTENT="Text Banking from Bank of America" />
                   <meta name="twitter:card" CONTENT="summary" />
                   <meta name="twitter:url" CONTENT="https://www.bankofamerica.com/online-banking/text-banking.go" />
                   <meta name="twitter:image" CONTENT="https://www.bankofamerica.com/content/images/ContextualSiteGraphics/Logos/en_US/Bank_of_America_Flagscape_71x71.gif" />
                   <meta name="twitter:description" CONTENT="Text message banking on your handheld device gives you information about your Bank of America accounts within seconds. Start using text banking today." />
                   <meta name="twitter:site" CONTENT="@BofA_Tips" />
                   <meta Property="og:title" CONTENT="Text Banking from Bank of America" />
                   <meta Property="og:type" CONTENT="website" />
                   <meta Property="og:url" CONTENT="https://www.bankofamerica.com/online-banking/text-banking.go" />
                   <meta Property="og:image" CONTENT="https://www.bankofamerica.com/content/images/ContextualSiteGraphics/Logos/en_US/Bank_of_America_Flagscape_71x71.gif" />
                   <meta Property="og:description" CONTENT="Text message banking on your handheld device gives you information about your Bank of America accounts within seconds. Start using text banking today." />
                   <meta Property="og:site_name" CONTENT="Bank of America" />
        <link REL="canonical" HREF="https://www.bankofamerica.com/online-banking/text-banking.go"/>                  
        
<link rel="shortcut icon" href="https://www2.bac-assets.com/pa/global-assets/1.0/graphic/favicon.ico" type="image/ico" />

			<link rel="stylesheet" type="text/css" media="all" href="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/APS-mobile-products/2017.03.0/style/aps-mp-jawr.css"/>	
			<script type="text/javascript" src="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/APS-mobile-products/2017.03.0/script/aps-mp-jawr.js"></script>
		
			<script type="text/javascript"> 
				$(window).load(function(){asyncPrintCssInclude('https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/APS-mobile-products/2017.03.0/style/aps-mp-jawr-print.css');});
			</script>	
<script type="text/javascript">
(function() {
	if (typeof mboxUpdate == "function") {
		var windowURL = window.location.href
	    windowURL = windowURL.slice( windowURL.indexOf('.')+1);
		windowURL = windowURL.split( '?' )[0];
		windowURL = windowURL.toLowerCase();
		//alert(windowURL);
		if (
		    //If no mboxes on page, mbox count will be < 1
		    (mboxFactoryDefault.getMboxes().length() < 1) &&  
			
			//Also check for high-volume pages that do not need global logging
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go") &&
			(windowURL != "bankofamerica.com/myaccounts/signin/signin.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/entry/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signonscreen.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatechallengeanswer.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatePassword.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/mobile/banking.go")&&
			(windowURL != "bankofamerica.com/content/preload/olb-myaccount-preload-jawr-module.htm")
			)
		{

			var mboxDiv = document.createElement("div");
			mboxDiv.id = "adobe_touch_clarity_replacement";
			mboxDiv.style.display = "none";
			if (document.body && document.body.firstChild) document.body.insertBefore(mboxDiv,document.body.firstChild);
			mboxDefine(mboxDiv.id,'bac_global_bottom');
			mboxUpdate('bac_global_bottom');
		}
	}	
})();
</script>

		<script src="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/Global/1.0/script/tealeafbundle.js" type="text/javascript"></script>
			<script>
				var boaPageDataJS = {};
					boaPageDataJS.isLLE = "false";
			</script>
				<style>body{display:none;}</style>
	</head>		

	<body class="fsd-layout-body">	

				<script type="text/javascript">if(self == top){var theBody=document.getElementsByTagName("body")[0];theBody.style.display="block";}else{top.location=self.location;}</script>
				<noscript><style>body{display:block;}</style></noscript>
					<a class='ada-hidden ada-visible-focus' href='#skip-to-h1' id='ada-skip-link'>Skip to main content</a>
		<div class="fsd-layout fsd-2c-700lt-layout fsd-full-width">
			<div class="fsd-border">
				<div class="center-content">
					<div class="header">


	
	
		
			<noscript>
				<div class="fauxdal-overlay"></div>
				<div class="fauxdal-module">
					<div class="js-disabled-skin">
						<div class="fauxdal-top"></div>
						<div class="fauxdal-bottom">
							<div class="fsd-fauxdal-content">
									<div class="fsd-fauxdal-title">
										Please use JavaScript
									</div>
										<p>You need a web browser that supports JavaScript to use our site. Without it, some pages won&rsquo;t work as designed. To make sure JavaScript is turned on, please adjust your browser settings.</p>
<p><a name="Browser_Help_And_Tips" href="/onlinebanking/online-banking-security-faqs.go" target="_blank">Browser Help and Tips</a></p>
							</div>        
							<div class="fsd-fauxdal-close"> 
								<a class="btn-bofa btn-bofa-small" name="close_button_js_disabled_modal" href=?js=y>Close</a>
							</div>
							<div class="clearboth"></div>
						</div>
					</div>
				</div>
			</noscript>



 


<div class="header-module">
	<div class="text-w-logo-skin">
		<div class="header-left">
	  
			<div itemscope itemtype="http://schema.org/Corporation" class="bofa-logo">
				<a itemprop="url" name="anc-mobile-banking" title="Bank of America" href="/">
					<img itemprop="logo" height="28" width="221" 
					     alt="Bank of America" src="https://www2.bac-assets.com/content/images/ContextualSiteGraphics/Logos/en_US/new-bac-logo.gif"/>
				</a>
			</div>
				<div class="product" data-font="cnx-regular">Mobile Banking</div>
			
			<div class="clearboth"></div>

		</div>
		
		<div class="header-right">
			<ul class="header-links">
			
				
					
				
							<li class="sign-in">
		<a					href="/sitemap/hub/signin.go" target="_self"
		name="anc-signin">Sign in</a> 
							</li>
					
				
							<li>		<a					href="/" target="_self"
		name="anc-home">Home</a> 
</li>
					
				
							<li>		<a					href="https://locators.bankofamerica.com" target="_self"
		name="anc-location">Locations</a> 
</li>
					
				
							<li>		<a					href="/contactus/contactus.go" target="_self"
		name="anc-contact-us">Contact us</a> 
</li>
					
				
							<li>		<a					href="/help/overview.go" target="_self"
		name="anc-help">Help</a> 
</li>
					
				
							<li class="last-link">	
									<a href="/online-banking/text-banking.go?request_locale=es_US" name="en_espanol" target="_self">En espa&#241;ol</a> 				
							</li>
			</ul>
			
			<div class="clearboth"></div>

			<!-- include search-dotcom-util -->



<div class="header-search nlh">
  
  <div class="nav-search">
    <form class="search-form" action="https://secure.bankofamerica.com/myaccounts/public/search-results/unAuthenticatedSearch.go" data-js="/pa/components/utilities/search-util/1.0/script/nav-search.min.js" data-css="/pa/components/utilities/search-util/1.0/style/nav-search.css" data-text-unavailable="Search Currently Unavailable">
      <div class="search-input-container cf" data-icon="search">
        <label for="nav-search-query" class="ada-hidden">Search Term</label>
        <input type="text" placeholder="How can we help you?" name="query" class="search-query" id="nav-search-query" 
          maxlength="99" rel="Search" autocomplete="off"><input type="submit" alt="Search" title="Search" value="Submit Search" name="Search Module - Top Result – Search Button" class="submit track-me">
      </div>
    </form>
  </div>

</div>

		</div>

 		<div class="clearboth"></div>
 	</div>
</div>
<!-- module start here -->
<!-- top nav 1.7 with fsd skin -->

	<div class="top-nav-module">
		<div class="fsd-skin sup-ie">
			<ul class="nav-list">
					
					
					<li>
						
									<a href="/online-banking/mobile.go" class="top-menu-item"
									name="anc_mobile_banking_overview_topnav" id="anc_mobile_banking_overview_topnav">Overview</a>
					</li>
					
					
					<li>
						
								<a href="/online-banking/mobile-banking-features.go" class="top-menu-item"
								name="anc_features_topnav" id="anc_features_topnav">Features<span class="ada-hidden"> link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/online-banking/mobile-banking-account.go"  name="anc_manage_accounts_text_banking_topnav" id="anc_manage_accounts_text_banking_topnav">Manage Accounts </a>
															<a href="/online-banking/mobile-check-deposit.go"  name="anc_deposit_checks_text_banking_topnav" id="anc_deposit_checks_text_banking_topnav">Deposit Checks </a>
															<a href="/online-banking/mobile-money-transfer.go"  name="anc_transfer_money_text_banking_topnav" id="anc_transfer_money_text_banking_topnav">Transfer Money </a>
															<a href="/online-banking/mobile-banking-alerts.go"  name="anc_alerts_text_banking_topnav" id="anc_alerts_text_banking_topnav">Alerts </a>
															<a href="/online-banking/mobile-bill-pay.go"  name="anc_bill_pay_text_banking_topnav" id="anc_bill_pay_text_banking_topnav">Bill Pay </a>
															<a href="/online-banking/bankamerideals-cash-back-deals.go"  name="anc_cash_back_deals_text_banking_topnav" id="anc_cash_back_deals_text_banking_topnav">Cash Back Deals </a>
															<a href="/online-banking/bank-atm-locations.go"  name="anc_find_locations_text_banking_topnav" id="anc_find_locations_text_banking_topnav">Find Locations </a>
									</div>
								
									<span class="ada-hidden">End of sub menu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
					
					
					<li>
						
								<a href="/online-banking/iphone-banking-app.go" class="top-menu-item"
								name="anc_mobile_basics_topnav" id="anc_mobile_basics_topnav">Mobile Basics<span class="ada-hidden"> link and menu. Press enter to navigate to this link. Press control + space to open submenu. To move through submenu items press tab and then press up or down arrow.</span></a>
							<div class="sub-nav-box">
								<div class="sub-nav-left">
								
									<div class="hasSub">
															<a href="/online-banking/iphone-banking-app.go"  name="anc_supported_devices_text_banking_topnav" id="anc_supported_devices_text_banking_topnav">Supported Devices </a>
															<a href="/online-banking/mobile-banking-faq.go"  name="anc_how_it_works_text_banking_topnav" id="anc_how_it_works_text_banking_topnav">How It Works </a>
									</div>
								
									<span class="ada-hidden">End of sub menu</span>
								</div>
								
								<div class="nav-bottom">
									<div class="bottom-left"></div>
									<div class="bottom-right"></div>
								</div>
							</div>
					</li>
					
					
					<li>
						
									<a href="/online-banking/text-banking.go" class="top-menu-item selected"
									name="anc_text_banking_topnav" id="anc_text_banking_topnav">Text Banking</a>
					</li>
			</ul>
				<div class="clearboth"></div>
		</div>
	</div>

<!-- module ends here -->

<div class="page-title-fsd-module h-100" id="skip-to-h1">
	<div class="standard-red-skin sup-ie">
			<h1 data-font="cnx-regular">Text Banking</h1>
	</div>
</div>


 


<div class="banner-aps-mp-module">
    <div class="graybg-img-skin ">        
        <div class="content-wrapper" style="background-image:url(/content/images/ContextualSiteGraphics/Instructional/en_US/TextBakingImage.png);">
            <h2 data-font="cnx-medium">The fastest account access</h2>
            <p>Get your account balance,<br />recent transactions and more</p>           
        </div> 
    </div> 
</div> 
			<div itemscope="itemscope" itemtype="http://schema.org/WebPage">
					<span style="display:none" itemprop="name">Text Banking from Bank of America</span>
					<a style="display:none" itemprop="url" href="https://www.bankofamerica.com/online-banking/text-banking.go"></a>
					<span style="display:none" itemprop="description">Text message banking on your handheld device gives you information about your Bank of America accounts within seconds. Start using text banking today.</span>
					<img style="display:none" class="no-stretch" itemprop="image" alt="Text Banking from Bank of America" src="https://www.bankofamerica.com/content/images/ContextualSiteGraphics/Logos/en_US/Bank_of_America_Flagscape_71x71.gif">
			</div>
		  



<script language="javascript" src="/pa/components/modules/tag-manager-module/1.1/script/tag-manager-module-borneo-global-skin.js"></script>
<script>

(function() {
  var fireCallback = function( cb ) {
    if ( typeof cb === "function" ) cb();
  };
  
  function ddoPopulateBase( callback ) {
    try {
		  var DDO = window.digitalData,
		  	bactm_mergeDDO = function( newDDO, priorDDO ) {
		  		if( typeof priorDDO === "undefined" ) {
				  	priorDDO = digitalData || {};
				  }

			    for (var l in newDDO) {
			        if (typeof priorDDO[l] === "undefined") {
			            priorDDO[l] = newDDO[l];
			        }
			        if (newDDO[l] !== null) {
			            if (typeof newDDO[l] === "object") {
			                bactm_mergeDDO(newDDO[l], priorDDO[l]);
			            } else {
			                priorDDO[l] = bactm_validateValue( newDDO[l] ) ? newDDO[l] : priorDDO[l];
			            }
			        }
			    }

			    return priorDDO;
				},
				bactm_olb3rdPartyId = "null";

			if (typeof DDO === "undefined") {
				var simpleDDO = { page: { pageInfo:[{ pageID: null }], attributes: {}, category: { primaryCategory: null }}};

				DDO = (typeof digitalData === "object") ? digitalData : simpleDDO; 
			}

				DDO = bactm_mergeDDO( <![CDATA[{pageInstanceID:"notprod",load_coremetrics:false,load_opinionlabs:false,load_touchcommerce:true,load_audiencemanager:true,page:{pageInfo:[{pageID:null,destinationURL:null,referringURL:null,issueDate:null,language:null,segmentValue:null,appName:null,appStepNumber:null,appStepName:null,attr:"-_--_--_--_--_--_--_--_--_--_--_--_--_--_-"}],category:{primaryCategory:null,addlCategory:null,pageType:null},attributes:{searchString:null,searchResults:null,olbSessionID:null,subCampaignCode:null,DARTUrl:null,stateCookie:null,SASIEnabled:false,needOLBcookie:false,standardDART:[],standardDARTes:[],clickDART:[],clickDARTes:[],gaId:[],chat:{account_type:null,boa_associate:null,boa_retiree:null,customer_lob:null,customer_segment:null,data:null,email_campaign:null,entitlement_code:null,error_category:null,error_count:null,first_login:null,inqSalesProductTypes:{},invitation_background:null,invitation_template:null,referral_campaign:null,getStateValue:false,cust_fn:null,cust_ln:null,target:null}}},user:{segment:null,online_id:null,preferred_rewards_tier:null,olb3rdpartyid:null},version:"BAC_0.12"}]]>, DDO );

			DDO.page.pageInfo[0].pageID = "OSP:Content:Mobile;text-banking";
			DDO.page.category.primaryCategory  = "OSP:Content:Mobile";
			DDO.page.pageInfo[0].language = "en-US";
			DDO.page.attributes.olbSessionID = "null";
			DDO.page.attributes.SASIEnabled =  "false";
			if (typeof DDO.user != "undefined" && typeof DDO.user.olb3rdpartyid != "undefined") {
				DDO.user.olb3rdpartyid = bactm_olb3rdPartyId;
			}

			window.utag_data = {};
			window.bactm_envSelector = bactm_setTMLib();
			window.digitalData = DDO;

      return fireCallback( callback );

    } catch(e) { }
  }
	if( window.boa && window.boa.digitalData ) {
    window.boa.digitalData.register( ddoPopulateBase );
	}
	else {
	  // Handle scenario where the header isn't available (and thus the default digitalData object and utag loader are missing).
	  //
		var writeScript = function(a,b,c,d){
			a='//tags.tiqcdn.com/utag/bofa/main/' + bactm_envSelector + '/utag.js';
			b=document;
			c='script';
			d=b.createElement(c);
			d.src=a;
			d.type='text/java'+c;
			d.async=true;
			a=b.getElementsByTagName(c)[0];
			a.parentNode.insertBefore(d,a);
		};

		ddoPopulateBase( writeScript );
	}
})();			
</script>

</div>
					<div class="columns">
						<div class="flex-col lt-col" >


 

	<div class="columns-aps-mp-module">
		<div class="split-skin aps-mobile-products fsd-font ">
							<div class="col gray-box">
									<div class="sprite sprite-A8"></div>
								<div class="content-wrapper">
									<a target="_blank" class="dart-click heading" href="https://secure.bankofamerica.com/login/sign-in/signOnScreen.go?reason=sms" name="anc_enroll_online_in_text_banking" data-dart-event-type="FireOnClickWithoutNumParam" data-dart-src="1359940" data-dart-type="bacal484" data-dart-cat="2014_517" data-dart-url="https://secure.bankofamerica.com/login/sign-in/signOnScreen.go?reason=sms"><strong>Enroll online</strong></a>
													<span class="medium-text">Sign in to Online Banking and go to:<br />Profile &amp; Settings &gt; Mobile Settings</span>
								</div>
								<div class="clearboth"></div>
							</div>
					  					
								<div class="splitter">
						<strong>or</strong>          
					</div>
										<div class="col gray-box">
									<div class="sprite sprite-B8"></div>
								<div class="content-wrapper">
								<p class="heading"><strong>Enroll by phone</strong><br />call <strong>1.800.604.9961</strong><br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 24/7</p>
								</div>
								<div class="clearboth"></div>
							</div>
					  					
			  
			<div class="clearboth"></div>
				<p class="mtop-15">Once you receive our welcome text, you&rsquo;re all set to start Text Banking.</p>
		</div>
	</div>

	<script>
		columnAPSMpSplitSkin.init(); 
	</script>



 

	<div class="mainwell-aps-mp-module">
	   <div class="com-sections-skin com-main-well-content aps-mobile-products">
	   			<div class="section-container table-vzd3-common">
					
					<h3 data-font="cnx-light" class="">Text any of these commands to <strong>MYBOFA</strong> (or <strong>692632</strong>):</h3>
							<p class="pad-adjust">By texting us you agree to receive an automated text message reply. Not a condition of purchasing any products/services.</p>
							  <div>
									<a class="print-page print-only" href="javascript:void(0)" name="anc-print-commands">Print <span class="ada-hidden">&nbsp;text banking commands</span></a>
								<table id="text-banking-commands" summary="This table consists list of text banking commands" class="box-spacing">
											<thead>
												<tr>
														<th>Text us</th>
														<th>To find out</th>
												</tr>
											</thead>
											<tbody>
												<tr>
														<td><strong>BAL</strong></td>																														
														<td>Available balance for eligible deposit accounts<br />(current balance for credit card accounts)</td>																														
												</tr>
												<tr>
														<td><strong>BILL</strong> + account type + last 4 digits<br /><em>Example: <strong>BILL CARD1234</strong></em></td>																														
														<td>Details of your credit card account</td>																														
												</tr>
												<tr>
														<td><strong>HIST</strong> + account type + last 4 digits<br /><em>Example: <strong>HIST CHK1234</strong></em></td>																														
														<td>Recent checking account transactions</td>																														
												</tr>
												<tr>
														<td><strong>MENU</strong></td>																														
														<td>List of text commands</td>																														
												</tr>
												<tr>
														<td><strong>ACCTS</strong></td>																														
														<td>List of your eligible accounts</td>																														
												</tr>
												<tr>
														<td><strong>SRCH</strong> + account type + last 4 digits +<br />date, amount or keyword<br /><em>Example: <strong>SRCH CHCK1234 03/24/14</strong></em></td>																														
														<td>Search transaction history</td>																														
												</tr>
												<tr class="last">
														<td><strong>HELP</strong></td>																														
														<td>Customer service number for your area</td>																														
												</tr>
												</tbody>
								</table>	
							  </div>
							<p class="pad-adjust">For the text message, supported carriers include but are not limited to AT&amp;T, Verizon Wireless, T-Mobile <sup>&reg;</sup>, MetroPCS, Sprint, Boost, Virgin Mobile USA, Cincinnati Bell, U.S. Cellular <sup>&reg;</sup>. Text <strong>STOP </strong>to 692632 to cancel and text <strong>HELP </strong>to 692632 for help.</p>
				</div>		
	   			<div class="section-container">
					
					<h3 data-font="cnx-light" class="sprite sprite sprite-A4  left-icon">Good to know</h3>
							<h4>Bank of America doesn't charge for Text Banking</h4>			
							<p class="pad-adjust">There is&nbsp;no cost to enroll in Text Banking&mdash; Bank of America does not charge you for this convenience. (Message and data rates may apply.)</p>
							
							<h4>Lost or stolen mobile phone</h4>			
							<p class="pad-adjust">Cancel Text Banking immediately by calling customer service at 1.800.604.9961. Or you can sign in to Online Banking and go to Help &amp; Support &gt; Mobile Banking &gt; Set up/Manage Mobile Banking Settings. In the Text Banking section, choose Delete Device next to the mobile device that was lost or stolen.</p>
							<p>If you find your mobile device later, you can re-enroll that same mobile number.</p>
							<h4>Getting multiple messages</h4>			
							<p>You may receive more than 1 message if it&rsquo;s longer than 160 characters (the limit for our text messages). For an extensive transaction history, the response may require multiple messages.</p>
							<h4>Receiving information for multiple accounts</h4>			
							<p>For the commands <strong>BAL</strong>, <strong>SRCH</strong> or <strong>ACCTS</strong>, our reply will include information for your first 15 accounts. This may exceed the 160-character limit, so you may receive multiple messages. Specify the account by texting the command plus the account type and the last 4 digits of the account number. For example, to get the balance of a savings account, text <strong>BAL SAV4576</strong>.</p>
							<h4>Changing your mobile number or service provider</h4>			
							<p class="pad-adjust">Sign in to Online Banking and go to Select Profile in Settings &gt; Mobile Settings &gt; Text Banking &gt; Edit Number to change your mobile number or update your provider.</p>
							<h4>Ending your Text Banking service</h4>			
							<p>Texting STOP, CANCEL or any similar command from your mobile device will not end your Text Banking service. You must call us at 1.800.604.9961 or sign in to Online Banking and select the Mobile settings link from the Profile &amp; Settings navigation menu.</p>
				</div>		
		</div>
	</div>
<script>
	MainWellApsMpModuleComSectionsSkin.init();
</script>
</div>
						<div class="flex-col rt-col" >


 

	<div class="sidewell-aps-mp-module">
	   <div class="contact-us-skin">
			<div class="sw-main sw-std-pad">
			   <h3 class="h2-fsd-sw-gray">Have a question?</h3>
				  <p>Text Banking customer support</p>
				  <div class="fsd-cu-number">1.800.604.9961</div>
				  
		  </div>
	   </div>
	</div>



		<style type="text/css">
			.aps-mobile-products .sprite .spr {
			 background-image: url('/content/images/ContextualSiteGraphics/Instructional/en_US/aps-mobile-products-icon-sprite-dev.png'); 
			background-size: 700px 550px; 
			
		}
		</style>
</div>
						<div class="clearboth"></div>
					</div>
					<div class="footer">
						<div class="footer-top">&nbsp;

<script type="text/javascript">
var axel = Math.random()+"";var a = axel * 10000000000000;document.write('<iframe title="iFrame used for layout purpose" src="https://1359940.fls.doubleclick.net/activityi;src=1359940;type=bacal484;cat=2014_459;ord=1;num='+ a + '?" width="1" height="1" frameborder="0" style="display:none;"></iframe>');
</script>
<noscript>
	<iframe title="iFrame used for layout purpose" src="https://1359940.fls.doubleclick.net/activityi;src=1359940;type=bacal484;cat=2014_459;ord=1;num=1?" width="0" height="0" frameborder="0" style="display:none;"></iframe>
</noscript>
</div>
						<div class="footer-inner">
<!-- added only for cards project-->


	
	

		<div class="power-footer-module">
			<div class="fsd-four-col-skin sup-ie">
				<div class="breadcrumbs">	
										<a class="bold-bc" href="/" name="anc_bc_bank_of_america_text_banking_breadcrumbs" target="_self">Bank of America</a>
										<a href="/online-banking/mobile.go" name="anc_bc_mobile_banking_text_banking_breadcrumbs" target="_self">Mobile Banking</a>
							<span>Text Banking</span>
					<div class="clearboth"></div>
				</div>
			
				<div class="pf-columns">
									<div class="pf-col pf-one">
							  
										<a href="/online-banking/mobile.go" name="anc_pf_mobile_banking_overview_text_banking_power_footer" class="bold" target="_self">Mobile Banking Overview</a>
								
								</div>   
						  
									<div class="pf-col pf-two">
							  
										<a href="/online-banking/mobile-banking-features.go" name="anc_pf_features_text_banking_power_footer" class="bold" target="_self">Features</a>
								
											<a href="/online-banking/mobile-banking-account.go" name="anc_pf_manage_accounts_text_banking_power_footer" target="_self">Manage Accounts</a>
											<a href="/online-banking/mobile-check-deposit.go" name="anc_pf_deposit_checks_text_banking_power_footer" target="_self">Deposit Checks</a>
											<a href="/online-banking/mobile-money-transfer.go" name="anc_pf_transfer_money_text_banking_power_footer" target="_self">Transfer Money</a>
											<a href="/online-banking/mobile-banking-alerts.go" name="anc_pf_alerts_text_banking_power_footer" target="_self">Alerts</a>
											<a href="/online-banking/mobile-bill-pay.go" name="anc_pf_bill_pay_text_banking_power_footer" target="_self">Bill Pay</a>
											<a href="/online-banking/bankamerideals-cash-back-deals.go" name="anc_pf_cash_back_deals_text_banking_power_footer" target="_self">Cash Back Deals</a>
											<a href="/online-banking/bank-atm-locations.go" name="anc_pf_find_locations_text_banking_power_footer" target="_self">Find Locations</a>
								</div>   
						  
									<div class="pf-col pf-three">				
							  
										<a href="/online-banking/iphone-banking-app.go" name="anc_pf_mobile_basics_text_banking_power_footer" class="bold" target="_self">Mobile Basics</a>
								
											<a href="/online-banking/iphone-banking-app.go" name="anc_pf_supported_devices_text_banking_power_footer" target="_self">Supported Devices</a>
											<a href="/online-banking/iphone-banking-app.go" name="anc_pf_iphone_text_banking_power_footer" target="_self">iPhone</a>
											<a href="/online-banking/android-banking-app.go" name="anc_pf_android_text_banking_power_footer" target="_self">Android</a>
											<a href="/online-banking/windows-banking-app.go" name="anc_pf_windows_10_text_banking_power_footer" target="_self">Windows 10</a>
											<a href="/online-banking/blackberry-banking-app.go" name="anc_pf_blackberry_text_banking_power_footer" target="_self">BlackBerry</a>
											<a href="/online-banking/kindle-banking-systems.go" name="anc_pf_kindle_text_banking_power_footer" target="_self">Kindle</a>
											<a href="/online-banking/mobile-banking-apps.go" name="anc_pf_other_devices_text_banking_power_footer" target="_self">Other Devices</a>
											<a href="/online-banking/mobile-banking-faq.go" name="anc_pf_how_it_works_text_banking_power_footer" target="_self">How It Works</a>
								</div>   
						  
									<div class="pf-col pf-four pf-last">
							  
										<a href="/online-banking/text-banking.go" name="anc_pf_text_banking_text_banking_power_footer" class="bold" target="_self">Text Banking</a>
								
								</div>   
						  
						  
						<div class="clearboth"></div>
				</div>
			</div>
		</div>



 



		<div class="global-footer-module">
			<div class="fsd-skin">

				<div class="footer-bottom-left" style="float:left;max-width:66%;">
	    			<div class="gf-links">	          	
						
					
									
									<a  target="_self" href="/" 
									    name="anc-global-footer-home">Home
									</a>
									
						
					
									
									<a  target="_self" href="/privacy/overview.go" 
									    name="anc-privacy-and-security">Privacy &amp; Security
									</a>
									
						
					
									
									<a  target="_self" href="http://careers.bankofamerica.com/careershome.aspx" 
									    name="anc-global-footer-careers">Careers
									</a>
									
						
					
									
									<a  target="_self" href="/sitemap/personal.go" 
									    name="anc-global-footer-sitemap">Site Map
									</a>
									
						
					
									<a href="javascript:void(0);" class="gf-last-link boa-dialog boa-com-info-layer-link" name="global_footer_advertising_practices_lnk" rel="global_footer_advertising_practices">Advertising Practices</a>
								<div id="global_footer_advertising_practices" class="hide">
									<h3>Advertising Practices</h3>
										<p>We strive to provide you with information about products and services you might find interesting and useful. Relationship-based ads and online behavioral advertising help us do that.</p>
<p>Here's how it works: We gather information about your online activities, such as the searches you conduct on our Sites and the pages you visit. This information may be used to deliver advertising on our Sites and offline (for example, by phone, email and direct mail) that's customized to meet specific interests you may have.</p>
<p>If you prefer that we do not use this information, you may <a onclick="$('.ui-dialog').remove();" name="WebsiteAdPractices_OptOut" href="/privacy/online-privacy-notice.go#advertising-on-our-sites" target="_blank">opt out of online behavioral advertising</a>. If you opt out, though, you may still receive generic advertising. In addition, financial advisors/Client Managers may continue to use information collected online to provide product and service information in accordance with account agreements.</p>
<p>Also, if you opt out of online behavioral advertising, you may still see ads when you sign in to your account, for example through Online Banking or MyMerrill. These ads are based on your specific account relationships with us.</p>
<p>To learn more about relationship-based ads, online behavioral advertising and our privacy practices, please review the <a onclick="$('.ui-dialog').remove();" name="WebsiteAdPractices_PrivacyNotice" href="/privacy/online-privacy-notice.go" target="_blank">Bank of America Online Privacy Notice</a> and our <a onclick="$('.ui-dialog').remove();" name="Online-privacy-faqs" href="/privacy/faq/online-privacy-faq.go" target="_blank">Online Privacy FAQs</a>.</p>
								</div>
						<div class="clearboth"></div>
	    			</div>
	      			<p>Bank of America, N.A. Member FDIC. <a class="boa-window force-large" name="Equal_Housing_Lender" href="/help/equalhousing_popup.go">Equal Housing Lender<img src="https://www2.bac-assets.com/content/images/ContextualSiteGraphics/Logos/en_US/icon_equal_housing_lender.gif" alt="" width="14" height="9" /></a> <br />&copy; 2017 Bank of America Corporation. All rights reserved.</p>
         		</div>
         		<div class="footer-social-container" style="float:right;max-width:30%;padding-left:50px;padding-top:19px;">




<div class="boa-social-loader" data-loaded="false" data-platform="borneo"  data-options=''></div>

         		</div>
         		<div class="clearboth"></div>
  			</div>
		</div>

<script src="https://www2.bac-assets.com/pa/global-assets/external/coremetrics/hp/eluminate.js" type="text/javascript"></script>
<script src="https://www2.bac-assets.com/pa/global-assets/external/coremetrics/hp/cmdatatagutils.js" type="text/javascript"></script>


<script type="text/javascript" id="coremetrics-bdf-module-mobilesales-skin">
	var cmPageId = "OSP:Content:Mobile;text-banking";
	var cmCategoryId = "OSP:Content:Mobile"; 
	var testString = window.location.href;		
	var cmReqLocale = $('html').attr('lang');
	var locAppendage;
	if (cmReqLocale.toLowerCase().indexOf('en') !== -1) {
		locAppendage = '';
	} else if (cmReqLocale.toLowerCase().indexOf('es') !== -1) {
		locAppendage = '_ES';
	}
	

function cmSetDD(){var testString=window.location.href;if(testString.toLowerCase().indexOf(".bankofamerica.com")>-1){testString=testString.toLowerCase();var tempArr=testString.split(".bankofamerica.com");var tempStr=tempArr[0];if(tempStr.indexOf("//")>-1){tempArr=tempStr.split("//");tempStr=tempArr[1];if(tempStr.indexOf(".")>-1){tempArr=tempStr.split(".");tempStr=tempArr[0];var tempStrPt2=tempArr[1]}if(tempStr.indexOf("www")>-1){if(tempStr.indexOf("-")>-1){cmSetStaging()}else{if(tempStrPt2!=null){if(tempStrPt2.indexOf("ecnp")>-1){cmSetStaging()}}else{cmSetProduction()}}}else{if(tempStr.indexOf("-")>-1){if(tempStr.indexOf("sitekey")>-1){if(tempStr=="sitekey"){cmSetProduction()}else{cmSetStaging()}}else{cmSetStaging()}}else{if(tempStrPt2!=null){if(tempStrPt2.indexOf("ecnp")>-1){cmSetStaging()}}else{cmSetProduction()}}}}}}if(typeof cmSetStaging=="function"){cmSetDD()};
	
	if (typeof cmSetStaging == 'function') {cmSetDD()}

	cmCreatePageviewTag(cmPageId+locAppendage, null, null, cmCategoryId, false, false, null, false, false, null, null, null, null, null, null, null, null, null, null, null, null);

</script>


 
</div>
					</div>
				</div>
			</div>
		</div>
	</body>	
</html>

