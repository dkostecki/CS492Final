
 

				<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
				<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
				<head>


<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<title>Bank of America | Online Banking | eCommunications Disclosure</title>

                   <meta name="Keywords" CONTENT="Online Banking, eCommunications Disclosure" />
                   <meta name="Description" CONTENT="The Bank of America Online Banking eCommunications Disclosure" />
        <link REL="canonical" HREF="https://www.bankofamerica.com/online-banking/eComm-Disclosure.go"/>                  
        
<link rel="shortcut icon" href="https://www2.bac-assets.com/pa/global-assets/1.0/graphic/favicon.ico" type="image/ico" />

			<link rel="stylesheet" type="text/css" media="all" href="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/APS-mobile-products/2017.03.0/style/aps-mp-jawr.css"/>	
			<script type="text/javascript" src="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/APS-mobile-products/2017.03.0/script/aps-mp-jawr.js"></script>
		
			<script type="text/javascript"> 
				$(window).load(function(){asyncPrintCssInclude('https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/APS-mobile-products/2017.03.0/style/aps-mp-jawr-print.css');});
			</script>	
<script type="text/javascript">
(function() {
	if (typeof mboxUpdate == "function") {
		var windowURL = window.location.href
	    windowURL = windowURL.slice( windowURL.indexOf('.')+1);
		windowURL = windowURL.split( '?' )[0];
		windowURL = windowURL.toLowerCase();
		//alert(windowURL);
		if (
		    //If no mboxes on page, mbox count will be < 1
		    (mboxFactoryDefault.getMboxes().length() < 1) &&  
			
			//Also check for high-volume pages that do not need global logging
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go") &&
			(windowURL != "bankofamerica.com/myaccounts/signin/signin.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/entry/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signonscreen.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatechallengeanswer.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatePassword.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/mobile/banking.go")&&
			(windowURL != "bankofamerica.com/content/preload/olb-myaccount-preload-jawr-module.htm")
			)
		{

			var mboxDiv = document.createElement("div");
			mboxDiv.id = "adobe_touch_clarity_replacement";
			mboxDiv.style.display = "none";
			if (document.body && document.body.firstChild) document.body.insertBefore(mboxDiv,document.body.firstChild);
			mboxDefine(mboxDiv.id,'bac_global_bottom');
			mboxUpdate('bac_global_bottom');
		}
	}	
})();
</script>

		<script src="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/Global/1.0/script/tealeafbundle.js" type="text/javascript"></script>
			<script>
				var boaPageDataJS = {};
					boaPageDataJS.isLLE = "false";
			</script>
				<style>body{display:none;}</style>
	</head>		

	<body class="fsd-layout-body">	

				<script type="text/javascript">if(self == top){var theBody=document.getElementsByTagName("body")[0];theBody.style.display="block";}else{top.location=self.location;}</script>
				<noscript><style>body{display:block;}</style></noscript>
					<a class='ada-hidden ada-visible-focus' href='#skip-to-h1' id='ada-skip-link'>Skip to main content</a>
		<div class="fsd-layout fsd-2c-700lt-layout">
			<div class="fsd-border">
				<div class="center-content">
					<div class="header">


 


<div class="header-module">
	<div class="text-w-logo-skin">
		<div class="header-left">
	  
			<div itemscope itemtype="http://schema.org/Corporation" class="bofa-logo">
				<a itemprop="url" name="anc-online-banking" title="Bank of America" href="/">
					<img itemprop="logo" height="28" width="221" 
					     alt="Bank of America" src="https://www2.bac-assets.com/content/images/ContextualSiteGraphics/Logos/en_US/boa_logo.gif"/>
				</a>
			</div>
				<div class="product" data-font="cnx-regular">Online Banking</div>
			
			<div class="clearboth"></div>

		</div>
		
		<div class="header-right">
			<ul class="header-links">
			
				
					
				
							<li class="sign-in">
		<a					href="/sitemap/hub/signin.go" target="_self"
		name="Sign In">Sign In</a> 
							</li>
					
				
							<li>		<a					href="/" target="_self"
		name="Home">Home</a> 
</li>
					
				
							<li>		<a					href="http://locators.bankofamerica.com/locator/locator/LocatorAction.do" target="_self"
		name="Locations">Locations</a> 
</li>
					
				
							<li>		<a					href="/contactus/contactus.go" target="_self"
		name="Contact Us">Contact Us</a> 
</li>
					
				
							<li>		<a					href="/help/overview.go" target="_self"
		name="Help">Help</a> 
</li>
					
				
							<li class="last-link">	
									<a href="/online-banking/eComm-Disclosure.go?request_locale=es_US" name="En espa&#241;ol" target="_self">En espa&#241;ol</a> 				
							</li>
			</ul>
			
			<div class="clearboth"></div>

			<!-- include search-dotcom-util -->



<div class="header-search nlh">
  
  <div class="nav-search">
    <form class="search-form" action="https://secure.bankofamerica.com/myaccounts/public/search-results/unAuthenticatedSearch.go" data-js="/pa/components/utilities/search-util/1.0/script/nav-search.min.js" data-css="/pa/components/utilities/search-util/1.0/style/nav-search.css" data-text-unavailable="Search Currently Unavailable">
      <div class="search-input-container cf" data-icon="search">
        <label for="nav-search-query" class="ada-hidden">Search Term</label>
        <input type="text" placeholder="How can we help you?" name="query" class="search-query" id="nav-search-query" 
          maxlength="99" rel="Search" autocomplete="off"><input type="submit" alt="Search" title="Search" value="Submit Search" name="Search Module - Top Result – Search Button" class="submit track-me">
      </div>
    </form>
  </div>

</div>

		</div>

 		<div class="clearboth"></div>
 	</div>
</div>

<div class="page-title-fsd-module h-100" id="skip-to-h1">
	<div class="standard-red-skin sup-ie">
			<h1 data-font="cnx-regular">eCommunications Disclosure</h1>
	</div>
</div>		  



<script language="javascript" src="/pa/components/modules/tag-manager-module/1.1/script/tag-manager-module-borneo-global-skin.js"></script>
<script>

(function() {
  var fireCallback = function( cb ) {
    if ( typeof cb === "function" ) cb();
  };
  
  function ddoPopulateBase( callback ) {
    try {
		  var DDO = window.digitalData,
		  	bactm_mergeDDO = function( newDDO, priorDDO ) {
		  		if( typeof priorDDO === "undefined" ) {
				  	priorDDO = digitalData || {};
				  }

			    for (var l in newDDO) {
			        if (typeof priorDDO[l] === "undefined") {
			            priorDDO[l] = newDDO[l];
			        }
			        if (newDDO[l] !== null) {
			            if (typeof newDDO[l] === "object") {
			                bactm_mergeDDO(newDDO[l], priorDDO[l]);
			            } else {
			                priorDDO[l] = bactm_validateValue( newDDO[l] ) ? newDDO[l] : priorDDO[l];
			            }
			        }
			    }

			    return priorDDO;
				},
				bactm_olb3rdPartyId = "null";

			if (typeof DDO === "undefined") {
				var simpleDDO = { page: { pageInfo:[{ pageID: null }], attributes: {}, category: { primaryCategory: null }}};

				DDO = (typeof digitalData === "object") ? digitalData : simpleDDO; 
			}

				DDO = bactm_mergeDDO( {pageInstanceID:"notprod",load_coremetrics:false,load_opinionlabs:false,load_touchcommerce:true,load_audiencemanager:true,page:{pageInfo:[{pageID:null,destinationURL:null,referringURL:null,issueDate:null,language:null,segmentValue:null,appName:null,appStepNumber:null,appStepName:null,attr:"-_--_--_--_--_--_--_--_--_--_--_--_--_--_-"}],category:{primaryCategory:null,addlCategory:null,pageType:null},attributes:{searchString:null,searchResults:null,olbSessionID:null,subCampaignCode:null,DARTUrl:null,stateCookie:null,SASIEnabled:false,needOLBcookie:false,standardDART:[],standardDARTes:[],clickDART:[],clickDARTes:[],gaId:[],chat:{account_type:null,boa_associate:null,boa_retiree:null,customer_lob:null,customer_segment:null,data:null,email_campaign:null,entitlement_code:null,error_category:null,error_count:null,first_login:null,inqSalesProductTypes:{},invitation_background:null,invitation_template:null,referral_campaign:null,getStateValue:false,cust_fn:null,cust_ln:null,target:null}}},user:{segment:null,online_id:null,preferred_rewards_tier:null,olb3rdpartyid:null},version:"BAC_0.12"}, DDO );

			DDO.page.pageInfo[0].pageID = "";
			DDO.page.category.primaryCategory  = "";
			DDO.page.pageInfo[0].language = "en-US";
			DDO.page.attributes.olbSessionID = "null";
			DDO.page.attributes.SASIEnabled =  "false";
			if (typeof DDO.user != "undefined" && typeof DDO.user.olb3rdpartyid != "undefined") {
				DDO.user.olb3rdpartyid = bactm_olb3rdPartyId;
			}

			window.utag_data = {};
			window.bactm_envSelector = bactm_setTMLib();
			window.digitalData = DDO;

      return fireCallback( callback );

    } catch(e) { }
  }
	if( window.boa && window.boa.digitalData ) {
    window.boa.digitalData.register( ddoPopulateBase );
	}
	else {
	  // Handle scenario where the header isn't available (and thus the default digitalData object and utag loader are missing).
	  //
		var writeScript = function(a,b,c,d){
			a='//tags.tiqcdn.com/utag/bofa/main/' + bactm_envSelector + '/utag.js';
			b=document;
			c='script';
			d=b.createElement(c);
			d.src=a;
			d.type='text/java'+c;
			d.async=true;
			a=b.getElementsByTagName(c)[0];
			a.parentNode.insertBefore(d,a);
		};

		ddoPopulateBase( writeScript );
	}
})();			
</script>

</div>
					<div class="columns">
						<div class="flex-col lt-col" >
<link type="text/css" rel="stylesheet" media="all" href="https://www2.bac-assets.com/pa/components/modules/service-agreement-module/1.2/style/service-agreement-module-com-skin.css">
<script type="text/javascript" src="https://www2.bac-assets.com/pa/components/modules/service-agreement-module/1.2/script/service-agreement-module-com-skin.js"></script>


<div class="service-agreement-module">
<div class="com-skin com-ecd-skin com-main-well-content table-vzd3-common embed-bullet">
<script type="text/javascript">
	var ADAShowTopicsText = "Show Topics for ";  
	var ADAHideTopicsText = "Hide Topics for ";  	
</script>
<div class="intro-link"><a href="/onlinebanking/online-banking.go">
<span class="guillemet">&#8249;&#8249;&nbsp;</span>
Go to Online Banking Overview
</a></div>
<div class="h-100">
	<h2 id="back-to-top-anchor">
		<strong>Electronic Communications Disclosure</strong>
	</h2>
</div>
<p class="eff-date">
		Effective Date: April 28, 2016
</p>
		<p><strong>Please read this Electronic Communications Disclosure ("eCommunications Disclosure") thoroughly - It contains important information about your legal rights.</strong> This eCommunications Disclosure covers all of your accounts, products, and services with Bank of America, Merrill Lynch, Pierce, Fenner &amp; Smith Incorporated (&ldquo;Merrill Lynch&rdquo;) and their affiliates (collectively, "we", "us", and "our") accessible, either currently or in the future, through Online Banking (whether accessed through a personal computer or mobile device, sometimes referred to as &ldquo;Mobile Banking&rdquo; or "Mobile Banking app"), our websites, or other electronic means. This includes, but is not limited to, the following account, product, and service types: deposit, credit card, charge card, line of credit, loan, mortgage, brokerage, investment advisory, insurance and others. The words "I", "you" and "your" mean each account holder, product owner and/or service user identified on an account, product or service.</p>
<div class="sa-main-content">
		<div class="h-100">
			<h3 id="cat1">
					(1) Your Legal Rights
			</h3>
		</div>
			<p>Certain laws and regulations require us to provide specific information to you in writing, which means you have a right to receive that information on paper. We may provide such information to you electronically if we first present this eCommunications Disclosure and obtain your consent to receive the information electronically. Your consent will also apply to any other person named on your account, product or service, subject to applicable law. Since certain of our accounts, products or services are provided online and use electronic means to deliver some of this information, you must consent to this eCommunications Disclosure in order to use these services. At times, we may still send you paper communications, but as a basic proposition we need to know that you are willing to receive communications electronically that we may otherwise be required to provide on paper and that you have the hardware and software needed to access to this information (and note that in Section No. 3 below, we explain how you may be able to obtain selected disclosures or other information on paper even after you have consented to this eCommunications Disclosure).</p>
		<div class="back-to-top-link"> <a href="#back-to-top-anchor">Back to top</a> </div>
		<div class="h-100">
			<h3 id="cat2">
					(2) Types of Electronic Communications You Will Receive
			</h3>
		</div>
			<p>You understand and agree that we may provide to you in electronic format only, such as by posting the information on the website where you access your accounts, products or services, through e-mail (if applicable and if you have provided a valid e-mail address), or through other electronic means, agreements, disclosures, notices, and other information and communications regarding your accounts, services and products, the use of our websites or our other electronic services, your relationship with us, and/or other programs, products or services that are or may be in the future made available to you (collectively, "Communications"). Such Communications may include, but are not limited to:</p>
<ul class="tc-disc">
<li>This eCommunications Disclosure and any updates;</li>
<li>The Online Banking Service Agreement, other service or user agreements for access to our websites or other electronic services, all updates to these agreements and all disclosures, notices and other communications regarding transactions you make through websites or our other electronic services;</li>
<li>Disclosures, agreements, notices and other information related to the opening or initiation of an account, product or service including, but not limited to, account agreements, fee schedules or other disclosures or notices that may be required by the Truth in Savings Act, Electronic Fund Transfer Act, Truth in Lending Act, the Equal Credit Opportunity Act, the Fair Credit Reporting Act, the Gramm Leach Bliley Act, the Real Estate Settlement Procedures Act or other applicable federal or state laws and regulations;</li>
<li>Periodic, annual, monthly or other statements, disclosures and notices relating to the maintenance or operation of an account, product or service including, but not limited to account information, account activity, account inactivity, payments made or due, or other statements, disclosures or notices that may be required by the Truth in Savings Act, Electronic Fund Transfer Act, Truth in Lending Act, the Equal Credit Opportunity Act, the Fair Credit Reporting Act, the Gramm Leach Bliley Act, the Real Estate Settlement Procedures Act or other applicable federal or state laws and regulations;</li>
<li>Investment account disclosures, agreements, statements, trade confirmations, tax reporting statements, shareholder notices, prospectuses, service notices and performance reports regarding accounts, products and services;</li>
<li>Any notice or disclosure regarding an account, product or service fee, such as a late fee, an overdraft fee, an overlimit fee, a fee for a draft, check or electronic debit returned for any reason, such as insufficient funds fee or a fee as a result of a stop payment order;</li>
<li>Any notice of the addition of new terms and conditions or the deletion or amendment of existing terms and conditions applicable to accounts, products or services you obtain from us;</li>
<li>Our Privacy Notice and other privacy statements or notices (by posting such notices on our website);</li>
<li>Certain tax statements or notices that we are legally required to provide to you, such as the annual IRS interest statements; and</li>
<li>Certain information or forms that we request from you and ask you to submit electronically, such as signature cards, W-9s, or other agreements.</li>
</ul>
		<div class="back-to-top-link"> <a href="#back-to-top-anchor">Back to top</a> </div>
		<div class="h-100">
			<h3 id="cat3">
					(3) Setting Your Electronic Communications Preferences
			</h3>
		</div>
			<p>After you consent to this eCommunications Disclosure, you may still be able to set your preferences to receive certain categories of Communications in (1) both electronic and paper format; (2) electronic format only; or (3) paper format only. Setting your Communications preferences may not be available for all products, accounts or services. For more information on the availability of your electronic communications preference management options, please refer to the appropriate electronic communications preference page on the website where you access your Communications. If you decide to receive some Communications in paper and some electronically, the Communications that you receive electronically will be governed by this eCommunications Disclosure.</p>
		<div class="back-to-top-link"> <a href="#back-to-top-anchor">Back to top</a> </div>
		<div class="h-100">
			<h3 id="cat4">
					(4) Types of Communications You Will Receive in Paper
			</h3>
		</div>
			<p>This eCommunications Disclosure does not apply to any communications that we determine, in our sole discretion, that we are required to deliver in paper form under applicable law or that you should receive in paper rather than electronic form.</p>
<p>Such communications shall be mailed to the primary address we show for you in our records or otherwise delivered as required by law or the governing agreement.</p>
		<div class="back-to-top-link"> <a href="#back-to-top-anchor">Back to top</a> </div>
		<div class="h-100">
			<h3 id="cat5">
					(5) Hardware and Software Requirements
			</h3>
		</div>
			<p><strong>For Online and Mobile Banking:</strong>&nbsp;</p>
<p>You will need a computer or mobile device with internet access and browser, a compatible operating system, and/or a compatible Bank of America Mobile Banking app to access the Communications. While you may be able to access and retain the Communications using other hardware and software, we recommend that you use the latest version of the supported browsers or Mobile Banking app available, keep your security settings up to date and that you enable JavaScript. In certain circumstances, we may need to block certain browsers and software from accessing Online Banking and Mobile Banking due to possible security risks and may not be able to inform you in advance.</p>
<p>Please refer to <a href="https://www.bankofamerica.com/help/supported-browsers.go" target="_blank">Browser and Operating System Requirements</a> for a current list of browsers and operating systems compatible with Bank of America&rsquo;s Online Banking website and Mobile Banking App.</p>
<p><strong>For Merrill Lynch websites:</strong></p>
<ul class="tc-disc">
<li>You must have access to a computer or device with compatible browser software such as Microsoft Internet Explorer; Adobe Acrobat Reader; and Internet access (at your cost).</li>
<li>Browser and reader versions necessary to view the Merrill Lynch websites are as follows:
<ul class="tc-square">
<li>Microsoft Internet Explorer version 6.0 or later</li>
<li>Firefox version 3.5 or later</li>
<li>Safari version 3.2 or later</li>
<li>Chrome version 41 or later</li>
</ul>
</li>
</ul>
<p>Most Communications provided within our websites are provided either in HTML and/or PDF format. For Communications provided in PDF format, Adobe Reader 6.0 or later versions is required &ndash; A free copy of Adobe Reader may be obtained from the Adobe website at www.adobe.com.</p>
<p>In certain circumstances, some Communications may be provided by e-mail. You are responsible for providing us with a valid e-mail address to accept delivery of Communications. At our option, we may also post the emailed Communications within our websites. In this situation, you agree that once we email the Communications to you and post them within our websites, that we have delivered the Communications to you in a form that you can retain.</p>
<p>To print or download Communications you must have a printer connected to your device or sufficient hard-drive or other storage space to store the Communications.</p>
		<div class="back-to-top-link"> <a href="#back-to-top-anchor">Back to top</a> </div>
		<div class="h-100">
			<h3 id="cat6">
					(6) How to Withdraw Your Consent to this eCommunications Disclosure
			</h3>
		</div>
			<p>Subject to applicable law, you may withdraw your consent to this eCommunications Disclosure by calling the appropriate toll-free customer service phone numbers. Please access the "Contact Us" link on the applicable website where you access your Communications to find the appropriate phone number. You will not be charged a fee for withdrawal of your consent.</p>
<p>For Online Banking, if you withdraw your consent to this eCommunications Disclosure, we may stop providing you with Communications electronically and we may terminate your Online Banking access.</p>
<p>For Merrill Lynch or Merrill Edge Advisory Center clients, if you withdraw your consent to this eCommunications Disclosure, we may stop providing you with Communications electronically.&nbsp;</p>
<p>For Merrill Edge Self-Directed Investing clients, if you withdraw your consent to this eCommunications Disclosure, we may stop providing you with Communications electronically and we may terminate your relationship and/or account with us.&nbsp; For Merrill Edge Self-Directed Investing clients whose accounts transitioned to Merrill Edge from Banc of America Investment Services, Inc., if you withdraw your consent to this eCommunications Disclosure, we may stop providing you with Communications electronically.&nbsp;</p>
<p>In any of the situations discussed above, your withdrawal of consent is effective only after you have communicated your withdrawal to Bank of America, Merrill Lynch, and/or Merrill Edge, as applicable, by calling the appropriate customer service phone number(s) and we have had a reasonable period of time to act upon your withdrawal. If you separately provided your consent to this eCommunications Disclosure to Bank of America, Merrill Lynch, and/or Merrill Edge, you must separately withdraw your consent by calling each of the entities to whom you provided your consent.&nbsp; Your consent shall remain in force until withdrawn in the manner provided in this section.</p>
<p>Remember that you may be able to set your Communications preferences as described in Section 3 above without withdrawing your consent to this eCommunications Disclosure.</p>
		<div class="back-to-top-link"> <a href="#back-to-top-anchor">Back to top</a> </div>
		<div class="h-100">
			<h3 id="cat7">
					(7) Consent Coverage; Certain Notices From You Are Not Covered.
			</h3>
		</div>
			<p>Applicable law or contracts sometimes require you to give us "written" notices. You must still provide these notices to us on paper. Your consent here does not relate to those notices.</p>
		<div class="back-to-top-link"> <a href="#back-to-top-anchor">Back to top</a> </div>
		<div class="h-100">
			<h3 id="cat8">
					(8) Obtaining Copies of Electronic Communications.
			</h3>
		</div>
			<p>You may print or make a copy of Communications by using the "Print" button (or otherwise using your printing functionality) or saving a copy &ndash; do this when you first review the Communications because after submission we do not necessarily keep them all in a place that you can access. For certain products, accounts, or services, we will, upon request, provide you with a paper copy of any Communications provided electronically by us to you pursuant to this eCommunications Disclosure, provided we receive your request within 12 months after the date the Communication was first made available to you electronically. You may request a paper copy of these Communications by calling us at the appropriate toll-free customer service phone number for your account, product or service. Please refer to the&nbsp;Help &amp; Support Page within the Online Banking or the Merrill Lynch websites or the "Contact Us" link on the Bank of America website to find the appropriate customer service phone number.</p>
<p>Be sure to specify your account, service or product identification number, as applicable, the specific Communication for which you are requesting a paper copy, and the address to which it should be mailed. We may charge fees for paper copies of the Communications.</p>
		<div class="back-to-top-link"> <a href="#back-to-top-anchor">Back to top</a> </div>
		<div class="h-100">
			<h3 id="cat9">
					(9) Updating Your Contact Information
			</h3>
		</div>
			<p>In the event that your e-mail address or other contact information is changed, you must notify us of such changes immediately through one of the following methods:</p>
<ul class="tc-disc">
<li>For Online Banking, access the&nbsp;Help &amp; Support page within Online Banking and click the appropriate links on "Your Profile Information" to update your contact information. Note: The&nbsp;Help &amp; Support page is not yet available if you are accessing Online Banking through a mobile-optimized experience (e.g., Mobile Banking App or www.bofa.mobi). You will need to log in to Online Banking using a desktop browser to access this page.</li>
<li>For Merrill Lynch websites, access the Profile page and click on the appropriate links on the "Personal Information" page to update your contact information; or</li>
<li>Call the appropriate toll-free customer service phone number and communicate the contact information changes.</li>
</ul>
<p>If you fail to update or change an incorrect or invalid e-mail address or other contact information, you understand and agree that any Communications shall nevertheless be deemed to have been provided to you if they were made available to you in electronic form on our websites, e-mailed to the e-mail address we have for you in our records, or delivered through other electronic means.</p>
		<div class="back-to-top-link"> <a href="#back-to-top-anchor">Back to top</a> </div>
		<div class="h-100">
			<h3 id="cat10">
					(10) Retain Copies for Your Records
			</h3>
		</div>
			<p>We recommend that you print or download a copy of this eCommunications Disclosure, the applicable service or account agreement and all other Communications to retain for your permanent records; if you have not already placed a copy of our Privacy Policy in your records, you can obtain <a href="https://www.bankofamerica.com/privacy/consumer-privacy-notice.go" title="Get a copy of the Bank of America Privacy Policy. Link opens a new window." target="_blank">another copy<span class="ada-hidden"> of our privacy notice</span></a>.</p>
		<div class="back-to-top-link"> <a href="#back-to-top-anchor">Back to top</a> </div>
</div>
</div>
</div>





	<div class="hide com-interstitial-modal">
     	<h3>Important Notice</h3>
   		<div class="flex-modal-main-content">
   		
      		<p><strong>You're continuing to another website</strong></p>
      		<p>You're continuing to another website that Bank of America doesn't own or operate. Its owner is solely responsible for the website's content, offerings and level of security, so please refer to the website's posted privacy policy and terms of use.</p>
   	
   	<div class="flex-modal-buttons">
	      	<a href="javascript:void(0);" class="button-common button-blue" name="leaving_bank_modal_continue"><span>Continue</span></a>
	         
	      	<a href="javascript:void(0);" class="button-common button-gray close-com-interstitial" name="leaving_bank_modal_cancel"><span>Return to Bank of America</span></a>
	         
          <div class="clearboth"></div>
      </div>
   </div>
</div>

</div>
						<div class="flex-col rt-col" ></div>
						<div class="clearboth"></div>
					</div>
					<div class="footer">
						<div class="footer-top">&nbsp;</div>
						<div class="footer-inner">
<div class="disclaimers-module">
	<div class="fsd-skin sup-ie">
			<p>Some accounts and services, and the fees that apply to them, vary from state to state. Please review the information for your state in the Personal Schedule of Fees (at          <a href="http://www.bankofamerica.com/feesataglance" target="_self">www.bankofamerica.com/feesataglance</a> or at your local Banking Center) and in the Online Banking Service Agreement at <a href="http://www.bankofamerica.com/serviceagreement" target="_self">www.bankofamerica.com/serviceagreement</a>.</p>
	</div>
</div>




 



		<div class="global-footer-module">
			<div class="fsd-skin">

				<div class="footer-bottom-left" style="float:left;max-width:66%;">
	    			<div class="gf-links">	          	
						
					
									
									<a  target="_self" href="/" 
									    name="Home">Home
									</a>
									
						
					
									
									<a  target="_self" href="/privacy/overview.go" 
									    name="Privacy and Security">Privacy & Security
									</a>
									
						
					
									
									<a  target="_self" href="http://careers.bankofamerica.com/careershome.aspx" 
									    name="Careers">Careers
									</a>
									
						
					
									
									<a  target="_self" href="/sitemap/personal.go" 
									    name="Site Map">Site Map
									</a>
									
						
					
									<a href="javascript:void(0);" class="gf-last-link boa-dialog boa-com-info-layer-link" name="global_footer_ad_practices_lnk" rel="global_footer_ad_practices">Advertising Practices</a>
								<div id="global_footer_ad_practices" class="hide">
									<h3>Advertising Practices</h3>
										<p>We strive to provide you with information about products and services you might find interesting and useful. Relationship-based ads and online behavioral advertising help us do that.</p>
<p>Here's how it works: We gather information about your online activities, such as the searches you conduct on our Sites and the pages you visit. This information may be used to deliver advertising on our Sites and offline (for example, by phone, email and direct mail) that's customized to meet specific interests you may have.</p>
<p>If you prefer that we do not use this information, you may <a onclick="$('.ui-dialog').remove();" name="WebsiteAdPractices_OptOut" href="/privacy/online-privacy-notice.go#advertising-on-our-sites" target="_blank">opt out of online behavioral advertising</a>. If you opt out, though, you may still receive generic advertising. In addition, financial advisors/Client Managers may continue to use information collected online to provide product and service information in accordance with account agreements.</p>
<p>Also, if you opt out of online behavioral advertising, you may still see ads when you sign in to your account, for example through Online Banking or MyMerrill. These ads are based on your specific account relationships with us.</p>
<p>To learn more about relationship-based ads, online behavioral advertising and our privacy practices, please review the <a onclick="$('.ui-dialog').remove();" name="WebsiteAdPractices_PrivacyNotice" href="/privacy/online-privacy-notice.go" target="_blank">Bank of America Online Privacy Notice</a> and our <a onclick="$('.ui-dialog').remove();" name="Online-privacy-faqs" href="/privacy/faq/online-privacy-faq.go" target="_blank">Online Privacy FAQs</a>.</p>
								</div>
						<div class="clearboth"></div>
	    			</div>
	      			<p>Bank of America, N.A. Member FDIC. <a name="Equal_Housing_Lender" href="/help/equalhousing_popup.go" target="_blank">Equal Housing Lender<img src="https://www2.bac-assets.com/content/images/ContextualSiteGraphics/Logos/en_US/icon_equal_housing_lender.gif" alt="" width="14" height="9" /></a> <br />&copy; 2017 Bank of America Corporation. All rights reserved.</p>
         		</div>
         		<div class="footer-social-container" style="float:right;max-width:30%;padding-left:50px;padding-top:19px;">




<div class="boa-social-loader" data-loaded="false" data-platform="borneo"  data-options=''></div>

         		</div>
         		<div class="clearboth"></div>
  			</div>
		</div>




 
</div>
					</div>
				</div>
			</div>
		</div>
	</body>	
</html>

