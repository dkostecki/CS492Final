
 

				<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
				<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
				<head>


<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<title>Bank of America | Online Banking | Service Agreement</title>

                   <meta name="Keywords" CONTENT="service agreement,online agreement" />
                   <meta name="Description" CONTENT="The Bank of America Online Banking Service Agreement" />
        <link REL="canonical" HREF="https://www.bankofamerica.com/online-banking/service-agreement.go"/>                  
        
<link rel="shortcut icon" href="https://www2.bac-assets.com/pa/global-assets/1.0/graphic/favicon.ico" type="image/ico" />

			<link rel="stylesheet" type="text/css" media="all" href="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/APS-mobile-products/2017.03.0/style/aps-mp-jawr.css"/>	
			<script type="text/javascript" src="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/APS-mobile-products/2017.03.0/script/aps-mp-jawr.js"></script>
		
			<script type="text/javascript"> 
				$(window).load(function(){asyncPrintCssInclude('https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/APS-mobile-products/2017.03.0/style/aps-mp-jawr-print.css');});
			</script>	
<script type="text/javascript">
(function() {
	if (typeof mboxUpdate == "function") {
		var windowURL = window.location.href
	    windowURL = windowURL.slice( windowURL.indexOf('.')+1);
		windowURL = windowURL.split( '?' )[0];
		windowURL = windowURL.toLowerCase();
		//alert(windowURL);
		if (
		    //If no mboxes on page, mbox count will be < 1
		    (mboxFactoryDefault.getMboxes().length() < 1) &&  
			
			//Also check for high-volume pages that do not need global logging
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go") &&
			(windowURL != "bankofamerica.com/myaccounts/signin/signin.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/entry/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signonscreen.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatechallengeanswer.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatePassword.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/mobile/banking.go")&&
			(windowURL != "bankofamerica.com/content/preload/olb-myaccount-preload-jawr-module.htm")
			)
		{

			var mboxDiv = document.createElement("div");
			mboxDiv.id = "adobe_touch_clarity_replacement";
			mboxDiv.style.display = "none";
			if (document.body && document.body.firstChild) document.body.insertBefore(mboxDiv,document.body.firstChild);
			mboxDefine(mboxDiv.id,'bac_global_bottom');
			mboxUpdate('bac_global_bottom');
		}
	}	
})();
</script>

		<script src="https://www2.bac-assets.com/pa/components/bundles/gzip-compressed/xengine/Global/1.0/script/tealeafbundle.js" type="text/javascript"></script>
			<script>
				var boaPageDataJS = {};
					boaPageDataJS.isLLE = "false";
			</script>
				<style>body{display:none;}</style>
	</head>		

	<body class="fsd-layout-body">	

				<script type="text/javascript">if(self == top){var theBody=document.getElementsByTagName("body")[0];theBody.style.display="block";}else{top.location=self.location;}</script>
				<noscript><style>body{display:block;}</style></noscript>
					<a class='ada-hidden ada-visible-focus' href='#skip-to-h1' id='ada-skip-link'>Skip to main content</a>
		<div class="fsd-layout fsd-2c-700lt-layout">
			<div class="fsd-border">
				<div class="center-content">
					<div class="header">


 


<div class="header-module">
	<div class="text-w-logo-skin">
		<div class="header-left">
	  
			<div itemscope itemtype="http://schema.org/Corporation" class="bofa-logo">
				<a itemprop="url" name="anc-online-banking" title="Bank of America" href="/">
					<img itemprop="logo" height="28" width="221" 
					     alt="Bank of America" src="https://www2.bac-assets.com/content/images/ContextualSiteGraphics/Logos/en_US/boa_logo.gif"/>
				</a>
			</div>
				<div class="product" data-font="cnx-regular">Online Banking</div>
			
			<div class="clearboth"></div>

		</div>
		
		<div class="header-right">
			<ul class="header-links">
			
				
					
				
							<li class="sign-in">
		<a					href="/sitemap/hub/signin.go" target="_self"
		name="Sign In">Sign In</a> 
							</li>
					
				
							<li>		<a					href="/" target="_self"
		name="Home">Home</a> 
</li>
					
				
							<li>		<a					href="http://locators.bankofamerica.com/locator/locator/LocatorAction.do" target="_self"
		name="Locations">Locations</a> 
</li>
					
				
							<li>		<a					href="/contactus/contactus.go" target="_self"
		name="Contact Us">Contact Us</a> 
</li>
					
				
							<li>		<a					href="/help/overview.go" target="_self"
		name="Help">Help</a> 
</li>
					
				
							<li class="last-link">	
									<a href="/online-banking/service-agreement.go?request_locale=es_US" name="En espa&#241;ol" target="_self">En espa&#241;ol</a> 				
							</li>
			</ul>
			
			<div class="clearboth"></div>

			<!-- include search-dotcom-util -->



<div class="header-search nlh">
  
  <div class="nav-search">
    <form class="search-form" action="https://secure.bankofamerica.com/myaccounts/public/search-results/unAuthenticatedSearch.go" data-js="/pa/components/utilities/search-util/1.0/script/nav-search.min.js" data-css="/pa/components/utilities/search-util/1.0/style/nav-search.css" data-text-unavailable="Search Currently Unavailable">
      <div class="search-input-container cf" data-icon="search">
        <label for="nav-search-query" class="ada-hidden">Search Term</label>
        <input type="text" placeholder="How can we help you?" name="query" class="search-query" id="nav-search-query" 
          maxlength="99" rel="Search" autocomplete="off"><input type="submit" alt="Search" title="Search" value="Submit Search" name="Search Module - Top Result – Search Button" class="submit track-me">
      </div>
    </form>
  </div>

</div>

		</div>

 		<div class="clearboth"></div>
 	</div>
</div>

<div class="page-title-fsd-module h-100" id="skip-to-h1">
	<div class="standard-red-skin sup-ie">
			<h1 data-font="cnx-regular">Online Banking Service Agreement</h1>
	</div>
</div>		  



<script language="javascript" src="/pa/components/modules/tag-manager-module/1.1/script/tag-manager-module-borneo-global-skin.js"></script>
<script>

(function() {
  var fireCallback = function( cb ) {
    if ( typeof cb === "function" ) cb();
  };
  
  function ddoPopulateBase( callback ) {
    try {
		  var DDO = window.digitalData,
		  	bactm_mergeDDO = function( newDDO, priorDDO ) {
		  		if( typeof priorDDO === "undefined" ) {
				  	priorDDO = digitalData || {};
				  }

			    for (var l in newDDO) {
			        if (typeof priorDDO[l] === "undefined") {
			            priorDDO[l] = newDDO[l];
			        }
			        if (newDDO[l] !== null) {
			            if (typeof newDDO[l] === "object") {
			                bactm_mergeDDO(newDDO[l], priorDDO[l]);
			            } else {
			                priorDDO[l] = bactm_validateValue( newDDO[l] ) ? newDDO[l] : priorDDO[l];
			            }
			        }
			    }

			    return priorDDO;
				},
				bactm_olb3rdPartyId = "null";

			if (typeof DDO === "undefined") {
				var simpleDDO = { page: { pageInfo:[{ pageID: null }], attributes: {}, category: { primaryCategory: null }}};

				DDO = (typeof digitalData === "object") ? digitalData : simpleDDO; 
			}

				DDO = bactm_mergeDDO( {pageInstanceID:"notprod",load_coremetrics:false,load_opinionlabs:false,load_touchcommerce:true,load_audiencemanager:true,page:{pageInfo:[{pageID:null,destinationURL:null,referringURL:null,issueDate:null,language:null,segmentValue:null,appName:null,appStepNumber:null,appStepName:null,attr:"-_--_--_--_--_--_--_--_--_--_--_--_--_--_-"}],category:{primaryCategory:null,addlCategory:null,pageType:null},attributes:{searchString:null,searchResults:null,olbSessionID:null,subCampaignCode:null,DARTUrl:null,stateCookie:null,SASIEnabled:false,needOLBcookie:false,standardDART:[],standardDARTes:[],clickDART:[],clickDARTes:[],gaId:[],chat:{account_type:null,boa_associate:null,boa_retiree:null,customer_lob:null,customer_segment:null,data:null,email_campaign:null,entitlement_code:null,error_category:null,error_count:null,first_login:null,inqSalesProductTypes:{},invitation_background:null,invitation_template:null,referral_campaign:null,getStateValue:false,cust_fn:null,cust_ln:null,target:null}}},user:{segment:null,online_id:null,preferred_rewards_tier:null,olb3rdpartyid:null},version:"BAC_0.12"}, DDO );

			DDO.page.pageInfo[0].pageID = "";
			DDO.page.category.primaryCategory  = "";
			DDO.page.pageInfo[0].language = "en-US";
			DDO.page.attributes.olbSessionID = "null";
			DDO.page.attributes.SASIEnabled =  "false";
			if (typeof DDO.user != "undefined" && typeof DDO.user.olb3rdpartyid != "undefined") {
				DDO.user.olb3rdpartyid = bactm_olb3rdPartyId;
			}

			window.utag_data = {};
			window.bactm_envSelector = bactm_setTMLib();
			window.digitalData = DDO;

      return fireCallback( callback );

    } catch(e) { }
  }
	if( window.boa && window.boa.digitalData ) {
    window.boa.digitalData.register( ddoPopulateBase );
	}
	else {
	  // Handle scenario where the header isn't available (and thus the default digitalData object and utag loader are missing).
	  //
		var writeScript = function(a,b,c,d){
			a='//tags.tiqcdn.com/utag/bofa/main/' + bactm_envSelector + '/utag.js';
			b=document;
			c='script';
			d=b.createElement(c);
			d.src=a;
			d.type='text/java'+c;
			d.async=true;
			a=b.getElementsByTagName(c)[0];
			a.parentNode.insertBefore(d,a);
		};

		ddoPopulateBase( writeScript );
	}
})();			
</script>

</div>
					<div class="columns">
						<div class="flex-col lt-col" >
<link type="text/css" rel="stylesheet" media="all" href="https://www2.bac-assets.com/pa/components/modules/service-agreement-module/1.2/style/service-agreement-module-com-skin.css">
<script type="text/javascript" src="https://www2.bac-assets.com/pa/components/modules/service-agreement-module/1.2/script/service-agreement-module-com-skin.js"></script>


<div class="service-agreement-module">
<div class="com-skin com-main-well-content table-vzd3-common embed-bullet">
<script type="text/javascript">
	var ADAShowTopicsText = "Show Topics for ";  
	var ADAHideTopicsText = "Hide Topics for ";  
</script>
<div class="intro-link"><a href="/onlinebanking/online-banking.go">
<span class="guillemet">&#8249;&#8249;&nbsp;</span>
Go to Online Banking Overview
</a></div>

<div class="h-100"><h2 id="back-to-top-anchor">
		<p>Online Banking and Transfers Outside Bank of America Service Agreement and Electronic Disclosure</p>
</h2></div>
<p class="eff-date">
		Effective Date: March 02, 2017
</p>
<p><strong>
		Table of Contents: 
</strong>	
<a href="javascript:void(0);" class="topic-toggle" id="show-topics">Show all Topics</a>
<a href="javascript:void(0);" class="hide topic-toggle">Hide all Topics</a>
</p>
<ol class="cat-list">
	
	
	<li><a href="javascript:void(0);" class="category-link"><span class="ada-hidden">Show Topics for</span>
			1. General Description of Online Banking and Transfers Outside Bank of America Service Agreement
		</a>
		<div class="section-intro"><a href="#cat1">Introduction</a></div>
		<ol type="A">
				<li><a href="#cat1_topic1">
					A. What This Agreement Covers
			   		 </a>
			 	</li>
				<li><a href="#cat1_topic2">
					B. Accepting the Agreement
			   		 </a>
			 	</li>
				<li><a href="#cat1_topic3">
					C. Relation to Other Agreements
			   		 </a>
			 	</li>
		</ol>
	</li>
	
	
	<li><a href="javascript:void(0);" class="category-link"><span class="ada-hidden">Show Topics for</span>
			2. Online Banking Services
		</a>
		<div class="section-intro"><a href="#cat2">Introduction</a></div>
		<ol type="A">
				<li><a href="#cat2_topic1">
					A. Online Banking for Consumers and Businesses
			   		 </a>
			 	</li>
				<li><a href="#cat2_topic2">
					B. Bill Payment Services
			   		 </a>
			 	</li>
				<li><a href="#cat2_topic3">
					C. Email/Mobile Transfer Network Service 
			   		 </a>
			 	</li>
				<li><a href="#cat2_topic4">
					D. Additional Services Intended for Businesses
			   		 </a>
			 	</li>
				<li><a href="#cat2_topic5">
					E. Online Banking Alerts
			   		 </a>
			 	</li>
				<li><a href="#cat2_topic6">
					F. Mobile Text Alerts
			   		 </a>
			 	</li>
				<li><a href="#cat2_topic7">
					G. ShopSafe<sup>&reg;</sup>
			   		 </a>
			 	</li>
		</ol>
	</li>
	
	
	<li><a href="javascript:void(0);" class="category-link"><span class="ada-hidden">Show Topics for</span>
			3. Description of Online Banking Services (does not apply to Transfers Outside Bank of America)
		</a>
		<div class="section-intro"><a href="#cat3">Introduction</a></div>
		<ol type="A">
				<li><a href="#cat3_topic1">
					A. Transfers (does not apply to Email/Mobile Transfers or Transfers Outside Bank of America, except as otherwise provided)
			   		 </a>
			 	</li>
				<li><a href="#cat3_topic2">
					B. Online Banking Bill Payment Processing
			   		 </a>
			 	</li>
				<li><a href="#cat3_topic3">
					C. Email/Mobile Transfer Network Service 
			   		 </a>
			 	</li>
				<li><a href="#cat3_topic4">
					D. Limitations and Dollar Amounts for Transfers and Payments (does not apply to Transfers Outside Bank of America)
			   		 </a>
			 	</li>
				<li><a href="#cat3_topic5">
					E. Transfer/Payment Authorization and Sufficient Available Funds
			   		 </a>
			 	</li>
				<li><a href="#cat3_topic6">
					F. Canceling Transfers and Payments (does not apply to Transfers Outside Bank of America)
			   		 </a>
			 	</li>
				<li><a href="#cat3_topic7">
					G. Our Liability for Failure to Cancel or Stop the Transfer or Payment
			   		 </a>
			 	</li>
				<li><a href="#cat3_topic8">
					H. E-Bills
			   		 </a>
			 	</li>
				<li><a href="#cat3_topic9">
					I. Accounts Linked to Your Online Banking Services (does not apply to Transfers Outside Bank of America)
			   		 </a>
			 	</li>
				<li><a href="#cat3_topic10">
					J. Activity Levels for Linked Accounts
			   		 </a>
			 	</li>
		</ol>
	</li>
	
	
	<li><a href="javascript:void(0);" class="category-link"><span class="ada-hidden">Show Topics for</span>
			4. Other Terms and Conditions
		</a>
		<div class="section-intro"><a href="#cat4">Introduction</a></div>
		<ol type="A">
				<li><a href="#cat4_topic1">
					A. Monthly Service Charge
			   		 </a>
			 	</li>
				<li><a href="#cat4_topic2">
					B. Other Charges
			   		 </a>
			 	</li>
				<li><a href="#cat4_topic3">
					C. Service Hours
			   		 </a>
			 	</li>
				<li><a href="#cat4_topic4">
					D. Business Days
			   		 </a>
			 	</li>
				<li><a href="#cat4_topic5">
					E. Participation By Payees
			   		 </a>
			 	</li>
				<li><a href="#cat4_topic6">
					F. Canceling Your Online Banking
			   		 </a>
			 	</li>
				<li><a href="#cat4_topic7">
					G. Joint Accounts
			   		 </a>
			 	</li>
				<li><a href="#cat4_topic8">
					H. Changes to Agreement
			   		 </a>
			 	</li>
				<li><a href="#cat4_topic9">
					I. Cancellation
			   		 </a>
			 	</li>
				<li><a href="#cat4_topic10">
					J. Use of External Email Address
			   		 </a>
			 	</li>
				<li><a href="#cat4_topic11">
					K. Transfers From Money Market Deposit Accounts
			   		 </a>
			 	</li>
				<li><a href="#cat4_topic12">
					L. Contact by Bank of America or Affiliated Parties
			   		 </a>
			 	</li>
				<li><a href="#cat4_topic13">
					M. Reporting Unauthorized Transactions
			   		 </a>
			 	</li>
				<li><a href="#cat4_topic14">
					N. Initiating Payment Inquiries
			   		 </a>
			 	</li>
				<li><a href="#cat4_topic15">
					O. Disclosure of Account Information
			   		 </a>
			 	</li>
				<li><a href="#cat4_topic16">
					P. Account Statements and Documents
			   		 </a>
			 	</li>
				<li><a href="#cat4_topic17">
					Q. Mobile Single Text Messaging For Financial Center Transactions
			   		 </a>
			 	</li>
		</ol>
	</li>
	
	
	<li><a href="javascript:void(0);" class="category-link"><span class="ada-hidden">Show Topics for</span>
			5. Additional Provisions Applicable Only to Consumer Accounts
		</a>
		<div class="section-intro"><a href="#cat5">Introduction</a></div>
		<ol type="A">
				<li><a href="#cat5_topic1">
					A. In Case of Errors or Questions About Your Electronic Transactions
			   		 </a>
			 	</li>
				<li><a href="#cat5_topic2">
					B. Limitation of Liability for Online Banking Transactions
			   		 </a>
			 	</li>
				<li><a href="#cat5_topic3">
					C. Our Liability for Failure to Complete Transactions
			   		 </a>
			 	</li>
				<li><a href="#cat5_topic4">
					D. Our Liability for Transfers Outside Bank of America
			   		 </a>
			 	</li>
		</ol>
	</li>
	
	
	<li><a href="javascript:void(0);" class="category-link"><span class="ada-hidden">Show Topics for</span>
			 6. Additional Provisions Applicable Only to Business Accounts
		</a>
		<div class="section-intro"><a href="#cat6">Introduction</a></div>
		<ol type="A">
				<li><a href="#cat6_topic1">
					A. Protecting Passcodes
			   		 </a>
			 	</li>
				<li><a href="#cat6_topic2">
					B. Acknowledgment of Commercially Reasonable Security Procedures
			   		 </a>
			 	</li>
				<li><a href="#cat6_topic3">
					C. Limitation of Bank's Liability (does not apply to Transfers Outside Bank of America or Direct Payments Service)
			   		 </a>
			 	</li>
		</ol>
	</li>
	
	
	<li><a href="javascript:void(0);" class="category-link"><span class="ada-hidden">Show Topics for</span>
			7. Additional Services Intended for Businesses
		</a>
		<div class="section-intro"><a href="#cat7">Introduction</a></div>
		<ol type="A">
				<li><a href="#cat7_topic1">
					A. Creating and Managing Users
			   		 </a>
			 	</li>
				<li><a href="#cat7_topic2">
					B. Linking Accounts of Additional Businesses and Personal Accounts
			   		 </a>
			 	</li>
				<li><a href="#cat7_topic3">
					C. Contacting Bank of America
			   		 </a>
			 	</li>
				<li><a href="#cat7_topic4">
					D. Business Payroll Services
			   		 </a>
			 	</li>
		</ol>
	</li>
	
	
	<li><a href="javascript:void(0);" class="category-link"><span class="ada-hidden">Show Topics for</span>
			8. Transfers Outside Bank of America Services
		</a>
		<div class="section-intro"><a href="#cat8">Introduction</a></div>
		<ol type="A">
				<li><a href="#cat8_topic1">
					A. Transfers Outside Bank of America for Online Banking Customers
			   		 </a>
			 	</li>
				<li><a href="#cat8_topic2">
					B. Initiating and Scheduling transfers
			   		 </a>
			 	</li>
				<li><a href="#cat8_topic3">
					C. Cancelling Transfers
			   		 </a>
			 	</li>
				<li><a href="#cat8_topic4">
					D. Transfer Fees for Transfers Outside of Bank of America Services
			   		 </a>
			 	</li>
				<li><a href="#cat8_topic5">
					E. Dollar Limits
			   		 </a>
			 	</li>
				<li><a href="#cat8_topic6">
					F. Processing Transfers and Disqualifying Events
			   		 </a>
			 	</li>
				<li><a href="#cat8_topic7">
					G. Liability
			   		 </a>
			 	</li>
				<li><a href="#cat8_topic8">
					H. Special Rules for Remittance Transfers
			   		 </a>
			 	</li>
				<li><a href="#cat8_topic9">
					I. Additional Rules for International Outbound Transfers
			   		 </a>
			 	</li>
		</ol>
	</li>
	
	
	<li><a href="javascript:void(0);" class="category-link"><span class="ada-hidden">Show Topics for</span>
			9. BankAmeriDeals<sup>&reg;</sup>
		</a>
		<div class="section-intro"><a href="#cat9">Introduction</a></div>
		<ol type="A">
				<li><a href="#cat9_topic1">
					A. Redeeming BankAmeriDeals
			   		 </a>
			 	</li>
				<li><a href="#cat9_topic2">
					B. Eligible Cards
			   		 </a>
			 	</li>
				<li><a href="#cat9_topic3">
					C. Participating Retailers
			   		 </a>
			 	</li>
				<li><a href="#cat9_topic4">
					D. Hiding or Opting Out of Receiving BankAmeriDeals
			   		 </a>
			 	</li>
				<li><a href="#cat9_topic5">
					E. Reporting an Error in the Cash Back Amount
			   		 </a>
			 	</li>
		</ol>
	</li>
	
	
	<li><a href="javascript:void(0);" class="category-link"><span class="ada-hidden">Show Topics for</span>
			10. My Portfolio Service (Not available through Mobile Banking Apps or Mobile Web)
		</a>
		<div class="section-intro"><a href="#cat10">Introduction</a></div>
		<ol type="A">
				<li><a href="#cat10_topic1">
					A. Relationship to Other Agreements
			   		 </a>
			 	</li>
				<li><a href="#cat10_topic2">
					B. Description of My Portfolio
			   		 </a>
			 	</li>
				<li><a href="#cat10_topic3">
					C. Description of Real Estate Center
			   		 </a>
			 	</li>
				<li><a href="#cat10_topic4">
					D. Provide Accurate Information
			   		 </a>
			 	</li>
				<li><a href="#cat10_topic5">
					E. Proprietary Rights
			   		 </a>
			 	</li>
				<li><a href="#cat10_topic6">
					F. User Conduct
			   		 </a>
			 	</li>
				<li><a href="#cat10_topic7">
					G. Restriction on Commercial Use or Resale
			   		 </a>
			 	</li>
				<li><a href="#cat10_topic8">
					H. Your Indemnification of the Bank
			   		 </a>
			 	</li>
				<li><a href="#cat10_topic9">
					I. My Portfolio Service Limitations
			   		 </a>
			 	</li>
				<li><a href="#cat10_topic10">
					J. Third Party Products and My Portfolio
			   		 </a>
			 	</li>
				<li><a href="#cat10_topic11">
					K. Privacy and My Portfolio
			   		 </a>
			 	</li>
				<li><a href="#cat10_topic12">
					L. Changes or Cancellation
			   		 </a>
			 	</li>
				<li><a href="#cat10_topic13">
					M. Third Party Beneficiary
			   		 </a>
			 	</li>
		</ol>
	</li>
	
	
	<li><a href="javascript:void(0);" class="category-link"><span class="ada-hidden">Show Topics for</span>
			11. FICO<sup>&reg;</sup> Score Program for Consumer Credit Card Customers (Not available for all Mobile Banking Apps)
		</a>
		<div class="section-intro"><a href="#cat11">Introduction</a></div>
		<ol type="A">
				<li><a href="#cat11_topic1">
					A. Enrollment in the FICO<sup>&reg;</sup> Score Program
			   		 </a>
			 	</li>
				<li><a href="#cat11_topic2">
					B. Email and Text Notifications
			   		 </a>
			 	</li>
				<li><a href="#cat11_topic3">
					C. FICO<sup>&reg;</sup> Score Display
			   		 </a>
			 	</li>
				<li><a href="#cat11_topic4">
					D. Eligibility
			   		 </a>
			 	</li>
				<li><a href="#cat11_topic5">
					E. About TransUnion and FICO<sup>&reg;</sup> Scores
			   		 </a>
			 	</li>
				<li><a href="#cat11_topic6">
					F. Bank of America is Not a Credit Repair Organization
			   		 </a>
			 	</li>
		</ol>
	</li>
	
	
			<li><a href="#cat12" class="category-link">
			12. Additional Services (Not available through Mobile Banking Apps or Mobile Web)
	   		 </a>
	   		 </li>
</ol>
<div class="sa-main-content">
<!--First Heading-->
	<div class="h-100">
		<h3 id="cat1">
				1. General Description of Online Banking and Transfers Outside Bank of America Service Agreement
		</h3>
	</div>
	
		<div class="h-100">
			<h4 id="cat1_topic1">
					A. What This Agreement Covers
			</h4>
		</div>
			<p><br />This Agreement between you and Bank of America, N.A (Bank of America) governs the use of Online Banking services and the Transfers Outside Bank of America service. These services permit U.S.-based Bank of America customers (consumers and business customers who are account owners) to perform a number of banking functions through the use of a personal computer or, for some functions, a mobile device (e.g., tablet or Smartphone), on accounts linked to the service, including some with our affiliates, Merrill Lynch, Pierce, Fenner &amp; Smith Incorporated ("MLPF&amp;S"). Unless indicated otherwise by the context, "linked Bank of America accounts" or "linked accounts" refers to all of your U.S.-based accounts with Bank of America that you have linked to Online Banking or Transfers Outside Bank of America. When used in this Agreement, the term &ldquo;business&rdquo; includes sole proprietors, non-consumer business entities, and individual owners of the business, unless the context indicates otherwise.</p>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
		<div class="h-100">
			<h4 id="cat1_topic2">
					B. Accepting the Agreement
			</h4>
		</div>
			<p><br />When you use any of the Online Banking services described in this Agreement or Transfers Outside Bank of America, or authorize others to use them, you agree to the terms and conditions of the entire Agreement.</p>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
		<div class="h-100">
			<h4 id="cat1_topic3">
					C. Relation to Other Agreements
			</h4>
		</div>
			<p><br />Your use of Online Banking services or Transfers Outside Bank of America may also be affected by a deposit or other agreement between us for your linked Bank of America accounts. When you link an account to Online Banking services or Transfers Outside Bank of America, you do not change the agreements you already have with us for that account. For example, if you link a MLPF&amp;S investment account to Online Banking, the terms and conditions of your MLPF&amp;S customer agreement(s) and/or user agreement(s) do not change. Similarly, when you use Online Banking services to access a credit account, you do so under the terms and conditions we gave you in the agreement and disclosure for the credit account. You should review those and other Bank of America account-related&nbsp;agreements and fee schedules for any applicable fees, for limitations on the number of transactions you can make, liability rules for electronic fund transfers, and for other restrictions that might impact your use of an account with Online Banking services or Transfers Outside Bank of America.</p>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
	<div class="h-100">
		<h3 id="cat2">
				2. Online Banking Services
		</h3>
	</div>
	
		<p>Note: If you access Online Banking or Transfers Outside Bank of America through Bank of America's Downloadable Mobile Banking Applications ("Mobile Banking Apps"), the mobile-optimized version of the Bank of America website ("Mobile Web"), Personal Financial Management (PFM) software, or through an indirect service, all of the features of Online Banking or Transfers Outside Bank of America may not be available, including, but not limited to, bill presentment. To access all of the features and services offered by Online Banking and Transfers Outside Bank of America, sign in directly through our web site at <a href="https://www.bankofamerica.com" title="www.bankofamerica.com" name="www.bankofamerica.com">www.bankofamerica.com</a>&nbsp;from a personal computer. Within Online Banking, you can also access optional services such as Bill Payment. Please refer to this Agreement, your applicable account agreement or fee schedule for information on fees for optional services.</p>
		<div class="h-100">
			<h4 id="cat2_topic1">
					A. Online Banking for Consumers and Businesses
			</h4>
		</div>
			<p><br />You may use Online Banking to:</p>
<ul class="tc-disc">
<li>Transfer funds between your linked Bank of America accounts on either a one-time or recurring basis, including as a payment to a linked installment loan or mortgage.</li>
<li>Transfer funds between linked Bank of America business accounts and linked personal accounts.</li>
<li>Transfer funds from your linked Bank of America personal or small business accounts to most Bank of America personal or small business deposit accounts.</li>
<li>Transfer funds between your linked MLPF&amp;S investment accounts and your linked Bank of America accounts on either a one-time or recurring basis.</li>
<li>View current balance information for your linked Bank of America accounts.</li>
<li>Review available transactions for your linked accounts.</li>
<li>Perform self-service account maintenance such as re-ordering checks, ordering copies of paid checks, requesting copies of monthly checking (<span style="color: #333333;">including SafeBalance Banking<sup>TM</sup>)</span><span style="line-height: 115%; font-family: 'Verdana','sans-serif'; color: #333333; font-size: 7.5pt; mso-fareast-font-family: 'Times New Roman'; mso-ansi-language: EN-US; mso-fareast-language: EN-US; mso-bidi-language: AR-SA; mso-bidi-font-family: 'Times New Roman';">&nbsp;</span>or saving statements, stopping payment on checks, changing address and phone, and changing your Online ID and Online passcode.</li>
<li>Send us secure online mail messages and questions regarding your Online Banking service.</li>
</ul>
<p><br />Some of the above services may not be available for certain accounts or customers, or if you access Online Banking through Mobile Banking Apps or Mobile Web.</p>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
		<div class="h-100">
			<h4 id="cat2_topic2">
					B. Bill Payment Services
			</h4>
		</div>
			<p><br />In addition to the Online Banking features listed above, Bank of America customers with eligible deposit accounts may also use the optional Bill Payment service.</p>
<p>If you are a Bank of America customer with a deposit account, you may use the Bill Payment service to:</p>
<ul class="tc-disc">
<li>Make one-time or recurring payments online from your linked checking account(s) (including SafeBalance Banking<sup>TM</sup>), and money market deposit account(s) to companies or individuals (Payees) you select.</li>
<li>Make one-time or recurring payments online from your linked Home Equity Line of Credit (HELOC) account(s) to a limited group of merchants (does not apply to HELOC accounts opened in the state of Texas).</li>
<li>Add personal checking or money market account(s) that you maintain at another financial institution through the <strong>Add an Account from Another Bank </strong>feature in the bill payment service. Make one-time or recurring payments online from such accounts to a limited group of merchants or Bank of America loan, credit card, charge card and/or line of credit accounts.</li>
<li>Use the e-Bills feature to:
<ul class="tc-circle">
<li>Receive bills from participating Payees</li>
<li>View Payee bill summary and bill detail information.</li>
</ul>
</li>
</ul>
<p><br />If you are a customer with a Bank of America credit card-only or charge card-only relationship, or with a business line of credit-only or vehicle loan-only relationship (automotive, recreational vehicle, boat or aircraft), you may:</p>
<ul class="tc-disc">
<li>Make one time or automatic payments online from a deposit or money market deposit account maintained at another financial institution to your Bank of America credit card(s), charge card(s), business line of credit(s) and/or vehicle loan account(s).</li>
<li>Receive credit card, charge card, business line of credit and/or vehicle loan e-Bills from Bank of America and view bill summary and detail information.</li>
</ul>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
		<div class="h-100">
			<h4 id="cat2_topic3">
					C. Email/Mobile Transfer Network Service 
			</h4>
		</div>
			<p class="mtop-15">In addition to the Transfer services listed in 2.A above, Email/Mobile Transfers allows you to send money from your&nbsp;Bank of America personal checking or savings account to another Bank of America customer or a customer of another U.S based bank by using a recipient's email address or mobile phone number. Another Bank of America customer or a customer of a different U.S. based bank may also send money to your personal or small business account using your email address or mobile phone number. Please note that there are dollar amount and other limits for these transfers that may differ from the other Transfers services, as provided in Section 3.D below.</p>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
		<div class="h-100">
			<h4 id="cat2_topic4">
					D. Additional Services Intended for Businesses
			</h4>
		</div>
			<p><br />We offer businesses the ability to create multiple Online IDs each with the access level you designate. In some circumstances, we also permit you to link the accounts of other businesses you own or control. See Section 7 below for special registration procedures and applicable terms.</p>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
		<div class="h-100">
			<h4 id="cat2_topic5">
					E. Online Banking Alerts
			</h4>
		</div>
			<p><br />We provide three types of Online Banking Alerts:</p>
<ol>
<li>General &amp; Security Alerts are sent to you following important account activities or when certain changes are made online to your Online Banking account, such as a change in your email or home address, telephone number, Online ID or passcode, insufficient funds, or irregular card activity. You do not need to activate these alerts. We automatically activate them for you. Although you have the option to suppress these General &amp; Security&nbsp;Alerts, we strongly recommend that you do not do so since they provide important information related to your online security or account activities.</li>
<li class="mtop-15">Account Alerts, which&nbsp;must be activated by you.
<ul class="tc-disc" style="list-style-type: square;">
<li>Account Alerts allow you to choose optional alert messages for your accounts.</li>
<li>Each Account Alert has different options available, and you will be asked to select from among these options upon activation of an Account Alert.</li>
</ul>
</li>
<li>Automatic Alerts are sent to your primary email address only and provide you with important account notifications, such as information about a money transfer&nbsp; or availability of an eStatement.&nbsp;
<ul class="tc-disc" style="list-style-type: square;">
<li>You do not have the option to suppress these Automatic Alerts.</li>
</ul>
</li>
</ol>
<p>Alerts are subject to the following:&nbsp;</p>
<ul class="tc-disc" style="list-style-type: square;">
<li>We may add new Alerts from time to time, or cancel old alerts. We usually notify you when we cancel alerts, but are not obligated to do so.</li>
<li>Alerts will be sent to the email address you have provided as your primary email address for Online Banking. For General &amp; Security and Account Alerts you can also choose to have&nbsp;these sent to a secondary email address, a mobile device that accepts text messages, or a mobile device that can receive our Mobile App Alerts through a push notification system. If your email address or your mobile device's number changes, you are responsible for informing us of that change. While Bank of America does not charge for the delivery of the alerts, please be advised that text or data charges or rates may be imposed by your carrier. Your alerts will be updated to reflect the changes that you communicate to us with regard to your primary and secondary email addresses or mobile device number.</li>
<li>We do our best to provide alerts in a timely manner with accurate information, but alerts may be delayed or prevented by a variety of factors beyond our control (such as system failures or misdirected delivery). We don't guarantee the delivery or accuracy of alerts. The contents of an alert may be outdated by the time an alert is sent or received, due to other activity on your account or to delays in sending data among various systems. You agree that we are not liable for any delays, failure to deliver, or misdirected delivery of any alert; for any errors in the content of an alert or for any actions taken or not taken by you or a third party as the result of an alert.</li>
<li>Because alerts are not encrypted, we will never include your passcode or full account number. However, alerts may include your name and some information about your accounts. Depending upon the type of alert, information such as your account&nbsp;balance, transaction information or the due date for your credit card, charge card and/or business line of credit payment may be included. Anyone with access to your alerts will be able to view the contents of these messages.</li>
</ul>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
		<div class="h-100">
			<h4 id="cat2_topic6">
					F. Mobile Text Alerts
			</h4>
		</div>
			<p>1.&nbsp; Online Banking Alerts via Text Message<br /><br />You have the option of adding a mobile phone number to your Online Banking profile.&nbsp; By adding a mobile phone number to your Online Banking profile, you are certifying that you are the account holder for the mobile phone account or have the account holder's permission to use the mobile phone number for Online Banking.&nbsp; You are also consenting to receive Online Banking Alerts via text messages as further described in Section 2.E.&nbsp; Text message fees may apply.&nbsp; Text messages may be transmitted automatically.<br /><br />Message frequency varies by account and preferences. Message and Data Rates may apply. You can text STOP to MyBofA (692632) at any time to stop the mobile alerts that you activate on the Alerts page in Online Banking desktop. Alerts sent to your primary email address will be unaffected by this action.&nbsp; To restore Alerts on your mobile phone, just visit the Alerts tab in Online Banking and click the box next to your mobile number for the alerts you'd like to receive again.&nbsp; For help with SMS text alerts, send the word HELP to 692632 or call us at 800.604.9961.<br /><br /><strong>Supported Carriers:<br /></strong>AT&amp;T, Sprint, Verizon Wireless, T-Mobile, Cricket, and MetroPCS</p>
<p>2.&nbsp; Fraud Alerts via Text Message<br /><br />We may also send you credit card, charge card, business line of credit and/or debit card fraud text alerts to your mobile phone number in your Online Banking profile when applicable.<br /><br />Credit fraud alerts coming from 322632 will be a Free to End User (FTEU) campaign. However, data rates may apply depending of your mobile carrier plan. You can opt out of this campaign at anytime by sending the word STOP to 322632.&nbsp; For help with SMS, send the word HELP to 322632 or call us at 800-427-2449.<br /><br /><strong>Supported Carriers for Credit Card, Charge Card, and/or Business Line of Credit Fraud Alerts:</strong><br />AT&amp;T, Sprint, Verizon Wireless, T-Mobile, and Cricket<br /><br />Debit fraud alerts coming from 35422 will be a Free to End User (FTEU) campaign. However, data rates may apply depending of your mobile carrier plan. You can opt out of this campaign at anytime by sending the word STOP to 35422.&nbsp; For help with SMS, send the word HELP to 35422 or call us at 855-926-5104.&nbsp;&nbsp; <br /><br /><strong>Supported Carriers for Debit Card Fraud Alerts:</strong><br />AT&amp;T, Sprint, Verizon Wireless, T-Mobile, and MetroPCS<br /><br />For information about our privacy and security practices and a link to our U.S. Consumer Privacy Notice, go to our Web site at <a href="https://www.bankofamerica.com/privacy">https://www.bankofamerica.com/privacy</a>.</p>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
		<div class="h-100">
			<h4 id="cat2_topic7">
					G. ShopSafe<sup>&reg;</sup>
			</h4>
		</div>
			<p><br />We provide the ShopSafe<sup>&reg;</sup> service to allow you to create a unique, temporary credit card account number for online purchases at a specified merchant. The number links to the real credit card number, but keeps that number private and protected. The 16-digit ShopSafe<sup>&reg;</sup> number is used just like any other credit card account number.</p>
<p>ShopSafe<sup>&reg;</sup> allows you to set a dollar limit for purchases at a specified merchant. When we consider it appropriate, we may permit charges in addition to your preset dollar limit to allow for shipping, handling and taxes, which may not have been taken into consideration at the time of purchase.</p>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
	<div class="h-100">
		<h3 id="cat3">
				3. Description of Online Banking Services (does not apply to Transfers Outside Bank of America)
		</h3>
	</div>
	
		<div class="h-100">
			<h4 id="cat3_topic1">
					A. Transfers (does not apply to Email/Mobile Transfers or Transfers Outside Bank of America, except as otherwise provided)
			</h4>
		</div>
			<ul class="tc-disc">
<li>Processing of Transfer Requests
<ul class="tc-circle">
<li>Transfers can be made in 2 ways, on a 1-time or recurring basis. One-time transfers may be immediate or scheduled for a future date. The recurring transfer feature may be used when a set amount is transferred at regular intervals. For example, a $100 transfer from a checking to a savings account which occurs every 2 weeks.</li>
<li>One-time immediate transfers can be made from a linked Bank of America checking, savings, money market, line of credit, credit card, charge card, business line of credit or brokerage account to most linked Bank of America accounts.</li>
<li>Scheduled and recurring transfers can be made from a linked Bank of America checking, savings, money market, credit card, charge card or business line of credit account to a linked checking or savings account.</li>
<li>Scheduled and recurring transfers can be made between a linked MLPF&amp;S investment account and a linked Bank of America checking, savings or money market account.</li>
<li>Transfers can be made from a linked Bank of America personal or small business checking, savings, money market or line of credit account to most personal or small business checking, savings, or money market accounts of other Bank of America customers. Some account types, including those with foreign addresses, cannot be set up to receive funds.</li>
<li>Transfers from a deposit account (excluding investment accounts) are immediately reflected in the account's available balance. Transfers from a credit card, charge card, business line of credit or a line of credit account are immediately reflected in the account's available credit amount. Transfers from a MLPF&amp;S investment account are immediately reflected in the account's available balance.</li>
</ul>
</li>
<li>Scheduled and Recurring Transfers
<ul class="tc-circle">
<li>Transfers scheduled for a weekend or a non-bank business day will be processed on the prior bank business day. All other scheduled and recurring transfers will be processed from the funding account at the beginning of the business day requested.</li>
</ul>
</li>
<li>Transfers to Credit Accounts
<ul class="tc-circle">
<li>Funds transferred as a payment to a credit card, charge card, business line of credit, line of credit, installment loan or mortgage account before 11:59 p.m. ET will be credited with the date the payment is submitted. Transfer payments submitted after 11:59 p.m. ET will be credited with the next day's date. Updates to account balances, funds availability, and transaction posting may take up to 2 bank business days.</li>
</ul>
</li>
<li>Transfers to Deposit Accounts
<ul class="tc-circle">
<ul class="tc-circle">
<li>Funds transferred to a deposit account (excluding transfers from a credit card, charge card or business line of credit) prior to 10:45 p.m. ET on a business day will appear with the same day's date in the deposit account transaction history.</li>
<li>Transfers to a Bank of America checking account or money market savings made after 10:45 p.m. as described above on a business day but before 11:59 p.m. as shown in the table below will be included in the balance we use to pay transactions that night. This process may impact when fees apply to your account. Credits can help you avoid overdrafts, returned items and related fees. However, debits may cause you to incur overdrafts, returned items and related fees. Please note that although these transfers are included in the balance we use to pay transactions that night, they will appear with our next business day's date in the deposit account transaction history.</li>
</ul>
</ul>
<br />
<table class="tc-tablardata" style="width: 100%;" cellspacing="0" cellpadding="0" summary="Contact details for various states" border="0">
<tbody>
<tr><th scope="col"><strong>State Where Account Was Opened</strong></th><th scope="col"><strong>After Business Day Cut-Off Transaction Deadline</strong></th></tr>
<tr>
<td><strong>CA </strong></td>
<td><strong>11:59 p.m. PT</strong></td>
</tr>
<tr>
<td><strong>AR, AZ, CO, IA, ID, IL, IN, KS, MI, MN, MO,&nbsp;NM, NV, OK, OR, TX, WA</strong></td>
<td><strong>11:59 p.m. CT</strong></td>
</tr>
<tr>
<td><strong>CT, DC, DE, FL, GA, MA, MD, ME, NC, NH, NJ, NY, PA, RI, SC, TN, VA</strong></td>
<td><strong>11:59 p.m. ET</strong></td>
</tr>
</tbody>
</table>
<ul class="tc-circle">
<li>Please note, transfers to any deposit account on a Saturday, Sunday or bank holiday, will appear with our next business day's date in the deposit account transaction history.</li>
<li>All transfers submitted to a deposit account (such as checking, savings, money market) are immediately reflected in the account's available balance.</li>
</ul>
</li>
<li>Transfers to or from MLPF&amp;S Investment Accounts
<ul class="tc-circle">
<li>Transfers submitted to or from an MLPF&amp;S investment account before the cut-off time of 4:45 p.m. ET on a bank business day are posted to your investment account on the same day. All transfers submitted after the cut-off time or on a non bank business day are posted to your investment account at the beginning of the next bank business day following the day the transfer was submitted.</li>
</ul>
</li>
</ul>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
		<div class="h-100">
			<h4 id="cat3_topic2">
					B. Online Banking Bill Payment Processing
			</h4>
		</div>
			<p><br />1.&nbsp; Bill Pay for Checking, Money Market and Home Equity Line of Credit Accounts (Not Applicable to SafeBalance Banking<sup>TM</sup>)</p>
<p>Bank of America customers with a checking (excluding SafeBalance Banking<sup>TM</sup>), money market savings or home equity line of credit (HELOC) account may use the optional Bill Payment service in the following manner:</p>
<ul class="tc-disc">
<li>Payments can be scheduled from linked checking, money market savings, and HELOC accounts. (Does not apply to HELOC accounts opened in Texas or SafeBalance Banking<sup>TM</sup> accounts.)</li>
<li>Payments can be scheduled from a checking, money market savings or other consumer asset account maintained at another financial institution that you have added through the bill payment service. You certify that any account you add through the bill payment service is an account from which you are authorized to make payments, and any payment you make using the bill payment service will debit an account that you are legally authorized to use. When you add an account maintained at another financial institution, you do not change the agreements you have with that financial institution for that account. You should review those agreements for any applicable fees, for limitations on the number of transactions you can make, and for other restrictions that might limit your use of the account with the Bill Payment service.</li>
<li>Payments can be entered as a 1-time transaction up to a year in advance, recurring transactions or as payments that are automatically scheduled upon the receipt of an electronic bill (e-Bill).</li>
<li>Payments (other than payments to a Bank of America credit card account, charge card or business line of credit) entered on our system before 5:00 p.m. ET on a bank business day will be scheduled and begin processing on the same bank business day. Payments that are entered after this cut-off time or on a day that is a non-bank business day will be scheduled and processed the next bank business day.</li>
<li>Scheduled recurring payments that fall on a weekend or a non-bank business day will be processed on the prior bank business day.</li>
<li>You authorize us to make payments in the manner we select from the following methods:
<ul class="tc-circle">
<li>Electronic transmission. Most payments are made by electronic transmission.</li>
<li>Corporate check- This is a check drawn on our account or the account of our vendor. If a Payee on a corporate check fails to negotiate the check within 90 days, we will stop payment on the check and re-credit your account for the amount of the payment. If a corporate check is returned to you prior to the end of the 90 day period, please inform us immediately so that we can stop payment on the check and re-credit your account.</li>
<li>Personal check &ndash; This is a check drawn on your account based on your authorization under this Agreement.</li>
</ul>
</li>
<li>All payments under the Bill Payment service that are sent care of APO/FPO or similar addresses will be sent by corporate or personal check. Because all such payments will be made by check, they will not be Remittance Transfers (as defined in section 8 of this Agreement (Transfers Outside Bank of America Services).</li>
<li>Scheduling Bill Payments
<ul class="tc-circle">
<li>The scheduled delivery date is the date you enter for the payment to be delivered to the Payee. For payments made by electronic transmission or corporate check, the payment amount will be debited from, or charged to the account that you designate on the scheduled delivery date. If the scheduled delivery date is a weekend or non-bank business day, then the delivery date will be the prior bank business day. For payments made by personal check, the account you designate will be debited when the check is presented to us for payment which may occur before, on or after the scheduled delivery date.</li>
<li>For payments to a Bank of America loan, line of credit, or mortgage, Bank of America will process and credit the payment to the appropriate account effective the same business day, provided the payment is scheduled prior to the 5:00 p.m. ET cut-off.</li>
<li>For payments to Bank of America Gold Option and Gold Reserve accounts, Bank of America will process and credit the payment to the appropriate account effective the same day, provided the payment is scheduled prior to the 11:59 p.m. ET cut-off.</li>
</ul>
</li>
</ul>
<p>When you attempt to schedule a payment, we will inform you of the earliest available delivery date. To assure timely payment and obtain the full benefit of the Online Banking Guarantee, you must schedule payments and your account must be in good standing at least four (4) bank business days before the payment due date. If you do not, or if for any reason your account is not in good standing, you will be fully responsible for all late fees, interest charges or other action taken by the Payee. Under our Online Banking Guarantee, if we fail to process a payment in accordance with your properly completed instructions, we will reimburse you for any late-payment-related fees. If we are unable to complete the payment because of insufficient funds in your account or some other reason, we will send you an alert to the email address you have provided with this Agreement. We will also notify you if your account is no longer in good standing and eligible to be used for bill payments. As indicated above, some payments may be made by a personal check. Since we can't predict the exact date that a personal check will be presented to us for payment, please make sure you have sufficient funds in your account beginning a few days before your scheduled delivery date and keep such funds available until the payment is deducted from your account.</p>
<p>2.&nbsp; Bill Pay for SafeBalance Banking<sup>TM</sup> Accounts<br /><br />Bank of America customers with SafeBalance Banking<sup>TM</sup> account may use optional Bill Payment service in the following manner:</p>
<ul>
<li>Payments can be entered as a 1-time transaction up to a year in advance, recurring transactions or as payments that are automatically scheduled upon the receipt of an electronic bill (e-Bill).</li>
<li>Payments (other than payments to a Bank of America credit card, charge card or business line of credit account) entered on our system before 5:00 p.m. ET on a bank business day will be scheduled and withdrawn from your SafeBalance Banking<sup>TM</sup> account on the same bank business day. Payments that are entered after this cut-off time will be scheduled and withdrawn from your SafeBalance Banking<sup>TM</sup> account the next bank business day.&nbsp;</li>
<li>Scheduled recurring payments that fall on a weekend or a non-bank business day will be withdrawn from your SafeBalance Banking<sup>TM</sup> account on the prior bank business day.&nbsp;</li>
<li>You authorize us to make payments in the manner we select from the following methods:&nbsp;<br />&nbsp;&nbsp;&nbsp;&nbsp; o&nbsp;&nbsp;&nbsp;Electronic transmission. Most payments are made by electronic transmission. <br />&nbsp;&nbsp;&nbsp;&nbsp; o&nbsp;&nbsp;&nbsp;Corporate check- This is a check drawn on our account or the account of our vendor. If a Payee on a corporate check fails to negotiate&nbsp; the&nbsp;check&nbsp;within 90 days, we will stop payment on the check and re-credit your account for the amount of the payment. If a corporate check is returned to you prior to the end of the 90 day period, please inform us immediately so that we can stop payment on the check and re-credit your account.</li>
<li>Scheduling Bill Payments <br />&nbsp;&nbsp;&nbsp;&nbsp; o&nbsp;&nbsp;&nbsp;The scheduled send on date is the date you enter for withdrawal of the payment funds from your SafeBalance Banking<sup>TM</sup> account. The scheduled delivery date is calculated based on your selected send on date and represents the estimated date when the payment is to be delivered to the Payee (typically five (5) or fewer business days from the send on date). The payment amount will be debited from your account that you designate on the scheduled send on date. <br />&nbsp;&nbsp;&nbsp;&nbsp; o&nbsp;&nbsp;&nbsp;If there are not sufficient funds in your SafeBalance Banking<sup>TM</sup> account on the send on date, your payment will not be made and we will send you an alert to the email address you provided in your Online Banking profile.<br />&nbsp;&nbsp;&nbsp;&nbsp; o&nbsp;&nbsp;&nbsp;For recurring payments, if the scheduled send on date is a weekend or non-bank business day, then the send on date will be the prior bank business day.&nbsp; For payments to a Bank of America loan, line of credit, or mortgage, Bank of America will process and credit the payment to the appropriate account effective the same bank business day, provided the payment is scheduled prior to the 5:00 p.m. ET cut-off. <br />&nbsp;&nbsp;&nbsp;&nbsp; o&nbsp; &nbsp;For payments to Bank of America Gold Option and Gold Reserve accounts, Bank of America will process and credit the payment to the appropriate account effective the same day, provided the payment is scheduled prior to the 11:59 p.m. ET cut-off.</li>
</ul>
<p>When you attempt to schedule a payment, we will inform you of the earliest available delivery date based on your selected send on date. To assure timely payment and obtain the full benefit of the Online Banking Guarantee, your account must be in good standing and you must schedule your payments choosing an appropriate send on date so that the delivery date to the Payee is at least five (5) bank business days before the payment due date. If you do not, or if for any reason your account is not in good standing, you will be fully responsible for all late fees, interest charges or other action taken by the Payee. Under our Online Banking Guarantee, if we fail to process a payment in accordance with your properly completed instructions, we will reimburse you for any late-payment-related fees. If we are unable to process the payment, we will send you an alert to the email address you provided in your Online Banking profile.</p>
<p>3. Bill Pay for Credit Card, Charge Card, Business Line of Credit&nbsp;or Vehicle Loan (automotive, recreational vehicle, boat or aircraft) Only Customers</p>
<p>Bank of America credit card, charge card, business line&nbsp;of credit&nbsp;or vehicle loan account only customers may use the optional Bill Payment service in the following manner:</p>
<ul class="tc-disc">
<li>Payments to your Bank of America credit card, charge card, business line of credit&nbsp;or vehicle loan account can be scheduled from a checking, money market savings or other consumer asset account&nbsp;maintained at another financial institution that you have added through the bill payment service. You certify that any account you add through the bill payment service is an account from which you are authorized to make payments, and any payment you make using the bill payment service will debit an account that you are legally authorized to use. When you add an account maintained at another financial institution, you do not change the agreements you have with that financial institution for that account. You should review those agreements for any applicable fees, for limitations on the number of transactions you can make, and for other restrictions that might limit your use of the account with the Bill Payment service.</li>
<li>Payments can be entered as a 1-time transaction up to a year in advance, or as payments that are automatically scheduled upon the receipt of an electronic bill (e-Bill).</li>
<li>Payments to your credit card, charge card and/or business line of&nbsp;credit account&nbsp;entered on our system before 11:59 p.m. ET will be applied&nbsp;on the same day. Payments entered after this cut-off will be scheduled and processed on the next&nbsp;day. For all entries, the time is recorded on our computer controls. The payment date will be pre-populated with the current day prior to the 11:59 p.m. ET cutoff time.</li>
<li>Payments to your vehicle loan entered on our system before 3:30 p.m. ET on a bank business day will be applied on the same day. Payments entered after this cut-off will be scheduled and processed on the next bank business day. For all entries, the time is recorded on our computer controls.&nbsp; The payment date will be pre-populated with the current bank business day prior to the 3:30 p.m. ET cutoff time.</li>
<li>If the financial institution upon which your payment is drawn rejects, refuses, or returns the payment, the payment to your Bank of America credit card, charge card, business line of credit&nbsp;or vehicle loan will be reversed and you may incur late payment or other fees. The institution holding your deposit account may impose a returned item or other fee. See your credit card, charge card, business line of credit, vehicle loan and deposit account agreements for details.</li>
</ul>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
		<div class="h-100">
			<h4 id="cat3_topic3">
					C. Email/Mobile Transfer Network Service 
			</h4>
		</div>
			<p><br />1. <strong>Description of Service and Consent</strong><br />Email/Mobile Transfers allows you to send money from your Bank of America checking or savings account or requests for money to another Bank of America customer or a customer of another U.S. based bank by using a recipient's email address or mobile phone number. Another Bank of America customer or a customer of a different U.S. based bank may also send money to your account or a request for money using your email address or mobile phone number. In order to send or receive money transfers or requests for money, you must register through Online Banking from your personal computer or Mobile Banking from your mobile device. Recipients of your money transfers or requests for money must also register with Bank of America or another participating bank or with ClearXChange<sup>TM</sup>, a company that arranges electronic money transfers. Once registered, you may send a money transfer or request for money using Online Banking or Mobile Banking by entering the email address or mobile phone number of the recipient. Money sent to your email address or mobile number will be deposited into the account you designated when you registered for the service. By participating in Email/Mobile Transfers, you are representing to us that you are the owner or you have the authority to act on behalf of the owner of the mobile phone number or email address you are using to send or receive messages regarding money transfers and requests for money. In addition, you are consenting to the receipt of emails or automated text messages from Bank of America, or its agent, regarding money transfers or requests for money and represent to us that you have obtained the consent of the recipients of your intended transfers to the receipt of such emails or automated text messages.</p>
<p>Requests For Money<br />By participating in Email/Mobile Transfers, you also have the option of sending a request for money to other people with whom you are splitting a bill or are requesting reimbursement. You may also receive a request for money from other people, which you can respond to by sending money or declining the request. By participating in Email/Mobile Transfers, you agree to receive money requests from others and to only send requests for legitimate and lawful purposes. Requests for money are solely between the sender and recipient and are not reviewed or verified by Bank of America. Bank of America assumes no responsibility for the accuracy or legality of such requests and does not act as a debt collector on your behalf or on behalf of the sender of a request for money. Bank of America reserves the right, but assumes no obligation, to terminate your ability to send requests for money in general, or to specific recipients, if it deems such requests to be potentially unlawful, abusive, offensive or unwelcome by the recipient.</p>
<p>2. <strong>Scheduling Transfers</strong><br />Once registered, you may make one-time transfers at any time using Online Banking or Mobile Banking by entering the email address or mobile phone number of the recipient. An unregistered recipient must register within 14 days and set up the same email address or mobile phone number that you entered to send them money. If the recipient does not register, set up an email address or mobile number and accept the transfer within 14 days, the transaction will be cancelled. During this period, a hold will be placed on the sender's account for the amount of the transfer. Once the recipient has successfully enrolled in the Email/Mobile Transfer Network, transfers will automatically be debited from the sender's account and deposited in the recipient's account. If the sender and recipient are both Bank of America customers enrolled in the Email/Mobile Transfer Network, transfers will be immediately debited from the sender's account and reflected in the recipient's account in accordance with the time frames indicated in Transfers to Deposit Accounts in Section 3.A. If both parties are enrolled in the Email/Mobile Transfer Network but you are sending money to a customer of a different bank, the transfer will be immediately debited from your account and, if completed by 9:00 p.m. ET, will be delivered to the recipient's bank within three business days. Bank of America is not responsible for any failure of another bank to timely credit its customer's account. The transfer process for funds sent to you using your email address or mobile number generally takes approximately four business days, subject to the terms of the sender's agreement with its bank. Bank of America will deposit the funds into your designated account when the transfer has settled and the funds are available.</p>
<p>You acknowledge and agree that payment transfers will be completed using only the email address or mobile phone number you enter even if it identifies a person different from your intended recipient. The name you enter will help you identify your intended recipient in the drop down menu and your transaction history but will not be used to process payments. Please make sure you accurately enter the recipient's email address or mobile phone number since your obligation to pay for the transfer will not be excused by an error in the information you enter.</p>
<p>Transfer Instructions relating to external accounts and the transmission and issuance of data related to such Instructions shall be received pursuant to the terms of this Agreement and the rules of the National Automated Clearing House Association ("NACHA") and the applicable automated clearing house ("Regional ACH") (collectively, the "Rules") and you and we agree to be bound by such Rules as in effect from time to time. In accordance with such Rules, any credit to an account shall be provisional until such credit has been finally settled by us or the third party institution which holds the account.</p>
<p>3. <strong>Fees<br /></strong>There is no fee for sending or receiving a transfer under the Email/Mobile Transfer Service. Please note that your mobile carrier may charge you for text messaging. Please check your mobile service agreement for details on applicable fees.</p>
<p>You may also make payments without a transaction fee by using Bill Pay (described in Section 3.B above). Bill Pay allows you to transfer money to individuals, regardless of whether they are Bank of America customers, usually within 4 business days. You may also make transfers without charge to other Bank of America customers through online banking if you know the recipient's account number.</p>
<p>4. <strong>Mobile Carrier Information<br /></strong>By registering a mobile phone number through the enrollment process, you are certifying that you are the account holder for the mobile phone account or have the account holder's permission to register the number.</p>
<p><strong>Message &amp; data rates may apply. For help text "HELP" to 53849. To cancel your plan, send a text "STOP" to 53849 at anytime.</strong></p>
<p>After you text "STOP", you agree to receive one additional text message confirming your choice.</p>
<p>In case of questions, please call customer service at <strong>1.800.933.6262</strong> for consumer accounts and <strong>1.866.758.5972</strong> for small business accounts.</p>
<p><strong>Supported Carriers:</strong></p>
<p>AT&amp;T, Sprint, Boost, Verizon Wireless, U.S. Cellular&reg;, T-Mobile&reg;, Cincinnati Bell, Virgin Mobile USA, Cellular South, Centennial and Ntelos</p>
<p>For information about our privacy and security practices and a link to our U.S. Consumer Privacy Notice, go to our Web site at <a href="https://www.bankofamerica.com/privacy">https://www.bankofamerica.com/privacy</a>.</p>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
		<div class="h-100">
			<h4 id="cat3_topic4">
					D. Limitations and Dollar Amounts for Transfers and Payments (does not apply to Transfers Outside Bank of America)
			</h4>
		</div>
			<p><br />Transfers and Payments made using Online Banking are subject to the following limitations:</p>
<ul class="tc-disc">
<li>Bill payments can be for any amount between $0.01 and $9,999,999.99.</li>
<li>One-time immediate transfers between linked Bank of America accounts can be for any amount between $0.01 and $9,999,999.99.</li>
<li>One-time immediate transfers from a linked Bank of America account to a linked MLPF&amp;S investment account may not exceed $9,999,999.99. Additional dollar limitations and verifications may apply. Please contact your financial advisor if you have questions on a particular transfer transaction.</li>
<li>One-time immediate transfers from a linked MLPF&amp;S investment account to a linked Bank of America account may not exceed $25,000. Additional dollar limitations and verifications may apply. Please contact your financial advisor if you have questions on a particular transfer transaction.</li>
<li>Transfers&nbsp;submitted to the accounts of other Bank of America customers may not total more than $1,000 during any 24-hour period or $2,500 during any 7-day period for personal accounts. If you are a U.S. Trust or Merrill Lynch Wealth Management client you may have higher limits for this type of transfer. Please contact your advisor for more information on your limits. If you are a Small Business customer, you may also have higher limits for this type of transfer. In addition, for all customers, we may limit the total amount of money that any Bank of America customer can receive through these transfers.</li>
<li>Scheduled and recurring transfers between linked Bank of America accounts can be for any amount between $0.01 and $9,999,999.99.</li>
<li>Scheduled and recurring transfers between a linked MLPF&amp;S investment account and a linked Bank of America account can be for any amount between $0.01 and $9,999,999.99. Additional dollar limitations may apply. Please contact your financial advisor if you have questions on a scheduled or recurring transfer transaction.</li>
<li>Consumers participating in the Email/Mobile Transfer Network Service may send up to 10 transfers with an aggregate dollar limit of $2,500 and receive up to 10 transfers with an aggregate dollar limit of $5,000 during any 24-hour period, and may not send or receive in excess of 30 transfers with an aggregate dollar amount of $20,000 in any 30-day period. If you are a U.S. Trust or Merrill Lynch Wealth Management client you may have higher limits for this type of transfer. Please contact your advisor for more information on your limits. Small business customers may receive up to 10 transfers with an aggregate dollar limit of $25,000 during any 24-hour period and 30 transfers with an aggregate dollar amount of $100,000 in any 30-day period. Receiver limits may not apply to transfers from customers of other banks participating in the clearXchange network. The minimum transfer amount under the Email/Mobile Transfer Service is $1.00.</li>
<li>All transfer limits are subject to temporary reductions to protect the security of customer accounts and/or the transfer system.</li>
<li>At our discretion we may refuse to process any transaction that exceeds any of the above limits. In this case, you are responsible for making alternate arrangements or rescheduling the payment or transfer within Online Banking.</li>
</ul>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
		<div class="h-100">
			<h4 id="cat3_topic5">
					E. Transfer/Payment Authorization and Sufficient Available Funds
			</h4>
		</div>
			<ul class="tc-disc">
<li>You authorize Bank of America to withdraw, debit or charge the necessary funds from your designated account in order to complete all of your designated transfers and payments.</li>
<li>You agree that you will instruct us to make a withdrawal only when a sufficient balance is or will be available in your accounts at the time of the withdrawal.</li>
<li>The completion of a transfer or payment is subject to the availability of sufficient funds (including any overdraft protection plans) at the time the transaction is posted. If enough funds to complete the transfer or payment are not available, we may either (i) complete the transaction and overdraw the account or (ii) refuse to complete the transaction. In either case, we may charge a non-sufficient funds (NSF), returned item, overdraft, or similar fee. Transfers or payments from SafeBalance Banking<sup>TM</sup> accounts will not be completed if there are not sufficient funds on the date of the scheduled transfer or payment. Please refer to the applicable account agreement and fee schedule for details. If you schedule a payment from an account maintained at another financial institution and there are insufficient funds in that account, you may be charged a fee by that financial institution.</li>
<li>At our option, we may make a further attempt to issue the payment or process the transfer request.</li>
<li>Bank of America is under no obligation to inform you if it does not complete a payment or transfer because there are non-sufficient funds or credit in your account to process the transaction. In this case, you are responsible for making alternate arrangements or rescheduling the payment or transfer within Online Banking.</li>
</ul>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
		<div class="h-100">
			<h4 id="cat3_topic6">
					F. Canceling Transfers and Payments (does not apply to Transfers Outside Bank of America)
			</h4>
		</div>
			<ul class="tc-disc">
<li>Bill Payments
<ul class="tc-circle">
<li>In order to cancel a payment (including a payment you scheduled from an account maintained at another financial institution), you must sign into Online Banking and follow the directions provided on the Bill Pay screens. The cancel feature is found in the Payment History or Recurring Payments sections of Online Banking.</li>
<li>For payments scheduled from SafeBalance Banking<sup>TM</sup> accounts, future-dated payments can be cancelled prior to 5 p.m. ET on the scheduled send on date.</li>
<li>For payments scheduled from other accounts, future-dated payments can be cancelled prior to 5 p.m. ET on the third bank business day prior to the scheduled delivery date.</li>
</ul>
</li>
<li>Transfers
<ul class="tc-circle">
<li>A 1-time immediate transfer to another Bank of America customer using the recipient's account number cannot be cancelled after it has been submitted in Online Banking. A transfer submitted through the Email/Mobile Transfer Network Service may not be cancelled once the recipient has registered.</li>
<li>Future-dated and recurring transfers can be canceled prior to midnight ET on the bank business day prior to the date the transfer is scheduled to be made. If the transfer's status is In Process or Processed, you can no longer cancel it. After you cancel a future-dated transfer, the status changes to Canceled. Canceled transfers remain under Review Transfers.</li>
</ul>
</li>
</ul>
<p><br />Alternative Method</p>
<p>Note: The easiest and most convenient way to cancel a payment or transfer is through the method described above. However, you may request to cancel a scheduled or recurring payment or a future-dated transfer by calling us at <strong>1.800.933.6262 </strong>for consumer accounts and 1866.758.5972 for small business accounts. If you are calling from outside of the continental U.S., call us collect at <strong>1.925.681.7600</strong>.</p>
<p>We must receive your request three (3) bank business days or more before the payment or transfer is scheduled for processing. If you call, we may also require you to put your request in writing and get it to us within 14 days after you call. If you call or write to cancel a payment or transfer that is pending, you will be charged for a stop payment in accordance with the agreement for the appropriate linked account.</p>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
		<div class="h-100">
			<h4 id="cat3_topic7">
					G. Our Liability for Failure to Cancel or Stop the Transfer or Payment
			</h4>
		</div>
			<p><br />If you attempt to cancel a payment or transfer in accordance with the above instructions and we do not do so, we will be liable for your losses or damages.</p>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
		<div class="h-100">
			<h4 id="cat3_topic8">
					H. E-Bills
			</h4>
		</div>
			<p><br />E-Bills is a feature of the Bill Pay service that enables you to receive bills electronically from participating Payees</p>
<ul class="tc-disc">
<li>Approval of e-Bills <br />Participating Payees establish their own criteria for reviewing requests to receive e-Bills and have sole discretion to accept or decline your request. We do not participate in this decision. Participating Payees generally take up to five (5) bank business days to approve an e-Bill set-up request.</li>
<li>Accessing e-Bills from a Third Party <br />In some cases we obtain the e-Bill from the web site of the Payee. To do so, we will ask you for information needed for this purpose, such as any required password. When you provide this information, you authorize us to access the third party web site to retrieve the account information on your behalf, and you appoint us your agent for this limited purpose.</li>
<li>Timely Delivery of e-Bills <br />We take no responsibility if a Payee does not provide the necessary data to forward an e-Bill in a timely manner. If you do not receive a bill, it is your responsibility to contact the Payee directly. We are not responsible for any late charges or other adverse consequences. Any questions regarding your bill details should be directed to your Payee.</li>
<li>Stop e-Bills <br />All parties have the right to cancel the service at any time. We will notify you if Bank of America or a Payee discontinues/stops e-Bills. If you request that an e-Bill be discontinued, we require seven (7) bank business days for the Payee to receive and process the request.</li>
<li>Privacy <br />When you&nbsp;request e-Bills&nbsp;from a participating Payee you will provide certain information, that will be forwarded onto the Payee to complete your enrollment. If you have concerns about the future use of this information you should contact your Payee directly.</li>
<li>Introductory e-Bill Opportunity<br />You understand and agree that selected Payees may provide e-Bills to you through Bill Pay for up to three months in order to introduce you to the convenience of online bill payment.&nbsp; We will notify you in advance of such introductory opportunities.&nbsp;&nbsp; Bank of America does not have access to and does not store detailed billing information contained in the e-Bill. Only you will have access to the detailed bill information. If at any time you choose not to participate in this introductory e-Bill opportunity, you have the following options:
<ul class="tc-circle">
<li>You can discontinue a specific e-Bill by signing into Online Banking and choosing to edit it.&nbsp; Select &ldquo;cancel the e-Bill trial&rdquo;, confirm your cancellation and the e-Bill trial will end.</li>
<li>To be removed from future e-Bill trial enrollments, please e-mail customer care at <a href="mailto:optoutebill@customercenter.net">optoutebill@customercenter.net</a> . Please make sure to include the email address that you use for online banking messaging in your response to us.</li>
</ul>
</li>
</ul>
<p>If you wish to continue to receive the e-Bills after the introductory period, please follow the instructions at the e-Bills page of Online Banking.</p>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
		<div class="h-100">
			<h4 id="cat3_topic9">
					I. Accounts Linked to Your Online Banking Services (does not apply to Transfers Outside Bank of America)
			</h4>
		</div>
			<p><br />When you first set up your Online ID, we will link all of your eligible Bank of America accounts. If you open an additional eligible account at a later date, we will link your new account to Online Banking, unless you instruct us not to do so. If you want to limit the accounts linked or the activity level assigned to an account, please call us at 1.800.933.6262 and a representative will discuss the available options with you. For businesses, see also Section 7.B.</p>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
		<div class="h-100">
			<h4 id="cat3_topic10">
					J. Activity Levels for Linked Accounts
			</h4>
		</div>
			<p><br />Currently there are 3 activity levels that can be assigned to your linked accounts:</p>
<ul class="tc-disc">
<li>View - This level allows you to obtain current account balance and transaction information. This level does not allow transfer of funds between linked accounts. However, for linked investment accounts, you may be able to perform investment activities (including trading) by linking directly to the investment site.</li>
<li>Inquiry - This level allows you to obtain current account balance and transaction information. This level does not allow transfers of funds from this account to any linked accounts.</li>
<li>Financial - This level allows you to obtain account information and transfer funds between linked accounts, as well as to add Bill Pay services, and certain other banking services.</li>
</ul>
<p><br />When you first use Online Banking, all of your linked accounts are assigned the activity level of "financial." If any additional accounts are linked to Online Banking, it will automatically be assigned to the activity level of "financial." If you want to change the activity level assigned to your linked accounts, please call us at <strong>1.800.933.6262.</strong> If you are calling from outside of the continental U.S., call us collect at:<strong> 1.925.681.7600. </strong>For businesses, see also Section 7.A.</p>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
	<div class="h-100">
		<h3 id="cat4">
				4. Other Terms and Conditions
		</h3>
	</div>
	
		<div class="h-100">
			<h4 id="cat4_topic1">
					A. Monthly Service Charge
			</h4>
		</div>
			<p><br />Except as otherwise provided in this Agreement or your applicable account agreements and schedule of fees, there is no monthly service charge for accessing your linked accounts with the Online Banking service.<br /><strong>Note:</strong> For Personal Financial Management programs (such as QuickBooks<sup>&reg;</sup>) using Online Banking with Bill Pay service through QuickBooks<sup>&reg;</sup> Direct Connect - There is a&nbsp;$15.00 charge for Business customers who have the Online Business Suite Account Management product. The fee is waived for business customers if you are a Business Advantage checking customer.</p>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
		<div class="h-100">
			<h4 id="cat4_topic2">
					B. Other Charges
			</h4>
		</div>
			<p><br />In addition to the fees already described in this Agreement, you should note that depending on how you access Online Banking or Transfers Outside Bank of America, you might incur charges for:</p>
<ul class="tc-disc">
<li>Normal account fees and service charges.</li>
<li>Any Internet service provider fees.</li>
<li>Any wireless carrier fees.</li>
<li>Purchase of computer programs such as Personal Financial Management (PFM) software.</li>
<li>Payments or transfers made through Online Banking services from a savings or money market account may result in an excess transaction fee. See your savings or money market account for details. Additionally, fees may be assessed for added self-service features available through Online Banking&nbsp;Help &amp; Support, such as stop payment requests, check copy orders and account statement copy orders. For additional information, please see the applicable Deposit Agreement.</li>
<li>An NSF-fee, returned item, overdraft or similar fee may also apply if you schedule payments or transfers and your available balance is not sufficient to process the transaction on the date scheduled or, in the case of a personal check, on the date when the check is presented to us for payment.</li>
</ul>
<p>Please see Section 8 for additional fees for Transfers Outside Bank of America.</p>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
		<div class="h-100">
			<h4 id="cat4_topic3">
					C. Service Hours
			</h4>
		</div>
			<p><br />Online Banking services and Transfers Outside Bank of America are available 365 days a year and 24 hours a day, except during system maintenance and upgrades. When this occurs, a message will be displayed on-line when you sign on to Online Banking. Our Call Centers are available Monday through Friday from 7:00 a.m. to 10:00 p.m., and Saturday and Sunday from 8:00 a.m. to 5:00 p.m. local time, excluding bank holidays. You may also write us at:</p>
<p><br /><strong>Bank of America<br />FL1-300-02-07<br />P.O. Box 25118<br />Tampa,&nbsp;FL 33622-5118</strong></p>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
		<div class="h-100">
			<h4 id="cat4_topic4">
					D. Business Days
			</h4>
		</div>
			<p><br />For Online Banking services and Transfers Outside Bank of America, our business days are Monday through Friday, excluding bank holidays. For investment accounts only, all stock exchange closures and holidays will be observed (such as Good Friday) as well as the bank holidays.</p>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
		<div class="h-100">
			<h4 id="cat4_topic5">
					E. Participation By Payees
			</h4>
		</div>
			<p><br />Occasionally a Payee may choose not to participate in Bill Pay, or may require additional information before accepting payments. We will work with these Payees to encourage them to accept an electronic or check payment from the Bank. If we are unsuccessful, or if we determine that the Payee cannot process payments in a timely manner, we may decline future payments to this Payee. In the unlikely event that this occurs, we will promptly send you a notice. Any obligations that you wish to pay through Online Banking with Bill Pay must be payable in U.S. dollars to a Payee located in the United States. We reserve the right to restrict categories of Payees to whom payments may be made using the service. You should not use the service to make:</p>
<ul class="tc-disc">
<li>Tax payments</li>
<li>Court-ordered payments</li>
<li>Payments to settle securities transactions</li>
</ul>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
		<div class="h-100">
			<h4 id="cat4_topic6">
					F. Canceling Your Online Banking
			</h4>
		</div>
			<p><br />If you choose to cancel your Online Banking services, any unprocessed payments will be canceled. We recommend that you cancel any scheduled payments prior to notifying us that you are discontinuing the service. Bank of America will cancel any scheduled payments within two (2) bank business days from the date we receive your request to discontinue the service. If you close your primary checking account, or if it's no longer linked to your service, any unprocessed payments will be canceled. If you cancel your Online Banking services, Transfers Outside Bank of America will also be canceled. Your Online Banking services will also end if you close all accounts linked to your Online Banking profile.</p>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
		<div class="h-100">
			<h4 id="cat4_topic7">
					G. Joint Accounts
			</h4>
		</div>
			<p><br />When your Online Banking service is linked to one or more joint accounts, we may act on the verbal, written or electronic instructions of any authorized signer. Joint accounts using the same Online ID will be identified as one service.</p>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
		<div class="h-100">
			<h4 id="cat4_topic8">
					H. Changes to Agreement
			</h4>
		</div>
			<p><br />We may change this agreement at any time. For example, we may add, delete or amend terms or services. We will notify you of such changes by mail or electronic message. If you initiate any transfer of funds or bill payment through your Online Banking services or make any Transfers Outside Bank of America after the effective date of a change, you indicate your agreement to the change.</p>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
		<div class="h-100">
			<h4 id="cat4_topic9">
					I. Cancellation
			</h4>
		</div>
			<p><br />Your Online Banking services and Transfers Outside Bank of America remain in effect until they are terminated by you or Bank of America. You may cancel your service at any time by notifying us of your intent to cancel in writing, through Online Banking secure mail, or by calling Online Banking customer service at 1.800.933.6262. This cancellation applies to your Online Banking services and Transfers Outside Bank of America, and does not terminate your Bank of America accounts. We recommend that you cancel any scheduled payments prior to notifying us that you are discontinuing the service.<br />We may terminate your participation in Online Banking services for any reason, including inactivity, at any time. We will try to notify you in advance, but we are not obliged to do so.</p>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
		<div class="h-100">
			<h4 id="cat4_topic10">
					J. Use of External Email Address
			</h4>
		</div>
			<p><br />With Online Banking services and Transfers Outside Bank of America, we may send messages to your external email address and notify you that responses to your payment inquiries or customer service inquiries are available, or as otherwise described within the Online Banking or Transfers Outside Bank of America services. If you subscribe to e-Bills service, we may also use external email to notify you that you have new bills. We cannot act on instructions sent by you from an external email address. You should use Online Banking secure mail to send instructions to Bank of America. If, for any reason your external email address changes or becomes disabled, please contact Bank of America immediately so that we can continue to provide you with automated messages. Because we may also use external email to send important notices about service and privacy changes, we require that every Online Banking customer provide us with a valid and current external email address. You are responsible for providing us with a valid email address and you may notify us of any changes to your external email address through the&nbsp;Help &amp; Support&nbsp;tab within your Online Banking service.</p>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
		<div class="h-100">
			<h4 id="cat4_topic11">
					K. Transfers From Money Market Deposit Accounts
			</h4>
		</div>
			<p>Federal regulations and the Deposit Agreement impose limits on the number of certain types of withdrawals and transfers you can make each month from a savings and money market deposit account. You can make no more than a total of six (6) automatic or preauthorized transfers, telephone transfers, Online Banking transfers or payments, or if checks and debit cards are allowed on the account, check, draft and point of sale transactions from a savings or money market deposit account each monthly statement cycle (each month for savings accounts with a quarterly statement cycle).&nbsp; If you exceed these limits on more than an occasional basis, we convert your account to another type of account and your account may no longer earn interest.</p>
<p>Each transfer or payment through the Online Banking services from your savings or money market deposit account is counted as one of the six limited transfers you are permitted each statement period. We recommend that you not use a savings or money market deposit account as your bill payment account because of these limits on transfers. Please review the deposit agreement for your account for more information.</p>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
		<div class="h-100">
			<h4 id="cat4_topic12">
					L. Contact by Bank of America or Affiliated Parties
			</h4>
		</div>
			<p><br />No Bank of America or Payee employee, nor any company affiliated with Bank of America Online Banking or Transfers Outside Bank of America, will contact you via email or phone requesting your Online ID or online passcode. If you are contacted by anyone requesting this information, please contact us immediately.</p>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
		<div class="h-100">
			<h4 id="cat4_topic13">
					M. Reporting Unauthorized Transactions
			</h4>
		</div>
			<p><br />For reporting unauthorized transactions, please call us at <strong>1.800.933.6262</strong> for consumer accounts and 1.866.758.5972 for small business accounts.</p>
<p>If you are calling from outside of the continental U.S., please call us collect at <strong>1.925.681.7600</strong></p>
<p><br />You may also write us at:</p>
<p><strong>Bank of America<br />FL1-300-02-07<br />P.O. Box 25118<br />Tampa,&nbsp;FL 33622-5118</strong></p>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
		<div class="h-100">
			<h4 id="cat4_topic14">
					N. Initiating Payment Inquiries
			</h4>
		</div>
			<p><br />To initiate a payment inquiry, you may use Online Banking services to send the request via secure online mail. Or you may contact Online Banking Customer Service by calling 1.800.933.6262 for consumer accounts and 1.866.758.5972 for small business accounts and&nbsp;following the voice prompts to speak to a customer service representative. If you are calling from outside of the continental U.S., call us collect at 1.925.681.7600.</p>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
		<div class="h-100">
			<h4 id="cat4_topic15">
					O. Disclosure of Account Information
			</h4>
		</div>
			<p><br />We may disclose information to third parties about you or your transactions in the following instances:</p>
<ul class="tc-disc">
<li>When it's necessary for completing transfers or bill payments, or to investigate or resolve a problem related to a transfer or payment</li>
<li>To verify the existence and condition of your account for a third party, such as a credit bureau or merchant</li>
<li>To comply with a government agency or court orders, or in connection with fraud prevention or an investigation</li>
<li>If you give us your permission</li>
<li>With our affiliates as permitted under Federal and applicable state laws</li>
<li>On a closed account, if we reasonably believe you have mishandled it</li>
</ul>
<p><br />For more information about our privacy and security practices and a link to our U.S. Consumer Privacy Notice go to our Web site at <a href="https://www.bankofamerica.com/privacy">https://www.bankofamerica.com/privacy</a>.</p>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
		<div class="h-100">
			<h4 id="cat4_topic16">
					P. Account Statements and Documents
			</h4>
		</div>
			<p>&nbsp;</p>
<p>1. Account Statements and Transaction Details<br /><br />For deposit accounts, we report your Online Banking and Transfers Outside Bank of America transactions on the monthly or periodic statements for your linked accounts. A description of each transaction, including whom you paid, and the date and amount of the transaction will appear on your statement. <br /><br />In Online Banking, the account statements and documents (including notices) for your eligible checking, savings, money market, credit card, charge card, business line of credit, mortgage and loan accounts are shown within the statements and documents area of your account details page. Note: Online statements and documents are not available for viewing using Mobile Banking Apps or through Mobile Web.</p>
<p>2.&nbsp; Enrollment in Paperless Account Statements and Documents<br /><br />As part of Online Banking enrollment, all Online Banking customers must consent to the Online Banking Electronic Communications Disclosure (&ldquo;eCommunications Disclosure&rdquo;).&nbsp; The eCommunications Disclosure allows us to provide this Agreement and certain Online Banking communications electronically.&nbsp; In addition, the eCommunications Disclosure provides important information about paperless delivery if you choose to replace certain mailed account statements and documents with paperless (online-only) statements and documents.&nbsp; For more details, please review the eCommunications Disclosure by visiting the paperless settings page in Online Banking.</p>
<p>On the paperless settings page in Online Banking, you can choose paperless delivery for all statements and documents at the account level, or for some eligible accounts, at the document group level.&nbsp;&nbsp; As new document types are added to Online Banking for your chosen paperless account or document group, you will automatically receive those new document types online instead of by mail without needing to make an additional paperless choice.&nbsp; At times, we may, in our sole discretion, mail you a paper copy of certain statements and documents even if you have chosen paperless delivery.&nbsp; Note:&nbsp; Tax statements for eligible accounts require a separate consent process for paperless delivery.&nbsp; <br /><br />When a statement or document is delivered online, we send an email to alert you that it is available for viewing in Online Banking.&nbsp; You must have a valid email address to receive these alerts.&nbsp; Paperless statements and documents are generally provided in PDF or HTML format.&nbsp; In order to view, print or save copies of your account statements and documents, you will need to ensure that the computer or device you are using meets the hardware and software requirements specified by the eCommunications Disclosure.</p>
<p>3. Managing your Paperless Delivery Settings<br /><br />You can switch your paperless account statements and documents back to mail delivery at any time by visiting the paperless settings page in Online Banking.&nbsp; It may take up to two months for your revised delivery settings to take effect.&nbsp; Setting your paperless delivery preferences may not be available for all accounts, products or services.&nbsp; See the paperless settings page for more details on the eligible accounts with paperless options, the documents that are currently available to view online, and how to manage your document delivery preferences.&nbsp; We may, in our sole discretion, add to, modify or delete any of the features we provide within our paperless statements and documents service.</p>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
		<div class="h-100">
			<h4 id="cat4_topic17">
					Q. Mobile Single Text Messaging For Financial Center Transactions
			</h4>
		</div>
			<p>&nbsp;</p>
<p>1. Financial Center Authorization Code</p>
<p>In the Financial Center you may have the option to conduct certain transactions electronically. To help facilitate the electronic transaction, you may receive a single text message containing a one-time Financial Center Authorization Code at the mobile number you provide. By providing a mobile number you are (1) certifying that you are the account holder for the mobile phone account or have the account holder's permission to use the mobile phone number, and (2) consenting to receive this one-time text message to conduct this transaction.</p>
<p>This text message may be sent using auto-dialer technology. You will not be sent additional texts or other messages unless you affirmatively request to receive a Financial Center Authorization Code for another transaction. Message and Data Rates may apply. If you need help with text or mobile messages, send the word <strong>HELP</strong> to 26259 or call us at 800.933.6262. You can text <strong>STOP</strong> to 26259 at any time to stop one-time texts related to this Financial Center Authorization Code.</p>
<p>If your mobile phone is off, out of range, or subject to a variety of other conditions, you may not receive the message or messages may be delayed. Wireless carriers are not liable for delayed or undelivered messages. This consent is only applicable to one-time text messages used to facilitate electronic transactions in the Financial Center and does not apply to any other programs that may use an authorization code or link.</p>
<p>2. Financial Center Link</p>
<p>In the Financial Center you may have the option to conduct certain transactions electronically, such as to view or consent to disclosures electronically or provide a digital signature. To help facilitate that electronic transaction, you may choose receive a single text message at the mobile number you provide which will contain a Financial Center Link to www.bankofamerica.com/ok. By providing a mobile number you are (1) certifying that you are the account holder for the mobile phone account or have the account holder's permission to use the mobile phone number, and (2) consenting to receive this one-time text message to conduct this transaction.</p>
<p>This text message may be sent using auto-dialer technology. You will not be sent additional texts or other messages unless you affirmatively request to receive a Financial Center Link for another transaction. Message and Data Rates may apply. If you need help with text or mobile messages, send the word <strong>HELP</strong> to 26259 or call us at 800.933.6262. You can text <strong>STOP</strong> to 26259 at any time to stop one-time texts related to this Financial Center Link.</p>
<p>If your mobile phone is off, out of range, or subject to a variety of other conditions, you may not receive the message or messages may be delayed. Wireless carriers are not liable for delayed or undelivered messages. This consent is only applicable to one-time text messages used to facilitate electronic transactions in the Financial Center and does not apply to any other programs that may use an authorization code or link.</p>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
	<div class="h-100">
		<h3 id="cat5">
				5. Additional Provisions Applicable Only to Consumer Accounts
		</h3>
	</div>
	
		<div class="h-100">
			<h4 id="cat5_topic1">
					A. In Case of Errors or Questions About Your Electronic Transactions
			</h4>
		</div>
			<p><br />Send us a secure online mail message or call us at <strong>1.800.933.6262</strong></p>
<p>If you are calling from outside of the continental U.S., call us collect at <strong>1.925.681.7600</strong></p>
<p><br />You may also write us at:</p>
<p><strong>Bank of America<br />FL1-300-02-07<br />P.O. Box 25118<br />Tampa,&nbsp;FL 33622-5118</strong></p>
<p><br />Contact us immediately if you think:</p>
<ul class="tc-disc">
<li>Your statement or transaction record is wrong</li>
<li>You need more information about a transaction listed on your statement</li>
<li>An unauthorized person has discovered your Online Banking passcode</li>
<li>Someone has transferred or may transfer money from your account without your permission</li>
<li>Bill payment transactions have been made without your authorization</li>
</ul>
<p><br />We must hear from you no later than 60 days after we have sent the FIRST statement on which the problem or error appeared (or 90 days if the problem or error relates to a bill payment from an account maintained at another financial institution).<br />If you tell us verbally, we may require you to send us your complaint or question in writing or via email within ten (10) bank business days (Online Banking customers may use secure online mail). When you contact us, please provide the following information:</p>
<ul class="tc-disc">
<li>Your name and account number</li>
<li>The date and dollar amount of the transaction in question</li>
<li>The name of the Payee if the transaction in question is a payment</li>
<li>The transaction number assigned by Online Banking, if available</li>
<li>A description of the transaction about which you are unsure</li>
</ul>
<p><br />Please explain as clearly as you can why you believe there is an error or why you need more information.<br /><br />We will tell you the results of our investigation within 10 bank business days after we hear from you, and we will promptly correct any error we have made. If we need more time, however, we may take up to 45 days to investigate your complaint or question. In this case, we will provisionally credit your account within 10 bank business days for the amount you think is in error, so that you have the use of the money during the time it takes us to complete our investigation. If we ask you to put your complaint or question in writing, and we do not receive your letter in 10 bank business days, we reserve the right not to provisionally credit your account.<br /><br />If we conclude there was no error, we will send you a written explanation within three (3) bank business days after we complete our investigation. You may request copies of the documents that we used in our investigation.</p>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
		<div class="h-100">
			<h4 id="cat5_topic2">
					B. Limitation of Liability for Online Banking Transactions
			</h4>
		</div>
			<p><br />Tell us at once if you believe your Online Banking passcode has been compromised or if someone has transferred or may transfer money from your account without your permission. The best way to minimize your loss is to call us immediately. The unauthorized use of your Online Banking services could cause you to lose all of your money in your accounts, plus any amount available under your overdraft protection plan.<br /><br />You will have no liability for unauthorized transactions if you notify us within 60 days after the statement showing the transaction has been mailed to you (or 90 days if the transaction was from an account maintained at another financial institution). If you do not, you may not get back any of the money you lost from any unauthorized transaction that occurs after the close of the 60-day period (or 90 day period if the transaction was from an account maintained at another financial institution), if we can show that we could have stopped the transaction if you had notified us in time. If a good reason (such as a long trip or hospital stay) kept you from telling us, we may extend the time periods. <br /><br />When you give someone your Online Banking ID and passcode, you are authorizing that person to use your service, and you are responsible for all transactions that person performs while using your service. All transactions that person performs, even those transactions you did not intend or want performed, are authorized transactions.<br /><br />Transactions that you or someone acting with you initiates with fraudulent intent are also authorized transactions.<br /><br />For your protection, sign off after every Online Banking session and close your browser to ensure confidentiality.<br /><br />Note: These liability rules are established by Regulation E, which implements the federal Electronic Fund Transfer Act and does not apply to business accounts. Our liability policy regarding unauthorized debit card or ATM Card transactions, and unauthorized Online Banking transactions on consumer deposit accounts may give you more protection, provided you report the transactions promptly. Please see the agreement you received with your ATM or debit card and the Online Banking agreement. Also, the state law applicable to your account may give you more time to report an unauthorized transaction or may give you more protection. For example, in Massachusetts, the two day and 60 day time limits for reporting unauthorized transactions do not apply and the $500 limit does not apply.</p>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
		<div class="h-100">
			<h4 id="cat5_topic3">
					C. Our Liability for Failure to Complete Transactions
			</h4>
		</div>
			<p><br />If we do not complete a transaction to or from your account on time, or in the correct amount according to our Agreement with you, we will be liable for your losses or damages. However, there are some exceptions. For instance, we will not be liable:</p>
<ul class="tc-disc">
<li>If, through no fault of ours, you don't have enough available funds in your account (or available funds under your overdraft protection plan), or credit to cover the transaction or transfer</li>
<li>If Online Banking services weren't working properly, and you knew about the malfunction when you started the transaction or transfer</li>
<li>If circumstances beyond our control (such as fire or flood) prevented the transaction or transfer, despite reasonable precautions we've taken</li>
<li>If there are postal delays or processing delays by the Payee</li>
<li>There may be other exceptions not specifically mentioned</li>
</ul>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
		<div class="h-100">
			<h4 id="cat5_topic4">
					D. Our Liability for Transfers Outside Bank of America
			</h4>
		</div>
			<p><br />For the provisions governing our liability for Same-Business Day Outbound transfers and International transfers through our Transfers Outside Bank of America Service, please see Section 8.G below. Our liability for Three-Business Day domestic transfers and Next Business Day domestic transfers involving a transfer to or from a Bank of America consumer account is as prescribed in this section.</p>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
	<div class="h-100">
		<h3 id="cat6">
				 6. Additional Provisions Applicable Only to Business Accounts
		</h3>
	</div>
	
		<div class="h-100">
			<h4 id="cat6_topic1">
					A. Protecting Passcodes
			</h4>
		</div>
			<p><br />You agree that we may send notices and other communications, including passcode confirmations, to the current address shown in our records, whether or not that address includes a designation for delivery to the attention of any particular individual. You further agree that Bank of America will not be responsible or liable to you in any way if information is intercepted by an unauthorized person, either in transit or at your place of business. You agree to: 1) keep your passcode secure and strictly confidential, providing it only to authorized signers on your account(s); 2) instruct each person to whom you give your passcode that he or she is not to disclose it to any unauthorized person; and 3) immediately notify us and select a new passcode if you believe your passcode may have become known to an unauthorized person. <strong>Bank of America will have no liability to you for any unauthorized payment or transfer made using your passcode that occurs before you have notified us of possible unauthorized use and we have had a reasonable opportunity to act on that notice.</strong> We may suspend or cancel your passcode even without receiving such notice from you, if we suspect your passcode is being used in an unauthorized or fraudulent manner. For businesses who use the additional services described in Section 7, this section applies to all Online Banking passcodes, including those assigned to users or Administrators. You are responsible for all transactions performed by you and any designated user(s), including Administrator(s), whether you specifically authorize the transactions or not. If you notify us that the person is no longer authorized, then only transactions that person performs after the time you notify us are considered unauthorized.</p>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
		<div class="h-100">
			<h4 id="cat6_topic2">
					B. Acknowledgment of Commercially Reasonable Security Procedures
			</h4>
		</div>
			<p><br />By using Online Banking, you acknowledge and agree that this Agreement sets forth security procedures for electronic banking transactions that are commercially reasonable. You agree to be bound by instructions, whether authorized or unauthorized, which we implement in compliance with these procedures, unless you have given us prior notice of possible unauthorized use as described above (and we had a reasonable opportunity to act on such notice).</p>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
		<div class="h-100">
			<h4 id="cat6_topic3">
					C. Limitation of Bank's Liability (does not apply to Transfers Outside Bank of America or Direct Payments Service)
			</h4>
		</div>
			<p><br />If we fail or delay in making a payment or transfer pursuant to your instructions, or if we make a payment or transfer in an erroneous amount that is less than the amount per your instructions, unless otherwise required by law, our liability shall be limited to interest on the amount that we failed to timely pay or transfer, calculated from the date on which the payment or transfer was to be made until the date it was actually made or you canceled the instructions. We may pay such interest either to you or the intended recipient of the payment or transfer, but in no event will we be liable to both parties, and our payment to either party will fully discharge any obligation to the other. If we make a payment or transfer in an erroneous amount that exceeds the amount per your instructions, or if we permit an unauthorized payment or transfer after we have had a reasonable time to act on a notice from you of possible unauthorized use as described above, unless otherwise required by law, our liability will be limited to a refund of the amount erroneously paid or transferred, plus interest thereon from the date of the payment or transfer to the date of the refund, but in no event to exceed 60 days' interest. If we become liable to you for interest compensation under this Agreement or applicable law, such interest shall be calculated based on the average federal funds rate at the Federal Reserve Bank in the district where Bank of America is headquartered for each day interest is due, computed on the basis of a 360-day year. <strong>Unless otherwise required by law, in no event will Bank of America be liable to you for special, indirect or consequential damages including, without limitation, lost profits or attorney's fees, even if we are advised in advance of the possibility of such damages.</strong></p>
<p>For the provisions governing our liability for Transfers Outside Bank of America, please see Section 8.G below. For the provisions governing our liability for Direct Payments Service, please see Section 4.G of the Online Business Suite Addendum.<br />Please note that if you give or make reasonably available, your PIN or other access device or code to anyone, you may be liable for any use made of such until you advise us that such person is not authorized to use them.</p>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
	<div class="h-100">
		<h3 id="cat7">
				7. Additional Services Intended for Businesses
		</h3>
	</div>
	
		<p>The additional services described in this Section 7 are available only if you also enroll in the Online Business Suite or if you are a payroll customer. Some customers have been provided continued access to these services without enrolling in the Online Business Suite. We have notified you separately if you qualified for this limited exception.</p>
		<div class="h-100">
			<h4 id="cat7_topic1">
					A. Creating and Managing Users
			</h4>
		</div>
			<p><br />You may authorize other users and control their scope of activities by designating user levels, access levels, and account settings.</p>
<p>You may add additional users to your Online Banking profile and provide each with a separate Online ID and passcode. You may designate the user level either as, &ldquo;user&rdquo; (also sometimes referred to as sub-user) or &ldquo;Administrator.&rdquo; An Administrator is a user who is able to create additional users and to edit and monitor other users. An Administrator is not eligible to enroll in other online business services or grant levels of access to other users that have not been granted to the Administrator. For each user, you can designate which account(s) the user will have access to. You may also place limits on the types of transactions for each account the user is granted access to.</p>
<p>For each account linked to your Online Banking profile, except for personal investment accounts, you can designate each user&rsquo;s access level and account settings.</p>
<p>Access Level (also sometimes referred to as Activity Level) means either Transactional Access, View Access or No Access.</p>
<p>You agree that users have Transactional Access, unless otherwise specified by you or an Administrator. You agree that by granting Transactional Access (also sometimes referred to as financial access or full access) to an account you will be allowing a user to transfer funds, make payments, perform account maintenance, and view account balances and activity on the account, subject to the selected account or general service settings.</p>
<p>View Access (also sometimes referred to as inquiry access or basic access) allows a user to only view account balances and activity, subject to the selected account or general service settings.</p>
<p>Account settings are levels of access and transactional limits that you and/or an Administrator may select for each user. In addition to specifying Transactional, View, or No Access for a user of an account, you can also specify certain other account settings, including transaction limitations as provided on our web site. You may also designate certain &ldquo;general service settings,&rdquo; which are global settings that may affect more than one account. These include Full Access Bill Pay, Payroll Services, Direct Payments, and Express Invoicing.</p>
<p>There are additional controls available for the Bill Pay option. If you select to enable Full Access Bill Pay for a user, that user will automatically have Transactional Access to all the accounts that you have set up for Bill Pay, and the user will be able to pay bills using the Bill Pay feature and set up new payees. You may, however, designate limited access for a user of Bill pay, which will permit the user to have transactional access for specific accounts and existing payees only. For the Bill Pay functionality, you may limit a user to use only certain specified accounts. For users of the Payroll, Direct Payments and Express Invoicing, only Transaction Access is available.</p>
<p>In addition to designating general service settings, you can also provide additional account settings on certain eligible accounts, such as allowing a user to view statements, view check images or make transfers for the selected accounts. Any user to whom you have given transfer ability will be able to see the last name and last 4 digits of account number for all transfer recipients created by you, an Administrator or any other user, even those that the user did not initiate.</p>
<p>If you no longer are a person authorized on the signature card for each linked account to designate signers for each such account, the business has the obligation to inform Business Online Banking of the new individual or individuals with such authority. Such notice must be given separately from any other notices given to other Bank of America departments or banking centers, by calling us at 1.800.933.6262. You may also write us at:</p>
<p><strong>Bank of America<br />FL1-300-02-07<br />P.O. Box 25118<br />Tampa,&nbsp;FL 33622-5118</strong></p>
<p>You are responsible for (and we will have no liability to you for) any unauthorized payments, transfers or other transactions performed on any account linked to this service that are made by a designated user or Administrator using the Passcodes you or an Administrator assign, and that occur before you have notified us of possible unauthorized use and we have had a reasonable opportunity to act on that notice.</p>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
		<div class="h-100">
			<h4 id="cat7_topic2">
					B. Linking Accounts of Additional Businesses and Personal Accounts
			</h4>
		</div>
			<p><br />If you also are authorized to enter into an Agreement for the Business Online Banking service for another business, and if you want to link the accounts of the other business to the accounts covered by this Agreement, you will need to agree separately to this Agreement for each other business. Upon doing so, you may link the accounts of the businesses so that you may elect, at your risk and that of the businesses, but not of the Bank, to use a common Online ID and passcode for Business Online Banking for all linked accounts. You should do this only if you are authorized to link the accounts of the different business and to use all the functions of Business Online Banking for each business. You further agree to inform Bank of America if your authority over any linked account decreases. Bank of America is not liable if your authority over any account decreases until it is informed of the change in authority using the "Notice" requirements of this Agreement.</p>
<p>You may also link an eligible Bank of America personal account to the accounts covered by this Agreement. SafeBalance Banking<sup>TM</sup>&nbsp;accounts are not eligible to be linked to Online Business Suite accounts. You may link eligible accounts only&nbsp;if you are the named owner of the business account and the personal account. If you link personal accounts to your business accounts, you agree and understand that users and Administrators will be able to view and/or perform transactions with linked personal accounts, subject to the selected account or general service settings described in Section 7.A. above.</p>
<p>You further agree to inform Bank of America if your authority over any linked account decreases. Bank of America is not liable if your authority over any account decreases until it is informed of the change in authority using the "Notice" requirements of this Agreement.</p>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
		<div class="h-100">
			<h4 id="cat7_topic3">
					C. Contacting Bank of America
			</h4>
		</div>
			<p><br />For general questions, to request cancellation of payments and transfers, or to report unauthorized transactions please call us at 1.800.933.6262. Business Online Banking Customer Service is available from 7:00 a.m. to 10:00 p.m. local time, seven (7) days a week, excluding bank holidays. You may also write us at:</p>
<p><strong>Bank of America<br />FL1-300-02-07<br />P.O. Box 25118<br />Tampa,&nbsp;FL 33622-5118</strong></p>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
		<div class="h-100">
			<h4 id="cat7_topic4">
					D. Business Payroll Services
			</h4>
		</div>
			<p><strong>For payroll customers who have accepted the Intuit terms and conditions on or after May 31, 2013, the following terms and conditions in subsection 7.D apply to your Online Banking Agreement with us:</strong></p>
<p>1. Self Service or Full Service</p>
<p>Bank of America has arranged for a third-party provider, Intuit Inc., to furnish optional web-based payroll processing services (the &ldquo;Payroll Service&rdquo;) to our online business customers. You can choose a self-service product (Intuit&reg; Online Payroll) that permits you to perform your own payroll, or you can choose a full service version (Intuit Full Service Payroll&reg;) where Intuit will perform your payroll for you.</p>
<p>This is a summary of current terms of the Intuit Payroll Services for business customers enrolling in and/or navigating to the Payroll Service through Bank of America Small Business Online Banking:</p>
<p>Intuit&reg; Online Payroll: Intuit Online Payroll&reg; offers two service levels, Basic and Enhanced. Enhanced service provides state and multi-state tax service and direct deposit to banks other than Bank of America.&nbsp; Monthly fees: Basic service is $20/month and Enhanced service is $36/month. With Basic, you will receive a $20 discount in any month you pay all your employees (includes contractors) by direct deposit to Bank of America accounts. For both Enhanced and Basic, if you pay more than 20 employees, but not all are paid by direct deposits to Bank of America accounts, an additional monthly fee of $2 will be charged for each employee over the first 20. The monthly payroll service fees are waived during the first 3 months of enrollment. Intuit guarantees the accuracy of its payroll tax calculations, based on the information you provide and subject to the terms of your agreement with Intuit. If Intuit causes a calculation error, Intuit will pay the tax penalty incurred as a result of a calculation error.</p>
<p>Intuit Full Service Payroll&reg;: Monthly fees: $99/month, plus $2 for each employee (includes contractor). Intuit guarantees the accuracy of the payroll tax calculations, tax filings, and any paychecks Intuit prepares for you, based on the information you provide and subject to the terms of your agreement with Intuit. If Intuit causes a service error, Intuit will pay the tax penalty, pay the resulting bank fees, and waive the next month&rsquo;s service fee.</p>
<p>Both Intuit&reg; Online Payroll&reg; and Intuit Full Service Payroll: Additional multi-state payroll processing fees ($12/state/month for IOP and $10/state/month for IFSP) will apply for every state in which you have employees (or contractors), other than your primary business state location. Monthly service fees, including multi-state fees, apply each month in which you are enrolled, whether or not you use the service. Additional fees for exception processing and other special services may apply. Pricing does not include applicable taxes. You must have an open Bank of America business checking account to be eligible to access the payroll service through Bank of America Online Banking. The maximum number of active employees and contractors being paid cannot exceed 150.</p>
<p><br />Intuit&reg; Online Payroll and Intuit Full Service Payroll&reg; are products of Intuit Inc. You must go to the Intuit Website to enroll in and use the payroll product. Bank of America is not responsible for the product or the performance of Intuit Inc. Intuit and the Intuit Logo are registered trademarks of Intuit Inc., used under license.</p>
<p><br /><strong>Terms, conditions, features, availability, pricing, fees, service and support options are subject to change. The actual terms and conditions of your Payroll Service are in the service agreement you execute with Intuit, Inc. Bank of America makes no representation or warranty concerning the accuracy or continuance of any of the these terms, whether shown in this agreement, on the Bank of America website, or on any other Bank of America communication.</strong></p>
<p>2.&nbsp; Enrollment and Navigation.</p>
<p>You must navigate to the Intuit website to enroll and to use the Payroll Services. You will be subject to the Intuit terms and conditions, privacy, and security agreements and policies. Intuit may decline to initiate the Payroll Service for you or any of your employees in its sole discretion. The Payroll Services are not Bank of America services or products, and Bank of America is not responsible for the Payroll Services or the performance of Intuit.</p>
<p><br />We provide a link from your Bank of America Small Business Online Banking session for you to access your Payroll Service on the Intuit Web Site, which you are permitted to use if you maintain a Bank of America business checking account.&nbsp; This will enable you to simultaneously work in both sessions as permitted by the applicable service agreements; however, there will be no download or transfer of your account information or data from the Bank of America website to the Intuit website except as described herein. When you navigate from the Bank of America site to the Intuit web site you hereby authorize us to transmit to Intuit the necessary identification and security information concerning you and your authorized users. You acknowledge that Bank of America may market its products and services to your employees whose information we have received from you in order for us to facilitate access to the Payroll Service.</p>
<p>3.&nbsp; Disclaimer of Warranties.</p>
<p>TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, BANK OF AMERICA AND ITS AGENTS, LICENSORS, DISTRIBUTORS, ADVERTISERS, DEALERS AND SUPPLIERS, EXCEPT FOR INTUIT, INC., DISCLAIM ALL WARRANTIES, EXPRESS OR IMPLIED, REGARDING THE PAYROLL SERVICE AND ITS RELATED MATERIALS, INCLUDING THEIR FITNESS FOR A PARTICULAR PURPOSE, THEIR QUALITY, THEIR MERCHANTABILITY, OR THEIR NON-INFRINGEMENT. BANK OF AMERICA DOES NOT WARRANT THAT THE SERVICE IS COMPLETELY SECURE OR IS FREE FROM BUGS, INTERRUPTIONS, ERRORS, OR OTHER PROGRAM LIMITATIONS. BANK OF AMERICA DOES NOT WARRANT THAT THE WEB SITE, OR THE SERVER THAT MAKES IT AVAILABLE, IS FREE OF VIRUSES OR OTHER HARMFUL COMPONENTS. YOU (AND NOT BANK OF AMERICA) ASSUME THE ENTIRE COST OF ALL NECESSARY SERVICING, REPAIR, OR CORRECTION OF PROBLEMS CAUSED BY VIRUSES OR OTHER HARMFUL COMPONENTS. SOME STATES DO NOT ALLOW THE EXCLUSION OF IMPLIED WARRANTIES, SO THE ABOVE EXCLUSIONS MAY NOT APPLY TO YOU. IN THAT EVENT, ANY IMPLIED WARRANTIES ARE LIMITED IN DURATION TO 60 DAYS FROM THE DATE OF PURCHASE OF THE SERVICE. HOWEVER, SOME STATES DO NOT ALLOW LIMITATIONS ON HOW LONG AN IMPLIED WARRANTY LASTS, SO THE ABOVE LIMITATION MAY NOT APPLY TO YOU. THIS WARRANTY GIVES YOU SPECIFIC LEGAL RIGHTS, AND YOU MAY HAVE OTHER RIGHTS THAT VARY FROM STATE TO STATE.</p>
<p>4.&nbsp; Limitation of Liability.</p>
<p>THIS LIMITATION OF LIABILITY SUPERSEDES THE LIABILITY LIMITATION SECTION OF THE ONLINE BANKING AGREEMENT (6.C.) ONLY WITH RESPECT TO THE PAYROLL SERVICE. THE ENTIRE LIABILITY OF BANK OF AMERICA AND ITS AGENTS, LICENSORS, DISTRIBUTORS, ADVERTISERS, DEALERS AND SUPPLIERS, EXCEPT FOR INTUIT, INC., FOR ANY REASON SHALL BE LIMITED TO THE AGGREGATE AMOUNT OF SERVICE FEES PAID BY YOU TO BANK OF AMERICA DURING THE TWELVE (12) MONTHS IMMEDIATELY PRECEDING THE DATE ON WHICH THE CLAIM ACCRUED. TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, BANK OF AMERICA AND ITS LICENSORS, DISTRIBUTORS, ADVERTISERS, DEALERS AND SUPPLIERS, EXCEPT FOR INTUIT, INC., ARE NOT LIABLE FOR ANY INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES (INCLUDING DAMAGES FOR LOSS OF BUSINESS, LOSS OF PROFITS OR INVESTMENT, OR THE LIKE), WHETHER BASED ON BREACH OF CONTRACT, BREACH OF WARRANTY, TORT (INCLUDING NEGLIGENCE), PRODUCT LIABILITY OR OTHERWISE, EVEN IF SUCH PERSON HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES AND EVEN IF A REMEDY SET FORTH IN THIS ADDENDUM IS FOUND TO HAVE FAILED OF ITS ESSENTIAL PURPOSE. BANK OF AMERICA AND ITS AGENTS, LICENSORS, DISTRIBUTORS, ADVERTISERS, DEALERS AND SUPPLIERS, EXCEPT FOR INTUIT, INC., ARE NOT LIABLE FOR ANY LOSS, ERASURE OR CORRUPTION OF OR UNAUTHORIZED ACCESS TO ANY DATA OR OTHER INFORMATION TRANSMITTED, PROCESSED OR STORED VIA THE SERVICE. SOME STATES DO NOT ALLOW THE LIMITATION AND/OR EXCLUSION OF LIABILITY FOR INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE LIMITATION OR EXCLUSION MAY NOT APPLY TO YOU.</p>
<p>You acknowledge that if an employee of yours is paid by check through the Payroll Service, and the employee does not have a deposit account with Bank of America, the employee may be charged a fee to cash that check at a Bank of America location.&nbsp; You further acknowledge that some states require an employer to provide its employees with the means to obtain the full value of their paychecks.&nbsp; You agree that compliance with any such requirement is your responsibility and not the responsibility of Bank of America or Intuit, and you indemnify and hold harmless Bank of America and Intuit for any claim asserting a violation of such requirement.</p>
<p>The limitations of damages and liability set forth in this Section are fundamental elements of the basis of the bargain between Bank of America and you. You acknowledge and agree that Bank of America would not be able to provide your access to the Payroll Service on an economic basis without such limitations.</p>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
	<div class="h-100">
		<h3 id="cat8">
				8. Transfers Outside Bank of America Services
		</h3>
	</div>
	
		<p>Transfers sent outside of the United States that are initiated by consumers primarily for personal, family or household purposes (&ldquo;Remittance Transfers&rdquo;), are governed by a new federal law (see section 8.H below). This Agreement governs not only Remittance Transfers, but also certain other transfers that are sent outside of Bank of America as described in section 8.A below. Beginning on the date set forth in the final rule implementing Section 919 of the Electronic Funds Transfer Act (&ldquo;EFTA&rdquo;), 15 U.S.C. Section 1693o-1 (the &ldquo;Effective Date&rdquo;),&nbsp;your rights and obligations with respect to Remittance Transfers, as set forth in EFTA, may vary in certain ways from the terms and conditions applicable to other types of transfers.&nbsp;Your rights with respect to Remittance Transfers, including error resolution and cancellation rights, will be explained to you at the time you initiate each Remittance Transfer&nbsp;and are also contained in Section 8.H below.</p>
<p>For transfers <em>other than</em> Remittance Transfers, including general questions, requests for&nbsp;cancellation of payments and transfers, or to report unauthorized transactions, please call us at 1.800.933.6262, available Monday through Friday from 7:00 a.m. to 10:00 p.m., and Saturday and Sunday from 8:00 a.m. to 5:00 p.m., local time. From outside of the continental U.S., call us collect at 1.925.681.7600.</p>
<p>You may also write us at:<br /><strong>Bank of America<br />FL1-300-02-07<br />P.O. Box 25118<br />Tampa,&nbsp;FL 33622-5118<br /></strong></p>
<p>For <em>Remittance Transfers</em>, please see the contact information in Section 8.H. below.</p>
		<div class="h-100">
			<h4 id="cat8_topic1">
					A. Transfers Outside Bank of America for Online Banking Customers
			</h4>
		</div>
			<ul class="tc-disc">
<li>You must be enrolled in Online Banking to use the Transfers Outside Bank of America Service.</li>
<li>Within Online Banking, you have the option of participating in the Transfers Outside Bank of America Service which allows you to transfer funds between your linked personal deposit accounts at Bank of America and certain deposit or investment accounts owned by you or someone else at other financial institutions using an account number and financial institution identifier. An inbound transfer moves funds into an account you own at Bank of America from an account you own outside Bank of America. An outbound transfer moves funds from an account you own at Bank of America to an account outside Bank of America that is owned by you or someone else.&nbsp;</li>
<li>Small Business customers may transfer funds from their business checking account to an individual's or vendor's account at another financial institution. Before scheduling a transfer to an individual, you agree that you will have received a signed authorization from the payee, and that the authorization will not have been revoked. You agree to provide a copy of the authorization to us upon our request. Before scheduling any vendor payment, you agree that you will have received authorization from the vendor to make the payment by electronic means.</li>
<li>You will need to provide certain identifying information about each non-Bank of America account in order to register that account for this service. For inbound transfers, you agree that you will only attempt to register non-Bank of America personal accounts that you own or for which you have the authority to transfer funds. Delivery speeds for domestic (U.S.) transfers are 3-Business-Day, Next-Business-Day or Same-Business-Day transfers. Same-Business-Day transfers are not available for inbound transfers. Transfers to accounts located outside the United States are available for outbound transfers only and are subject to the delivery times indicated below. Next-Business-Day and Three-Business-Day transfers are not available for international transfers. Please see below for a more detailed description of these transfers.</li>
<li>Types of domestic (U.S.) outbound transfers:
<ul class="tc-circle">
<li>Three-Business-Day transfers: Funds will be debited from your Bank of America account on the business day you direct us to initiate processing of the transfer, and typically will be credited to the receiving account on the third business day after the transfer is initiated.</li>
<li>Next-Business-Day transfers: Funds will be debited from your Bank of America account on the business day you direct us to initiate processing of the transfer, and typically will be credited to the receiving account on the next business day after the transfer is initiated.</li>
<li>Same-Business-Day transfers: Funds will be debited from your Bank of America account on the business day you direct us to initiate processing of the transfer and typically will be credited to the receiving account on the same business day.</li>
</ul>
</li>
<li>Types of domestic (U.S.) inbound transfers:
<ul class="tc-circle">
<li>Three-Business-Day transfers: Funds typically will be debited from your account outside Bank of America on the business day or next business day after you direct us to initiate processing of the transfer, and will be credited to your Bank of America personal account on the third business day after the transfer is initiated.</li>
<li>Next-Business-Day transfers: Funds typically will be debited from your account outside Bank of America on the business day or next business day after you direct us to initiate processing of the transfer, and will be credited to your Bank of America personal account on the next business day after the transfer is initiated.</li>
</ul>
</li>
<li>Types of international outbound transfers:
<ul class="tc-circle">
<li>For all international outbound transfers, funds will be debited from your Bank of America account on the business day you direct us to initiate processing of the transfer.&nbsp;Bank of America will send the payment out on that business day and, except for Remittance Transfers, the beneficiary&rsquo;s bank typically receives the funds 1 to 2 business days later and the funds typically will be credited to the beneficiary within 2 days.</li>
<li>Special rules apply to Remittance Transfers, including, but not limited to, disclosures, cancellation and refund rights and error resolution rights. See Section 8.H below for details.</li>
</ul>
</li>
<li>Some of the above services may not be available for certain accounts, customers, or if you access Online Banking through Mobile Banking Apps or Mobile Web.</li>
<li>Bank of America cannot guarantee the timely delivery or return of funds as a result of the failure of another financial institution to act in a timely manner. Please note that beneficiary banks located in some countries may take several days or even weeks to credit the receiving account. There may be some risk in making a transfer to a slow-to-pay country. Currency conversion charges also may apply to international outbound transfers. Bank of America will trace your transfer if the recipient has not received it in 3 weeks. A $25 fee will be charged for each transfer trace.</li>
<li>You agree that you will have sufficient available funds in the designated deposit account to cover all outbound transfers on the date scheduled. If a SafeBalance Banking<sup>TM</sup> account does not have sufficient funds available on the scheduled transfer date, the transfer will not be made. For other deposit accounts (excluding SafeBalance Banking<sup>TM</sup>), if the account does not have sufficient available funds on the scheduled date, we may elect not to initiate one or more of the transfers. If we do elect to initiate the transfer, it may cause an overdraft in your account in which case you shall be liable for the overdraft and any overdraft fees and interest thereon, as set forth in your Deposit Agreement. If we do elect to initiate the transfer, you agree to pay all related fees as disclosed in your Deposit Agreement.</li>
<li>You agree that Bank of America may use any means or routes which we in our sole discretion consider suitable to execute your transfer. Bank of America hereby gives notice that Same-Business-Day domestic transfers and international outbound transfers may be executed through Fedwire, a funds transfer system operated by the Federal Reserve Banks, through CHIPS (Clearing House Interbank Payments System), a funds transfer system operated by The Clearing House or through SWIFT (Society for Worldwide Interbank Financial Telecommunication). With respect to payment orders relating to the transfer which are executed through Fedwire, Federal Reserve Regulation J and all applicable Federal Reserve operating rules&nbsp;shall govern the payment orders. With respect to payment orders relating to the transfer which are executed through CHIPS, the CHIPS Operating Rules shall govern the payment orders. With respect to payment orders relating to the transfer which are executed through SWIFT, the SWIFT operating rules shall govern the payment orders. However, with respect to Remittance Transfers, to the extent of any inconsistencies between the above referenced rules and the provisions of the EFTA, the provisions of EFTA shall prevail.&nbsp;Notwithstanding anything to the contrary contained herein, the rights and obligations that apply to Remittance Transfers are set forth in the EFTA and, as applicable, as set forth in New York law. Three-Business-Day transfers and Next-Business-Day transfers may be made through the Automated Clearing House processor selected by us or directly to another bank, and you agree will be subject to the National Automated Clearing House Association rules or our agreement with the other bank, in effect at such time, as applicable.</li>
</ul>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
		<div class="h-100">
			<h4 id="cat8_topic2">
					B. Initiating and Scheduling transfers
			</h4>
		</div>
			<ul class="tc-disc">
<li>Cut-off Time: The cut-off time for 3-Business-Day transfers and Next-Business Day transfers is 8:00 p.m. ET on a business day. The cut-off time for Same-Business-Day domestic transfers and international outbound transfers is 5:00 p.m. ET on a business day. Any transfer initiated after the applicable cut-off time will be considered as being initiated on the next business day.</li>
<li>Domestic inbound or outbound transfers can be scheduled on either an immediate, 1-time future-dated or a recurring basis. Processing of 1-time domestic transfers may be initiated immediately or scheduled for initiation on a future date. International outbound transfers may only be initiated for immediate transfer. Recurring transfers may be scheduled for up to 1 year in advance for domestic (U.S.) transfers only. The recurring transfer feature may be used when a set amount is transferred at regular intervals. For example, you may schedule a $100 transfer from an account you own at another financial institution to your Bank of America checking account every 2 weeks.</li>
<li>In addition to choosing the delivery speed, as described above, for domestic transfers you will be asked to pick the date that you want us to initiate the processing of the transfer. For example, if you direct us to initiate processing an outbound transfer immediately and choose Next Business Day delivery, funds will be debited from your Bank of America account on the business day you schedule the transfer and typically will be credited to the receiving account on the next business day after the transfer is initiated.</li>
<li>1-time future-dated or recurring transfers scheduled for a weekend or a non business day will be processed on the prior business day.</li>
</ul>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
		<div class="h-100">
			<h4 id="cat8_topic3">
					C. Cancelling Transfers
			</h4>
		</div>
			<ul class="tc-disc">
<li>Except for Remittance Transfers, you can cancel 1-time future-dated and recurring domestic transfers prior to midnight ET on the date processing for the transfer is scheduled to be initiated by accessing the Transfers page and selecting To/From my accounts at other banks or To someone else&nbsp;or business within Online Banking. This is the preferred method for cancelling transfers. After you cancel a future-dated transfer, the status changes to Canceled.</li>
<li>Please see&nbsp;Section 8.H&nbsp;for the cancellation procedures applicable to Remittance Transfers.</li>
<li>Except for Remittance Transfers, if you direct us to begin processing a transfer immediately or a transfer's status is In Process or Processed, you no longer have the right to cancel it. However, the Bank at its option, may attempt to cancel the transaction, subject to the limitations in Section 8.G below.</li>
<li>Alternative Method: The easiest and most convenient way to cancel a transfer is through the method described above. However, you also may request to cancel a 1-time future-dated or recurring domestic transfer&nbsp;by calling us at 1.800.933.6262. From outside of the continental U.S., call us collect at: 1.925.681.7600.</li>
<li>If you call, we may also require you to put your request in writing and get it to us within 14 days after you call. You may not call and cancel a transfer whose status is In Process or Processed.</li>
<li>If you attempt to cancel a payment or transfer in accordance with the above instructions and we do not do so, we will be liable for your losses or damages, subject to the limitations in Section 8.G&nbsp;below.</li>
</ul>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
		<div class="h-100">
			<h4 id="cat8_topic4">
					D. Transfer Fees for Transfers Outside of Bank of America Services
			</h4>
		</div>
			<ul class="tc-disc">
<li>Inbound transfers: There is no fee for transferring funds into your Bank of America personal accounts through online banking, regardless of the delivery speed you choose.</li>
<li>Outbound transfers:
<ul class="tc-disc">
<li>If you transfer funds to an account owned by you or someone else at another financial institution, the following transfer fees will apply:<br />- 3-Business-Day transfers - $3<br />- Next-Business-Day transfers - $10</li>
<li>Same-Business Day domestic transfers - varies by region (The actual fee disclosure is on the Transfers page.)</li>
<li>International outbound transfers - varies by region (The actual fee disclosure is on the Transfers page.)&nbsp;See Section 8.H below for additional information about fees applicable to Remittance Transfers.</li>
</ul>
</li>
<li>Miscellaneous Fees: You will be charged $25 for each transfer trace that you ask us to execute for you. International payments may be subject to additional fees charged by intermediary, receiving and beneficiary banks. See Section 8.H below for additional information on Remittance Transfers.</li>
<li>You may also move money within the U.S. without a transfer fee by using Email and Mobile Transfers (described in Section 3.C above) or Bill Pay (described in Section 3.B above). The Transfers Outside Bank of America Service is an alternative that allows you to transfer funds to individuals or vendors when delivery of funds domestically by a specific date is critical or when you are transferring funds outside the U.S.</li>
</ul>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
		<div class="h-100">
			<h4 id="cat8_topic5">
					E. Dollar Limits
			</h4>
		</div>
			<ul class="tc-disc">
<ul class="tc-disc">
<li>Inbound transfers to your personal accounts are subject to the following dollar limits:</li>
</ul>
</ul>
<table class="tc-tablardata" style="width: 100%;" cellspacing="0" cellpadding="0" summary="Limits for Inbound Transfers" border="0">
<thead>
<tr>
<td align="center">&nbsp;</td>
<th scope="col"><strong>3 Business Day Transfers</strong></th><th scope="col"><strong>Next Business Day Transfers</strong></th></tr>
</thead>
<tbody>
<tr><th scope="col"><strong>Inbound</strong></th>
<td></td>
<td></td>
</tr>
<tr>
<td>Business Day</td>
<td align="center">$3,000</td>
<td align="center">$2,000</td>
</tr>
<tr>
<td>In Process</td>
<td align="center">$3,000</td>
<td align="center">$2,000</td>
</tr>
<tr>
<td>Monthly (rolling 30-day period)</td>
<td align="center">$6,000</td>
<td align="center">$5,000</td>
</tr>
</tbody>
</table>
<ul class="tc-disc">
<li>You will not have specific limits for outbound transfers, but all Transfers Outside Bank of America are subject to internal review by Bank of America based on to and from accounts, the amount of the transaction, your relationship with Bank of America, a successful fraud screening and such other factors that Bank of America may determine to apply from time to time. In the event we determine that there are risks associated with a transfer or if we determine you are subject to a "Disqualifying Event," as defined below, we may delay or cancel the transfer and notify you, or direct you to contact us to provide additional details on the transfer before it is initiated or funds are released.</li>
<li>Any transfer initiated on a day that is not a business day begins processing on the following business day and counts toward the applicable dollar limit for the next business day.</li>
</ul>
<p>You must enroll in SafePass to transfer funds over certain dollar amounts, depending on your relationship with Bank of America. After enrolling in SafePass, you will be required to enter your SafePass code each time you're initiating a transfer over the specified dollar amount and when adding a new account. The code will be sent to your mobile device or SafePass card. <a href="https://www.bankofamerica.com/privacy/online-mobile-banking-privacy/safepass.go" title="www.bankofamerica.com" name="www.bankofamerica.com">Learn more about SafePass.</a></p>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
		<div class="h-100">
			<h4 id="cat8_topic6">
					F. Processing Transfers and Disqualifying Events
			</h4>
		</div>
			<ul class="tc-disc">
<li>A transfer remains "In Process" until fully processed and it will appear as "In Process" on your Transfer Activity tab under Send Money To/From my accounts at other banks, or To someone else using an account number, within Online Banking. Transfers remain "In Process" until the close of business on the day the funds are scheduled to be credited to the receiving account.</li>
<li>For inbound transfers, 3-Business-Day delivery speed is available to all consumer customers participating in Transfers under Send Money To/From my accounts at other banks, or To someone else using an account number, within&nbsp;Online Banking, but you agree we may cancel a transfer, without prior notice, upon the occurrence of a "Disqualifying Event," as defined below. You must be approved to make a Next-Business-Day inbound transfer. Next-Business-Day inbound transfers are permitted only at our discretion, but you must have completed at least one 3-Business-Day inbound transfer involving the same non-Bank of America account no less than 60 days prior to the attempted Next-Business-Day inbound transfer. You may determine whether you have been approved for Next-Business-Day inbound transfers by going to Transfers under Send Money To/From my accounts at other banks, or To someone else using an account number within Online Banking and selecting Make a Transfer, then verify if the Next Business Day option is available once an account you own at another financial institution is selected. Once approved, you will remain eligible for Next-Business-Day inbound transfers, as applicable, unless we provide you with notice, as required by law.</li>
<li>We may change your dollar limits at any time. Any decrease will be subject to notice, as required by law, but you agree that we may reduce your limits below the amounts stated above or cancel your transfers without prior notice upon occurrence of a Disqualifying Event.</li>
<li>Each of the following is a "Disqualifying Event":
<ul class="tc-circle">
<li>Any of your deposit accounts with Bank of America are not current or are not in good standing.</li>
<li>Your funding account has been open for less than 24 hours.</li>
<li>You have had an overdraft, an over-limit item, or an item returned for insufficient funds with respect to any Bank of America deposit account during the current or 3 prior calendar months.</li>
<li>You have had any prior transfer canceled, revoked, or uncompleted due to insufficient funds, revoked authorization, stopped payments, frozen accounts, or any similar reason.</li>
</ul>
</li>
<li>
<p>Bank of America will use best efforts to provide oral, written or electronic notice to you of rejection of a transfer on the scheduled date of initiation of the transfer; provided, however, that Bank of America shall not be liable to you for interest compensation for its failure to give such notice.</p>
</li>
</ul>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
		<div class="h-100">
			<h4 id="cat8_topic7">
					G. Liability
			</h4>
		</div>
			<p class="mtop-15"><strong><strong>The following applies to Same-Business Day Domestic transfers, and all Transfers Outside of Bank of America from a business account. The liability for Three-Business Day domestic transfers and Next-Business Day domestic transfers involving a transfer to or from a Bank of America consumer account is described in Section 5 above. The liability for Remittance Transfers is described in Section 8.H. below.</strong></strong></p>
<ul class="tc-disc">
<li>By enrolling in online banking and accessing the Transfers Outside Bank of America Service using your Online ID and&nbsp;passcode, you acknowledge and agree that this system includes security procedures for transfers initiated through this Service that are commercially reasonable. You agree to be bound by instructions, whether authorized or unauthorized, which we implement in compliance with these procedures, unless you have given us prior notice of possible unauthorized use of your passcode and we had a reasonable opportunity to act on such notice.</li>
<li>If we fail or delay in making a transfer pursuant to your instructions, or if we make a transfer in an erroneous amount that is less than the amount per your instructions, unless otherwise required by law or as otherwise provided in this Agreement, our liability shall be limited to interest on the amount that we failed to timely pay or transfer, calculated from the date on which the payment or transfer was to be made until the date it was actually made or you canceled the instructions. We may pay such interest either to you or the intended recipient of the transfer, but in no event will we be liable to both parties, and our payment to either party will fully discharge any obligation to the other. If we make a payment or transfer in an erroneous amount that exceeds the amount per your instructions, or if we permit an unauthorized payment or transfer after we have had a reasonable time to act on a notice from you of possible unauthorized use of your passcode as described in this Section above, unless otherwise required by law or as otherwise provided in this Agreement, our liability will be limited to a refund of the amount erroneously paid or transferred, plus interest thereon from the date of the transfer to the date of the refund, but in no event to exceed 60 days' interest. If we become liable to you for interest compensation under this Agreement or applicable law, such interest shall be calculated based on the average federal funds rate at the Federal Reserve Bank in the district where Bank of America is headquartered for each day interest is due, computed on the basis of a 360-day year. <strong>Unless otherwise required by law, in no event will Bank of America be liable to you for special, indirect or consequential damages including, without limitation, loss or damage from subsequent wrongful dishonor resulting from our acts or omissions or lost profits, even if we are advised in advance of the possibility of such damages. </strong>We shall not be liable for your attorney's fees, except as required by law.</li>
<li>You expressly agree that Bank of America shall be liable to you only for our negligent performance or non-performance of the services provided pursuant to the Transfers Outside Bank of America Service, and that our responsibility shall be limited to the exercise of reasonable and ordinary care. Unless otherwise required by law, Bank of America shall not be liable for any error or delay on the part of any third party or for any other act or omission of any third party, including without limitation third parties used by Bank of America in executing any payment order relating to a transfer or performing a related act, and no such third party shall be deemed to be our agent. Further, we shall not be liable to you or any third party for failure to execute any transfer or perform a related act if such a failure is due to causes or conditions beyond our reasonable control, including without limitation, strikes, riots, insurrection, war, military, or national emergencies, acts of God, natural disasters, fire, outages of computers or associated equipment, or failure of transportation or communication methods or power supplies. <strong>Except as may be limited by applicable law, you agree to indemnify and hold Bank of America and officers, directors, employees and representatives harmless (including payment of reasonable attorney's fees) against any and all liability to third parties arising out of, or in connection with, this Agreement, the Transfers Outside Bank of America Service or any actions taken by Bank of America pursuant to your instructions.</strong></li>
<li>For each transfer, we will e-mail a confirmation to you at the e-mail address indicated in our records. The confirmation will note the date and the amount of the transfer and the bank or institution to or from which the transfer was made. You agree to examine the confirmation promptly upon receipt and to notify us immediately of any discrepancy between the confirmation and your records. Bank of America shall not be liable for interest compensation, as otherwise set forth in this Agreement, unless Bank of America is notified of the discrepancy within 30 days from the date of your receipt of the confirmation or your bank statement including the transfer, whichever is earlier.</li>
<li>You acknowledge and agree that if a payment order relating to a transfer describes a beneficiary inconsistently by name and account number, payment might be made by the beneficiary's bank on the basis of the account number, even if it identifies a person different from the named beneficiary, and that your obligation to pay the transfer issued by you to us shall not be excused by such payment.</li>
<li>Bank of America may at its option accept your cancellations or amendments to a transfer. You acknowledge that if Bank of America attempts to cancel or amend a transfer, then the reversal request or amendment must be agreed to by each financial institution which has accepted a payment order related to the transfer at issue before it will be acted upon and you further agree that Bank of America shall have no liability if a cancellation or amendment is not completed. <strong>You agree that you shall indemnify and hold Bank of America and officers, directors, employees, and representatives harmless from and against any and all claims, demands, losses, liabilities, and expenses, including attorney's fees and costs, resulting directly or indirectly from compliance with your cancellation or amendment request</strong><strong>.</strong></li>
</ul>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
		<div class="h-100">
			<h4 id="cat8_topic8">
					H. Special Rules for Remittance Transfers
			</h4>
		</div>
			<p><span style="font-size: 8pt; color: #333333; line-height: 115%; font-family: 'Verdana','sans-serif'; mso-fareast-font-family: 'Times New Roman'; mso-ansi-language: EN-US; mso-fareast-language: EN-US; mso-bidi-language: AR-SA; mso-bidi-font-family: 'Times New Roman';"><strong>The following applies to Remittance Transfers.</strong></span></p>
<ul class="tc-disc">
<li>As described above, a Remittance Transfer is an electronic transfer of funds initiated by a consumer primarily for personal, family or household purposes to a designated recipient in a foreign country.&nbsp;Beginning on the Effective Date, as defined above, federal law provides certain rights and obligations related to Remittance Transfers that may differ from rights and obligations that apply to other types of funds transfers, including disclosure, cancellation and error resolution rights. Your rights with respect to Remittance Transfers will be explained to you in a disclosure provided to you at the time you initiate each Remittance Transfer.</li>
<li>At the time you request a Remittance Transfer, but before your account is debited, you will be shown a pre-payment disclosure that includes the following items in the currency in which the transfer will be funded: (i) your requested transfer amount, (ii) any fees or taxes we impose, (iii) the total amount of the transaction (which is the sum of (i) and (ii) above,) (iv) the exchange rate we will use in the event you tell us that the receiving account is denominated in a foreign currency and you identify such currency. In addition, if you identify the foreign currency in which the transfer is to be received and we are required to disclose fees imposed by third parties, the pre-payment disclosure will also include the following items in such foreign currency: (x) the requested transfer amount, (y) the fees imposed by third parties in connection with the transfer, and (z) the total amount to be received by the recipient (which is the difference between (x) and (y) above.) Please note the recipient may receive less than the total amount disclosed due to foreign taxes and fees charged by the recipient&rsquo;s financial institution for receiving a Remittance Transfer into an account, which are not required to be disclosed.</li>
<li>Once you confirm your acceptance of the Remittance Transfer terms, you will be shown a receipt which includes the items listed above and, in addition, (i) the date the funds will be available to the recipient, (ii) information you provide that identifies the recipient, and (iii) a statement of your rights in the event of an error or if you wish to cancel the transfer, as described below.</li>
<li>Pre-payment disclosures and receipts may be printed directly in Transfers under the Transfer Activity tab in Send Money To/From my accounts at other banks, or To someone else using an account number, within Online Banking.</li>
<li><strong>You are hereby notified that in the event that you provide an incorrect account number or institutional identifying number, and we are not able to recover the funds, you may lose the amount of the payment order.</strong></li>
</ul>
<p><strong><strong>If you think there has been an error or problem with your Remittance Transfer:</strong></strong></p>
<p>Call us at 1.877.337.8357; or, from outside the U.S. call us collect at 302.781.6374.</p>
<p>You can also write to us at:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>
<p>Bank of America, N.A.<br />PO Box 25118<br />Tampa,&nbsp;FL 33622-5118 or</p>
<p>Access <a href="https://www.bankofamerica.com/deposits/manage/faq-wire-transfers.go">www.bankofamerica.com/deposits/manage/faq-wire-transfers</a>.</p>
<p>You must contact us within 180 days of the date we indicated to you that funds would be made available to the recipient. When you do, please tell us:&nbsp;</p>
<ol>
<li>Your name and address or telephone number;&nbsp;</li>
<li>The error or problem with the transfer, and why you believe it is an error or problem;</li>
<li>The name of the person receiving the funds, and if you know it, his or her telephone number or address;</li>
<li>The dollar amount of the transfer; and</li>
<li>The confirmation code or number of the transaction.</li>
</ol>
<p>&nbsp;We will determine whether an error occurred within 90 days after you contact us and we will correct any error promptly. We will tell you the results within three business days after completing our investigation. If we decide that there was no error, we will send you a written explanation. You may ask for copies of any documents we used in our investigation.</p>
<p><strong>What to do if you want to cancel a Remittance Transfer:</strong></p>
<p>You have the right to cancel a Remittance Transfer and obtain a refund of all funds paid to us, including any fees, within 30 minutes of your confirmation of the transfer. The best way to cancel a transfer is to sign in to your account at <a href="https://www.bankofamerica.com/">www.bankofamerica.com</a> and access the Transfer Activity tab by selecting Using a Wire from the Transfers menu. Alternatively, you may call us at 1.877.337.8357, Monday through Friday from 7:00 a.m. to 10:00 p.m., and Saturday and Sunday from 8:00 a.m. to 5:00 p.m., local time. From outside the U.S., call us collect at 302.781.6374. When you contact us, you must provide us with information to help us identify the transfer you wish to cancel, including the amount and location where the funds were sent. We will refund your money within three business days of your request to cancel a transfer as long as the funds have not already been picked up or deposited into a recipient's account.</p>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
		<div class="h-100">
			<h4 id="cat8_topic9">
					I. Additional Rules for International Outbound Transfers
			</h4>
		</div>
			<ul>
<li>Once an international outbound transfer has been sent, or, in the case of Remittance Transfers, after the 30 minute cancellation period has passed, you may request that a transfer be recalled, and we will communicate your request to the beneficiary's bank. If the beneficiary's bank agrees to return the funds to us, then upon confirmation of receipt of funds in our account, we will credit your account at the current Bank of America retail buy rate for that currency that day (see below). Please note that the exchange rate will be different from the original rate applicable to the transfer, which may result in a loss to you. Furthermore, the beneficiary's bank may assess charges for their services, which will be deducted from the amount returned to you. Except for Remittance Transfers that you cancel prior to the end of the 30 minute cancellation period, we will have no liability to you if the beneficiary's bank or foreign beneficiary refuses your request to recall the international wire transfer.</li>
<li>If a transfer is returned by the receiving bank or beneficiary's bank for no fault of ours, we will credit your account at the current Bank of America retail buy rate for the currency that day (see below). Please note that the exchange rate will be different from the original rate applicable to the transfer, which may result in a loss to you. Furthermore, a returning bank and/or beneficiary's bank may assess charges for their services, which will be deducted from the amount returned to you.</li>
<li>The exchange rate that Bank of America will offer you or assign to your transaction is determined by Bank of America based upon market conditions. We consider many factors in setting our exchange rates including without limitation exchange rates charged by other parties, desired rates of return, market risk and credit risk. You acknowledge that exchange rates for retail and commercial transactions, and for transactions effected after regular business hours and on weekends, are different from the exchange rates for large inter-bank transactions effected during the business day as reported in The Wall Street Journal or elsewhere. Exchange rates offered by other dealers, or shown at other sources (including online sources) may be different from Bank of America's rates. We do not accept any liability if our rates are different from rates offered or reported by third parties, or offered by us at a different time, at a different location, for a different transaction amount, or involving a different payment media (banknotes, check, wire transfer etc.) For Remittance Transfers, as of the Effective date defined above, the exchange rate to be applied to the transfer will be set forth in disclosures provided to you for the transfer in accordance with federal law.</li>
</ul>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
	<div class="h-100">
		<h3 id="cat9">
				9. BankAmeriDeals<sup>&reg;</sup>
		</h3>
	</div>
	
		<p><br />BankAmeriDeals ("deals" or "cash back deals" or "offers") are provided pursuant to these terms and conditions and any operating rules or policies that may be published by Bank of America (including its Privacy Notice), as may be amended from time to time. BankAmeriDeals provide you with the opportunity to earn cash back with deals based on your use of your eligible Bank of America accounts. If you are a customer who has a U.S. address listed as your primary residence in your Online Banking profile, has an eligible debit or credit card and meets the BankAmeriDeals other eligibility requirements, the deals recommended for you will appear in your Account Detail transaction list in Online Banking and on the Cash Back Deals tab in Online Banking or on the Deals tab in the Bank of America Mobile Banking App. We try to match deals to the places you've shopped or to similar places that might interest you. We do not share individually identifiable information with merchants as part of BankAmeriDeals, and we offer you the opportunity to hide or opt out of receiving these cash back deals. As always, we will only use personally identifiable information in accordance with our <a href="https://www.bankofamerica.com/privacy/Control.do?body=privacysecur_onlin" title="www.bankofamerica.com" name="www.bankofamerica.com">Online Privacy Notice</a> and <a href="https://www.bankofamerica.com/privacy/Control.do?body=privacysecur_cnsmr" title="www.bankofamerica.com" name="www.bankofamerica.com">U.S. Consumer Privacy Notice.</a></p>
<p>We reserve the right to amend, cancel, change, discontinue, or suspend BankAmeriDeals, in whole or in part, at any time in our discretion with or without notice to you, and any such action shall be effective as of the time we determine. However, in all instances, we will provide cash back in accordance with the terms of this Section (BankAmeriDeals) for all deals redeemed prior to the action.</p>
		<div class="h-100">
			<h4 id="cat9_topic1">
					A. Redeeming BankAmeriDeals
			</h4>
		</div>
			<p><br />In order to redeem a cash back deal you must first click on the deal to load it to your eligible Bank of America credit and debit cards and then complete the transaction using one of those cards. The amount of cash back and any specific terms and conditions related to a particular deal will be included in the deals details . However, cash back will not be earned for any portion of your purchase that you pay for with store credit, gift certificates or other payment types. Additionally, transactions must be made directly with the merchant to earn the cash back; you may not receive cash back in connection with a deal if your transaction is made using an electronic wallet where the identity of the merchant is not passed to us as part of the transaction.<br /><br />Cash back you earn will be posted into the account designated as your cash back account ("Designated Account") on the <strong>Preferences</strong> tab in the Cash Back Deals section of Online Banking or under <strong>BankAmeriDeals</strong> in <strong>Settings</strong> in the Mobile Banking App. You may change the Designated Account to another eligible account at any time by clicking the <strong>Change account</strong> link in Online Banking or tapping the <strong>Cash Back Account</strong> button in the Mobile Banking App. (An account will be auto-populated at random&nbsp;as the default account to receive your BankAmeriDeals cash back unless you access the <strong>Preferences</strong> or <strong>Settings</strong> tab and select another account. This could mean that cash back earned through use of a business card might be deposited into your consumer account as the default, for example.)<br /><br />Cash back from the BankAmeriDeals you redeem in a given month will appear as transaction(s) on the Account Details page for your Designated Account and will appear in your Earnings Summary in the Mobile Banking App. Your BankAmeriDeals cash back will typically be credited to your account within 30 days after you redeem the deal. For example, any deals you redeem in the month of December should be credited to your account by the end of January. Since we don't share your personal information with merchants as part of BankAmeriDeals, we cannot post the cash back reward to your account immediately at the time of purchase and there may be a delay for your cash back reward to show&nbsp;to be paid&nbsp;on the <strong>Cash Back Deals Earned</strong> tab in Online Banking or in the<strong> Earnings Summary</strong> in the Mobile Banking App. If you would like to see the BankAmeriDeals you have redeemed or the total value of the deals you have redeemed to date, please visit the <strong>Earned</strong> tab in Online Banking or the <strong>Earnings Summary</strong> in the Mobile Banking App.<br /><br />Cash back posted to a credit card account will not be posted as a payment. It will be posted as a statement credit and is not a substitute for a payment. You must continue to make your minimum monthly payment shown on your billing statement.<br /><br />Your Designated Account must be open in order to receive BankAmeriDeals cash payments. If your Designated Account is closed but you have other open eligible cards/accounts, we reserve the right to select an alternative Designated Account for you. You can go to the <strong>Preferences</strong> tab in Online Banking or to <strong>BankAmeriDeals</strong> in <strong>Settings</strong> in the Mobile Banking App to update or change your Designated Account. If all of your eligible cards/accounts are closed by you or us, you forfeit any BankAmeriDeals cash payments that you have not yet been awarded.</p>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
		<div class="h-100">
			<h4 id="cat9_topic2">
					B. Eligible Cards
			</h4>
		</div>
			<p><br />Only Bank of America credit or debit cards associated with certain accounts are eligible for use with BankAmeriDeals. ATM-only cards are not eligible for this Program. Only accounts linked to your unique Online Banking ID will be listed as eligible accounts on the BankAmeriDeals Preference tab. Accounts that are linked to two different Online Banking User ID profiles (such as jointly owned credit card accounts) will be listed for both account holders' Online Banking profiles. Each joint owner of an eligible account will be able to view deals in Online Banking. If you are an authorized user on a credit card account, and not a co-owner, that credit card account will not appear as an eligible account under your Online Banking ID profile.<br />Please note: Some checking accounts may be listed under "Eligible cards," but if the account does not have an associated debit card, it cannot be used in the Program, except to receive cash back. You must make a purchase with an eligible debit or credit card to earn cash back from BankAmeriDeals.</p>
<p>Please visit the<strong> Cash Back Deals Preferences</strong> tab in Online Banking or the Eligible Credit/Debit Cards button in BankAmeriDeals Settings in the Mobile Banking App to review the list of currently eligible cards.<br />Certain cards are not eligible for BankAmeriDeals. Bank customers with only the following card and account types are not eligible to participate in BankAmeriDeals. This list is subject to change without prior notice:</p>
<ul class="tc-disc">
<li>ATM-only cards</li>
<li>Credit Purchasing Card (P-Card), Travel/Corporate Card, Fleet Card</li>
<li>Prepaid Payroll &amp; Incentive Card</li>
<li>All healthcare account products - HSA/FSA Health Reimbursement/Flexible Spending</li>
<li>HELOC - Home Equity Line of Credit accounts</li>
<li>Merrill Lynch CMA deferred debit cards</li>
<li>AAA credit cards</li>
</ul>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
		<div class="h-100">
			<h4 id="cat9_topic3">
					C. Participating Retailers
			</h4>
		</div>
			<p><br />When redeeming a BankAmeriDeal, please refer to the retailer's terms and conditions related to the purchase, including but not limited to, guarantees, warranties, payment terms, shipping, delivery, taxes, return policies and processing of returns. The retailers are solely responsible for the content and offerings presented on their websites. We make no warranties and disclaim responsibility for fulfillment of the transaction between you and a participating retailer and, we disclaim any responsibility for the policy positions or business practices of any participating retailer. When redeeming your deals online, please remember that the participating retailers operate their websites with different privacy practices. You should review each retailer's website privacy policy, as we have no control over information that is submitted by you to these third parties.<br /><br />All returns must be made through the retailer. We are not responsible for any returns, and all questions about purchases or returns should be directed to the retailer.</p>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
		<div class="h-100">
			<h4 id="cat9_topic4">
					D. Hiding or Opting Out of Receiving BankAmeriDeals
			</h4>
		</div>
			<p>To hide BankAmeriDeals in your Online Banking Account Details list, you can click the <strong>Hide deals</strong> link at the top of the Account Details page or go to the Hide/Show deals section on the <strong>Preferences tab</strong> and select the <strong>Hide deals on my Account Details</strong> link. You will be able to view deals on the Cash Back Deals section in Online Banking and on the Deals tab in the Mobile Banking App. To return to viewing deals in your Accounts Details list, either click the &lsquo;Show Deals&rsquo; link on the Account Details page or go to the Hide/Show deals section on the <strong>Preferences tab</strong> and select the <strong>Show deals on my Account Details</strong> link.</p>
<p>You can opt to stop receiving BankAmeriDeals. In Online Banking go to the <strong>Opt out of BankAmeriDeals</strong> offers section on the <strong>Preferences</strong> tab and select the <strong>Opt out of BankAmeriDeals offers</strong> link.In the mobile banking App go to <strong>Settings &gt; BankAmeriDeals<sup>TM</sup> &gt; Opt Out of Deals</strong>, and confirm that you do want to stop receiving new deals. If you opt out, you will no longer be able to view deals in your accounts details list on the Cash Back Deals page in Online Banking or on the Deals tab in the Mobile Banking App. You will still be able to redeem any deals you have already loaded to your cards and continue to view your redemption history. To opt back in to receiving BankAmeriDeals: in Online Banking, go to the <strong>Cash Back Deals</strong> tab and click the <strong>Opt in to start receiving BankAmeriDeals</strong> link; in the Mobile Banking App, go to <strong>Deals &gt; Opt in to Deals</strong>.</p>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
		<div class="h-100">
			<h4 id="cat9_topic5">
					E. Reporting an Error in the Cash Back Amount
			</h4>
		</div>
			<p><br />If you wish to dispute the amount of cash back posted to your Designated Account in connection with BankAmeriDeals, please call the number listed on the back of your eligible debit or credit card.</p>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
	<div class="h-100">
		<h3 id="cat10">
				10. My Portfolio Service (Not available through Mobile Banking Apps or Mobile Web)
		</h3>
	</div>
	
		<div class="h-100">
			<h4 id="cat10_topic1">
					A. Relationship to Other Agreements
			</h4>
		</div>
			<p><br />You may use My Portfolio to access services offered by Bank of America, its affiliates, or third parties not affiliated with Bank of America. You agree that when you use these services, you will be subject to any terms and conditions established by those third parties, including Bank of America, its affiliates or unaffiliated service providers, and that this Agreement does not amend any of those terms and conditions. You agree that only the third parties are responsible for such services, and if you have any problems with these third parties, you should contact them directly. Any service offered by Bank of America or any of its affiliates will display the name of the Bank or the affiliate and the Bank of America logo on the webpage.</p>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
		<div class="h-100">
			<h4 id="cat10_topic2">
					B. Description of My Portfolio
			</h4>
		</div>
			<p><br />My Portfolio is a personal information management service that allows you to better manage your information by consolidating it in one place. My Portfolio uses proprietary technology to allow you to retrieve, view, and maintain information you have available at various web sites you designate, but all within one convenient service. All of the accounts linked to your Access ID through Online Banking from Bank of America are automatically added to My Portfolio.</p>
<p>You may add information about accounts accessible at other web sites that you maintain at other institutions, including Merrill Lynch, Pierce, Fenner &amp; Smith Incorporated. When you use My Portfolio to access a third party web site you designate, you agree to the following: 1)You authorized Bank of America and its providers to access the third party web sites and accounts you designate to retrieve account information on your behalf, and you appoint us as your agent for this limited purpose. In addition, you hereby grant Bank of America and its providers as your true and lawful attorney-in-fact, with full power of substitution and resubstitution, for you and in your name, place and stead, in any and all capacities, to access third party web sites, retrieve account information, and use your information, for the purpose of accessing your accounts and operating My Portfolio, with full power and authority to do and perform each and every act and thing requisite and necessary to be done in connection with such activities, as fully to all intents and purposes as you might or could do in person. 2)You represent that you are a legal owner of the accounts at third party web sites which you include in My Portfolio and that you have the authority to (i) designate us as your agent, (ii) use My Portfolio and (iii) give us your passwords, usernames, and all other information you provide. 3)YOU AGREE AND ACKNOWLEDGE THAT WHEN WE ACCESS AND RETRIEVE INFORMATION FROM THE THIRD PARTY WEB SITE, WE ACT AS YOUR AGENTS, AND NOT THE AGENTS OR ON BEHALF OF THE THIRD PARTY. 4)My Portfolio does not have the capability to initiate transactions affecting your financial accounts or provide notices or instructions affecting such financial accounts. When you access a third party web site through My Portfolio, you open a new browser window to directly connect you to the third party web site and submit information you have designated to allow further access to that site. Transactions and inquiries you initiate at such a site are not made through My Portfolio, and we have no responsibility for such transactions. You are responsible for all fees charged by the third party in connection with such transactions and accounts, and you agree to comply with the terms and conditions of those accounts. If you have a dispute or question about any transaction on such site, you agree to direct these to the account provider. 5)Third party web sites shall be entitle to rely on the above authorizations, agency and power of attorney granted by you. 6)My Portfolio is not sponsored or endorsed by any providers of the third party accounts you access through My Portfolio, except for affiliates of Bank of America. 7)Balances shown on My Portfolio reflect the most recent refresh and may not be accurate if a refresh was not successfully completed or the information obtained during the refresh from the third party is otherwise not accurate or current. <strong>Data and information is provided for informational purposes only, and is not intended for trading or transactional purposes.</strong> You agree that we are not liable for any errors or delays in the content, or for any actions taken in reliance thereon. The services which you may be able to access through My Portfolio are services of the listed institutions. My Portfolio provides links to selected institutions for your convenience only. We do not endorse or recommend the services of any institution. The third party institution you select is solely responsible for its services to you. We are not liable for any damages or costs of any type arising out of or in any way connected with your use of the services of the institution. 8)You may also add information into My Portfolio for accounts not available at other web sites or which are not linked to My Portfolio. In such case, you are solely responsible for the accuracy of such information.</p>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
		<div class="h-100">
			<h4 id="cat10_topic3">
					C. Description of Real Estate Center
			</h4>
		</div>
			<p><br />You may use the Real Estate Center feature in My Portfolio to add a home value estimate to the profile of your assets and net worth. You may opt to have your home value estimate automatically generated and updated. By electing to automatically update your home value estimate you agree to receive a computer-generated estimate of the worth of the property, called a Zestimate&reg;, provided by Zillow, Inc., a third-party online real estate service, and you authorize Bank of America and its service providers to access Zillow.com and retrieve Zestimates on your behalf. You agree that a Zestimate is not an appraisal and should not be used as a substitute for an appraisal, and that the actual value of the property may vary. Zillow is not affiliated with Bank of America N.A. or any of its affiliates. Bank of America and its service providers provide access to Zillow and Zestimates for your convenience only and do not endorse or recommend Zillow, the Zestimate or any other services provided by Zillow and you agree that neither Bank of America nor its service providers are responsible for the accuracy of the Zestimates or other information provided by Zillow or liable for any damages or costs of any type arising out of or in any way connected with your use of the Zestimate or other services provided by Zillow. You agree that you will use the Zillow services only for your personal use. If you elect to include the Zestimate in your net worth summary, you acknowledge and agree that the net worth summary is calculated based on information provided by you or third parties at your direction and that Bank of America makes no representation as to the accuracy of the net worth summary. <strong>Data and information provided in the Real Estate Center feature is for informational purposes only, and is not intended for transactional purposes.</strong> You agree that we are not liable for any errors or delays in the content, or for any actions taken in reliance thereon.</p>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
		<div class="h-100">
			<h4 id="cat10_topic4">
					D. Provide Accurate Information
			</h4>
		</div>
			<p><br />You represent and agree that all information you provide to us in connection with My Portfolio is accurate, current and complete, and that you have the right to provide such information to us for the purpose of operating My Portfolio. You agree to not misrepresent your identity or your account information. You agree to keep your account information up to date and accurate.</p>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
		<div class="h-100">
			<h4 id="cat10_topic5">
					E. Proprietary Rights
			</h4>
		</div>
			<p><br />You are permitted to use content delivered to you through My Portfolio only on My Portfolio. You may not copy, reproduce, distribute, or create derivative works from this content. Further, you agree not to reverse engineer or reverse compile any of My Portfolio technology, including but not limited to, any Java applets associated with My Portfolio.</p>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
		<div class="h-100">
			<h4 id="cat10_topic6">
					F. User Conduct
			</h4>
		</div>
			<p><br />You agree not to use My Portfolio or the content or information delivered through My Portfolio in any way that would: (a) infringe any third-party copyright, patent, trademark, trade secret, or other proprietary rights or rights of publicity or privacy; (b) be fraudulent or involve the sale of counterfeit or stolen items, including but not limited to use of My Portfolio to impersonate another person or entity; (c) violate any law, statute, ordinance or regulation (including without limitation those governing export control, consumer protection, unfair competition, anti-discrimination or false advertising); (d) be false, misleading or inaccurate; (e) create liability for Bank of America or its affiliates or cause us to lose (in whole or in part) the services of our third-party provider; (f) be defamatory, trade libelous, unlawfully threatening or unlawfully harassing; (g) may potentially be perceived as being obscene or pornographic or contain child pornography, or racially, ethnically, or otherwise objectionable; (h) interfere with or disrupt computer networks connected to My Portfolio; (i) interfere with or disrupt the use of My Portfolio by any other user; (j) access the information and content manually by request and not programmatically by macro or other automated means; or (k) use My Portfolio in such a manner as to gain unauthorized entry or access to the computer systems.</p>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
		<div class="h-100">
			<h4 id="cat10_topic7">
					G. Restriction on Commercial Use or Resale
			</h4>
		</div>
			<p><br />You agree not to resell or make any commercial use of the services in My Portfolio.</p>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
		<div class="h-100">
			<h4 id="cat10_topic8">
					H. Your Indemnification of the Bank
			</h4>
		</div>
			<p><br />Notwithstanding the language in Section 5 of this Online Banking Services Agreement, when you use My Portfolio, unless caused by our intentional misconduct or gross negligence, you agree to protect and fully compensate Bank of America and our service providers and affiliates from any and all third party claims, liability, damages, expenses and costs (including, but not limited to, reasonable attorneys fees) caused by or arising from your use of My Portfolio, your violation of this Agreement or your infringement, or infringement by any other user of your account, of any intellectual property or other right of anyone.</p>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
		<div class="h-100">
			<h4 id="cat10_topic9">
					I. My Portfolio Service Limitations
			</h4>
		</div>
			<p><br />We want to make your use of My Portfolio easy and productive, but we cannot always foresee or anticipate technical or other difficulties. These difficulties may result in loss of data, personalization settings or other My Portfolio interruptions. Notwithstanding the language in Section 5 of this Online Banking Services Agreement, with respect to My Portfolio, we do not assume responsibility for the timeliness, deletion, mis-delivery or failure to store any user data, communications or personalization settings.</p>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
		<div class="h-100">
			<h4 id="cat10_topic10">
					J. Third Party Products and My Portfolio
			</h4>
		</div>
			<p><br />You agree to exercise caution when browsing on the internet and to use good judgment and discretion when obtaining or transmitting information or making purchases. From My Portfolio you may access or be directed to sites containing information or material that may be offensive or inappropriate to some people. We do not endorse and make no effort to review the content of these sites, nor are we responsible for their validity, legality, copyright compliance, or decency of the content contained in these sites. We retain the right (not the obligation) at our sole discretion to prevent access to any site from My Portfolio.</p>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
		<div class="h-100">
			<h4 id="cat10_topic11">
					K. Privacy and My Portfolio
			</h4>
		</div>
			<p><br />Bank of America has a commitment to keeping information about you secure and confidential. Our U.S. Consumer Privacy Notice clearly states our promise to carefully manage information about you and your relationship with our family of companies.</p>
<p>Through the My Portfolio service, you are able to aggregate information about your accounts from sources other than Bank of America or its affiliates so that you may view them in one online location. Bank of America will use this information to help optimize your personal use of this service, and to understand what product or service offers may be most beneficial to you. This information is provided all the protections outlined in our U.S. Consumer Privacy Notice.</p>
<p>In addition to these protections, you may at any time choose to limit our use of information aggregated on My Portfolio from other institutions and accounts. You can select this option by going to the Set Your Privacy Preferences page on our Privacy and Security website at <a href="https://www.bankofamerica.com">www.bankofamerica.com</a>.</p>
<p>For more information on our U.S. Consumer Privacy Notice, you can visit our Privacy and Security website at <a href="https://www.bankofamerica.com/privacy">www.bankofamerica.com/privacy</a>.</p>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
		<div class="h-100">
			<h4 id="cat10_topic12">
					L. Changes or Cancellation
			</h4>
		</div>
			<p><br />Notwithstanding the language in Section 4 and 5 of this Online Banking Services Agreement, you may cancel your participation in My Portfolio by calling us at 1.800.933.6262. We reserve the right to change or cancel My Portfolio at any time without notice. We may also suspend your access to My Portfolio at anytime without notice and for any reason, including but not limited to your non-use of My Portfolio. You agree that we will not be liable to you or any third party for any modification or discontinuance of My Portfolio.</p>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
		<div class="h-100">
			<h4 id="cat10_topic13">
					M. Third Party Beneficiary
			</h4>
		</div>
			<p><br />You agree that our providers may rely upon your authorization and grant of a limited power of attorney, the disclaimer of warranties, and the limitation of liability in My Portfolio Sections 10.B and 10.H, respectively, above, and such providers are, for the purposes of those sections, third party beneficiaries to this agreement, with the power to enforce those provisions as applicable.</p>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
	<div class="h-100">
		<h3 id="cat11">
				11. FICO<sup>&reg;</sup> Score Program for Consumer Credit Card Customers (Not available for all Mobile Banking Apps)
		</h3>
	</div>
	
		<p>The FICO<sup>&reg;</sup> Score Program is provided pursuant to these terms and conditions and the other applicable terms and conditions of this Online Banking Service Agreement, as each may be amended from time to time. The FICO<sup>&reg;</sup> Score Program gives you the opportunity to view your FICO<sup>&reg;</sup> Score 8 (&ldquo;FICO<sup>&reg;</sup> Score&rdquo;) credit score in Online Banking at no charge, along with two key factors affecting that particular FICO<sup>&reg;</sup> Score. FICO is a registered trademark of the Fair Isaac Corporation (&ldquo;Fair Isaac&rdquo;) in the United States and other countries. This FICO<sup>&reg;</sup> Score is solely determined by the information in your file at TransUnion (one of the three major consumer reporting agencies) and is created using Fair Isaac&rsquo;s proprietary model. Your FICO<sup>&reg;</sup> Score may vary from consumer reporting agency to consumer reporting agency and other lenders may use scores from one or more of the other two major consumer reporting agencies. TransUnion and Fair Isaac are third parties not affiliated with Bank of America and Bank of America makes no representation or warranty related to the FICO<sup>&reg;</sup> Score.</p>
<p>Bank of America is providing you access to your FICO<sup>&reg;</sup> Score and related content only for educational purposes and your personal, non-commercial use. Only Bank of America customers with an eligible consumer credit card account (e.g., an open account with active charging privileges) may enroll in the FICO<sup>&reg;</sup> Score Program. At this time, the FICO<sup>&reg;</sup> Score Program is not available through all Bank of America's Downloadable Mobile Banking Applications ("Mobile Banking Apps"). We reserve the right to amend, cancel, change, discontinue, or suspend the FICO<sup>&reg;</sup> Score Program and/or your access to it, in whole or in part, at any time in our discretion with or without notice to you, and any such action shall be effective as of the time we determine.</p>
		<div class="h-100">
			<h4 id="cat11_topic1">
					A. Enrollment in the FICO<sup>&reg;</sup> Score Program
			</h4>
		</div>
			<p>By enrolling in the FICO<sup>&reg;</sup> Score Program, you authorize Bank of America to access your FICO<sup>&reg;</sup> Scores that we may already have based upon our relationships with you and/or to obtain your FICO<sup>&reg;</sup> Score periodically from TransUnion. Once we obtain your FICO<sup>&reg;</sup> Score it will be available to you in Online Banking for your educational and non-commercial use. Viewing your FICO<sup>&reg;</sup> Score as a part of the FICO<sup>&reg;</sup> Score Program will not negatively impact your score.</p>
<p>Your enrollment provides your authorization in writing for us to obtain your credit report under the federal Fair Credit Reporting Act and other applicable law. <strong>If you choose to enroll in the FICO<sup>&reg;</sup> Score Program, please be aware that all of your Online IDs and individuals who have access to your Online Banking profile will be able to view your FICO<sup>&reg;</sup> Score</strong>. You can un-enroll at any time by going to the <strong>Tools and Investing</strong> tab in Online Banking.</p>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
		<div class="h-100">
			<h4 id="cat11_topic2">
					B. Email and Text Notifications
			</h4>
		</div>
			<p>We will send you an email alert when you enroll in the FICO<sup>&reg;</sup> Score Program, when we post your updated FICO<sup>&reg;</sup> Score in Online Banking (typically once a month and for accounts in good standing), and if you unenroll in the FICO<sup>&reg;</sup> Score Program. Text messaging alerts will not be sent automatically when we post your FICO<sup>&reg;</sup> Score, but you can enable them by adjusting your alert settings in Online Banking. You may turn off the monthly FICO<sup>&reg;</sup> Score email and text alert at any time by changing your alert settings in Online Banking.</p>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
		<div class="h-100">
			<h4 id="cat11_topic3">
					C. FICO<sup>&reg;</sup> Score Display
			</h4>
		</div>
			<p>You will be able to view up to a 12-month history of your FICO<sup>&reg;</sup> Scores in Online Banking, starting when you enroll and for each month up to 12 months. Additionally, you will see two key factors affecting your most recent FICO<sup>&reg;</sup> Score, except in limited circumstances where TransUnion does not provide us with both key factors. Customers with newly opened credit card accounts may not see their first FICO<sup>&reg;</sup> Score in Online Banking for up to 60 days after enrollment. In certain circumstances, a FICO<sup>&reg;</sup> Score may not be available from TransUnion for various reasons, e.g., having a limited credit history. If your Bank of America consumer credit card account(s) are closed by you or us, we reserve the right to end your participation in the FICO<sup>&reg;</sup> Score Program. You can unenroll at any time by going to the <strong>Tools and Investing</strong> tab in Online Banking. If you opt out of the FICO<sup>&reg;</sup> Score Program, your FICO<sup>&reg;</sup> Score and FICO<sup>&reg;</sup> Score history will no longer be available for viewing in Online Banking. If you decide to re-enroll, your FICO<sup>&reg;</sup> Score history display in Online Banking will start anew and you will not have access to view previous history through the FICO<sup>&reg;</sup> Score Program.</p>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
		<div class="h-100">
			<h4 id="cat11_topic4">
					D. Eligibility
			</h4>
		</div>
			<p>Only Bank of America customers with an eligible consumer credit card account (e.g., an open account with active charging privileges) may enroll in the FICO<sup>&reg;</sup> Score Program. At this time, the FICO<sup>&reg;</sup> Score Program is not yet available through all&nbsp;Mobile Banking Apps. Customers with jointly owned credit card accounts who have their own Online ID will be able to view their own individual FICO<sup>&reg;</sup> Score by logging into Online Banking with their respective Online ID. If you are an authorized user on a credit card account, and are not an owner or a co-owner of another consumer credit card account, then you are not eligible to participate in the FICO<sup>&reg;</sup> Score Program. Additionally, if we cancel the FICO<sup>&reg;</sup> Score Program, you decide to unenroll, or you become ineligible, for example due to a change in account status, your FICO<sup>&reg;</sup> Score and past FICO<sup>&reg;</sup> Scores will not be viewable in Online Banking as part of the FICO<sup>&reg;</sup> Score Program.</p>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
		<div class="h-100">
			<h4 id="cat11_topic5">
					E. About TransUnion and FICO<sup>&reg;</sup> Scores
			</h4>
		</div>
			<p>TransUnion is one of three major consumer reporting agencies who provides consumer credit reports and credit scores to businesses and consumers. FICO<sup>&reg;</sup> Scores from TransUnion are useful information to help you understand your credit profile. The FICO<sup>&reg;</sup> Score based on TransUnion data is created using Fair Isaac&rsquo;s proprietary model and is solely determined by the information in your file at TransUnion at the time your FICO<sup>&reg;</sup> Score is calculated. Accounts not reported to or subsequently deleted from your file at TransUnion may not be reflected in your FICO<sup>&reg;</sup> Score. Your FICO<sup>&reg;</sup> Score may vary from consumer reporting agency to consumer reporting agency and other lenders may use scores from one or more of the other two major consumer reporting agencies. TransUnion and Fair Isaac are third parties not affiliated with Bank of America and Bank of America makes no representation or warranty related to the FICO<sup>&reg;</sup> Score.</p>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
		<div class="h-100">
			<h4 id="cat11_topic6">
					F. Bank of America is Not a Credit Repair Organization
			</h4>
		</div>
			<p>Bank of America and Fair Isaac are not credit repair organizations as defined under federal or state law, including the Credit Repair Organizations Act. Bank of America and Fair Isaac do not provide &ldquo;credit repair&rdquo; services or advice or assistance regarding "rebuilding" or "improving" your credit record, credit history or credit rating. We provide your FICO<sup>&reg;</sup> Score and content related to the FICO<sup>&reg;</sup> Score Program in Online Banking only for educational purposes and your non-commercial, personal use. We can provide no further assistance regarding improving your credit score except for addressing any disputes you may have regarding accounts you have with Bank of America.</p>
<p><strong>FICO is a registered trademark of the Fair Isaac Corporation in the United States and other countries.</strong></p>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
	<div class="h-100">
		<h3 id="cat12">
				12. Additional Services (Not available through Mobile Banking Apps or Mobile Web)
		</h3>
	</div>
	
		<p>The following addendum will apply if you register for any of these additional services.</p>
<p><span style="font-size: 10pt; line-height: 115%; font-family: 'Arial','sans-serif'; mso-fareast-font-family: Calibri; mso-bidi-font-size: 11.0pt; mso-fareast-theme-font: minor-latin; mso-ansi-language: EN-US; mso-fareast-language: EN-US; mso-bidi-language: AR-SA;"><span style="font-family: Verdana;"><a href="https://www.bankofamerica.com/onlinebanking/online_business_suite_addendum.go?request_locale=en_US" name="onlinebusiness_site_addendum" target="_blank">Online Business Suite Addendum </a></span></span></p>
		<div class="h-100">
			<h4 id="cat12_topic1">
			</h4>
		</div>
        <div class="back-to-top-link"> 
        	<a href="#back-to-top-anchor">Back to top</a> 
        </div>
</div>
</div>
</div>




 

			<div id="InterstitialModalComSkin" class="interstitial-module interstitial-module-com-skin im-cs com-main-well-content hide" data-component="module" data-module="interstitial" data-skin="com">
				<div class="com-content-section">
					<h3 data-font="cnx-regular" class="info-icon">Continuar en ingl�s</h3>
					<p>La informaci&oacute;n que se encuentra a continuaci&oacute;n est&aacute; disponible s&oacute;lo en ingl&eacute;s en la actualidad.</p>
<p>Las solicitudes y los documentos asociados con productos y servicios espec&iacute;ficos podr&iacute;an estar disponibles s&oacute;lo en ingl&eacute;s. Antes de escoger un producto, por favor aseg&uacute;rese de haber le&iacute;do y entendido todos los t&eacute;rminos y condiciones provistas.</p>
					<div class="button-container mtop-10">
								<a href="/online-banking/text-banking.go?request_locale=en_US" name="Continuar en ingl�s" class="btn-bofa btn-bofa-small btn-bofa-blue continue-button">Continuar en ingl�s</a>
								<a href="javascript:void(0)" name="Cancelar" class="btn-bofa btn-bofa-small cancel-button">Cancelar</a>
					</div>	
					<div class="checkbox-input-row mbtm-10">
						<input id="dontshowintl" type="checkbox"/><label for="dontshowintl">No mostrar esta notificacion</label>
						<div class="clearboth"></div>
					</div>	
				</div>
			</div>
		<script>
			boaInterestialModal.init();
		</script>	
</div>
						<div class="flex-col rt-col" ></div>
						<div class="clearboth"></div>
					</div>
					<div class="footer">
						<div class="footer-top">&nbsp;</div>
						<div class="footer-inner">
<div class="disclaimers-module">
	<div class="fsd-skin sup-ie">
			<p>Some accounts and services, and the fees that apply to them, vary from state to state. Please review the information for your state in the Personal Schedule of Fees (at          <a href="http://www.bankofamerica.com/feesataglance" target="_self">www.bankofamerica.com/feesataglance</a> or at your local Banking Center) and in the Online Banking Service Agreement at <a href="http://www.bankofamerica.com/serviceagreement" target="_self">www.bankofamerica.com/serviceagreement</a>.</p>
	</div>
</div>




 



		<div class="global-footer-module">
			<div class="fsd-skin">

				<div class="footer-bottom-left" style="float:left;max-width:66%;">
	    			<div class="gf-links">	          	
						
					
									
									<a  target="_self" href="/" 
									    name="Home">Home
									</a>
									
						
					
									
									<a  target="_self" href="/privacy/overview.go" 
									    name="Privacy and Security">Privacy & Security
									</a>
									
						
					
									
									<a  target="_self" href="http://careers.bankofamerica.com/careershome.aspx" 
									    name="Careers">Careers
									</a>
									
						
					
									
									<a  target="_self" href="/sitemap/personal.go" 
									    name="Site Map">Site Map
									</a>
									
						
					
									<a href="javascript:void(0);" class="gf-last-link boa-dialog boa-com-info-layer-link" name="global_footer_ad_practices_lnk" rel="global_footer_ad_practices">Advertising Practices</a>
								<div id="global_footer_ad_practices" class="hide">
									<h3>Advertising Practices</h3>
										<p>We strive to provide you with information about products and services you might find interesting and useful. Relationship-based ads and online behavioral advertising help us do that.</p>
<p>Here's how it works: We gather information about your online activities, such as the searches you conduct on our Sites and the pages you visit. This information may be used to deliver advertising on our Sites and offline (for example, by phone, email and direct mail) that's customized to meet specific interests you may have.</p>
<p>If you prefer that we do not use this information, you may <a onclick="$('.ui-dialog').remove();" name="WebsiteAdPractices_OptOut" href="/privacy/online-privacy-notice.go#advertising-on-our-sites" target="_blank">opt out of online behavioral advertising</a>. If you opt out, though, you may still receive generic advertising. In addition, financial advisors/Client Managers may continue to use information collected online to provide product and service information in accordance with account agreements.</p>
<p>Also, if you opt out of online behavioral advertising, you may still see ads when you sign in to your account, for example through Online Banking or MyMerrill. These ads are based on your specific account relationships with us.</p>
<p>To learn more about relationship-based ads, online behavioral advertising and our privacy practices, please review the <a onclick="$('.ui-dialog').remove();" name="WebsiteAdPractices_PrivacyNotice" href="/privacy/online-privacy-notice.go" target="_blank">Bank of America Online Privacy Notice</a> and our <a onclick="$('.ui-dialog').remove();" name="Online-privacy-faqs" href="/privacy/faq/online-privacy-faq.go" target="_blank">Online Privacy FAQs</a>.</p>
								</div>
						<div class="clearboth"></div>
	    			</div>
	      			<p>Bank of America, N.A. Member FDIC. <a name="Equal_Housing_Lender" href="/help/equalhousing_popup.go" target="_blank">Equal Housing Lender<img src="https://www2.bac-assets.com/content/images/ContextualSiteGraphics/Logos/en_US/icon_equal_housing_lender.gif" alt="" width="14" height="9" /></a> <br />&copy; 2017 Bank of America Corporation. All rights reserved.</p>
         		</div>
         		<div class="footer-social-container" style="float:right;max-width:30%;padding-left:50px;padding-top:19px;">




<div class="boa-social-loader" data-loaded="false" data-platform="borneo"  data-options=''></div>

         		</div>
         		<div class="clearboth"></div>
  			</div>
		</div>




 
</div>
					</div>
				</div>
			</div>
		</div>
	</body>	
</html>

